# One zone-redundant NAT gateway with a static public IP, plus the subnet associations.
#
# This is how the connectors reach the internet. The load balancer runs with outbound
# SNAT disabled, so without this they have no egress at all.
#
# StandardV2 spans every availability zone in the region on its own, so one gateway
# survives losing a zone. That is why there is one here rather than one per zone - and
# why neither resource sets `zones`, which would pin them to a single one.
#
# One gateway also means one public IP to allowlist in the Zscaler portal.

resource "azurerm_public_ip" "natgw" {
  name                = local.pip_name
  location            = var.location
  resource_group_name = var.resource_group_name
  # Must match the gateway's SKU - a StandardV2 gateway will not accept a Standard IP.
  sku               = "StandardV2"
  allocation_method = "Static"
  tags              = var.tags
}

resource "azurerm_nat_gateway" "zscc" {
  name                = local.natgw_name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku_name            = "StandardV2"
  # Ten minutes, matching Zscaler's module rather than Azure's four-minute default. A
  # connector holds long-lived tunnels to the Zscaler cloud, and at four minutes a quiet
  # tunnel loses its SNAT port and drops. That shows up as connectors reconnecting during
  # low-traffic periods rather than as anything obviously broken.
  idle_timeout_in_minutes = 10
  tags                    = var.tags
}

resource "azurerm_nat_gateway_public_ip_association" "zscc" {
  nat_gateway_id       = azurerm_nat_gateway.zscc.id
  public_ip_address_id = azurerm_public_ip.natgw.id
}

# A gateway can serve several subnets; a subnet can only have one gateway.
resource "azurerm_subnet_nat_gateway_association" "mgmt" {
  subnet_id      = var.mgmt_subnet_id
  nat_gateway_id = azurerm_nat_gateway.zscc.id
}

resource "azurerm_subnet_nat_gateway_association" "service" {
  subnet_id      = var.service_subnet_id
  nat_gateway_id = azurerm_nat_gateway.zscc.id
}

resource "azurerm_subnet_nat_gateway_association" "funcapp" {
  subnet_id      = var.funcapp_subnet_id
  nat_gateway_id = azurerm_nat_gateway.zscc.id
}
