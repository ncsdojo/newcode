@{
    RootModule        = 'ZscalerCloudConnector.psm1'
    ModuleVersion     = '5.4.1.0'
    GUID              = 'f7a3c1d2-8b4e-4f5a-9c6d-1e2f3a4b5c6d'
    Author            = 'NCS Dojo'
    CompanyName       = 'NCS Dojo'
    Copyright         = 'Copyright (c) 2026 NCS Dojo. Licensed under the MIT License.'
    Description       = 'Deploys Zscaler Cloud Connector on Azure via raw ARM REST API. SecureString secrets, ShouldProcess on mutations, idempotent, parallel-capable, greenfield/brownfield. Zero external dependencies.'
    PowerShellVersion = '7.0'
    CompatiblePSEditions = @('Core')

    # Zero external module dependencies by design (raw ARM REST, no Az modules).
    RequiredModules   = @()

    FunctionsToExport = @(
        'Connect-ZscalerAzure','Connect-ZscalerCloud','Disconnect-ZscalerAzure','Disconnect-ZscalerCloud'
        'New-ZsResourceGroup','New-ZsNetworkSecurity','New-ZsNetworkFoundation'
        'New-ZsPublicNetwork','New-ZsPrivateNetwork','New-ZsVnetPeering'
        'New-ZsIdentity','New-ZsKeyVault','New-ZsLifecycleFunctionApp','New-ZsLoadBalancer'
        'Approve-ZsMarketplaceTerms','New-ZsCloudConnector','New-ZsCloudConnectorVmss','New-ZsDnsResolver'
        'New-ZsProvisioningUrl','New-ZsSshKey'
        'New-ZsDeploymentConfig','Export-ZsDeploymentConfig'
        'New-ZsDeployment','Remove-ZsDeployment','Reset-ZsConnectors'
        'Test-ZsAccess','Test-ZsPrerequisites','Test-ZsDeployment','Get-ZsDeploymentManifest','Compare-ZsDeployment','Get-ZsUsableZones'
        'Set-ZsDefenderPlans','New-ZsDiagnostics','Get-ZsCapacityPlan','New-ZsBastion','New-ZsMonitorAlerts','New-ZsMonitorPrivateLink'
    )
    CmdletsToExport   = @()
    VariablesToExport  = @()
    AliasesToExport    = @()

    PrivateData = @{
        PSData = @{
            Tags         = @('Zscaler','Azure','CloudConnector','ZeroTrust','IaC','ARM','REST')
            License      = 'MIT'
            ReleaseNotes = '5.4.1.0 - Brownfield reaches Terraform parity for existing networks: the VNet and its subnets are named (VnetName, VnetResourceGroupName, VnetSubscriptionId, *SubnetName) exactly as the Terraform variables name them, with resource IDs still accepted; NSGs are created by the module and associated onto the existing management and service subnets when none are supplied; an existing delegated Function App subnet is used when named; Bastion deploys into an existing AzureBastionSubnet; NAT gateway and route table associate by subnet ID (fixing a doubled-endpoint URL on the brownfield route-table association); the brought VNet and subnets are recorded pre-existing so teardown detaches and never deletes them. See CHANGELOG.md. Previous: 5.3.0.11 - Health remediation refuses to act on a fleet-wide verdict or on an absence of metric data, so a fault in the health signal no longer drains the fleet; scale set capacity restore polls for the decrement rather than sleeping; -AllowNotFound returns null on a confirmed 404 as documented, and Test-ArmResource and Compare-ZsDeployment report absence correctly; token acquisition, blob transport and the Cloud Connector API all retry transient failures; NSG rules accept more than one workload CIDR; address validation rejects host bits and undersized subnets in preflight; the Key Vault secret-write window is scoped to the deployer address; ERROR and FATAL reach the error stream; -BreakStateLock requires evidence the holder is gone. See CHANGELOG.md. Licensed under the MIT License.'
        }
    }
}
