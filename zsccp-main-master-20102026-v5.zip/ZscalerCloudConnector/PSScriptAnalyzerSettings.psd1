@{
    # PSScriptAnalyzer configuration for the ZscalerCloudConnector module.
    # Run: Invoke-ScriptAnalyzer -Path . -Recurse -Settings ./PSScriptAnalyzerSettings.psd1

    Severity = @('Error', 'Warning')

    IncludeDefaultRules = $true

    # Rules intentionally excluded, with the reason:
    ExcludeRules = @(
        # The module deliberately converts SecureString to plaintext at the point of use
        # (BSTR marshalling with ZeroFreeBSTR) because the Zscaler legacy API and ARM REST
        # calls require plaintext in the request body. The unmanaged BSTR is zeroed; the
        # managed string it produces is immutable and cannot be, so what is actually bounded
        # is its lifetime — references are dropped as soon as the call completes. A blanket
        # ban on plaintext conversion would be a false positive.
        'PSAvoidUsingConvertToSecureStringWithPlainText'
    )

    Rules = @{
        PSPlaceOpenBrace           = @{ Enable = $true; OnSameLine = $true }
        PSPlaceCloseBrace          = @{ Enable = $true }
        PSUseConsistentIndentation = @{ Enable = $true; Kind = 'space'; IndentationSize = 4 }
        PSUseConsistentWhitespace  = @{ Enable = $true }
        PSAlignAssignmentStatement = @{ Enable = $true }
    }
}
