<#
.SYNOPSIS
    Creates a private Key Vault and stores the Zscaler credentials as secrets.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function New-ZsKeyVault {
    <#
    .SYNOPSIS Creates a private Key Vault (RBAC authorization), stores the Zscaler credentials through
        Azure Resource Manager, and places the vault behind a Private Endpoint.
    .DESCRIPTION The vault is private from the create request onward: public network access disabled and
        default-deny network ACLs, which is what an "Azure Key Vault should disable public network
        access" policy requires of the request itself. Neither virtual machine nor template
        deployments may read it. An existing vault that is still open, or still allows either, is
        changed to match.

        The three secrets are written through Resource Manager - a PUT on
        Microsoft.KeyVault/vaults/secrets, the path ARM templates and Bicep use - rather than through
        the vault's own endpoint, which is the only thing the vault firewall guards. That takes
        Microsoft.KeyVault/vaults/secrets/write on the vault, which Contributor carries, and no Key
        Vault data role, so the deployer is granted none and the run needs no line of sight to the
        vault. Resource Manager never returns a secret's value.

        Connectors and the lifecycle function read the secrets through the Private Endpoint, resolved
        through the privatelink.vaultcore.azure.net zone, as Key Vault Secrets User.
    .PARAMETER VnetId The VNet resource ID, for the private DNS zone link.
    .PARAMETER PrivateEndpointSubnetId The subnet resource ID where the Private Endpoint NIC is placed.
    .PARAMETER PrivateDnsZoneResourceGroupName Resource group of the platform's privatelink zones, in a
        hub-and-spoke network. The endpoint registers in the platform's privatelink.vaultcore.azure.net
        there instead of a zone this deployment creates and links.
    .PARAMETER PrivateDnsZoneSubscriptionId Subscription of those zones, when not the deployment's.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][string]$IdentityPrincipalId,
        [Parameter(Mandatory)][SecureString]$ApiKey,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$AdminUser,
        [Parameter(Mandatory)][SecureString]$AdminPassword,
        # Defaults to enabled. Purge protection is what makes soft delete mean anything: without
        # it, anyone who can delete the vault can also purge it immediately. Deliberately
        # irreversible once on; -EnablePurgeProtection:$false is for the rare vault that is
        # meant to be destroyable.
        [switch]$EnablePurgeProtection = $true,
        [ValidateRange(7,90)][int]$SoftDeleteRetentionInDays = 90,
        [ValidateSet('RBAC','AccessPolicy')][string]$AuthMode = 'RBAC',
        [string]$VnetId = '',
        [string]$PrivateEndpointSubnetId = '',
        [string]$PrivateDnsZoneResourceGroupName = '',
        [string]$PrivateDnsZoneSubscriptionId = ''
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $loc=$script:ZsSession.Location; $tid=$script:ZsSession.TenantId; $tags=Get-ZsTags; $rgPath=Get-ZsRgPath
        $api = $script:ApiVersions.KeyVault

        # Discover existing vault or generate a unique name.
        $VaultName = $null
        try {
            $existing = Invoke-ArmGet -Uri "$rgPath/providers/Microsoft.KeyVault/vaults?api-version=$api"
            $match = @($existing.value | Where-Object { $_.name -match '^kv-zscc-' }) | Select-Object -First 1
            if ($match) { $VaultName = $match.name }
        } catch { Write-ZsLog "Could not query existing vaults (will create new): $($_.Exception.Message)" -Level DEBUG }
        if (-not $VaultName) {
            $rnd = [guid]::NewGuid().ToString('N').Substring(0, 8)
            $VaultName = "kv-zscc-$rnd"
        }
        if ($VaultName.Length -gt 24) { $VaultName = $VaultName.Substring(0, 24) }

        $useRbac  = ($AuthMode -eq 'RBAC')
        $policies = @()
        if (-not $useRbac) {
            $policies = @(@{ tenantId=$tid; objectId=$IdentityPrincipalId; permissions=@{ secrets=@('get','list') } })
        }
        $privateAcls = @{ defaultAction='Deny'; bypass='AzureServices' }

        $kvPath="$rgPath/providers/Microsoft.KeyVault/vaults/$VaultName"; $kvUri="$kvPath`?api-version=$api"
        $check = Test-ArmResource -Uri $kvUri
        if ($check.Exists) {
            $kv = $check.Resource; Write-ZsLog "Key Vault $VaultName verified"
            # Recorded even though this run did not create it: the deployment locks it below, and a
            # lock teardown cannot see is a lock nothing will ever remove. Whether teardown may then
            # delete it turns on the managed-by tag, not on which run got here first — a vault this
            # module created in a run that stopped early is still this module's to remove.
            Add-ZsManifestResource -Type 'KeyVault' -Name $VaultName -ResourceId $kv.id -Properties @{ AccessMode='PrivateEndpoint' } -PreExisting:(-not (Test-ZsModuleOwned -Resource $kv))
            # Reconcile purge protection on vaults created before it was the default. This is a
            # one-way door in Azure: it can be turned on but never off, so there is nothing to undo
            # and no branch here for the reverse case.
            if ($EnablePurgeProtection) {
                $alreadyOn = $false
                try { $alreadyOn = [bool]$kv.properties.enablePurgeProtection } catch { }
                if (-not $alreadyOn -and $PSCmdlet.ShouldProcess($VaultName, 'Enable purge protection')) {
                    try {
                        $kvLive = Invoke-ArmGet -Uri $kvUri
                        $kvLive.properties | Add-Member -NotePropertyName 'enableSoftDelete' -NotePropertyValue $true -Force
                        $kvLive.properties | Add-Member -NotePropertyName 'enablePurgeProtection' -NotePropertyValue $true -Force
                        Invoke-ArmPut -Uri $kvUri -Body @{ location=$loc; tags=$tags; properties=$kvLive.properties } | Out-Null
                        $kv = Invoke-ArmGet -Uri $kvUri
                        Write-ZsLog "Purge protection enabled on existing vault $VaultName (irreversible)"
                    } catch {
                        Write-ZsLog "Could not enable purge protection on $VaultName`: $($_.Exception.Message)" -Level WARN
                    }
                }
            }
            # The 5.4.1.0 release opened the vault for every secret write and closed it afterwards,
            # so a run that stopped in between left it open, and it created every vault with
            # deployment access on. Nothing below needs the public endpoint or either deployment flag.
            $closing = @()
            if ([string](Get-ZsPropertyValue $kv 'properties.publicNetworkAccess') -ne 'Disabled' -or
                [string](Get-ZsPropertyValue $kv 'properties.networkAcls.defaultAction') -ne 'Deny') { $closing += 'public network access' }
            if ((Get-ZsPropertyValue $kv 'properties.enabledForDeployment') -or
                (Get-ZsPropertyValue $kv 'properties.enabledForTemplateDeployment')) { $closing += 'deployment access' }
            if ($closing -and $PSCmdlet.ShouldProcess($VaultName, "Disable $($closing -join ' and ')")) {
                $kvLive = Invoke-ArmGet -Uri $kvUri
                $kvLive.properties | Add-Member -NotePropertyName 'publicNetworkAccess' -NotePropertyValue 'Disabled' -Force
                $kvLive.properties | Add-Member -NotePropertyName 'networkAcls' -NotePropertyValue $privateAcls -Force
                $kvLive.properties | Add-Member -NotePropertyName 'enabledForDeployment' -NotePropertyValue $false -Force
                $kvLive.properties | Add-Member -NotePropertyName 'enabledForTemplateDeployment' -NotePropertyValue $false -Force
                Invoke-ArmPut -Uri $kvUri -Body @{ location=$loc; tags=$tags; properties=$kvLive.properties } | Out-Null
                $kv = Invoke-ArmGet -Uri $kvUri
                Write-ZsLog "Key Vault $VaultName`: $($closing -join ' and ') disabled; reachable only through its Private Endpoint, by the identities granted Secrets User"
            }
        } elseif ($PSCmdlet.ShouldProcess($VaultName, 'Create Key Vault')) {
            $kvProps = @{
                tenantId=$tid; sku=@{family='A';name='standard'}
                # The connectors and the function read the secrets at run time as their own
                # identities. With template deployment on, anyone with Contributor on the group,
                # which carries Microsoft.KeyVault/vaults/deploy/action, could pass a secret into a
                # deployment of their own and read it back from what it creates.
                enabledForDeployment=$false; enabledForTemplateDeployment=$false
                enableSoftDelete=$true; softDeleteRetentionInDays=$SoftDeleteRetentionInDays
                enableRbacAuthorization=$useRbac; accessPolicies=$policies
                # Private in the create request itself: a policy that denies public network access
                # refuses a vault created open and closed afterwards.
                publicNetworkAccess='Disabled'
                networkAcls=$privateAcls
            }
            if ($EnablePurgeProtection) {
                $kvProps.enablePurgeProtection = $true
            } else {
                Write-ZsLog ("Purge protection is disabled on $VaultName. Soft delete alone does not " +
                    "protect the connector credentials: a principal with delete rights can purge the " +
                    "vault immediately and the retention window will not apply.") -Level WARN
            }
            Invoke-ArmPut -Uri $kvUri -Body @{ location=$loc; tags=$tags; properties=$kvProps } | Out-Null
            $kv = Wait-ArmProvision -Uri $kvUri -Label $VaultName
            Add-ZsManifestResource -Type 'KeyVault' -Name $VaultName -ResourceId $kv.id -Properties @{ PurgeProtection=$EnablePurgeProtection; AccessMode='PrivateEndpoint' }
        } else { return [PSCustomObject]@{ VaultName=$VaultName; VaultId='(key vault created at deploy time)'; VaultUri='(whatif)' } }

        $kvBaseUri = $kv.properties.vaultUri.TrimEnd('/')

        if ($useRbac) {
            $roleDefId = "/subscriptions/$($script:ZsSession.SubscriptionId)/providers/Microsoft.Authorization/roleDefinitions/$($script:Roles.KvSecretsUser)"
            Set-ZsRoleAssignment -Scope $kv.id -RoleDefinitionId $roleDefId -PrincipalId $IdentityPrincipalId -PrincipalType 'ServicePrincipal'
            if (-not $WhatIfPreference) { Write-ZsLog "Connector identity holds Key Vault Secrets User on $VaultName" }
        }

        # The secrets, through Resource Manager. A PUT creates the secret or writes a new version
        # of it, so a re-run with changed credentials updates them in place.
        $secrets = [ordered]@{ 'api-key'=(ConvertFrom-ZsSecureString -Secure $ApiKey); 'username'=$AdminUser; 'password'=(ConvertFrom-ZsSecureString -Secure $AdminPassword) }
        foreach ($name in $secrets.Keys) {
            if ($PSCmdlet.ShouldProcess($name, 'Set Key Vault secret through Resource Manager')) {
                Invoke-ArmPut -Uri "$kvPath/secrets/$name`?api-version=$api" -Body @{ properties=@{ value=$secrets[$name] } } | Out-Null
            }
        }
        Add-ZsManifestOutput -Key 'KeyVaultUri' -Value $kvBaseUri

        # The connectors and the function read the vault through this endpoint. In a hub-and-spoke
        # network it registers in the platform's privatelink zone, otherwise in one this deployment
        # creates and links to the VNet.
        if ($PrivateEndpointSubnetId -and $VnetId) {
            $zoneId = Resolve-ZsPrivateDnsZone -ZoneName $script:ZsPrivateDnsZones.vault -VnetId $VnetId `
                -HubResourceGroupName $PrivateDnsZoneResourceGroupName -HubSubscriptionId $PrivateDnsZoneSubscriptionId
            $pe = Set-ZsPrivateEndpoint -Name "pe-$VaultName" -TargetId $kv.id -GroupId 'vault' `
                -SubnetId $PrivateEndpointSubnetId -ZoneIds @($zoneId) -Properties @{ VaultName=$VaultName; DnsZone=$script:ZsPrivateDnsZones.vault }
            if ($pe.PrivateIp) { Add-ZsManifestOutput -Key 'KeyVaultPrivateIp' -Value $pe.PrivateIp }
        }

        return [PSCustomObject]@{ VaultName=$VaultName; VaultId=$kv.id; VaultUri=$kvBaseUri }
    }
}
