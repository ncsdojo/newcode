<#
.SYNOPSIS
    Creates a Log Analytics workspace and attaches diagnostic settings and flow logs.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function New-ZsDiagnostics {
    <#
    .SYNOPSIS Creates a Log Analytics workspace and attaches diagnostic settings to deployed resources.
    .DESCRIPTION Provisions a workspace, then routes platform logs and metrics from the Key Vault, NSGs,
        load balancer, public IP, and (when present) the function storage account to it. Optionally
        configures VNet flow logs via Network Watcher.
    .PARAMETER ResourceIds Map of resource type to ARM resource ID to attach diagnostics to.
    .PARAMETER EnableVnetFlowLogs Configures VNet flow logs to the workspace and a flow-log storage account.
    .PARAMETER VnetId VNet resource ID for flow logs.
    .PARAMETER FlowLogStorageId Storage account resource ID for flow log retention.
    .PARAMETER RetentionDays Workspace retention. Default 90.
    .EXAMPLE
    New-ZsDiagnostics -ResourceIds $ids
    Sends diagnostic settings for the given resources to a Log Analytics workspace.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [hashtable]$ResourceIds = @{},
        [switch]$EnableVnetFlowLogs,
        [string]$VnetId = '',
        [string]$FlowLogStorageId = '',
        [ValidateRange(30,730)][int]$RetentionDays = 90,
        [string]$WorkspaceName = ''
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $env=$script:ZsSession.Environment; $loc=$script:ZsSession.Location; $tags=Get-ZsTags
        if (-not $WorkspaceName) { $WorkspaceName = Get-ZsWorkspaceName }

        # Shared with the Function App's Application Insights component, which is provisioned
        # earlier in the deployment. Both converge on one workspace rather than creating two.
        if (-not $PSCmdlet.ShouldProcess($WorkspaceName, 'Create Log Analytics workspace')) { return }
        $wa = New-ZsWorkspace -WorkspaceName $WorkspaceName -RetentionDays $RetentionDays
        Write-ZsLog "Workspace $WorkspaceName ready"

        $attached = @()
        foreach ($key in $ResourceIds.Keys) {
            $rid = $ResourceIds[$key]
            if (-not $rid) { continue }
            if ($PSCmdlet.ShouldProcess($key, 'Attach diagnostic settings')) {
                $diagUri = "$rid/providers/Microsoft.Insights/diagnosticSettings/zscc-diag?api-version=$($script:ApiVersions.Insights)"
                try {
                    Invoke-ArmPut -Uri $diagUri -Body @{
                        properties=@{ workspaceId=$wa.id
                            logs=@(@{ categoryGroup='allLogs'; enabled=$true })
                            metrics=@(@{ category='AllMetrics'; enabled=$true }) }
                    } | Out-Null
                    # An extension resource on its target. Deleting the target takes it, so this is
                    # recorded for the case where the target outlives the deployment — a diagnostic
                    # setting left on a BringYourOwn virtual network is this deployment's to remove.
                    Add-ZsManifestResource -Type 'DiagnosticSetting' -Name "zscc-diag ($key)" `
                        -ResourceId "$rid/providers/Microsoft.Insights/diagnosticSettings/zscc-diag"
                    $attached += $key
                    Write-ZsLog "Diagnostics attached: $key"
                } catch {
                    Write-ZsLog "Diagnostics failed for $key`: $_" -Level WARN
                }
            }
        }

        $flowLog = $null
        if ($EnableVnetFlowLogs -and $VnetId -and $FlowLogStorageId) {
            $nwRg = "NetworkWatcherRG"
            $nwName = "NetworkWatcher_$loc"
            $flName = New-ZsResourceName -Prefix 'fl-zscc' -Environment $env -Location $loc
            $flPath = "$(Get-ZsSubscriptionPath)/resourceGroups/$nwRg/providers/Microsoft.Network/networkWatchers/$nwName/flowLogs/$flName"
            if ($PSCmdlet.ShouldProcess($flName, 'Create VNet flow log')) {
                try {
                    Invoke-ArmPut -Uri "$flPath`?api-version=$($script:ApiVersions.Network)" -Body @{
                        location=$loc; tags=$tags
                        properties=@{ targetResourceId=$VnetId; storageId=$FlowLogStorageId; enabled=$true
                            retentionPolicy=@{ days=$RetentionDays; enabled=$true }
                            format=@{ type='JSON'; version=2 }
                            flowAnalyticsConfiguration=@{ networkWatcherFlowAnalyticsConfiguration=@{
                                enabled=$true; workspaceResourceId=$wa.id; trafficAnalyticsInterval=60 } } }
                    } | Out-Null
                    # Lives in NetworkWatcherRG, outside the deployment's own resource group, so
                    # neither a group delete nor the tag scan would ever reach it.
                    Add-ZsManifestResource -Type 'FlowLog' -Name $flName -ResourceId $flPath
                    $flowLog = $flName
                    Write-ZsLog "VNet flow log configured: $flName"
                } catch {
                    Write-ZsLog "VNet flow log failed: $_" -Level WARN
                }
            }
        }

        return [PSCustomObject]@{ WorkspaceName=$WorkspaceName; WorkspaceId=$wa.id; AttachedResources=$attached; FlowLog=$flowLog }
    }
}
