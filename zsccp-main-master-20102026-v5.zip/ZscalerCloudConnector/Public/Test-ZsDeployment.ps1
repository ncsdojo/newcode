<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Test-ZsDeployment).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
    .PARAMETER ResourceGroupName Resource group to validate (defaults to the connected session's RG).
    .PARAMETER ExpectedProbePort Expected HTTP probe port for load balancer health checks.
    .PARAMETER Zones Expected availability zones (auto-derived from deployed scale sets if omitted).
    #>

function Test-ZsDeployment {
    <#
    .SYNOPSIS Post-deployment validation covering all resource types, NIC config, VM state, peering, and Zscaler registration.
    .EXAMPLE
    Test-ZsDeployment
    Validates Azure resource state and Zscaler connector registration for the current deployment.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param([string]$ResourceGroupName = '', [int]$ExpectedProbePort = 50000, [string[]]$Zones = @())

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        if (-not $ResourceGroupName) { $ResourceGroupName = $script:ZsSession.ResourceGroupName }
        $rgPath = "$(Get-ZsSubscriptionPath)/resourceGroups/$ResourceGroupName"
        $n = $script:ApiVersions.Network; $c = $script:ApiVersions.Compute; $p = 0; $f = 0

        # Derive expected zones from deployed VMSS names if not specified.
        if (-not $Zones -or $Zones.Count -eq 0) {
            try {
                $vmssAll = @((Invoke-ArmGet -Uri "$rgPath/providers/Microsoft.Compute/virtualMachineScaleSets?api-version=$c").value)
                $derived = @($vmssAll | ForEach-Object { if ($_.name -match '-z(\d+)-') { $Matches[1] } } | Sort-Object -Unique)
                $Zones = if ($derived.Count -gt 0) { $derived } else { @('1','2') }
            } catch { $Zones = @('1','2') }
        }

        $check = Test-ArmResource -Uri "$rgPath`?api-version=$($script:ApiVersions.ResourceGroup)"
        if (-not $check.Exists) {
            # Same key set as the full result below; a shape that varies by outcome is a
            # StrictMode "property cannot be found" error waiting in whichever branch a caller
            # did not test against.
            return [PSCustomObject]@{ Passed=0; Failed=1; Status='ResourceGroupMissing'
                ExpectedZones=@(); MissingZones=@(); RunningConnectors=0; ZoneDistribution=@{}; ZonelessInstances=0 }
        }
        $p++

        # Network. A brownfield deployment's VNet lives wherever its owners put it — often another
        # resource group, sometimes another subscription — and its subnets carry their owners'
        # names, so the snet-zscc-* convention only describes a network this module created. The
        # manifest records which situation this is: a PreExisting VNet entry means verify that VNet
        # by its resource ID and check each manifest-recorded subnet is still on it. Without one,
        # the deployment group is scanned for the module's own names, as before.
        $manifestVnet = $null; $manifestSubnets = @()
        try {
            $mf = Get-ZsManifest
            if ($mf -and $mf.Resources.Contains('VNet')) {
                $manifestVnet = @($mf.Resources['VNet']) | Where-Object { $_.Contains('PreExisting') -and $_['PreExisting'] } | Select-Object -First 1
            }
            if ($manifestVnet -and $mf.Resources.Contains('Subnet')) {
                $manifestSubnets = @($mf.Resources['Subnet'] | Where-Object { $_['ResourceId'] })
            }
        } catch { }

        if ($manifestVnet) {
            $live = $null
            try { $live = Invoke-ArmGet -Uri "$($manifestVnet['ResourceId'])?api-version=$n" -AllowNotFound } catch { }
            if ($live) { $p++ } else { $f++ }
            $liveIds = @()
            if ($live -and $live.PSObject.Properties['properties'] -and $live.properties.PSObject.Properties['subnets']) {
                $liveIds = @($live.properties.subnets | ForEach-Object { ([string]$_.id).ToLowerInvariant() })
            }
            foreach ($ms in $manifestSubnets) {
                if ($liveIds -contains ([string]$ms['ResourceId']).ToLowerInvariant()) { $p++ } else { $f++ }
            }
        } else {
            $vnets = @((Invoke-ArmGet -Uri "$rgPath/providers/Microsoft.Network/virtualNetworks?api-version=$n").value)
            if ($vnets.Count -ge 1) { $p++ } else { $f++ }
            foreach ($v in $vnets) {
                $sn = @($v.properties.subnets | ForEach-Object { $_.name })
                # Per-zone connector subnets plus the shared workload and LB subnets.
                $req = [System.Collections.Generic.List[string]]::new()
                $req.Add('snet-zscc-mgmt'); $req.Add('snet-zscc-service')
                $req.Add('snet-zscc-workload'); $req.Add('snet-zscc-lb')
                foreach ($r in $req) { if ($sn -contains $r) { $p++ } else { $f++ } }
            }
        }

        $nsgs = @((Invoke-ArmGet -Uri "$rgPath/providers/Microsoft.Network/networkSecurityGroups?api-version=$n").value)
        if ($nsgs.Count -ge 2) { $p++ } else { $f++ }

        $lbs = @((Invoke-ArmGet -Uri "$rgPath/providers/Microsoft.Network/loadBalancers?api-version=$n").value)
        if ($lbs.Count -ge 1) { $p++ } else { $f++ }
        foreach ($l in $lbs) {
            if ($l.sku.name -eq 'Standard') { $p++ } else { $f++ }
            foreach ($pr in @($l.properties.probes)) { if ($pr.properties.port -eq $ExpectedProbePort) { $p++ } else { $f++ } }
            foreach ($r in @($l.properties.loadBalancingRules)) {
                if ($r.properties.frontendPort -eq 0) { $p++ } else { $f++ }
                # Floating IP off and source IP affinity, as the load balancer is built.
                if (-not [bool](Get-ZsPropertyValue $r 'properties.enableFloatingIP')) { $p++ } else { $f++; Write-ZsLog "LB rule $($r.name) has floating IP on" -Level WARN }
                $dist = [string](Get-ZsPropertyValue $r 'properties.loadDistribution')
                if ($dist -eq 'SourceIP') { $p++ } else { $f++; Write-ZsLog "LB rule $($r.name) distributes by '$dist', not SourceIP" -Level WARN }
            }
        }

        # Nothing that holds a secret or runs the lifecycle takes public traffic: the vault, the
        # function's storage account and the Function App all have public network access disabled.
        $lockChecks = @(
            @{ Label='Key Vault';       Uri="$rgPath/providers/Microsoft.KeyVault/vaults?api-version=$($script:ApiVersions.KeyVault)" }
            @{ Label='Storage account'; Uri="$rgPath/providers/Microsoft.Storage/storageAccounts?api-version=$($script:ApiVersions.Storage)" }
            @{ Label='Function App';    Uri="$rgPath/providers/Microsoft.Web/sites?api-version=$($script:ApiVersions.Web)" }
        )
        foreach ($lc in $lockChecks) {
            $items = @(Get-ZsPropertyValue (Invoke-ArmGet -Uri $lc.Uri) 'value' | Where-Object { $_ -and [string]$_.name -match 'zscc' })
            foreach ($it in $items) {
                # The site list does not carry every property, so each app is read on its own.
                $full = if ($lc.Label -eq 'Function App') { Invoke-ArmGet -Uri "$($it.id)?api-version=$($script:ApiVersions.Web)" } else { $it }
                $pna = [string](Get-ZsPropertyValue $full 'properties.publicNetworkAccess')
                if ($pna -eq 'Disabled') { $p++ }
                else { $f++; Write-ZsLog "$($lc.Label) $($it.name) has public network access '$pna'; it should be Disabled." -Level WARN }
            }
        }

        $rts = @((Invoke-ArmGet -Uri "$rgPath/providers/Microsoft.Network/routeTables?api-version=$n").value)
        foreach ($r in $rts) { $def = $r.properties.routes | Where-Object { $_.properties.addressPrefix -eq '0.0.0.0/0' }; if ($def) { $p++ } else { $f++ }; if ($r.properties.disableBgpRoutePropagation) { $p++ } else { $f++ } }

        $vms = @((Invoke-ArmGet -Uri "$rgPath/providers/Microsoft.Compute/virtualMachines?api-version=$c").value | Where-Object { $_.name -match 'zscc' })
        if ($vms.Count -ge 1) { $p++ } else { $f++ }
        foreach ($vm in $vms) {
            if ($vm.properties.provisioningState -eq 'Succeeded') { $p++ } else { $f++ }
            if ($vm.plan.publisher -eq $script:CcImage.Publisher) { $p++ } else { $f++ }
            if ($vm.identity.type -match 'UserAssigned') { $p++ } else { $f++ }
            $nics = @($vm.properties.networkProfile.networkInterfaces)
            if ($nics.Count -eq 2) { $p++ } else { $f++ }
            $primary = $nics | Where-Object { $_.properties.primary }
            if ($primary -and (($primary.id -split '/')[-1]) -match 'mgmt') { $p++ } else { $f++ }
            try { $iv = Invoke-ArmGet -Uri "$($vm.id)/instanceView?api-version=$c"; $ps = (@($iv.statuses) | Where-Object { $_.code -match 'PowerState' }).code; if ($ps -eq 'PowerState/running') { $p++ } else { $f++ } } catch { $f++ }
        }

        # Verify each zone has running instances (not just a provisioned scale set).
        $byZone = @{}
        foreach ($z in $Zones) { $byZone[$z] = 0 }
        $zonelessVms = 0
        foreach ($vm in $vms) {
            $vz = @($vm.zones)
            if ($vz.Count -eq 0) { $zonelessVms++; continue }
            foreach ($z in $vz) { if ($byZone.ContainsKey([string]$z)) { $byZone[[string]$z]++ } }
        }
        foreach ($z in $Zones) {
            if ($byZone[$z] -ge 1) {
                $p++
            } else {
                $f++
                Write-ZsLog "Zone $z has no running connector instance. The zone-$z scale set exists but its VM did not allocate — commonly a zone restricted for this subscription's VM size. This deployment is NOT providing the two-zone resilience it appears to." -Level WARN
            }
        }
        if ($zonelessVms -gt 0) {
            $f++
            Write-ZsLog "$zonelessVms connector instance(s) have no zone assignment (non-zonal placement). Expected zonal placement for zones $($Zones -join ', ')." -Level WARN
        }
        # Surface the actual distribution so the operator sees reality, not just pass/fail.
        $dist = ($Zones | ForEach-Object { "z${_}=$($byZone[$_])" }) -join ' '
        Write-ZsLog "Connector zone distribution: $dist$(if($zonelessVms){" zoneless=$zonelessVms"})"

        $allNics = @((Invoke-ArmGet -Uri "$rgPath/providers/Microsoft.Network/networkInterfaces?api-version=$n").value)
        foreach ($nic in @($allNics | Where-Object { $_.name -match 'svc' })) {
            if ($nic.properties.enableIPForwarding) { $p++ } else { $f++ }
            $pools = @(); try { $pools = @($nic.properties.ipConfigurations[0].properties.loadBalancerBackendAddressPools) } catch { }
            if ($pools.Count -ge 1) { $p++ } else { $f++ }
        }

        if ($vnets.Count -gt 0 -and $vnets[0].properties.virtualNetworkPeerings) {
            foreach ($pr in @($vnets[0].properties.virtualNetworkPeerings)) {
                if ($pr.properties.peeringState -eq 'Connected') { $p++ } else { $f++ }
            }
        }

        if ($script:ZsSession.ZscalerConnected) {
            try {
                $groups = Invoke-ZscalerRequest -Uri "$($script:ZsSession.ZscalerApiUrl)/api/v1/ecgroup" -Method Get
                $gl = if ($groups -is [array]) { $groups } else { @($groups) }
                if ($gl.Count -gt 0) { $p++ } else { $f++ }
            } catch { Write-ZsLog "Zscaler API check failed: $_" -Level WARN }
        }

        $missingZones = @($Zones | Where-Object { $byZone[$_] -lt 1 })
        $status = if ($f -eq 0) { 'Healthy' }
                  elseif ($missingZones.Count -gt 0) { 'DegradedZoneCoverage' }
                  else { 'Degraded' }
        Write-ZsLog "Validation: $p passed, $f failed ($status)"
        return [PSCustomObject]@{
            Passed=$p; Failed=$f; Status=$status
            ZoneDistribution=$byZone; MissingZones=$missingZones; ZonelessInstances=$zonelessVms
            ExpectedZones=@($Zones); RunningConnectors=$vms.Count
        }
    }
}
