<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (New-ZsVnetPeering).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
    .PARAMETER HubVnetId Resource ID of the hub VNet (the connector VNet).
    .PARAMETER SpokeVnetIds Resource IDs of spoke VNets to peer with the hub.
    .PARAMETER AllowForwardedTraffic Allow forwarded traffic through the peering.
    .PARAMETER AllowGatewayTransit Allow gateway transit through the peering.
    #>

function New-ZsVnetPeering {
    <#
    .SYNOPSIS Creates bidirectional VNet peerings between CC hub and spoke VNets.
    .EXAMPLE
    New-ZsVnetPeering -RemoteVnetId $spokeVnetId
    Peers the connector hub VNet with a spoke workload VNet.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([System.Collections.Generic.List[PSCustomObject]])]
    param(
        [Parameter(Mandatory)][string]$HubVnetId,
        [Parameter(Mandatory)][string[]]$SpokeVnetIds,
        [switch]$AllowForwardedTraffic, [switch]$AllowGatewayTransit
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $api = $script:ApiVersions.Network
        $results = [System.Collections.Generic.List[PSCustomObject]]::new()
        $hubN = ($HubVnetId -split '/')[-1]

        foreach ($spokeId in $SpokeVnetIds) {
            $spokeN = ($spokeId -split '/')[-1]
            $h2s = "peer-$hubN-to-$spokeN"; $s2h = "peer-$spokeN-to-$hubN"

            $chk = Test-ArmResource -Uri "$HubVnetId/virtualNetworkPeerings/$h2s`?api-version=$api"
            if ($chk.Exists -and $chk.State -eq 'Connected') {
                Write-ZsLog "Peering $h2s connected, skipping"
                $results.Add([PSCustomObject]@{ Hub=$h2s; Spoke=$s2h; SpokeVnet=$spokeN; Status='Existing' })
                continue
            }
            if ($PSCmdlet.ShouldProcess("$hubN <-> $spokeN", 'Create VNet peering')) {
                Invoke-ArmPut -Uri "$HubVnetId/virtualNetworkPeerings/$h2s`?api-version=$api" -Body @{
                    properties=@{ remoteVirtualNetwork=@{id=$spokeId}; allowVirtualNetworkAccess=$true; allowForwardedTraffic=($AllowForwardedTraffic.IsPresent -or $true); allowGatewayTransit=$AllowGatewayTransit.IsPresent; useRemoteGateways=$false }
                } | Out-Null
                Invoke-ArmPut -Uri "$spokeId/virtualNetworkPeerings/$s2h`?api-version=$api" -Body @{
                    properties=@{ remoteVirtualNetwork=@{id=$HubVnetId}; allowVirtualNetworkAccess=$true; allowForwardedTraffic=$true; allowGatewayTransit=$false; useRemoteGateways=$AllowGatewayTransit.IsPresent }
                } | Out-Null
                Wait-ArmProvision -Uri "$HubVnetId/virtualNetworkPeerings/$h2s`?api-version=$api" -Label $h2s | Out-Null
                Add-ZsManifestResource -Type 'VnetPeering' -Name $h2s -ResourceId "$HubVnetId/virtualNetworkPeerings/$h2s"
                $results.Add([PSCustomObject]@{ Hub=$h2s; Spoke=$s2h; SpokeVnet=$spokeN; Status='Created' })
                Write-ZsLog "Peered: $hubN <-> $spokeN"
            }
        }
        return $results
    }
}
