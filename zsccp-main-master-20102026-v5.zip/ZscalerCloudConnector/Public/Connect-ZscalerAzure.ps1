<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Connect-ZscalerAzure).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

# MSAL helpers

$script:MsalModule        = 'MSAL.PS'
$script:MsalModuleVersion = '4.37.0.0'
$script:LocalRedirectUri  = 'http://localhost:52836/'

function Install-ZsMsalIfRequired {
    $available = Get-Module -ListAvailable -Name $script:MsalModule |
        Where-Object { $_.Version -eq [version]$script:MsalModuleVersion }
    if ($available) { return $true }

    Write-ZsLog "MSAL.PS $($script:MsalModuleVersion) not found. Attempting pinned install (CurrentUser scope)..." -Level WARN

    try {
        $null = Get-PackageProvider -Name NuGet -ErrorAction Stop
    } catch {
        try {
            Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 `
                -Scope CurrentUser -Force -ErrorAction Stop | Out-Null
        } catch {
            Write-ZsLog "NuGet provider unavailable. MSAL install skipped." -Level WARN
            return $false
        }
    }

    try {
        Install-Module -Name $script:MsalModule -RequiredVersion $script:MsalModuleVersion `
            -Scope CurrentUser -Force -AllowClobber -AcceptLicense -ErrorAction Stop
        Write-ZsLog "MSAL.PS installed successfully"
        return $true
    } catch {
        Write-ZsLog "MSAL.PS install failed: $($_.Exception.Message)" -Level WARN
        return $false
    }
}

function Get-ZsInteractiveToken {
    <#
    .SYNOPSIS Acquires an ARM token via Authorization Code + PKCE using MSAL.PS.
    .DESCRIPTION Opens a local browser window for interactive sign-in. PKCE (Proof Key for
        Code Exchange) eliminates the need for a client secret — the code verifier/challenge
        pair proves possession without a stored credential. Requires the app registration to
        have http://localhost:52836/ as a redirect URI under Mobile and desktop applications.
    #>
    param(
        [Parameter(Mandatory)][string]$TenantId,
        [Parameter(Mandatory)][string]$ClientId,
        [string]$Resource = $script:Endpoints.Arm
    )

    Import-Module $script:MsalModule -RequiredVersion $script:MsalModuleVersion -ErrorAction Stop

    $token = Get-MsalToken `
        -ClientId    $ClientId `
        -TenantId    $TenantId `
        -Scopes      @("$Resource/.default") `
        -RedirectUri $script:LocalRedirectUri `
        -Interactive

    Write-ZsLog "Authenticated via interactive login (PKCE)"
    return $token
}

function Get-ZsSilentToken {
    <#
    .SYNOPSIS Non-interactive MSAL acquisition from the in-process token cache.
    .DESCRIPTION Succeeds only when the MSAL cache for this ClientId/TenantId already holds
        a usable entry — e.g. an operator authenticated interactively earlier in the same
        PowerShell session and is now re-running a deployment.
    #>
    param(
        [Parameter(Mandatory)][string]$TenantId,
        [Parameter(Mandatory)][string]$ClientId,
        [string]$Resource = $script:Endpoints.Arm
    )

    Import-Module $script:MsalModule -RequiredVersion $script:MsalModuleVersion -ErrorAction Stop

    $token = Get-MsalToken `
        -ClientId    $ClientId `
        -TenantId    $TenantId `
        -Scopes      @("$Resource/.default") `
        -RedirectUri $script:LocalRedirectUri `
        -Silent

    Write-ZsLog "Authenticated via cached MSAL token (silent)"
    return $token
}

function Get-ZsDeviceCodeToken {
    <#
    .SYNOPSIS Fallback authentication via OAuth2 device code flow.
    .DESCRIPTION Used when MSAL.PS is unavailable or interactive login fails (e.g. headless
        server, SSH session, no browser). Less secure than PKCE — susceptible to device code
        phishing. Displays a code for the user to enter at https://microsoft.com/devicelogin.
    #>
    param(
        [Parameter(Mandatory)][string]$TenantId,
        [Parameter(Mandatory)][string]$ClientId,
        [string]$Resource = $script:Endpoints.Arm
    )

    $loginBase = $script:Endpoints.Login

    try {
        $codeResponse = Invoke-RestMethod `
            -Uri "$loginBase/$TenantId/oauth2/v2.0/devicecode" `
            -Method Post `
            -Body @{ client_id = $ClientId; scope = "$Resource/.default offline_access openid profile" } `
            -ContentType "application/x-www-form-urlencoded"
    } catch {
        $errorDetail = if ($_.ErrorDetails) { $_.ErrorDetails.Message } else { $_.Exception.Message }
        if ($errorDetail -match 'AADSTS7000218') {
            Write-ZsLog "Public client flows are not enabled on application $ClientId, which device code sign-in requires." -Level ERROR
            Write-ZsLog "  Fix: Entra portal > App registrations > $ClientId > Authentication > Advanced settings > set 'Allow public client flows' to Yes, then save and re-run." -Level ERROR
            throw "Application ($ClientId) is not configured for public client flows, which device code sign-in requires. Enable 'Allow public client flows' on the app registration and re-run."
        }
        if ($errorDetail -match 'AADSTS65001') {
            throw "Administrative consent has not been granted for the application ($ClientId). " +
                  "A Global Administrator must grant admin consent under API permissions in the app registration."
        }
        throw "Device authorisation request failed: $errorDetail"
    }

    try { Start-Process $codeResponse.verification_uri -ErrorAction SilentlyContinue } catch { }
    try { Set-Clipboard -Value $codeResponse.user_code -ErrorAction SilentlyContinue } catch { }

    Write-ZsLog "Device code: $($codeResponse.user_code) — paste it into the browser window and sign in"

    $tokenBody = @{
        client_id   = $ClientId
        grant_type  = "urn:ietf:params:oauth:grant-type:device_code"
        device_code = $codeResponse.device_code
    }
    $pollInterval = [Math]::Max([int]$codeResponse.interval, 5)
    $deadline = (Get-Date).AddSeconds($codeResponse.expires_in)

    while ((Get-Date) -lt $deadline) {
        Start-Sleep $pollInterval

        try {
            $token = Invoke-RestMethod `
                -Uri "$loginBase/$TenantId/oauth2/v2.0/token" `
                -Method Post -Body $tokenBody `
                -ContentType "application/x-www-form-urlencoded"

            Write-ZsLog "Authenticated via device code"
            return $token
        } catch {
            $errorBody = $null
            try { $errorBody = $_.ErrorDetails.Message | ConvertFrom-Json } catch { }

            if (-not $errorBody) { throw "Token acquisition failed: $($_.Exception.Message)" }

            switch ($errorBody.error) {
                "authorization_pending" { Write-ZsLog "Awaiting browser sign-in" -Level DEBUG; continue }
                "slow_down"             { $pollInterval += 5; continue }
                "expired_token"         { throw "The device code has expired. Please re-run." }
                "authorization_declined" { throw "Authentication was declined by the user." }
                default {
                    $desc = if ($errorBody.PSObject.Properties.Name -contains 'error_description') { $errorBody.error_description } else { $errorBody.error }
                    throw "Authentication failed: $($errorBody.error) - $desc"
                }
            }
        }
    }
    throw "Authentication timed out. Please re-run."
}

function Get-ZsCertificateToken {
    <#
    .SYNOPSIS Acquires a token using a client certificate (no secret required).
    .DESCRIPTION Looks up the certificate by thumbprint in CurrentUser\My and LocalMachine\My.
        The certificate must have a private key accessible to the current process.
    #>
    param(
        [Parameter(Mandatory)][string]$TenantId,
        [Parameter(Mandatory)][string]$ClientId,
        [Parameter(Mandatory)][string]$Thumbprint,
        [string]$Resource = $script:Endpoints.Arm
    )

    Import-Module $script:MsalModule -RequiredVersion $script:MsalModuleVersion -ErrorAction Stop

    $tp = $Thumbprint.Replace(' ', '').ToUpper()
    $cert = @(Get-ChildItem Cert:\CurrentUser\My, Cert:\LocalMachine\My -ErrorAction SilentlyContinue |
        Where-Object { $_.Thumbprint -eq $tp }) | Select-Object -First 1
    if (-not $cert) { throw "Certificate $tp not found in Cert:\CurrentUser\My or Cert:\LocalMachine\My." }
    if (-not $cert.HasPrivateKey) { throw "Certificate $tp has no accessible private key." }

    $token = Get-MsalToken `
        -ClientId          $ClientId `
        -TenantId          $TenantId `
        -ClientCertificate $cert `
        -Scopes            @("$Resource/.default")

    Write-ZsLog "Authenticated via client certificate"
    return $token
}

# Main entry point

function Connect-ZscalerAzure {
    <#
    .SYNOPSIS Authenticates to Azure ARM and opens a deployment session.
    .DESCRIPTION
        Supports four authentication methods in priority order:

        1. Client secret   — service principal + secret (CI/CD pipelines).
        2. Client certificate — service principal + certificate thumbprint.
        3. Interactive PKCE — browser-based login via MSAL.PS (recommended for operators).
        4. Device code      — fallback when no browser or MSAL unavailable.

        If -ClientSecret is supplied, method 1 is used (existing behaviour, fully backward
        compatible). If -CertificateThumbprint is supplied, method 2 is used. Otherwise the
        function tries PKCE interactive login and falls back to device code.

    .PARAMETER ClientSecret  Service principal secret as SecureString (method 1).
    .PARAMETER CertificateThumbprint  Certificate thumbprint for SP auth (method 2).
    .PARAMETER NonInteractive  Skip browser prompts; use cached MSAL token only.
    .OUTPUTS PSCustomObject with session metadata.

    .EXAMPLE
    # Service principal (pipelines).
    $secret = Read-Host 'Client secret' -AsSecureString
    Connect-ZscalerAzure -TenantId $t -SubscriptionId $s -ClientId $c -ClientSecret $secret -Location westus2

    .EXAMPLE
    # Interactive PKCE (operators).
    Connect-ZscalerAzure -TenantId $t -SubscriptionId $s -ClientId $c -Location westus2

    .EXAMPLE
    # Certificate-based (no secret stored anywhere)
    Connect-ZscalerAzure -TenantId $t -SubscriptionId $s -ClientId $c -CertificateThumbprint $tp -Location westus2
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][ValidatePattern('^[0-9a-fA-F-]{36}$')][string]$TenantId,
        [Parameter(Mandatory)][ValidatePattern('^[0-9a-fA-F-]{36}$')][string]$SubscriptionId,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$ClientId,
        [object]$ClientSecret,
        [string]$CertificateThumbprint,
        [switch]$NonInteractive,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Location,
        [ValidateSet('prod','staging','dev','test','uat')][string]$Environment = 'prod',
        [string]$ResourceGroupName = '',
        [string]$LogFile = '',
        [string]$ArtifactRoot = ''
    )

    if (-not $ResourceGroupName) { $ResourceGroupName = "rg-zscc-$Environment-$Location" }
    $deploymentId = [guid]::NewGuid().ToString()
    $idInput = "$SubscriptionId/$($ResourceGroupName.ToLower())"
    $rgBytes = [System.Text.Encoding]::UTF8.GetBytes($idInput)
    $rgHash  = [System.Security.Cryptography.SHA256]::Create().ComputeHash($rgBytes)
    $shortId = [BitConverter]::ToString($rgHash[0..3]).Replace('-','').ToLower()

    # Determine auth method.
    $authMethod = 'interactive'
    if ($ClientSecret)          { $authMethod = 'client_secret' }
    if ($CertificateThumbprint) { $authMethod = 'certificate' }

    # Build session — ClientSecretSS is $null for non-SP flows.
    $clientSecretSS = $null
    if ($ClientSecret) {
        $clientSecretSS = ConvertTo-ZsSecureString -Value $ClientSecret -Name 'ClientSecret'
    }

    $script:ZsSession = @{
        TenantId = $TenantId; SubscriptionId = $SubscriptionId
        ClientId = $ClientId; ClientSecretSS = $clientSecretSS
        AuthMethod = $authMethod
        Location = $Location; Environment = $Environment
        ResourceGroupName = $ResourceGroupName
        DeploymentId = $deploymentId; ShortId = $shortId
        DeployedAt = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ssZ')
        Tokens = @{}; Connected = $false
        ArtifactRoot = $ArtifactRoot
        LogFile = $LogFile; LogBuffer = [System.Collections.Generic.List[string]]::new()
        ZscalerConnected = $false; ZscalerApiKeySS = $null; ZscalerUsername = ''; ZscalerPasswordSS = $null
        ZscalerSession = $null; ZscalerApiUrl = ''
        MsalTokenResponse = $null; MsalTokenExpiry = $null
    }

    $script:ZsSession.LogFile = Initialize-ZsLogging -LogFile $LogFile
    Write-ZsLog "Authenticating to tenant $TenantId (method: $authMethod)"

    switch ($authMethod) {
        'client_secret' {
            $null = Get-ArmToken
        }
        'certificate' {
            $useMsal = Install-ZsMsalIfRequired
            if (-not $useMsal) {
                throw "Certificate authentication requires MSAL.PS $($script:MsalModuleVersion). " +
                      "Pre-install it or allow PowerShell Gallery access."
            }
            $msalToken = Get-ZsCertificateToken -TenantId $TenantId -ClientId $ClientId `
                -Thumbprint $CertificateThumbprint
            $script:ZsSession.MsalTokenResponse = $msalToken
            $script:ZsSession.MsalTokenExpiry = $msalToken.ExpiresOn.LocalDateTime.AddMinutes(-2)
            $script:ZsSession.Tokens[$script:Endpoints.Arm] = @{
                AccessToken = $msalToken.AccessToken
                ExpiresOn   = $msalToken.ExpiresOn.ToUnixTimeSeconds()
            }
        }
        'interactive' {
            # StrictMode: both must exist before the post-branch if/elseif — only one
            # is ever assigned depending on which auth path succeeds.
            $msalToken = $null; $deviceToken = $null
            $useMsal = Install-ZsMsalIfRequired

            if ($NonInteractive) {
                if (-not $useMsal) {
                    throw ("Non-interactive mode requires MSAL.PS $($script:MsalModuleVersion). " +
                           "Pre-install it or authenticate interactively once first.")
                }
                try {
                    Write-ZsLog "Non-interactive mode: attempting silent MSAL token acquisition"
                    $msalToken = Get-ZsSilentToken -TenantId $TenantId -ClientId $ClientId
                } catch {
                    throw ("Non-interactive authentication failed: no usable cached token for client " +
                           "$ClientId in tenant $TenantId. Authenticate interactively once in this " +
                           "PowerShell session, then re-invoke with -NonInteractive. " +
                           "Inner error: $($_.Exception.Message)")
                }
            }
            elseif ($useMsal) {
                try {
                    Write-ZsLog "Attempting interactive login with PKCE (recommended)"
                    $msalToken = Get-ZsInteractiveToken -TenantId $TenantId -ClientId $ClientId
                } catch {
                    Write-ZsLog "Interactive auth unavailable: $($_.Exception.Message)" -Level WARN
                    Write-ZsLog "  Common causes: the app registration is missing the $($script:LocalRedirectUri) redirect URI, no browser could be launched on this machine, or a Conditional Access policy is blocking the request." -Level WARN
                    Write-ZsLog "Falling back to device code flow" -Level WARN
                    $deviceToken = Get-ZsDeviceCodeToken -TenantId $TenantId -ClientId $ClientId
                }
            }
            else {
                Write-ZsLog "MSAL.PS is not available; using device code flow. For the recommended PKCE flow, allow PowerShell Gallery access or pre-install: Install-Module MSAL.PS -Scope CurrentUser" -Level WARN
                $deviceToken = Get-ZsDeviceCodeToken -TenantId $TenantId -ClientId $ClientId
            }

            # Store the token from whichever flow succeeded.
            if ($msalToken) {
                $script:ZsSession.MsalTokenResponse = $msalToken
                $script:ZsSession.MsalTokenExpiry = $msalToken.ExpiresOn.LocalDateTime.AddMinutes(-2)
                $script:ZsSession.Tokens[$script:Endpoints.Arm] = @{
                    AccessToken = $msalToken.AccessToken
                    ExpiresOn   = $msalToken.ExpiresOn.ToUnixTimeSeconds()
                }
            }
            elseif ($deviceToken) {
                $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
                $script:ZsSession.Tokens[$script:Endpoints.Arm] = @{
                    AccessToken = $deviceToken.access_token
                    ExpiresOn   = $now + $deviceToken.expires_in
                }
                $script:ZsSession.AuthMethod = 'devicecode'
            }
        }
    }

    $sub = Invoke-ArmGet -Uri "/subscriptions/$SubscriptionId`?api-version=$($script:ApiVersions.Subscription)"
    $script:ZsSession.Connected = $true

    # Validate region.
    $regionCheck = Test-ZsRegion -Region $Location
    if (-not $regionCheck.Exists) {
        $hint = if ($regionCheck.Suggestions.Count -gt 0) {
            " Did you mean: $($regionCheck.Suggestions -join ', ')?"
        } else {
            ' Run "az account list-locations --query ""[].name"" -o tsv" to list valid regions for this subscription.'
        }
        $script:ZsSession.Connected = $false
        Write-ZsError -Message "Region '$Location' is not a valid or available Azure region for this subscription.$hint" -ErrorId 'ZsInvalidRegion' -Category 'InvalidArgument' -Cmdlet $PSCmdlet
        return
    }
    if (-not $regionCheck.HasZones) {
        Write-ZsLog "Region '$Location' ($($regionCheck.DisplayName)) does not support availability zones. Zonal deployments will fail; deploy without zones or choose a zone-enabled region." -Level WARN
    }

    Initialize-ZsManifest -SubscriptionId $SubscriptionId -ResourceGroupName $ResourceGroupName -Location $Location
    Write-ZsLog "Connected: $($sub.displayName) (auth: $($script:ZsSession.AuthMethod))"

    return [PSCustomObject]@{
        PSTypeName = 'ZsAzureSession'; Connected = $true
        SubscriptionName = $sub.displayName; DeploymentId = $deploymentId
        ResourceGroup = $ResourceGroupName; Location = $Location
        AuthMethod = $script:ZsSession.AuthMethod
    }
}
