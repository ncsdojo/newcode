<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Disconnect-ZscalerCloud).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Disconnect-ZscalerCloud {
    <#
    .SYNOPSIS Logs out of the Cloud & Branch Connector API and clears stored credentials.
    .DESCRIPTION Sends DELETE /api/v1/auth to invalidate the JSESSIONID, then clears the
    session cookie and SecureString credentials from memory.
    .EXAMPLE
    Disconnect-ZscalerCloud
    Invalidates the Zscaler session and clears cached API credentials.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param()

    if (-not $script:ZsSession.ZscalerConnected) {
        Write-Warning 'No active Zscaler session'
        return [PSCustomObject]@{ Disconnected = $false }
    }

    $base = $script:ZsSession.ZscalerApiUrl
    try {
        Invoke-RestMethod -Uri "$base/api/v1/auth" -Method Delete `
            -Headers @{ 'Content-Type' = 'application/json' } `
            -WebSession $script:ZsSession.ZscalerSession -ErrorAction Stop | Out-Null
        Write-ZsLog 'Zscaler session invalidated'
    } catch {
        Write-ZsLog "Zscaler logout returned an error (session may have already expired): $($_.Exception.Message)" -Level WARN
    }

    $script:ZsSession.ZscalerSession    = $null
    $script:ZsSession.ZscalerApiKeySS   = $null
    $script:ZsSession.ZscalerPasswordSS = $null
    $script:ZsSession.ZscalerConnected  = $false

    return [PSCustomObject]@{ Disconnected = $true }
}
