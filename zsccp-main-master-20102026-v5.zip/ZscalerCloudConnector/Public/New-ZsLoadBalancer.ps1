<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (New-ZsLoadBalancer).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
    .PARAMETER SubnetId Subnet resource ID for the load balancer frontend.
    .PARAMETER HttpProbePort TCP port for the health probe.
    .PARAMETER Zones Availability zones for the load balancer frontend IP.
    .PARAMETER Distribution Load balancer distribution mode.
    #>

function New-ZsLoadBalancer {
    <#
    .SYNOPSIS Creates internal Standard LB with HA ports rule and HTTP health probe.
    .DESCRIPTION The frontend address is the next hop for the workload route table and any spoke route
        table, and one of the addresses Zscaler Client Connector for VDI can be installed against.
        The HA ports rule matches the Terraform load-balancer module:

        - SourceIP distribution, the source IP affinity Zscaler recommends in front of the
          connectors. Azure's Default 5-tuple hash can spread a VDI session host's point-to-point
          tunnel across several connectors; SourceIP keeps everything one host sends to one address
          on one connector, while routed traffic still spreads by destination.
        - Floating IP off. A VDI client installed with the frontend as its SERVERIP addresses the
          frontend itself, and Azure rewrites that destination to the connector's own service
          address, which the connector answers on. With floating IP on, the traffic arrives still
          addressed to the frontend, which the connector does not hold, and the client's tunnel
          handshake fails.
        - No idle timeout: Azure does not support one on an internal HA ports rule that a
          user-defined route forwards into. No outbound SNAT setting: that applies only to a public
          load balancer, and connector egress is the NAT gateway's.

        An existing load balancer this module created is brought to the same rule and probe in
        place: the frontend keeps its address and every connector stays in the pool.
    .EXAMPLE
    New-ZsLoadBalancer -SubnetId $lbSubnetId
    Creates the internal Standard load balancer with an HA-ports rule and the /?cchealth probe.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$SubnetId,
        [ValidateRange(1,65535)][int]$HttpProbePort = 50000,
        [string[]]$Zones = @('1','2'),
        [ValidateSet('Default','SourceIP','SourceIPProtocol')][string]$Distribution = 'SourceIP'
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $env=$script:ZsSession.Environment; $loc=$script:ZsSession.Location; $tags=Get-ZsTags; $rgPath=Get-ZsRgPath; $api=$script:ApiVersions.Network
        $LbName = New-ZsResourceName -Prefix 'lb-zscc' -Environment $env -Location $loc
        $lbBase = "$rgPath/providers/Microsoft.Network/loadBalancers/$LbName"
        $lbUri  = "$lbBase`?api-version=$api"
        if ($Distribution -ne 'SourceIP') {
            Write-ZsLog ("Load balancer distribution '$Distribution' instead of SourceIP: Zscaler recommends source IP affinity " +
                "in front of the connectors, and VDI point-to-point tunnels can split across connectors without it.") -Level WARN
        }

        $probeName = "hp-$HttpProbePort"
        $probeProps = @{ protocol='Http'; port=$HttpProbePort; requestPath='/?cchealth'; intervalInSeconds=10; numberOfProbes=2; probeThreshold=2 }
        $ruleProps = @{
            frontendIPConfiguration=@{id="$lbBase/frontendIPConfigurations/fe-zscc"}
            backendAddressPool=@{id="$lbBase/backendAddressPools/be-zscc"}
            probe=@{id="$lbBase/probes/$probeName"}
            protocol='All'; frontendPort=0; backendPort=0
            enableFloatingIP=$false
            loadDistribution=$Distribution
        }

        $check = Test-ArmResource -Uri $lbUri
        if ($check.Exists) {
            $lb = $check.Resource; Write-ZsLog "LB $LbName verified"
            $lbOwned = Test-ZsModuleOwned -Resource $lb
            Add-ZsManifestResource -Type 'LoadBalancer' -Name $LbName -ResourceId $lb.id -PreExisting:(-not $lbOwned)

            # Reconcile the rule and probe in place: GET, change only those, PUT the whole load
            # balancer back, so the frontend address and the backend pool's members are untouched.
            $drift = [System.Collections.Generic.List[string]]::new()
            $liveRule = @(Get-ZsPropertyValue $lb 'properties.loadBalancingRules' | Where-Object { $_ -and $_.name -eq 'rule-haports' }) | Select-Object -First 1
            $liveProbe = @(Get-ZsPropertyValue $lb 'properties.probes' | Where-Object { $_ -and $_.name -eq $probeName }) | Select-Object -First 1
            if (-not $liveRule) { $drift.Add('rule-haports missing') }
            else {
                $rp = $liveRule.properties
                $flt = [bool](Get-ZsPropertyValue $rp 'enableFloatingIP')
                $dist = [string](Get-ZsPropertyValue $rp 'loadDistribution')
                $snat = [bool](Get-ZsPropertyValue $rp 'disableOutboundSnat')
                $probeRef = [string](Get-ZsPropertyValue $rp 'probe.id')
                if ($flt) { $drift.Add('floating IP on') }
                if ($dist -ne $Distribution) { $drift.Add("distribution $dist") }
                if ($snat) { $drift.Add('outbound SNAT setting on an internal rule') }
                if ($probeRef -notlike "*/probes/$probeName") { $drift.Add("probe $(($probeRef -split '/')[-1])") }
            }
            if (-not $liveProbe) { $drift.Add("$probeName missing") }
            else {
                $pp = $liveProbe.properties
                foreach ($k in @('protocol','port','requestPath','intervalInSeconds','numberOfProbes','probeThreshold')) {
                    $v = Get-ZsPropertyValue $pp $k
                    if ("$v" -ne "$($probeProps[$k])") { $drift.Add("probe $k $v") }
                }
            }

            if ($drift.Count -gt 0) {
                if (-not $lbOwned) {
                    Write-ZsLog ("LB $LbName differs from this module's rule ($($drift -join '; ')) but carries no managed-by tag of this " +
                        "deployment, so it is left as it is.") -Level WARN
                } elseif ($PSCmdlet.ShouldProcess($LbName, "Reconcile HA ports rule and probe ($($drift -join '; '))")) {
                    $props = $lb.properties
                    $probes = [System.Collections.Generic.List[object]]::new()
                    foreach ($p in @(Get-ZsPropertyValue $props 'probes' | Where-Object { $_ -and $_.name -ne $probeName })) { $probes.Add($p) }
                    $probes.Add(@{ name=$probeName; properties=$probeProps })
                    $rules = [System.Collections.Generic.List[object]]::new()
                    foreach ($r in @(Get-ZsPropertyValue $props 'loadBalancingRules' | Where-Object { $_ -and $_.name -ne 'rule-haports' })) { $rules.Add($r) }
                    $rules.Add(@{ name='rule-haports'; properties=$ruleProps })
                    $props | Add-Member -NotePropertyName 'probes' -NotePropertyValue $probes.ToArray() -Force
                    $props | Add-Member -NotePropertyName 'loadBalancingRules' -NotePropertyValue $rules.ToArray() -Force
                    Invoke-ArmPut -Uri $lbUri -Body @{ location=$lb.location; tags=$tags; sku=$lb.sku; properties=$props } | Out-Null
                    $lb = Wait-ArmProvision -Uri $lbUri -Label $LbName
                    Write-ZsLog "LB $LbName reconciled: $($drift -join '; ') -> floating IP off, $Distribution distribution, /?cchealth on $HttpProbePort"
                }
            }
        } elseif ($PSCmdlet.ShouldProcess($LbName, 'Create internal load balancer')) {
            # Frontend zones follow Zscaler's logic: a single specified zone pins the frontend there;
            # otherwise the frontend is zone-redundant across zones 1-3 so it survives a zone failure.
            [string[]]$feZones = if ($Zones.Count -eq 1) { $Zones[0] } else { @('1','2','3') }
            Invoke-ArmPut -Uri $lbUri -Body @{
                location=$loc; tags=$tags; sku=@{name='Standard';tier='Regional'}
                properties=@{
                    frontendIPConfigurations=@(@{ name='fe-zscc'; zones=$feZones; properties=@{ privateIPAllocationMethod='Dynamic'; subnet=@{id=$SubnetId} } })
                    backendAddressPools=@(@{ name='be-zscc' })
                    probes=@(@{ name=$probeName; properties=$probeProps })
                    loadBalancingRules=@(@{ name='rule-haports'; properties=$ruleProps })
                }
            } | Out-Null
            $lb = Wait-ArmProvision -Uri $lbUri -Label $LbName
            Add-ZsManifestResource -Type 'LoadBalancer' -Name $LbName -ResourceId $lb.id
        } else { return [PSCustomObject]@{ LbName=$LbName; LbId='(load balancer created at deploy time)'; FrontendIp='192.0.2.1'; BackendId='(whatif)'; ProbePort=$HttpProbePort } }

        $feIp = ''; try { $feIp = $lb.properties.frontendIPConfigurations[0].properties.privateIPAddress } catch { Write-ZsLog 'Could not read LB frontend IP' -Level WARN }
        $beId = ''; try { $beId = $lb.properties.backendAddressPools[0].id } catch { Write-ZsLog 'Could not read LB backend pool ID' -Level WARN }
        Add-ZsManifestOutput -Key 'LoadBalancerFrontendIp' -Value $feIp

        return [PSCustomObject]@{ LbName=$LbName; LbId=$lb.id; FrontendIp=$feIp; BackendId=$beId; ProbePort=$HttpProbePort }
    }
}
