<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Test-ZsPrerequisites).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Test-ZsPrerequisites {
    <#
    .SYNOPSIS Validates subscription state, resource providers, EncryptionAtHost, marketplace terms, image availability, and (when supplied) that the region supports the requested availability zones for the chosen VM size.
    .PARAMETER RegisterEncryptionAtHost Auto-registers the EncryptionAtHost feature if not already registered.
    .PARAMETER AcceptMarketplaceTerms Auto-accepts CC marketplace image terms if not already accepted.
    .PARAMETER VmSize The VM size to validate zone support for. When supplied with -Zones, the region/zone/size combination is checked against Microsoft.Compute/skus.
    .PARAMETER Zones The availability zones the deployment intends to use. Validated against what the region and VM size actually support.
    .EXAMPLE
    Test-ZsPrerequisites -RegisterEncryptionAtHost -AcceptMarketplaceTerms
    Validates the subscription and registers the EncryptionAtHost feature and accepts marketplace terms if needed.
    .EXAMPLE
    Test-ZsPrerequisites -VmSize Standard_D2s_v3 -Zones 1,2
    Additionally verifies that the session's region offers zones 1 and 2 for that VM size.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [switch]$RegisterEncryptionAtHost,
        [switch]$AcceptMarketplaceTerms,
        [string]$VmSize = '',
        [string[]]$Zones = @(),
        [ValidateSet('Vendor','Module')][string]$FunctionPackage = 'Vendor',
        # Where the Vendor package runs from. With a URL the platform fetches it and no local copy is
        # needed; empty means the copy in FunctionApp/vendor is zip-deployed, so it must be there.
        [AllowEmptyString()][string]$FunctionPackageUrl = $script:ZsVendorPackageUrl,
        [ValidateSet('Greenfield','Brownfield')][string]$Mode = 'Greenfield'
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $subPath = Get-ZsSubscriptionPath; $p = 0; $f = 0
        $skipped = [System.Collections.Generic.List[string]]::new()

        # A brownfield deployment may run as an identity holding rights only on its resource group.
        # Subscription-level reads legitimately return 403 for such an identity, and several of the
        # checks below are subscription-level by nature: they are reported as not applicable rather
        # than as failures, because failing them would block a deployment that would have succeeded.
        $subScoped = ($Mode -eq 'Greenfield')

        if ($subScoped) {
            try {
                $sub = Invoke-ArmGet -Uri "$subPath`?api-version=$($script:ApiVersions.Subscription)"
                if ($sub.state -eq 'Enabled') { $p++ } else { $f++; Write-ZsLog "Subscription state is $($sub.state), not Enabled" -Level WARN }
            } catch {
                $f++; Write-ZsLog "Subscription state could not be read: $($_.Exception.Message)" -Level WARN
            }
        } else {
            $skipped.Add('subscription state')
        }

        $providers = @('Microsoft.Compute','Microsoft.Network','Microsoft.ManagedIdentity','Microsoft.KeyVault','Microsoft.MarketplaceOrdering','Microsoft.Web','Microsoft.Storage','Microsoft.Insights','Microsoft.OperationalInsights','Microsoft.Authorization')
        $unregistered = [System.Collections.Generic.List[string]]::new()
        foreach ($rp in $providers) {
            if (-not $subScoped) { break }
            try {
                $prov = Invoke-ArmGet -Uri "$subPath/providers/$rp`?api-version=$($script:ApiVersions.Providers)"
                if ($prov.registrationState -eq 'Registered') { $p++ }
                elseif ($WhatIfPreference) {
                    # The register POST below is suppressed at the ARM layer under -WhatIf, so
                    # polling for the state change would wait 240s per provider for a registration
                    # that was never requested, and then report it as stuck. Say what would happen
                    # and move on; the dry run's report stays accurate.
                    Write-ZsLog "What if: would register resource provider $rp"
                    $p++
                }
                else {
                    Write-ZsLog "Registering $rp"
                    Invoke-ArmPost -Uri "$subPath/providers/$rp/register?api-version=$($script:ApiVersions.Providers)" | Out-Null
                    # Poll until registered (up to 240s per provider)
                    $waited = 0
                    do {
                        Start-Sleep -Seconds 10; $waited += 10
                        $chk = Invoke-ArmGet -Uri "$subPath/providers/$rp`?api-version=$($script:ApiVersions.Providers)"
                    } while ($chk.registrationState -ne 'Registered' -and $waited -lt 240)
                    if ($chk.registrationState -eq 'Registered') { $p++; Write-ZsLog "$rp registered" }
                    else { $f++; Write-ZsLog "$rp registration is still pending after 240s; it may complete on its own — re-run this check shortly" -Level WARN }
                }
            } catch {
                $cls = Resolve-ZsArmFailure -ErrorRecord $_
                if ($cls.Kind -eq 'Permission') {
                    # Registration is subscription level; an identity without it cannot self-serve.
                    $unregistered.Add($rp)
                    Write-ZsLog "Cannot read or register provider ${rp}: the identity lacks subscription-level provider permissions" -Level WARN
                } else {
                    $f++; Write-ZsLog "Provider check for $rp failed: $($cls.Detail)" -Level WARN
                }
            }
        }
        if (-not $subScoped) { $skipped.Add('resource provider registration') }
        if ($unregistered.Count -gt 0) {
            $f++
            Write-ZsLog ("Resource providers could not be verified or registered: $($unregistered -join ', '). " +
                "Provider registration is a subscription-level action; ask a subscription Contributor or Owner to register them once, then re-run.") -Level WARN
        }

        if (-not $subScoped) { $skipped.Add('EncryptionAtHost feature registration') }
        if ($subScoped) {
        try {
            $featBase = "$subPath/providers/Microsoft.Features/providers/Microsoft.Compute/features/EncryptionAtHost"
            $feat = Invoke-ArmGet -Uri "$featBase`?api-version=$($script:ApiVersions.Features)"
            if ($feat.properties.state -eq 'Registered') { $p++ }
            elseif ($RegisterEncryptionAtHost) {
                Invoke-ArmPost -Uri "$featBase/register?api-version=$($script:ApiVersions.Features)" | Out-Null
                # Under -WhatIf the POST above is suppressed, so the claim has to match what happened.
                if ($WhatIfPreference) { Write-ZsLog 'What if: would request EncryptionAtHost feature registration' }
                else { Write-ZsLog 'EncryptionAtHost feature registration requested; propagation can take several minutes' -Level WARN }
                $p++
            }
            else { $f++; Write-ZsLog 'EncryptionAtHost is not registered on this subscription. Re-run with -RegisterEncryptionAtHost, or have a subscription Owner register it.' -Level WARN }
        } catch { $f++; Write-ZsLog "EncryptionAtHost feature check failed: $($_.Exception.Message)" -Level WARN }
        }

        # Permissions are established by Test-ZsAccess, which reads the identity's effective actions
        # at the scope the deployment actually writes to and evaluates Azure Policy alongside them.
        # Probing individual reads here would duplicate that with a weaker signal, and would report a
        # resource-group-scoped brownfield identity as broken for failing subscription-level reads it
        # was never meant to hold.

        $img = $script:CcImage
        $termUri = "$subPath/providers/Microsoft.MarketplaceOrdering/offerTypes/VirtualMachine/publishers/$($img.Publisher)/offers/$($img.Offer)/plans/$($img.Sku)/agreements/current"
        try {
            $terms = Invoke-ArmGet -Uri "$termUri`?api-version=$($script:ApiVersions.Marketplace)"
            if ($terms.properties.accepted) { $p++ }
            elseif ($AcceptMarketplaceTerms) {
                $terms.properties.accepted = $true
                Invoke-ArmPut -Uri "$termUri`?api-version=$($script:ApiVersions.Marketplace)" -Body $terms | Out-Null
                $p++
                if ($WhatIfPreference) { Write-ZsLog 'What if: would accept the Cloud Connector marketplace image terms' }
                else { Write-ZsLog 'Accepted the Cloud Connector marketplace image terms' }
            }
            else { $f++; Write-ZsLog "Marketplace terms for the Cloud Connector image have not been accepted. Re-run with -AcceptMarketplaceTerms, or have a subscription Owner accept them once." -Level WARN }
        } catch {
            $cls = Resolve-ZsArmFailure -ErrorRecord $_
            $f++
            if ($cls.Kind -eq 'Permission') {
                Write-ZsLog ("Marketplace image terms could not be checked or accepted: accepting terms is a subscription-level " +
                    "operation and this identity holds rights only on the resource group. Have a subscription Owner accept the " +
                    "Cloud Connector image terms once, then re-run.") -Level WARN
            } else {
                Write-ZsLog "Marketplace terms check failed: $($cls.Detail)" -Level WARN
            }
        }

        try {
            $imgUri = "$subPath/providers/Microsoft.Compute/locations/$($script:ZsSession.Location)/publishers/$($img.Publisher)/artifacttypes/vmimage/offers/$($img.Offer)/skus/$($img.Sku)/versions?api-version=$($script:ApiVersions.Compute)"
            $versions = Invoke-ArmGet -Uri $imgUri
            if ($versions.Count -gt 0) { $p++ } else { $f++; Write-ZsLog "The Cloud Connector image is not published in $($script:ZsSession.Location). Choose a region where it is offered." -Level WARN }
        } catch {
            $f++
            Write-ZsLog "Cloud Connector image availability in $($script:ZsSession.Location) could not be confirmed: $((Resolve-ZsArmFailure -ErrorRecord $_).Detail)" -Level WARN
        }

        # Validate region/zone/SKU compatibility.
        if ($VmSize -and $Zones.Count -gt 0) {
            $region = $script:ZsSession.Location
            $regionCheck = Test-ZsRegion -Region $region

            if (-not $regionCheck.Exists) {
                $f++
                $hint = if ($regionCheck.Suggestions.Count -gt 0) { " Did you mean: $($regionCheck.Suggestions -join ', ')?" } else { '' }
                Write-ZsLog "Region '$region' is not valid or available for this subscription.$hint Set a valid region on Connect-ZscalerAzure -Location." -Level WARN
            }
            elseif (-not $regionCheck.HasZones) {
                $f++
                Write-ZsLog "Region '$region' ($($regionCheck.DisplayName)) has no availability zones, but your config requests zones $($Zones -join ', '). Either deploy to a zone-enabled region, or remove the Zones from your config for a non-zonal deployment." -Level WARN
            }
            else {
                $zoneInfo = Test-ZsZoneSupport -VmSize $VmSize
                if (-not $zoneInfo.SizeFound) {
                    $f++; Write-ZsLog "VM size $VmSize is not offered in $region. Choose a size available in this region (az vm list-skus --location $region --size $VmSize)."
                }
                elseif (-not $zoneInfo.RegionHasZones) {
                    $f++; Write-ZsLog "Region $region offers zones, but not for VM size $VmSize. Choose a different VM size, or a region that offers $VmSize zonally. Requested zones: $($Zones -join ', ')."
                }
                else {
                    $unsupported = @($Zones | Where-Object { $_ -notin $zoneInfo.SupportedZones })
                    if ($unsupported.Count -gt 0) {
                        $f++
                        $restrictNote = if ($zoneInfo.Restricted) { ' (one or more zones are restricted for this subscription)' } else { '' }
                        Write-ZsLog "Zone(s) $($unsupported -join ', ') not available for $VmSize in $region$restrictNote. Supported zones here: $($zoneInfo.SupportedZones -join ', '). Adjust the Zones in your config." -Level WARN
                    }
                    else {
                        $p++; Write-ZsLog "Region/zone check passed: $region supports zones $($Zones -join ', ') for $VmSize"
                    }
                }
            }
        }

        # The check count varies with parameters; name what was skipped so a bare run and a
        # deployment-time run are comparable at a glance.
        $note = if ($VmSize -and $Zones.Count -gt 0) { '' } else { ' (zone check skipped: pass -VmSize and -Zones to include it)' }
        if ($skipped.Count -gt 0) {
            Write-ZsLog "Not applicable at resource group scope, so not checked: $($skipped -join ', '). These are subscription-level and must already be in place." -Level WARN
        }
        # The lifecycle artifact. In Vendor mode (the supported position) the deployment
        # publishes Zscaler's own package, so its absence must fail here rather than at publish
        # time deep in the run.
        if ($FunctionPackage -eq 'Vendor' -and $FunctionPackageUrl) {
            $p++; Write-ZsLog "Vendor function package: runs from $FunctionPackageUrl (no local copy needed)"
        } elseif ($FunctionPackage -eq 'Vendor') {
            $vp = Test-ZsVendorPackage
            if ($vp.Valid) { $p++; Write-ZsLog "Vendor function package present$(if ($vp.Version) { " (v$($vp.Version), $($vp.SizeKB) KB)" })" }
            else { $f++; Write-ZsLog "Zscaler function package check failed: $($vp.Reason) ($($vp.Path)). Copy zscaler_cc_function_app.zip from Zscaler's terraform module (modules/terraform-zscc-function-app-azure/) into this module's FunctionApp/vendor folder, run from Zscaler's published URL (the default -FunctionPackageUrl), or deploy with -FunctionPackage Module." }
        } else { $p++; Write-ZsLog "FunctionPackage=Module: deploying this module's function instead of Zscaler's supported artifact" }

        $ready = $f -eq 0
        Write-ZsLog "Prerequisites: $p passed, $f failed, ready=$ready$note"
        return [PSCustomObject]@{ Passed=$p; Failed=$f; Ready=$ready }
    }
}
