<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Remove-ZsDeployment).

.DESCRIPTION
    Teardown removes what this module created and nothing else.

    The resource group is not the unit of deletion. A brownfield deployment goes into a resource
    group the customer already owned, which may hold their network, their workloads and their other
    services; deleting that group to remove a set of connectors destroys infrastructure the module
    never created and was never asked to manage. Teardown therefore works from an inventory —
    the deployment manifest, or the module's own deployment tag when no manifest is at hand — and
    deletes only the resources on it, together with the role assignments and custom role definitions
    the deployment introduced.

    Greenfield deployments create their own resource group, so removing it is a legitimate thing to
    want. It is never implied: -RemoveResourceGroup asks for it explicitly, and the switch is
    refused on a brownfield deployment no matter how it is invoked.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Remove-ZsDeployment {
    <#
    .SYNOPSIS Removes the resources this deployment created, leaving the resource group in place.
    .DESCRIPTION Deletes the deployment's resources in reverse dependency order, then the role
        assignments it made and any custom role definitions it created that nothing else still uses.
        The resource group itself is preserved unless -RemoveResourceGroup is given, which is
        accepted only for a greenfield deployment that created the group in the first place.

        What gets deleted is decided from the deployment manifest when one is available. Without a
        manifest, the module falls back to the resources carrying its own deployment tag — never to
        "everything in the resource group", which in a shared group would be someone else's estate.
    .PARAMETER ResourceGroupName Resource group holding the deployment. Defaults to the session's.
    .PARAMETER ManifestPath Deployment manifest to read the inventory from. Defaults to the session's.
    .PARAMETER RemoveResourceGroup Also delete the resource group. Greenfield deployments only:
        refused when the group was not created by this module.
    .PARAMETER Force Skip the confirmation prompt. Still respects -WhatIf.
    .PARAMETER TimeoutSeconds Maximum time to wait for deletions to complete. Default 900.
    .OUTPUTS PSCustomObject: Removed, Failed, Skipped, ResourceGroup, ResourceGroupRemoved.
    .EXAMPLE
    Remove-ZsDeployment -Force
    Removes the deployment's resources and identities, leaving the resource group in place.
    .EXAMPLE
    Remove-ZsDeployment -RemoveResourceGroup -Force
    Also deletes the resource group, if this module created it.
    #>
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High', PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [string]$ResourceGroupName = '',
        [string]$ManifestPath = '',
        [switch]$RemoveResourceGroup,
        [switch]$Force,
        [int]$TimeoutSeconds = 900
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $subId = $script:ZsSession.SubscriptionId
        if (-not $ResourceGroupName) { $ResourceGroupName = $script:ZsSession.ResourceGroupName }
        $rgPath = "/subscriptions/$subId/resourceGroups/$ResourceGroupName"

        $rgCheck = Test-ArmResource -Uri "$rgPath`?api-version=$($script:ApiVersions.ResourceGroup)"
        if (-not $rgCheck.Exists) {
            Write-ZsLog "Resource group $ResourceGroupName not found; nothing to remove"
            return [PSCustomObject]@{ Removed=0; Failed=0; Skipped=0; ResourceGroup=$ResourceGroupName; ResourceGroupRemoved=$false; Reason='NotFound' }
        }

        # Inventory
        # A -ManifestPath the operator named and that does not exist is a mistake, not an absence.
        # Falling through to the tag scan here would delete from a different and wider inventory than the
        # one asked for, without saying so — the failure mode of a mistyped path is silent breadth.
        if ($PSBoundParameters.ContainsKey('ManifestPath') -and $ManifestPath -and -not (Test-Path -LiteralPath $ManifestPath)) {
            Write-ZsError -Cmdlet $PSCmdlet -ErrorId 'ZsManifestNotFound' -Category ObjectNotFound -Message (
                "Manifest not found: $ManifestPath`n" +
                "  Teardown will not fall back to scanning by deployment tag when a manifest was named: that is a " +
                "different inventory than the one requested. Correct the path, or omit -ManifestPath to use the tag scan deliberately.`n" +
                "  Nothing has been removed.")
        }
        $inventory  = Get-ZsTeardownInventory -ResourceGroupPath $rgPath -ManifestPath $ManifestPath
        $resources  = @($inventory.Resources)
        $assignments = @($inventory.RoleAssignments)
        $roleDefs   = @($inventory.RoleDefinitions)
        $ownsGroup  = [bool]$inventory.OwnsResourceGroup

        if ($resources.Count -eq 0 -and $assignments.Count -eq 0 -and $roleDefs.Count -eq 0) {
            Write-ZsLog "No resources belonging to this deployment were found in $ResourceGroupName"
            return [PSCustomObject]@{ Removed=0; Failed=0; Skipped=0; ResourceGroup=$ResourceGroupName; ResourceGroupRemoved=$false; Reason='Empty' }
        }

        Write-ZsLog "Teardown of $ResourceGroupName ($($inventory.Source)): $($resources.Count) resource(s), $($assignments.Count) role assignment(s), $($roleDefs.Count) custom role(s)"
        $byType = @{}
        foreach ($r in $resources) {
            $t = 'resource'; try { $t = ($r.Type -split '/')[-1] } catch { }
            if (-not $byType.ContainsKey($t)) { $byType[$t] = [System.Collections.Generic.List[string]]::new() }
            $byType[$t].Add($r.Name)
        }
        foreach ($t in ($byType.Keys | Sort-Object)) { Write-ZsLog "  ${t}: $($byType[$t] -join ', ')" }

        # A manifest whose own run did not finish describes only what that run got to. Anything it
        # created or adopted after the failure point is absent, and teardown has no way to know it
        # existed — so an operator reading a clean result here should know the list may be short.
        $mStatus = ''
        try { $mStatus = [string]$inventory.ManifestStatus } catch { }
        if ($mStatus -and $mStatus -ne 'Succeeded') {
            Write-ZsLog ("This manifest reports Status=$mStatus. It lists what that run reached before it stopped, " +
                "which may not be everything it created. Resources missing from the list will be left behind, still " +
                "tagged and still deployed. Compare against the group before treating the teardown as complete.") -Level WARN
        }

        # The resource group's own fate
        if ($RemoveResourceGroup -and -not $ownsGroup) {
            Write-ZsError -Cmdlet $PSCmdlet -ErrorId 'ZsRgNotOwned' -Category InvalidOperation -Message (
                "-RemoveResourceGroup was requested, but resource group '$ResourceGroupName' was not created by this module.`n" +
                "  This is a brownfield deployment: the group predates it and may hold resources the deployment never created.`n" +
                "  Re-run without -RemoveResourceGroup to remove only this deployment's resources, or delete the group yourself if that is genuinely what you want.`n" +
                "  Nothing has been removed.")
        }

        $target = if ($RemoveResourceGroup) { "$ResourceGroupName and all $($resources.Count) deployment resources" }
                  else { "$($resources.Count) resources and $($assignments.Count) role assignments in $ResourceGroupName" }
        if ($Force) { $ConfirmPreference = 'None' }
        if (-not $PSCmdlet.ShouldProcess($target, 'Remove Cloud Connector deployment')) {
            return [PSCustomObject]@{ Removed=0; Failed=0; Skipped=0; ResourceGroup=$ResourceGroupName; ResourceGroupRemoved=$false; Reason='Cancelled' }
        }

        Suspend-ZsSleep
        $removed = 0; $failed = 0; $skipped = 0; $rgRemoved = $false
        try {
            # Locks
            # The group is listed once, rather than each lock's URI being guessed from a manifest
            # entry, because a lock that has to be guessed at is a lock that cannot be reported.
            #
            # Every lock is removed before any delete is attempted, because a lock discovered
            # mid-teardown is a delete failing with ScopeLocked and a run stopping partway. Which
            # locks qualify depends on whose ground this is:
            #
            #   - A group this module created exists for this deployment and nothing else, so every
            #     lock in it is removed, whoever wrote it — including one added by hand since the
            #     deploy. Sparing it would only strand a group whose one purpose is over.
            #   - In a BringYourOwn group, locks on manifest resources are removed — that includes
            #     resources this run adopted rather than created: it locked those, so it unlocks
            #     them. A lock on anything else in a shared group is someone else's protection and
            #     is left in place, named up front rather than inferred from a ScopeLocked later,
            #     because deleting it is precisely what that lock exists to prevent.
            #   - -RemoveResourceGroup removes every lock: the whole group is going.
            #
            # Removing a lock is not the same as deleting what it protected: an adopted resource is
            # unlocked here and then skipped by the delete loop below.
            $lockList = @()
            try {
                $found = Invoke-ArmGet -Uri "$rgPath/providers/Microsoft.Authorization/locks?api-version=$($script:ApiVersions.Lock)" -AllowNotFound
                if ($found -and $found.PSObject.Properties['value']) { $lockList = @($found.value) }
            } catch {
                # Most often a missing Microsoft.Authorization/locks/read. A lock may then be present
                # but unseen, and the ScopeLocked further down would have no stated cause.
                if ($_.FullyQualifiedErrorId -notmatch 'NotFound|Http404') {
                    Write-ZsLog ("Could not read the locks in $ResourceGroupName`: $($_.Exception.Message) " +
                        "A locked resource will fail to delete with ScopeLocked.") -Level WARN
                }
            }

            $onManifest = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
            foreach ($r in $resources) { if ($r.ResourceId) { $null = $onManifest.Add([string]$r.ResourceId) } }
            $locksLeft = [System.Collections.Generic.List[string]]::new()

            # What was done with each lock, kept so that a ScopeLocked further down can be answered
            # with a fact instead of a guess. Reporting "you need locks/delete" for a lock that was
            # never attempted sends an operator after a permission they already hold.
            $lockFate = @{}

            foreach ($lock in $lockList) {
                # Read defensively: Set-StrictMode -Version Latest turns a member ARM did not return
                # into a terminating error, which here would report a lock that was in fact removed
                # as one that could not be.
                $lockId = ''; $lockName = ''
                if ($lock -and $lock.PSObject.Properties['id'])   { $lockId   = [string]$lock.id }
                if ($lock -and $lock.PSObject.Properties['name']) { $lockName = [string]$lock.name }
                if (-not $lockId) { continue }

                $scope      = ($lockId -split '/providers/Microsoft.Authorization/locks/')[0]
                $lockTarget = ($scope -split '/')[-1]
                if (-not $lockTarget) { $lockTarget = $ResourceGroupName }

                # A lock on the group itself refuses every delete inside it. In a group this module
                # did not create it is the group owner's, like any other lock there: it is left in
                # place and named, and the deletes under it fail with ScopeLocked until its owner
                # lifts it.
                $groupScopeLock = ($scope.TrimEnd('/') -ieq $rgPath.TrimEnd('/'))
                $covered = $RemoveResourceGroup -or $ownsGroup -or $onManifest.Contains($scope)
                if (-not $covered) {
                    $locksLeft.Add($(if ($groupScopeLock) { "'$lockName' on the resource group itself, which refuses every delete in it" } else { "'$lockName' on $lockTarget" }))
                    $lockFate[$scope] = "lock '$lockName' was left in place: $lockTarget is not on this deployment's " +
                        "manifest and the group is not this module's, so removing its lock is not this teardown's to do. " +
                        "No removal was attempted, and this is not a permissions problem."
                    continue
                }
                try {
                    Invoke-ArmDelete -Uri "$lockId`?api-version=$($script:ApiVersions.Lock)" -AllowNotFound | Out-Null
                    Write-ZsLog "Removed lock '$lockName' on $lockTarget"
                    $lockFate[$scope] = "lock '$lockName' was removed by this run, so the lock still in force is one " +
                        "this teardown did not place and has not seen — check for a lock added since it started."
                } catch {
                    # Only an authorization failure is a permissions problem. Naming a missing role
                    # unconditionally sends an operator after one they already hold.
                    $denied = ($_.FullyQualifiedErrorId -match 'Unauthorized|Forbidden|Http40[13]') -or
                              ("$($_.Exception.Message)" -match 'AuthorizationFailed|does not have authorization|Forbidden')
                    $why = if ($denied) {
                        " Removing a lock requires Microsoft.Authorization/locks/delete, which Contributor does not carry —" +
                        " it comes from the custom deployer role in the README, or from Owner or User Access Administrator."
                    } else { '' }
                    Write-ZsLog ("Could not remove lock '$lockName' on $lockTarget`: $($_.Exception.Message)" +
                        "$why $lockTarget and anything scoped under it will fail to delete with ScopeLocked.") -Level WARN
                    $lockFate[$scope] = "lock '$lockName' could not be removed$(if ($denied) { ' (authorization denied)' } else { '' }): $($_.Exception.Message)"
                }
            }
            if ($locksLeft.Count -gt 0) {
                Write-ZsLog ("$($locksLeft.Count) lock(s) in $ResourceGroupName are on resources this deployment did not " +
                    "create and are left in place: $($locksLeft -join ', '). A delete that writes underneath one of those " +
                    "scopes — a private endpoint's connection proxy, for instance — will fail with ScopeLocked. Remove the " +
                    "lock yourself if that is what you intend.")
            }

            # Role assignments
            # Removed before the identities they reference, so nothing is left pointing at a
            # principal that no longer exists. Assignments the deployment merely found in place are
            # left alone: it did not create them and does not get to remove them.
            foreach ($a in $assignments) {
                if ($a.PreExisting) {
                    Write-ZsLog "Role assignment $($a.Name) predates this deployment; left in place" -Level DEBUG
                    $skipped++
                    continue
                }
                if (-not $PSCmdlet.ShouldProcess($a.Name, 'Remove role assignment')) { $skipped++; continue }
                try {
                    Invoke-ArmDelete -Uri "$($a.ResourceId)?api-version=$($script:ApiVersions.Authorization)" -AllowNotFound | Out-Null
                    $removed++
                    Write-ZsLog "Removed role assignment $($a.Name)" -Level DEBUG
                } catch {
                    $failed++
                    $null = Write-ZsArmFailure -ErrorRecord $_ -Context "Removing role assignment $($a.Name)"
                }
            }

            # Resources
            # Key Vaults are noted rather than purged. Purge protection — on by default here — is a
            # deliberate guarantee that a deleted vault stays recoverable for its retention period,
            # and Azure enforces it: the vault cannot be purged early even by an Owner. Silently
            # deleting one and moving on leaves an operator puzzled when the name will not free up,
            # so retained vaults are named and the reason given.
            $retainedVaults = [System.Collections.Generic.List[string]]::new()

            # The order below encodes every dependency this module knows about, but it cannot encode
            # one it was never told of — a reference added by a later Azure feature, or by something
            # outside the deployment. Those announce themselves as a resource still referencing this
            # one, and by the end of the pass the referencing resource is usually gone. So ordering
            # failures alone are collected and tried once more, and nothing else is: a lock, a policy
            # denial and a missing role are all just as true the second time, and repeating them
            # buys nothing but noise. One extra pass, not a loop to exhaustion — if the second
            # attempt still finds a reference, the dependency is real and belongs in the table above.
            $attempted = [System.Collections.Generic.List[object]]::new()
            $deferred  = [System.Collections.Generic.List[object]]::new()
            # Deleting the group deletes what is in it, and Resource Manager works out the order
            # itself — children first, then resources that manage other resources, then the rest,
            # waiting on dependencies and retrying. That is a better dependency resolver than the
            # table below can ever be, because it is the one Azure enforces. Walking each resource
            # by hand first would take the long way to the same end state, through every ordering
            # hazard, and would still not reach what the manifest cannot see: the instances, disks
            # and interfaces Azure created underneath the resources this module made.
            # Platform state (marketplace terms, provider and feature registrations, Defender
            # settings) never appears here: the inventory refuses such entries outright, so the
            # teardown has no platform-state phase - there is nothing to name, skip, or count.
            $deletable = $resources

            # Brownfield fallback for manifests written before subnets were recorded. When the
            # virtual network is not this deployment's to delete, its subnets may still reference
            # a NAT gateway, route table, or NSG that is - and Azure refuses those deletes outright
            # (InUse*CannotBeDeleted) rather than clearing the reference. The reference is removed
            # from each subnet by OMISSION: GET the subnet, remove the property from the object,
            # and PUT the whole subnet back. An explicit null is rejected by ARM with
            # InvalidRequestFormat/MissingJsonReferenceId, which is why the property is dropped
            # rather than nulled. Manifests that carry Subnet entries delete their own subnets at
            # rank 79 and never need this; the module-created subnets an old manifest cannot name
            # are left behind empty, which is noted rather than guessed at.
            $refProps = @('natGateway','routeTable','networkSecurityGroup')
            $strippable = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
            foreach ($r in $deletable) {
                if ([string]$r.Type -match '(?i)microsoft\.network/(natgateways|routetables|networksecuritygroups)$' -and $r.ResourceId) {
                    $null = $strippable.Add([string]$r.ResourceId)
                }
            }
            $hasSubnetEntries = [bool]@($deletable | Where-Object { [string]$_.Type -match '(?i)virtualnetworks/subnets$' })
            if ($strippable.Count -gt 0 -and -not $hasSubnetEntries) {
                foreach ($v in $resources) {
                    if ([string]$v.Type -notmatch '(?i)microsoft\.network/virtualnetworks$') { continue }
                    if (-not $v.PreExisting) { continue }
                    $vn = $null
                    try { $vn = Invoke-ArmGet -Uri "$($v.ResourceId)?api-version=$($script:ApiVersions.Network)" -AllowNotFound } catch { }
                    if (-not $vn -or -not $vn.PSObject.Properties['properties'] -or -not $vn.properties.PSObject.Properties['subnets']) { continue }
                    foreach ($sn in @($vn.properties.subnets)) {
                        $stripped = [System.Collections.Generic.List[string]]::new()
                        foreach ($propName in $refProps) {
                            $prop = $sn.properties.PSObject.Properties[$propName]
                            if ($prop -and $prop.Value -and $prop.Value.PSObject.Properties['id'] -and $strippable.Contains([string]$prop.Value.id)) {
                                $sn.properties.PSObject.Properties.Remove($propName)
                                $stripped.Add($propName)
                            }
                        }
                        if ($stripped.Count -eq 0) { continue }
                        if (-not $PSCmdlet.ShouldProcess($sn.name, "Detach $($stripped -join ', ')")) { continue }
                        $sUri = "$($v.ResourceId)/subnets/$($sn.name)?api-version=$($script:ApiVersions.Network)"
                        try {
                            Invoke-ArmPut -Uri $sUri -Body @{ properties = $sn.properties } | Out-Null
                            Wait-ArmProvision -Uri $sUri -Label "detach-$($sn.name)" | Out-Null
                            Write-ZsLog "Detached $($stripped -join ', ') from subnet $($sn.name): the referenced resource is being deleted and the virtual network is not"
                        } catch {
                            $null = Write-ZsArmFailure -ErrorRecord $_ -Context "Detaching $($stripped -join ', ') from subnet $($sn.name)"
                        }
                    }
                    Write-ZsLog ("Subnets this deployment created inside $($v.Name) are left in place (empty): this manifest " +
                        "predates subnet recording, so which subnets are the module's cannot be known from it. Remove them by hand if unwanted.")
                }
            }

            $queue = if ($RemoveResourceGroup) { @() } else { @(Get-ZsTeardownOrder -Resources $deletable) }
            if ($RemoveResourceGroup -and $deletable.Count -gt 0) {
                Write-ZsLog "$($deletable.Count) resource(s) will be removed with the group rather than one at a time"
            }
            for ($pass = 1; $pass -le 2; $pass++) {
                foreach ($r in $queue) {
                    if (-not $r.ResourceId) { $skipped++; continue }
                    if ($r.PreExisting) {
                        # A brought subnet stays, but the references this deployment put on it - its
                        # NSG, NAT gateway or route table - are removed by omission (GET, drop the
                        # property, PUT), or Azure refuses to delete what they point at.
                        if ($pass -eq 1 -and [string]$r.Type -match '(?i)virtualnetworks/subnets$' -and $strippable.Count -gt 0) {
                            $sn = $null
                            try { $sn = Invoke-ArmGet -Uri "$($r.ResourceId)?api-version=$($script:ApiVersions.Network)" -AllowNotFound }
                            catch { Write-ZsLog "Could not read subnet $($r.Name) to detach this deployment's references: $($_.Exception.Message)" -Level WARN }
                            if ($sn) {
                                $stripped = [System.Collections.Generic.List[string]]::new()
                                foreach ($propName in $refProps) {
                                    $prop = $sn.properties.PSObject.Properties[$propName]
                                    if ($prop -and $prop.Value -and $prop.Value.PSObject.Properties['id'] -and $strippable.Contains([string]$prop.Value.id)) {
                                        $sn.properties.PSObject.Properties.Remove($propName)
                                        $stripped.Add($propName)
                                    }
                                }
                                if ($stripped.Count -gt 0 -and $PSCmdlet.ShouldProcess($r.Name, "Detach $($stripped -join ', ')")) {
                                    try {
                                        $sUri = "$($r.ResourceId)?api-version=$($script:ApiVersions.Network)"
                                        Invoke-ArmPut -Uri $sUri -Body @{ properties = $sn.properties } | Out-Null
                                        Wait-ArmProvision -Uri $sUri -Label "detach-$($r.Name)" | Out-Null
                                        Write-ZsLog "Detached $($stripped -join ', ') from subnet $($r.Name), which predates this deployment and stays"
                                    } catch {
                                        $null = Write-ZsArmFailure -ErrorRecord $_ -Context "Detaching $($stripped -join ', ') from subnet $($r.Name)"
                                    }
                                }
                            }
                        }
                        Write-ZsLog "$($r.Name) predates this deployment; left in place"
                        $skipped++
                        continue
                    }
                    $apiVersion = Resolve-ZsTeardownApiVersion -ResourceType $r.Type
                    $isVault    = ([string]$r.Type -like 'Microsoft.KeyVault/vaults*')

                    $purgeProtected = $false
                    if ($isVault) {
                        try {
                            $v = Invoke-ArmGet -Uri "$($r.ResourceId)?api-version=$($script:ApiVersions.KeyVault)" -AllowNotFound
                            if ($v -and $v.properties -and $v.properties.PSObject.Properties['enablePurgeProtection']) {
                                $purgeProtected = [bool]$v.properties.enablePurgeProtection
                            }
                        } catch { }
                    }

                    if (-not $PSCmdlet.ShouldProcess($r.Name, "Delete $($r.Type)")) { $skipped++; continue }
                    try {
                        # The rank ordering below only holds if each delete completes before the
                        # next begins, and a scale set of instances or a Bastion deletes in ten to
                        # twenty minutes. The ceiling covers the slowest of them.
                        Invoke-ArmDelete -AsyncTimeoutSeconds 1800 -Uri "$($r.ResourceId)?api-version=$apiVersion" -AllowNotFound | Out-Null
                        $attempted.Add($r)
                        $removed++
                        if ($purgeProtected) { $retainedVaults.Add($r.Name) }
                        Write-ZsLog "Deleted $($r.Name)" -Level DEBUG
                    } catch {
                        $f = Resolve-ZsArmFailure -ErrorRecord $_

                        # Held back for the retry pass rather than reported: at this point in the run the
                        # resource holding the reference may not have been deleted yet, so the failure
                        # says more about position in the order than about the resource.
                        if ($pass -eq 1 -and $f.Kind -in @('Dependency','Transient')) {
                            $deferred.Add($r)
                            # The order above is built so this never fires: every delete is meant to
                            # succeed on its first attempt. A deferral here means a dependency the
                            # table does not know about (or platform residue such as a lingering
                            # serviceAssociationLink), so it is said at WARN, and belongs in the
                            # table once identified. The single retry pass remains as a safety net.
                            Write-ZsLog "$($r.Name): $($f.Summary). The deletion order should have prevented this; deferring for one retry as a safety net" -Level WARN
                            continue
                        }

                        $failed++
                        $null = Write-ZsArmFailure -ErrorRecord $_ -Context "Deleting $($r.Type) $($r.Name)"
                        # ARM names the scope whose lock refused this. Say what this run did about that
                        # exact lock, rather than leaving the operator to work it out from the group.
                        if ($f.Kind -eq 'Locked' -and $f.Scope) {
                            $fate = $null
                            foreach ($k in $lockFate.Keys) { if ($k -eq $f.Scope) { $fate = $lockFate[$k] } }
                            if ($fate) { Write-ZsLog "  $fate" -Level WARN }
                            else {
                                Write-ZsLog ("  No lock was found at $($f.Scope) when this run listed $ResourceGroupName, so " +
                                    "the lock refusing it was added since, or sits at a scope the listing did not cover.") -Level WARN
                            }
                        }
                    }
                }
                if ($deferred.Count -eq 0) { break }
                Write-ZsLog ("Retrying $($deferred.Count) resource(s) held back for a reference that should now be gone: " +
                    "$(($deferred | ForEach-Object { $_.Name }) -join ', ')")
                $queue    = @(Get-ZsTeardownOrder -Resources $deferred)
                $deferred = [System.Collections.Generic.List[object]]::new()
            }

            if ($retainedVaults.Count -gt 0) {
                Write-ZsLog ("Key vault(s) $($retainedVaults -join ', ') are purge protected: they are soft deleted and " +
                    "retained until their retention period expires, and cannot be purged early. Redeploying under the same " +
                    "name will fail until then — recover the vault instead, or deploy under a different name.") -Level WARN
            }

            # Custom role definitions
            # A definition is shared across every deployment in the subscription, so it is removed
            # only once nothing is assigned to it any more. A definition still in use elsewhere is
            # left alone and said so.
            foreach ($d in $roleDefs) {
                $stillUsed = Test-ZsRoleDefinitionInUse -RoleDefinitionId $d.ResourceId
                if ($stillUsed.InUse) {
                    Write-ZsLog "Custom role '$($d.Name)' still has $($stillUsed.Count) assignment(s) elsewhere in the subscription; left in place"
                    $skipped++
                    continue
                }
                if ($stillUsed.Inconclusive) {
                    Write-ZsLog "Could not confirm whether custom role '$($d.Name)' is still in use; left in place" -Level WARN
                    $skipped++
                    continue
                }
                if (-not $PSCmdlet.ShouldProcess($d.Name, 'Remove custom role definition')) { $skipped++; continue }
                try {
                    Invoke-ArmDelete -Uri "$($d.ResourceId)?api-version=$($script:ApiVersions.Authorization)" -AllowNotFound | Out-Null
                    $removed++
                    Write-ZsLog "Removed custom role definition '$($d.Name)'"
                } catch {
                    $failed++
                    $null = Write-ZsArmFailure -ErrorRecord $_ -Context "Removing custom role definition $($d.Name)"
                }
            }

            # Wait for deletions to settle
            if ($failed -eq 0 -and $attempted.Count -gt 0) {
                # Wrapped: PowerShell unrolls an empty array return to $null, and reading .Count on
                # $null throws under Set-StrictMode rather than reporting zero.
                $pending = @(Wait-ZsResourcesGone -Resources $attempted -TimeoutSeconds $TimeoutSeconds)
                if ($pending.Count -gt 0) {
                    Write-ZsLog "$($pending.Count) resource(s) still deleting after ${TimeoutSeconds}s: $($pending -join ', '). Deletion may still complete on its own." -Level WARN
                }
            }

            # Resource group
            if ($RemoveResourceGroup) {
                Write-ZsLog "Deleting resource group $ResourceGroupName (created by this module)"
                try {
                    # The group delete gets the run's own timeout budget; the existence loop
                    # below then confirms the end state rather than doing the waiting itself.
                    Invoke-ArmDelete -AsyncTimeoutSeconds $TimeoutSeconds -Uri "$rgPath`?api-version=$($script:ApiVersions.ResourceGroup)" -AllowNotFound | Out-Null
                    $sw = [System.Diagnostics.Stopwatch]::StartNew()
                    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
                        Start-Sleep -Seconds 15
                        $still = Test-ArmResource -Uri "$rgPath`?api-version=$($script:ApiVersions.ResourceGroup)"
                        if (-not $still.Exists) { $rgRemoved = $true; break }
                        Write-Progress -Activity "Deleting $ResourceGroupName" -Status "$([int]$sw.Elapsed.TotalSeconds)s elapsed" -SecondsRemaining ([int]($TimeoutSeconds - $sw.Elapsed.TotalSeconds))
                    }
                    Write-Progress -Activity "Deleting $ResourceGroupName" -Completed
                    if ($rgRemoved) {
                        Write-ZsLog "Resource group $ResourceGroupName deleted ($([int]$sw.Elapsed.TotalSeconds)s)"
                        # The resources went with the group, so the count reflects that rather than
                        # reporting nothing removed after removing everything. The marketplace
                        # agreement is subscription-scoped and not in the group, so it is not counted.
                        $removed += $deletable.Count
                    }
                    else { Write-ZsLog "Resource group $ResourceGroupName still exists after ${TimeoutSeconds}s; deletion may still be in progress" -Level WARN }
                } catch {
                    $null = Write-ZsArmFailure -ErrorRecord $_ -Context "Deleting resource group $ResourceGroupName"
                    $failed++
                }
            } else {
                Write-ZsLog "Resource group $ResourceGroupName left in place; only this deployment's resources were removed"
            }
        } finally {
            Resume-ZsSleep
        }

        if ($failed -eq 0) { Write-ZsLog "Teardown complete: $removed removed, $skipped left in place" }
        else { Write-ZsLog "Teardown finished with $failed failure(s): $removed removed, $skipped left in place" -Level WARN }

        return [PSCustomObject]@{
            Removed              = $removed
            Failed               = $failed
            Skipped              = $skipped
            ResourceGroup        = $ResourceGroupName
            ResourceGroupRemoved = $rgRemoved
            Reason               = if ($failed -eq 0) { 'Succeeded' } else { 'PartialSuccess' }
        }
    }
}

function Get-ZsTeardownInventory {
    <#
    .SYNOPSIS Builds the list of things this deployment created, and nothing else.
    .DESCRIPTION Prefers the deployment manifest, which records every resource the module created
        along with the role assignments and custom roles it introduced. Without a manifest it falls
        back to resources tagged with this module's deployment marker — a tag the module writes on
        everything it creates — so a shared resource group's other contents are never in scope.
    .OUTPUTS PSCustomObject: Resources, RoleAssignments, RoleDefinitions, OwnsResourceGroup, Source.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][string]$ResourceGroupPath,
        [string]$ManifestPath = ''
    )

    $manifestStatus = ''
    $resources   = [System.Collections.Generic.List[object]]::new()
    $assignments = [System.Collections.Generic.List[object]]::new()
    $roleDefs    = [System.Collections.Generic.List[object]]::new()
    $ownsGroup   = $false
    $seenIds     = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    $source      = ''

    # Manifest
    $manifest = $null
    if (-not $ManifestPath) {
        $candidate = Get-ZsArtifactPath -FileName "zscc-manifest-$($script:ZsSession.ShortId).json"
        if (Test-Path $candidate) { $ManifestPath = $candidate }
    }
    if ($ManifestPath -and (Test-Path $ManifestPath)) {
        try { $manifest = Get-Content -Path $ManifestPath -Raw | ConvertFrom-Json } catch {
            Write-ZsLog "Manifest at $ManifestPath could not be read: $($_.Exception.Message)" -Level WARN
        }
    }
    if (-not $manifest -and $script:ZsManifest) {
        try { $manifest = $script:ZsManifest | ConvertTo-Json -Depth 20 | ConvertFrom-Json } catch { }
    }

    if ($manifest -and $manifest.PSObject.Properties['Status']) {
        try { $manifestStatus = [string]$manifest.Status } catch { }
    }

    if ($manifest -and $manifest.PSObject.Properties['Resources']) {
        $source = "manifest $(if ($ManifestPath) { $ManifestPath } else { 'from session' })"
        foreach ($typeProp in $manifest.Resources.PSObject.Properties) {
            $type = $typeProp.Name
            foreach ($entry in @($typeProp.Value)) {
                $id   = ''; $name = ''
                try { $id = [string]$entry.ResourceId } catch { }
                try { $name = [string]$entry.Name } catch { }
                if (-not $id -or $id -notlike '/subscriptions/*') { continue }
                # A verify-and-reuse run appends its own entry for a resource the first run already
                # recorded. One delete per resource is enough; the duplicate only inflates counts.
                if ($seenIds.Contains($id)) { continue }
                $null = $seenIds.Add($id)

                # Subscription-level platform state is not part of this deployment, whatever an
                # older or hand-edited manifest says: marketplace terms, feature and provider
                # registrations, and Defender settings are the platform owner's, out of scope for
                # deploy and teardown alike. Such an entry is refused here, at inventory - it never
                # becomes a resource of this teardown, is never named, skipped, or counted, and no
                # phase of the run ever sees it.
                if ($id -match '/providers/Microsoft\.(MarketplaceOrdering|Features)/' -or
                    $id -match '/providers/Microsoft\.Security/(pricings|securityContacts)' -or
                    $id -match '^/subscriptions/[^/]+/providers/[^/]+/?$') {
                    Write-ZsLog "Manifest entry '$name' is subscription-level platform state; not part of this deployment's inventory" -Level DEBUG
                    continue
                }

                switch ($type) {
                    'ResourceGroup'  { $ownsGroup = $true; continue }
                    'RoleAssignment' {
                        $pre = $false; try { $pre = [bool]$entry.PreExisting } catch { }
                        $assignments.Add([PSCustomObject]@{ Name=$name; ResourceId=$id; PreExisting=$pre })
                        continue
                    }
                    'RoleDefinition' {
                        $roleDefs.Add([PSCustomObject]@{ Name=$name; ResourceId=$id })
                        continue
                    }
                    default {
                        $armType = Resolve-ZsArmTypeFromId -ResourceId $id
                        # A resource the deployment adopted rather than created is on the manifest so
                        # that teardown knows it was acted on — it was locked — and not so that it
                        # can be deleted.
                        $pre = $false; try { $pre = [bool]$entry.PreExisting } catch { }
                        $resources.Add([PSCustomObject]@{ Name=$name; ResourceId=$id; Type=$armType; PreExisting=$pre })
                    }
                }
            }
        }
    }

    # Tag fallback
    if ($resources.Count -eq 0) {
        $deploymentId = $script:ZsSession.DeploymentId
        if ($manifest -and $manifest.PSObject.Properties['DeploymentId']) {
            try { $deploymentId = [string]$manifest.DeploymentId } catch { }
        }
        $source = if ($source) { "$source + deployment tag" } else { 'deployment tag' }
        try {
            $all = Invoke-ArmGet -Uri "$ResourceGroupPath/resources?api-version=$($script:ApiVersions.ResourceGroup)&`$expand=tags"
            foreach ($r in @($all.value)) {
                $tagged = $false
                try {
                    if ($r.PSObject.Properties['tags'] -and $r.tags) {
                        $tid = $null
                        foreach ($tp in $r.tags.PSObject.Properties) {
                            if ($tp.Name -eq 'zscaler-deployment-id') { $tid = [string]$tp.Value }
                            if ($tp.Name -eq 'managed-by' -and [string]$tp.Value -in $script:ZsOwnedByTags -and -not $tid) { $tid = '' }
                        }
                        # Match this deployment specifically when its id is known; otherwise accept
                        # anything this module marked as its own.
                        if ($null -ne $tid) { $tagged = (-not $deploymentId) -or ($tid -eq $deploymentId) -or ($tid -eq '') }
                    }
                } catch { }
                if ($tagged) {
                    # Everything carrying this deployment's tag was created by it: the tag is written
                    # at creation, and an adopted resource keeps the tag of the run that made it.
                    $resources.Add([PSCustomObject]@{ Name=[string]$r.name; ResourceId=[string]$r.id; Type=[string]$r.type; PreExisting=$false })
                }
            }
        } catch {
            Write-ZsLog "Could not enumerate resources in the resource group: $($_.Exception.Message)" -Level WARN
        }
    }

    return [PSCustomObject]@{
        Resources         = $resources.ToArray()
        RoleAssignments   = $assignments.ToArray()
        RoleDefinitions   = $roleDefs.ToArray()
        OwnsResourceGroup = $ownsGroup
        Source            = if ($source) { $source } else { 'none' }
        ManifestStatus    = $manifestStatus
    }
}

function Resolve-ZsArmTypeFromId {
    <#
    .SYNOPSIS Extracts the ARM resource type from a resource ID.
    .DESCRIPTION Returns the namespace and type, e.g. Microsoft.Network/virtualNetworks, by taking
        the segments after the last /providers/ and skipping the interleaved resource names. Nested
        types such as virtualNetworks/subnets are preserved. A resource ID with no provider segment —
        a resource group's own ID, for instance — yields an empty string.

        The last /providers/ rather than the first, because an extension resource carries two: a
        diagnostic setting on a virtual network is
        .../Microsoft.Network/virtualNetworks/vnet/providers/Microsoft.Insights/diagnosticSettings/zscc-diag,
        and reading from the first one names the target instead of the extension. That resolved to a
        type no ordering rank matches and, worse, sent the target's api-version to the extension's
        delete. Every non-extension shape has exactly one /providers/, so they are unaffected.
    .PARAMETER ResourceId The full ARM resource ID.
    .OUTPUTS [string] The resource type, or an empty string when the ID carries none.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([string])]
    param([Parameter(Mandatory)][string]$ResourceId)
    $idx = $ResourceId.LastIndexOf('/providers/', [StringComparison]::OrdinalIgnoreCase)
    if ($idx -lt 0) { return '' }
    $parts = ($ResourceId.Substring($idx + 11) -split '/')
    if ($parts.Count -lt 2) { return '' }
    # namespace/type[/subtype...] with the names interleaved after the first pair.
    $type = $parts[0]
    for ($i = 1; $i -lt $parts.Count; $i += 2) { $type += "/$($parts[$i])" }
    return $type
}

function Get-ZsTeardownOrder {
    <#
    .SYNOPSIS Orders resources so dependants are deleted before what they depend on.
    .DESCRIPTION Azure refuses to delete a resource another still references, so compute goes before
        the interfaces it owns, interfaces before the subnets and load balancers they join, and the
        virtual network last of the networking. Anything unrecognised sorts into the middle, where a
        wrong guess costs a retry rather than a failure.

        An Application Insights component that a private link scope has taken into scope cannot be
        deleted while that scope exists: the scope holds a scopedResources child pointing at the
        component, and ARM refuses the component with 409 until it is gone. Deleting the scope takes
        its children with it, so the scope sorts ahead of the component, and the private endpoints
        that terminate on the scope sort ahead of both.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([object[]])]
    param([Parameter(Mandatory)][AllowEmptyCollection()][object[]]$Resources)

    # Each rank encodes a constraint Azure enforces, and the comment on it is the constraint. A
    # number changed without a reason to change it reintroduces a 409 that is tedious to diagnose.
    $rank = @{
        # Settings attached to another resource go first: they are extension resources on a target,
        # and an association outliving its target is orphaned and then undeletable.
        'microsoft.insights/diagnosticsettings'            = 5
        'microsoft.insights/datacollectionruleassociations' = 5

        # A flow log observes a virtual network and lives in NetworkWatcherRG, so it is neither
        # taken by a group delete nor found by the tag scan. It precedes the network it targets.
        'microsoft.network/networkwatchers/flowlogs'       = 6

        # Alert rules reference both their scope and their action group, so they precede both.
        'microsoft.insights/autoscalesettings'             = 8
        'microsoft.insights/metricalerts'                  = 8
        'microsoft.insights/scheduledqueryrules'           = 8

        'microsoft.compute/virtualmachinescalesets'        = 10
        'microsoft.compute/virtualmachines'                = 10
        'microsoft.web/sites'                              = 15
        'microsoft.web/serverfarms'                        = 20

        # A private endpoint terminates on a target and writes a connection proxy underneath it, so
        # it goes before that target and before the subnet it occupies.
        'microsoft.network/privateendpoints'               = 22

        # A private link scope holds a scopedResources child pointing at each resource it covers,
        # and ARM refuses that resource with 409 while the child exists. Deleting the scope takes
        # its children with it, so the scope precedes everything it scopes.
        'microsoft.insights/privatelinkscopes/scopedresources' = 23
        'microsoft.insights/privatelinkscopes'             = 24
        'microsoft.insights/actiongroups'                  = 25
        'microsoft.insights/components'                    = 26

        # A data collection endpoint associated with a private link scope cannot be deleted while
        # the association stands, and deleting the scope first strands it.
        'microsoft.insights/datacollectionrules'           = 27
        'microsoft.insights/datacollectionendpoints'       = 28

        'microsoft.compute/disks'                          = 30
        'microsoft.compute/availabilitysets'               = 32

        # Interfaces release the subnet they sit in and the backend pool they join.
        'microsoft.network/networkinterfaces'              = 40

        # Bastion owns AzureBastionSubnet and must clear before the virtual network.
        'microsoft.network/bastionhosts'                   = 45
        'microsoft.network/loadbalancers'                  = 50

        # A public address stays allocated to a frontend or interface until that is gone.

        'microsoft.keyvault/vaults'                        = 62
        'microsoft.storage/storageaccounts'                = 62
        'microsoft.operationalinsights/workspaces'         = 64
        'microsoft.network/dnsresolvers'                   = 66

        # A zone cannot go while a virtual network link remains, including a link whose network no
        # longer exists, so links precede zones.
        'microsoft.network/privatednszones/virtualnetworklinks' = 67
        'microsoft.network/privatednszones'                = 68

        # A forwarding ruleset links to the virtual network and references the resolver's outbound
        # endpoint, so it goes before both. Its own links and rules are children and go with it.
        # DNS Private Resolver, in Microsoft's prescribed order: the ruleset's virtual network
        # links, then the ruleset, then the endpoints (the outbound endpoint cannot be deleted
        # while the ruleset references it), then the resolver (undeletable while endpoints exist).
        'microsoft.network/dnsforwardingrulesets/virtualnetworklinks' = 63
        'microsoft.network/dnsforwardingrulesets'          = 64
        'microsoft.network/dnsresolvers/inboundendpoints'  = 65
        'microsoft.network/dnsresolvers/outboundendpoints' = 65

        # Route tables and security groups are refused while a subnet still references them.

        # Peerings before the network that carries them.
        'microsoft.network/virtualnetworks/virtualnetworkpeerings' = 78
        # Subnets are deleted explicitly, one by one, once everything inside them is gone. A
        # subnet delete is what clears its natGateway, routeTable, and networkSecurityGroup
        # references - Azure refuses to delete those resources while any subnet still points at
        # them, and does not clear the reference on their DELETE. Doing it per subnet, before
        # the network, makes the order identical whether the virtual network itself is this
        # deployment's to delete (greenfield) or someone else's to keep (brownfield).
        'microsoft.network/virtualnetworks/subnets'        = 79
        'microsoft.network/virtualnetworks'                = 80
        # Only now, with no subnet left referencing them, do the reference-holding resources
        # delete on the first attempt: the NAT gateway, then its public IP (retained by design
        # when the gateway goes, released the moment the gateway's delete completes), then
        # route tables and network security groups. Deleting these before the subnets was the
        # source of every InUse*CannotBeDeleted retry this order previously relied on.
        'microsoft.network/natgateways'                    = 82
        'microsoft.network/publicipaddresses'              = 84
        'microsoft.network/publicipprefixes'               = 84
        'microsoft.network/routetables'                    = 86
        'microsoft.network/networksecuritygroups'          = 88

        # Last of all: every resource that ran as this identity has to be gone before it is.
        'microsoft.managedidentity/userassignedidentities' = 90
    }
    # -Stable so that resources sharing a rank keep manifest order instead of an arbitrary one.
    # Two types at the same rank ordering differently between runs is how a dependency that was
    # never expressed appears to work until the day it does not.
    return @($Resources | Sort-Object -Stable -Property @{ Expression = {
        $t = ''; try { $t = ([string]$_.Type).ToLowerInvariant() } catch { }
        if ($t -and $rank.ContainsKey($t)) { $rank[$t] } else { 50 }
    }})
}

function Resolve-ZsTeardownApiVersion {
    <#
    .SYNOPSIS Returns the api-version to issue a delete against for a given resource type.
    .DESCRIPTION Each provider is versioned independently, so the delete uses the same api-version
        the module used to create the resource. An unrecognised namespace falls back to the generic
        resource api-version, which ARM accepts for a delete by resource ID.

        Microsoft.Insights is versioned per resource type, not per namespace: metricAlerts,
        scheduledQueryRules, components, actionGroups and privateLinkScopes each advertise a
        different set of supported api-versions, and no single value is valid for all of them.
        Sending one that the type does not support returns 400 NoRegisteredProviderFound — ARM's
        generic "nothing matches this type at this api-version in this location" — which reads as a
        provider registration problem but is not one. The full type is therefore matched first, and
        the values used here are the same ones the create path uses, so a resource that could be
        created can always be deleted.
    .PARAMETER ResourceType The ARM resource type, e.g. Microsoft.Network/virtualNetworks.
    .OUTPUTS [string] The api-version to use.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([string])]
    param([string]$ResourceType = '')

    # namespace/type only: a nested child (privateLinkScopes/scopedResources) is served at the same
    # api-version as its parent, so the extra segments are dropped before matching.
    $full = ''
    try { $full = ((($ResourceType -split '/') | Select-Object -First 2) -join '/').ToLowerInvariant() } catch { }

    # Per-type first: namespaces whose types do not share an api-version.
    switch ($full) {
        'microsoft.insights/metricalerts'        { return $script:ApiVersions.MetricAlert }
        'microsoft.insights/scheduledqueryrules' { return $script:ApiVersions.ScheduledQuery }
        'microsoft.insights/components'          { return $script:ApiVersions.AppInsights }
        'microsoft.insights/actiongroups'        { return $script:ApiVersions.ActionGroup }
        'microsoft.insights/privatelinkscopes'   { return $script:ApiVersions.PrivateLinkScope }
        'microsoft.insights/autoscalesettings'   { return $script:ApiVersions.Insights }
        'microsoft.insights/diagnosticsettings'  { return $script:ApiVersions.Insights }
        # Microsoft.Network is not one api-version. Private DNS and the DNS resolver family are
        # versioned separately from the core networking types, and sending the core version to a
        # private DNS zone is the NoRegisteredProviderFound case described above — which the
        # classifier would then report as an unregistered provider rather than a wrong version.
        'microsoft.network/privatednszones'       { return $script:ApiVersions.PrivateDns }
        'microsoft.network/dnsresolvers'          { return $script:ApiVersions.DnsResolver }
        'microsoft.network/dnsresolvers/inboundendpoints'  { return $script:ApiVersions.DnsResolver }
        'microsoft.network/dnsresolvers/outboundendpoints' { return $script:ApiVersions.DnsResolver }
        'microsoft.network/dnsforwardingrulesets' { return $script:ApiVersions.DnsResolver }
        'microsoft.network/dnsforwardingrulesets/virtualnetworklinks' { return $script:ApiVersions.DnsResolver }
        # StandardV2 gateways, addresses and prefixes, and private-only Bastion, are created at
        # api-versions newer than the core networking one; deleted at the same.
        'microsoft.network/natgateways'           { return $script:ApiVersions.NatGateway }
        'microsoft.network/publicipaddresses'     { return $script:ApiVersions.NatGateway }
        'microsoft.network/publicipprefixes'      { return $script:ApiVersions.NatGateway }
        'microsoft.network/bastionhosts'          { return $script:ApiVersions.Bastion }
    }

    $ns = ''
    try { $ns = ($ResourceType -split '/')[0].ToLowerInvariant() } catch { }
    switch ($ns) {
        'microsoft.network'            { return $script:ApiVersions.Network }
        'microsoft.compute'            { return $script:ApiVersions.Compute }
        'microsoft.keyvault'           { return $script:ApiVersions.KeyVault }
        'microsoft.storage'            { return $script:ApiVersions.Storage }
        'microsoft.web'                { return $script:ApiVersions.Web }
        'microsoft.managedidentity'    { return $script:ApiVersions.Identity }
        'microsoft.operationalinsights'{ return $script:ApiVersions.LogAnalytics }
        'microsoft.insights'           { return $script:ApiVersions.Insights }
        default                        { return $script:ApiVersions.ResourceGroup }
    }
}

function Test-ZsRoleDefinitionInUse {
    <#
    .SYNOPSIS Reports whether any assignment in the subscription still references a role definition.
    .DESCRIPTION A custom role definition is subscription-wide, so removing one that another
        deployment still relies on would break it. When the answer cannot be established the caller
        keeps the definition: leaving an unused role behind is harmless, removing a used one is not.
    .OUTPUTS PSCustomObject: InUse (bool), Count (int), Inconclusive (bool).
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param([Parameter(Mandatory)][string]$RoleDefinitionId)

    # Matched on the GUID: an assignment names its role under the subscription it sits in, while a
    # definition written at a resource group is addressed through that group.
    $guid = ($RoleDefinitionId -split '/')[-1]
    try {
        $uri  = "$(Get-ZsSubscriptionPath)/providers/Microsoft.Authorization/roleAssignments?api-version=$($script:ApiVersions.Authorization)"
        $seen = 0
        $page = 0
        while ($uri -and $page -lt 20) {
            $page++
            $resp = if ($uri -like 'http*') {
                Invoke-RestMethod -Uri $uri -Headers @{ Authorization = "Bearer $(Get-ArmToken)" } -TimeoutSec 60 -ErrorAction Stop
            } else {
                Invoke-ArmGet -Uri $uri
            }
            foreach ($a in @($resp.value)) {
                if ((([string]$a.properties.roleDefinitionId) -split '/')[-1] -eq $guid) { $seen++ }
            }
            $uri = ''
            if ($resp.PSObject.Properties['nextLink'] -and $resp.nextLink) { $uri = [string]$resp.nextLink }
        }
        return [PSCustomObject]@{ InUse = ($seen -gt 0); Count = $seen; Inconclusive = $false }
    } catch {
        return [PSCustomObject]@{ InUse = $false; Count = 0; Inconclusive = $true }
    }
}

function Wait-ZsResourcesGone {
    <#
    .SYNOPSIS Waits for deletions to complete, reporting anything still present when time runs out.
    .DESCRIPTION Azure deletes asynchronously, so a successful delete request means the removal was
        accepted rather than finished. Polling until the resources stop resolving lets teardown
        report what actually went, and name what is still going, instead of implying completion it
        has not confirmed. Running out of time is reported, not treated as a failure: the deletion
        usually finishes on its own shortly afterwards.
    .PARAMETER Resources The resources whose removal is being awaited.
    .PARAMETER TimeoutSeconds How long to wait before reporting what remains.
    .PARAMETER PollSeconds Interval between checks.
    .OUTPUTS [string[]] Names still present when the wait ended. Empty when everything went.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([string[]])]
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][object[]]$Resources,
        [int]$TimeoutSeconds = 900,
        [int]$PollSeconds = 15
    )
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $pending = [System.Collections.Generic.List[string]]::new()
    foreach ($r in $Resources) { if ($r.ResourceId) { $pending.Add($r.Name) } }
    if ($pending.Count -eq 0) { return @() }

    $lookup = @{}
    foreach ($r in $Resources) { if ($r.ResourceId) { $lookup[$r.Name] = $r } }

    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSeconds -and $pending.Count -gt 0) {
        Start-Sleep -Seconds $PollSeconds
        $stillHere = [System.Collections.Generic.List[string]]::new()
        foreach ($name in $pending) {
            $r = $lookup[$name]
            $api = Resolve-ZsTeardownApiVersion -ResourceType $r.Type
            try {
                $chk = Test-ArmResource -Uri "$($r.ResourceId)?api-version=$api"
                if ($chk.Exists) { $stillHere.Add($name) }
            } catch { }
        }
        $pending = $stillHere
        Write-Progress -Activity 'Removing deployment resources' -Status "$($pending.Count) remaining ($([int]$sw.Elapsed.TotalSeconds)s elapsed)" -SecondsRemaining ([int]($TimeoutSeconds - $sw.Elapsed.TotalSeconds))
    }
    Write-Progress -Activity 'Removing deployment resources' -Completed
    return $pending.ToArray()
}
