<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Compare-ZsDeployment).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
    .PARAMETER ManifestPath Path to the deployment manifest JSON.
    .PARAMETER Detailed Show per-resource detail in the comparison output.
    #>

function Compare-ZsDeployment {
    <#
    .SYNOPSIS Compares live Azure resources against expected deployment state. Similar to terraform plan.
    .DESCRIPTION Reads the deployment manifest, GETs each resource from ARM, and compares key properties
    against expected values. Reports drift: missing resources, changed properties, and unexpected state.
    Requires an active Azure connection (Connect-ZscalerAzure).
    .EXAMPLE
    Compare-ZsDeployment -ManifestPath ./zscc-manifest-7d86adfd.json
    Compares live Azure state against the manifest and reports differences.
    .EXAMPLE
    Compare-ZsDeployment -ManifestPath ./zscc-manifest-7d86adfd.json -Detailed
    Includes property-level diff for each resource.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][string]$ManifestPath,
        [switch]$Detailed
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        if (-not (Test-Path $ManifestPath)) {
            Write-ZsError -Message "Manifest not found: $ManifestPath" -ErrorId 'ZsManifestNotFound' -Cmdlet $PSCmdlet
        }
        $manifest = Get-Content $ManifestPath -Raw | ConvertFrom-Json

        $results = [System.Collections.Generic.List[PSCustomObject]]::new()
        $ok = 0; $drift = 0; $missing = 0; $errors = 0

        # Flatten all resources from the manifest into a check list.
        $checks = [System.Collections.Generic.List[hashtable]]::new()
        foreach ($type in $manifest.Resources.PSObject.Properties) {
            foreach ($r in $type.Value) {
                $checks.Add(@{ Type=$type.Name; Name=$r.Name; ResourceId=$r.ResourceId; Properties=$r.Properties })
            }
        }

        Write-ZsLog "Comparing $($checks.Count) resources against live Azure state"

        foreach ($item in $checks) {
            $name = $item.Name; $type = $item.Type; $rid = $item.ResourceId
            if ($rid -match '^\(') { continue } # Skip WhatIf placeholders

            # Determine the API version for this resource type. The resource ID carries the real ARM
            # type, which is authoritative and per-type — the manifest's grouping label is neither,
            # and a label that falls through to the default below would read Microsoft.Insights
            # resources at a version they do not serve and report a live resource as missing.
            $apiVer = ''
            $armType = ''
            try { $armType = Resolve-ZsArmTypeFromId -ResourceId $rid } catch { }
            if ($armType) {
                try { $apiVer = Resolve-ZsTeardownApiVersion -ResourceType $armType } catch { }
            }
            if (-not $apiVer) { $apiVer = switch -Regex ($type) {
                'ResourceGroup'     { $script:ApiVersions.ResourceGroup }
                'VNet|Subnet|NSG|NAT|PublicIp|Route|LoadBalancer' { $script:ApiVersions.Network }
                'VMSS|VM'           { $script:ApiVersions.Compute }
                'Identity|Role'     { $script:ApiVersions.Identity }
                'KeyVault'          { $script:ApiVersions.KeyVault }
                'Storage'           { $script:ApiVersions.Storage }
                'FunctionApp|AppService' { $script:ApiVersions.Web }
                'Autoscale'         { $script:ApiVersions.Insights }
                'Lock'              { $script:ApiVersions.Lock }
                'Bastion'           { $script:ApiVersions.Network }
                default             { $script:ApiVersions.Network }
            } }

            try {
                $uri = "$rid`?api-version=$apiVer"
                $live = Invoke-ArmGet -Uri $uri -AllowNotFound
                # -AllowNotFound returns $null for a confirmed 404. Without this branch the
                # property checks below would run against nothing and report every absent
                # resource as drift ("probes: none", "routes: no default route") rather than
                # as the missing resource it is.
                if ($null -eq $live) {
                    $missing++
                    $results.Add([PSCustomObject]@{ Status='Missing'; Type=$type; Name=$name; Details='Resource not found in Azure' })
                    Write-ZsLog "  MISSING $type/$name" -Level WARN
                    continue
                }
                $state = $null
                if ($live.properties -and ($live.properties.PSObject.Properties.Name -contains 'provisioningState')) {
                    $state = $live.properties.provisioningState
                }

                $diffs = [System.Collections.Generic.List[string]]::new()

                # Check provisioning state.
                if ($state -and $state -ne 'Succeeded') {
                    $diffs.Add("provisioningState: expected Succeeded, actual $state")
                }

                # Property-level checks from manifest.
                if ($Detailed -and $item.Properties) {
                    foreach ($prop in $item.Properties.PSObject.Properties) {
                        $expected = $prop.Value
                        $actual = $null
                        # Look for the property in the live resource.
                        if ($live.properties -and ($live.properties.PSObject.Properties.Name -contains $prop.Name)) {
                            $actual = $live.properties."$($prop.Name)"
                        }
                        if ($null -ne $expected -and "$actual" -ne "$expected") {
                            $diffs.Add("$($prop.Name): expected '$expected', actual '$actual'")
                        }
                    }
                }

                # Type-specific checks.
                switch ($type) {
                    'NSG' {
                        $ruleCount = @($live.properties.securityRules).Count
                        if ($ruleCount -eq 0) { $diffs.Add('securityRules: empty (expected rules)') }
                    }
                    'VMSS' {
                        $cap = $live.sku.capacity
                        if ($cap -eq 0) { $diffs.Add("sku.capacity: 0 (no running instances)") }
                        # Check IP forwarding on service NIC.
                        $nics = $live.properties.virtualMachineProfile.networkProfile.networkInterfaceConfigurations
                        if ($nics) {
                            $svcNic = $nics | Where-Object { $_.name -match 'svc|fwd' }
                            if ($svcNic -and -not $svcNic.properties.enableIPForwarding) {
                                $diffs.Add('service NIC: enableIPForwarding is disabled')
                            }
                        }
                    }
                    'LoadBalancer' {
                        $rules = @($live.properties.loadBalancingRules)
                        if ($rules.Count -eq 0) { $diffs.Add('loadBalancingRules: none (expected HA Ports)') }
                        $probes = @($live.properties.probes)
                        if ($probes.Count -eq 0) { $diffs.Add('probes: none (health probe missing)') }
                    }
                    'RouteTable' {
                        $routes = @($live.properties.routes)
                        $default = $routes | Where-Object { $_.properties.addressPrefix -eq '0.0.0.0/0' }
                        if (-not $default) { $diffs.Add('routes: no default 0.0.0.0/0 route') }
                    }
                    'AutoscalePolicy' {
                        $profiles = @($live.properties.profiles)
                        if ($profiles.Count -eq 0) { $diffs.Add('profiles: none (autoscale unconfigured)') }
                        if (-not $live.properties.enabled) { $diffs.Add('enabled: false (autoscale disabled)') }
                    }
                }

                if ($diffs.Count -gt 0) {
                    $drift++
                    $results.Add([PSCustomObject]@{ Status='Drift'; Type=$type; Name=$name; Details=($diffs -join '; ') })
                    Write-ZsLog "  DRIFT  ${type}/${name}: $($diffs -join '; ')" -Level WARN
                } else {
                    $ok++
                    $results.Add([PSCustomObject]@{ Status='OK'; Type=$type; Name=$name; Details='Matches expected state' })
                }
            } catch {
                if ($_ -match '404|NotFound') {
                    $missing++
                    $results.Add([PSCustomObject]@{ Status='Missing'; Type=$type; Name=$name; Details='Resource not found in Azure' })
                    Write-ZsLog "  MISSING $type/$name" -Level WARN
                } else {
                    $errors++
                    $results.Add([PSCustomObject]@{ Status='Error'; Type=$type; Name=$name; Details=$_.Exception.Message })
                    Write-ZsLog "  ERROR  ${type}/${name}: $($_.Exception.Message)" -Level ERROR
                }
            }
        }

        $summary = "Compared $($checks.Count) resources: $ok OK, $drift drifted, $missing missing, $errors errors"
        Write-ZsLog $summary
        return [PSCustomObject]@{
            Summary    = $summary
            OK         = $ok
            Drift      = $drift
            Missing    = $missing
            Errors     = $errors
            Resources  = $results
        }
    }
}
