<#
.SYNOPSIS
    Orchestrates an end-to-end Zscaler Cloud Connector deployment on Azure (VM or VMSS topology).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function New-ZsDeployment {
    <#
    .SYNOPSIS Full-stack Cloud Connector deployment orchestrator.
    .DESCRIPTION Deploys all resources in dependency order. Supports greenfield (new), brownfield (existing
        infrastructure via -ConfigFile or -Interactive), and idempotent re-runs. Credentials are auto-derived
        from Connect-ZscalerCloud session when available.
    .PARAMETER Mode Greenfield creates all infrastructure. Brownfield reuses existing resources.
    .PARAMETER ConfigFile JSON config path with BYO resource IDs for brownfield.
    .PARAMETER Interactive Prompts for each brownfield resource.
    .PARAMETER ApiKey Zscaler API key as SecureString. Auto-derived from Zscaler session if connected.
    .PARAMETER AdminPassword Zscaler admin password as SecureString.
    .PARAMETER NotificationEmail Addresses for the deployment's Azure Monitor action group. Alert
        rules are created regardless; without an address they fire into the void.
    .PARAMETER DisablePurgeProtection Opts the Key Vault out of purge protection, which is on by default.
    .PARAMETER SkipPrerequisites Skips every preflight: the access check, zone entitlement
        resolution, Test-ZsPrerequisites (provider registration, quota, encryption-at-host), and
        the marketplace terms check and acceptance. Marketplace terms are then assumed accepted
        out of band by the platform owner; if they were not, the scale set create fails with the
        marketplace legal-terms error. Intended for pipelines whose deployer identity holds only
        resource-group rights and whose subscription-level prerequisites are managed elsewhere.
    .PARAMETER FunctionRoleMode Control-plane role for the lifecycle function identity: Reader
        (default, plus a scoped custom role), LeastPrivilege, NetworkContributor, or None.
    .PARAMETER AllowedScmIpRanges Retained so existing scripts bind; no effect. Public network access
        is off for the Function App and its SCM site from creation.
    .PARAMETER EnableFunctionPrivateEndpoint Private Endpoint for the Function App, for operators inside
        the network who want the portal's function views. Public access is off either way.
    .PARAMETER FunctionPackageUrl Where the Vendor package runs from. Zscaler's published 1.0.3 zip,
        pinned to the commit that released it, by default; the deployment then touches no data plane
        and runs from anywhere. Empty zip-deploys the copy in FunctionApp/vendor onto the plan's disk
        through the app's private endpoint instead, as the Module package always is, which needs the
        run to be on a host inside the network (from elsewhere the run ends PartialSuccess, with
        FunctionPackagePending set, and a re-run from inside deploys it).
    .PARAMETER BastionSku Premium (default, private-only, no public IP), Standard or Basic (with a public IP).
    .PARAMETER BastionClientSourceAddressPrefix Where Bastion sessions may come from, on 443. Empty uses
        VirtualNetwork for private-only and Internet for a public SKU.
    .PARAMETER NatPublicIpMode The NAT gateway's egress address: ip (a StandardV2 public IP, default) or
        prefix (a StandardV2 public IP prefix). A policy refusing Microsoft.Network/publicIPAddresses
        needs an exemption for the one address in ip mode.
    .PARAMETER NatExistingPublicIpId An existing StandardV2 public IP (ip mode) or prefix (prefix mode) to
        attach instead of creating one, such as one the platform team created under an exemption.
    .PARAMETER NatPublicIpPrefixLength Prefix length in prefix mode, 28 to 31 (default 31, two addresses).
    .PARAMETER SupportServerIp Zscaler's remote-support server for -EnableSupportTunnel: the address
        remotesupport.<cloud>.net resolves to. Defaults to the commercial-cloud address.
    .PARAMETER RemediationRoleName Role the lifecycle function gets on the resource group (and on the
        connector subnets when their VNet is elsewhere) to replace an unhealthy connector. Virtual
        Machine Contributor by default; a custom role must carry the actions Set-ZsHealthRemediationRole lists.
    .PARAMETER CreateRemediationRole Define a custom role with exactly the actions replacing a connector
        needs, assignable at the resource group (and the connector subnets' group when the VNet is
        elsewhere), and grant it in place of RemediationRoleName. Needs
        Microsoft.Authorization/roleDefinitions/write there. Config: CreateRemediationRole.
    .PARAMETER ServiceAllowAllOutbound Allow every port outbound from the service subnet to the internet,
        as Zscaler's own module does, for a forwarding policy that sends traffic DIRECT on ports other
        than the ones the service NSG allows. Config: ServiceAllowAllOutbound.
    .PARAMETER DisableLegacyVmNvaTag Leave the LegacyVMNVA tag off the connectors. It keeps them off Azure
        hosts with the MANA network adapter until Zscaler's image supports MANA.
    .PARAMETER EnableMonitorPrivateLink Accepted for compatibility; Monitor Private Link is on
        by default and this switch changes nothing.
    .PARAMETER DisableMonitorPrivateLink Opts out of the default Azure Monitor Private Link Scope.
        On by default: telemetry ingestion goes PrivateOnly with public ingestion disabled on the
        workspace and component. Skipped on its own when BringYourOwn names the platform's
        privatelink zones, which belong to the hub's own scope.
        Opt out where a centralised enterprise AMPLS already owns the privatelink DNS zones — a
        VNet's zones can serve one scope's endpoints — and scope these resources into it instead.
        Query access stays Entra-authenticated public unless -PrivateQueryAccess is also set.
        Connector custom metrics (smedge_metrics) remain on the public custom-metrics endpoint —
        Azure Monitor does not support them over Private Link.
    .PARAMETER PrivateQueryAccess With -EnableMonitorPrivateLink, also closes public query access;
        portal and CLI queries then work only from inside the VNet.
    .PARAMETER StateStorageAccount Store deployment state in this storage account and hold a blob
        lease for the run, so two operators cannot deploy the same resource group concurrently.
    .PARAMETER BreakStateLock Break a leftover state lease from a crashed run before locking.
    .EXAMPLE
    New-ZsDeployment -Topology VMSS -CcCount 2 -ConfigFile ./config.json -EnableDiagnostics -NotificationEmail 'ops@example.com'
    Greenfield VMSS deployment: builds the network, identity, Key Vault, load balancer, NAT, connectors, and lifecycle Function App.
    .EXAMPLE
    New-ZsDeployment -Topology VMSS -CcCount 2 -ConfigFile ./config.json -WhatIf
    Dry run. Shows every resource that would be created without creating anything.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [ValidateSet('Greenfield','Brownfield')][string]$Mode = 'Greenfield',
        [ValidateSet('VM','VMSS')][string]$Topology = 'VM',
        [string]$ConfigFile = '', [switch]$Interactive,
        [string]$ProvisioningUrl = '',
        [object]$ApiKey = $null, [string]$AdminUser = '', [object]$AdminPassword = $null,
        [string]$SshPublicKey = '',
        [string]$VmSize = '', [int]$CcCount = 0, [string[]]$Zones = @(), [int]$HttpProbePort = 0,
        [switch]$EnableSupportTunnel, [switch]$EnableZpa, [switch]$SkipPrerequisites,
        [switch]$AdaptZones,
        # Purge protection is on by default in New-ZsKeyVault. -EnablePurgeProtection is retained
        # for existing scripts and does nothing; -DisablePurgeProtection is the opt-out.
        [switch]$EnablePurgeProtection, [switch]$DisablePurgeProtection,
        [switch]$EncryptAtHost,
        [switch]$EnableDefender, [switch]$EnableDiagnostics,
        [int]$MinInstances = 0,
        [int]$MaxInstances = 0,
        [int]$ScaleOutThreshold = 0,
        [int]$ScaleInThreshold = 0,
        [int]$ScaleOutCooldownMinutes = 0,
        [int]$ScaleInCooldownMinutes = 0,
        [ValidateRange(1,1440)][int]$SyncIntervalMinutes = 0,
        [switch]$ScheduledScaling,
        [int]$ScheduledMinInstances = 1,
        [string[]]$ScheduledDays = @('Monday','Tuesday','Wednesday','Thursday','Friday'),
        [int]$ScheduledStartHour = 9, [int]$ScheduledStartMinute = 0,
        [int]$ScheduledEndHour = 17, [int]$ScheduledEndMinute = 0,
        [string]$ScheduledTimezone = 'Pacific Standard Time',
        [switch]$NoBastion,
        [ValidateSet('LeastPrivilege','NetworkContributor','None')][string]$IdentityRoleMode = '',
        [string]$VnetAddressSpace = '',
        [string]$WorkloadSubnetCidr = '', [string]$LbSubnetCidr = '',
        [string]$BastionSubnetCidr = '',
        [string]$DnsInboundCidr = '', [string]$DnsOutboundCidr = '',
        [string]$SecurityContactEmail = '',
        [ValidatePattern('^[^@\s]+@[^@\s]+\.[^@\s]+$', ErrorMessage = "NotificationEmail entries must be email addresses (name@domain.tld); received: '{0}'")]
        [string[]]$NotificationEmail = @(),
        [ValidateSet('Reader','LeastPrivilege','NetworkContributor','None')][string]$FunctionRoleMode = 'Reader',
        # Health remediation is on by default, matching the Zscaler reference: unhealthy
        # connectors are terminated and replaced. -DisableHealthRemediation keeps the evaluation
        # and its alerting but leaves deletion to an operator.
        [ValidateSet('Auto','Vendor','Module')][string]$FunctionPackage = 'Auto',
        [string]$DeployerIpCidr = '',
        [switch]$DisableHealthRemediation,
        [ValidateRange(3,60)][int]$HealthDataPoints = 10,
        [ValidateRange(1,60)][int]$HealthUnhealthyThreshold = 7,
        [ValidateRange(1,60)][int]$HealthConsecutiveThreshold = 5,
        [ValidateRange(5,240)][int]$HealthGracePeriodMinutes = 30,
        [ValidateRange(0.05,1.0)][double]$MaxTerminationPercent = 0.2,
        [ValidateSet('oldest','newest')][string]$TerminationPolicy = 'oldest',
        [string[]]$AllowedScmIpRanges = @(),
        [switch]$AllowPublicSiteAccess,
        [string[]]$AllowedSiteIpRanges = @(),
        [switch]$EnableFunctionPrivateEndpoint,
        # Monitor Private Link is on by default. -EnableMonitorPrivateLink is retained for
        # existing scripts and does nothing; -DisableMonitorPrivateLink is the opt-out.
        [switch]$EnableMonitorPrivateLink, [switch]$DisableMonitorPrivateLink,
        [switch]$PrivateQueryAccess,
        [string]$StateStorageAccount = '',
        [string]$StateContainerName = 'zscc-state',
        [switch]$BreakStateLock,
        [string]$ManifestPath = '',
        [ValidateSet('STABLE','LATEST','BETA')][string]$ReleaseChannel = 'STABLE',
        [AllowEmptyString()][string]$FunctionPackageUrl = $script:ZsVendorPackageUrl,
        [ValidateSet('','Premium','Standard','Basic')][string]$BastionSku = '',
        [string]$BastionClientSourceAddressPrefix = '',
        [ValidateSet('','ip','prefix')][string]$NatPublicIpMode = '',
        [string]$NatExistingPublicIpId = '',
        [ValidateRange(0,31)][int]$NatPublicIpPrefixLength = 0,
        [string]$SupportServerIp = '',
        [string]$RemediationRoleName = '',
        [switch]$CreateRemediationRole,
        [switch]$ServiceAllowAllOutbound,
        [switch]$DisableLegacyVmNvaTag
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        # Both switches name what is now the default, and are retained only so scripts written
        # against an earlier release keep binding. Neither is read anywhere below; say so rather
        # than accepting them in silence, which reads as the setting having been applied.
        if ($EnablePurgeProtection) {
            Write-ZsLog ("-EnablePurgeProtection has no effect: purge protection is on by default. " +
                "Use -DisablePurgeProtection to opt out.") -Level WARN
        }
        if ($EnableMonitorPrivateLink) {
            Write-ZsLog ("-EnableMonitorPrivateLink has no effect: Monitor Private Link is on by default. " +
                "Use -DisableMonitorPrivateLink to opt out.") -Level WARN
        }

        # Accept both plain strings and SecureStrings for ApiKey and AdminPassword.
        $ApiKey        = ConvertTo-ZsSecureString -Value $ApiKey        -Name 'ApiKey'
        $AdminPassword = ConvertTo-ZsSecureString -Value $AdminPassword -Name 'AdminPassword'

        $cfg = New-ZsDeploymentConfig -Mode $Mode -ConfigFile $ConfigFile -Interactive:$Interactive

        # A config file written by hand leaves fields out, and under StrictMode reading an absent
        # key throws ("The property 'NoBastion' cannot be found"), from PowerShell 7.4 on for
        # dictionaries too. Fields every topology reads get their defaults here. The VMSS-only
        # scaling block is left alone: whether a config carries it is how a VM config is told
        # apart from a VMSS one, and every read of it is guarded.
        $cfgDefaults = [ordered]@{
            NoBastion=$false; VnetAddressSpace=''; MgmtSubnetCidr=''; ServiceSubnetCidr=''; WorkloadSubnetCidr=''
            LbSubnetCidr=''; FuncAppSubnetCidr=''; BastionSubnetCidr=''; DnsInboundCidr=''; DnsOutboundCidr=''
            VmSize='Standard_D2s_v3'; CcCount=2; Zones=@('1','2'); HttpProbePort=50000; IdentityRoleMode='LeastPrivilege'
            EnableSupportTunnel=$false; EnableZpa=$false; SshSourceCidr='VirtualNetwork'; WorkloadCidrs=@(); SpokeVnetIds=@()
            BringYourOwn=[ordered]@{}
        }
        foreach ($k in $cfgDefaults.Keys) {
            if ($cfg -is [System.Collections.IDictionary]) { if (-not $cfg.Contains($k)) { $cfg[$k] = $cfgDefaults[$k] } }
            elseif (-not $cfg.PSObject.Properties[$k]) { $cfg | Add-Member -NotePropertyName $k -NotePropertyValue $cfgDefaults[$k] }
        }

        # Config validation.
        $cfgErrors = [System.Collections.Generic.List[string]]::new()
        if ($cfg.VmSize -and $cfg.VmSize -notmatch '^Standard_') { $cfgErrors.Add("VmSize '$($cfg.VmSize)' does not look like a valid Azure VM size") }
        if ($cfg.HttpProbePort -and ($cfg.HttpProbePort -lt 1 -or $cfg.HttpProbePort -gt 65535)) { $cfgErrors.Add("HttpProbePort $($cfg.HttpProbePort) out of range (1-65535)") }
        if ($cfg.Zones -and $cfg.Zones.Count -gt 0) { foreach ($z in $cfg.Zones) { if ($z -ne 'auto' -and $z -notmatch '^\d+$') { $cfgErrors.Add("Zone '$z' is not a number or 'auto'") } } }
        if ($cfg.IdentityRoleMode -and $cfg.IdentityRoleMode -notin @('LeastPrivilege','NetworkContributor','None')) { $cfgErrors.Add("IdentityRoleMode '$($cfg.IdentityRoleMode)' invalid (use LeastPrivilege, NetworkContributor, or None)") }
        if ($cfgErrors.Count -gt 0) { Write-ZsError -Message "Config validation failed:`n  $($cfgErrors -join "`n  ")" -ErrorId 'ZsConfigInvalid' -Cmdlet $PSCmdlet }

        if ($VmSize)        { $cfg.VmSize = $VmSize }
        if ($CcCount -gt 0) { $cfg.CcCount = $CcCount }
        if ($Zones.Count)   { $cfg.Zones = $Zones }
        if ($HttpProbePort) { $cfg.HttpProbePort = $HttpProbePort }
        if ($EnableSupportTunnel) { $cfg.EnableSupportTunnel = $true }
        if ($EnableZpa) { $cfg.EnableZpa = $true }
        # VNet address space and per-subnet CIDRs: runtime takes precedence over JSON. Per-zone
        # connector CIDRs are supplied via the config file or interactive prompts (MgmtSubnetCidr/ServiceSubnetCidr).
        if ($VnetAddressSpace)   { $cfg.VnetAddressSpace   = $VnetAddressSpace }
        if ($WorkloadSubnetCidr) { $cfg.WorkloadSubnetCidr = $WorkloadSubnetCidr }
        if ($LbSubnetCidr)       { $cfg.LbSubnetCidr        = $LbSubnetCidr }
        if ($BastionSubnetCidr)  { $cfg.BastionSubnetCidr   = $BastionSubnetCidr }
        if ($DnsInboundCidr)     { $cfg.DnsInboundCidr       = $DnsInboundCidr }
        if ($DnsOutboundCidr)    { $cfg.DnsOutboundCidr      = $DnsOutboundCidr }
        if ($IdentityRoleMode)   { $cfg.IdentityRoleMode     = $IdentityRoleMode }

        # Config objects from ConvertFrom-Json -AsHashtable are IDictionary; interactive
        # mode may yield PSCustomObject. PSObject.Properties does NOT expose hashtable
        # keys, so key-existence checks must be shape-aware.
        $cfgHas = { param($k)
            if ($cfg -is [System.Collections.IDictionary]) { $cfg.Contains($k) }
            else { $null -ne $cfg.PSObject.Properties[$k] }
        }

        # Config validation: Topology, Mode, IdentityRoleMode
        # Case-insensitive matching with canonical casing.
        $validTopologies = @{ 'VM' = 'VM'; 'VMSS' = 'VMSS' }
        $validModes      = @{ 'GREENFIELD' = 'Greenfield'; 'BROWNFIELD' = 'Brownfield' }
        $validRoleModes  = @{ 'LEASTPRIVILEGE' = 'LeastPrivilege'; 'NETWORKCONTRIBUTOR' = 'NetworkContributor'; 'NONE' = 'None' }

        # Topology validation.
        $cfgTopology = $null; try { $cfgTopology = $cfg.Topology } catch { }
        if ($cfgTopology) {
            $topoUpper = $cfgTopology.ToString().Trim().ToUpper()
            if (-not $validTopologies.ContainsKey($topoUpper)) {
                Write-ZsError -Message "Invalid Topology '$cfgTopology' in config file '$ConfigFile'. Valid values: $($validTopologies.Values -join ', ')." -ErrorId 'ZsInvalidTopology' -Cmdlet $PSCmdlet
                return
            }
            $cfg.Topology = $validTopologies[$topoUpper]

            if ($PSBoundParameters.ContainsKey('Topology') -and $Topology -ne $cfg.Topology) {
                Write-ZsError -Message "Topology mismatch: -Topology '$Topology' was passed on the command line, but the config file '$ConfigFile' declares Topology '$($cfg.Topology)'. Use a config file that matches the requested topology, or remove -Topology to use the config's value." -ErrorId 'ZsTopologyMismatch' -Cmdlet $PSCmdlet
                return
            }
            $Topology = $cfg.Topology
        }

        # Mode validation.
        $cfgMode = $null; try { $cfgMode = $cfg.Mode } catch { }
        if ($cfgMode) {
            $modeUpper = $cfgMode.ToString().Trim().ToUpper()
            if (-not $validModes.ContainsKey($modeUpper)) {
                Write-ZsError -Message "Invalid Mode '$cfgMode' in config file '$ConfigFile'. Valid values: $($validModes.Values -join ', ')." -ErrorId 'ZsInvalidMode' -Cmdlet $PSCmdlet
                return
            }
            $cfg.Mode = $validModes[$modeUpper]
        }

        # IdentityRoleMode validation.
        $cfgRole = $null; try { $cfgRole = $cfg.IdentityRoleMode } catch { }
        if (-not $cfgRole) { $cfg.IdentityRoleMode = 'LeastPrivilege'; $cfgRole = 'LeastPrivilege' }
        $roleUpper = $cfgRole.ToString().Trim().ToUpper()
        if (-not $validRoleModes.ContainsKey($roleUpper)) {
            Write-ZsError -Message "Invalid IdentityRoleMode '$cfgRole' in config file '$ConfigFile'. Valid values: $($validRoleModes.Values -join ', ')." -ErrorId 'ZsInvalidRoleMode' -Cmdlet $PSCmdlet
            return
        }
        $cfg.IdentityRoleMode = $validRoleModes[$roleUpper]

        # Architecture validation: config structure must match declared topology
        $vmssOnlyFields = @('MinInstances','MaxInstances','ScaleOutThreshold','ScaleInThreshold',
                            'ScaleOutCooldownMinutes','ScaleInCooldownMinutes','ScheduledScaling',
                            'ScheduledMinInstances','ScheduledDays','ScheduledStartHour','ScheduledStartMinute',
                            'ScheduledEndHour','ScheduledEndMinute','ScheduledTimezone')

        if ($Topology -eq 'VM') {
            $unexpected = @($vmssOnlyFields | Where-Object { & $cfgHas $_ })
            if ($unexpected.Count -gt 0) {
                $sample = ($unexpected | Select-Object -First 3) -join ', '
                if ($unexpected.Count -gt 3) { $sample += ', ...' }
                Write-ZsError -Message "Architecture mismatch in config file '$ConfigFile': Topology is 'VM' but the config contains VMSS-specific fields ($sample) that only apply to VMSS deployments. Either change Topology to 'VMSS' or remove the scaling fields." -ErrorId 'ZsArchitectureMismatch' -Cmdlet $PSCmdlet
                return
            }
        }
        elseif ($Topology -eq 'VMSS') {
            if ($cfg.CcCount -lt 1) {
                Write-ZsError -Message "VMSS topology requires CcCount >= 1 in config file '$ConfigFile'." -ErrorId 'ZsInvalidCcCount' -Cmdlet $PSCmdlet
                return
            }
            if (-not $cfg.Zones -or $cfg.Zones.Count -lt 1) {
                Write-ZsError -Message "VMSS topology requires at least one zone in config file '$ConfigFile'." -ErrorId 'ZsNoZones' -Cmdlet $PSCmdlet
                return
            }
        }

        # Scaling: config values override defaults; CLI parameters override config.
        # Use PSObject.Properties to safely check — these fields may not exist in older configs.
        if ((& $cfgHas 'MinInstances') -and -not $PSBoundParameters.ContainsKey('MinInstances'))                     { $MinInstances = $cfg.MinInstances }
        if (-not $MinInstances) { $MinInstances = [math]::Max(1, $cfg.CcCount - 1) }
        if ((& $cfgHas 'MaxInstances') -and -not $PSBoundParameters.ContainsKey('MaxInstances'))                     { $MaxInstances = $cfg.MaxInstances }
        if (-not $MaxInstances) { $MaxInstances = $cfg.CcCount * 2 }
        if ((& $cfgHas 'ScaleOutThreshold') -and -not $PSBoundParameters.ContainsKey('ScaleOutThreshold'))           { $ScaleOutThreshold = $cfg.ScaleOutThreshold }
        if (-not $ScaleOutThreshold) { $ScaleOutThreshold = 70 }
        if ((& $cfgHas 'ScaleInThreshold') -and -not $PSBoundParameters.ContainsKey('ScaleInThreshold'))             { $ScaleInThreshold = $cfg.ScaleInThreshold }
        if (-not $ScaleInThreshold) { $ScaleInThreshold = 30 }
        if ((& $cfgHas 'ScaleOutCooldownMinutes') -and -not $PSBoundParameters.ContainsKey('ScaleOutCooldownMinutes')) { $ScaleOutCooldownMinutes = $cfg.ScaleOutCooldownMinutes }
        if (-not $ScaleOutCooldownMinutes) { $ScaleOutCooldownMinutes = 5 }
        if ((& $cfgHas 'ScaleInCooldownMinutes') -and -not $PSBoundParameters.ContainsKey('ScaleInCooldownMinutes'))   { $ScaleInCooldownMinutes = $cfg.ScaleInCooldownMinutes }
        if (-not $ScaleInCooldownMinutes) { $ScaleInCooldownMinutes = 10 }

        # Scheduled scaling: config values override defaults; CLI parameters override config.
        if ((& $cfgHas 'ScheduledScaling') -and $cfg.ScheduledScaling -and -not $PSBoundParameters.ContainsKey('ScheduledScaling'))   { $ScheduledScaling = [switch]$true }
        if ((& $cfgHas 'ScheduledMinInstances') -and -not $PSBoundParameters.ContainsKey('ScheduledMinInstances'))   { $ScheduledMinInstances = $cfg.ScheduledMinInstances }

        # The portal refuses joins beyond 16 VMs per EC group (one group per scale set), so a
        # larger ceiling deploys Azure capacity that can never register. Config-sourced values
        # bypass parameter validation, so the bound values are checked here.
        if ($MaxInstances -gt 16 -or $ScheduledMinInstances -gt 16) {
            Write-ZsError -Message "MaxInstances=$MaxInstances / ScheduledMinInstances=${ScheduledMinInstances}: the portal enforces a hard limit of 16 VMs per EC group and refuses joins past it with INVALID_OPERATION. Set both to 16 or less per zone. Nothing has been deployed." -ErrorId 'ZsExceedsEcGroupLimit' -Cmdlet $PSCmdlet
        }
        if ($MinInstances -gt $MaxInstances) {
            Write-ZsError -Message "MinInstances=$MinInstances exceeds MaxInstances=$MaxInstances. Nothing has been deployed." -ErrorId 'ZsInvalidInstanceRange' -Cmdlet $PSCmdlet
        }
        if ((& $cfgHas 'ScheduledDays') -and -not $PSBoundParameters.ContainsKey('ScheduledDays'))                   { $ScheduledDays = $cfg.ScheduledDays }
        if ((& $cfgHas 'ScheduledStartHour') -and -not $PSBoundParameters.ContainsKey('ScheduledStartHour'))         { $ScheduledStartHour = $cfg.ScheduledStartHour }
        if ((& $cfgHas 'ScheduledStartMinute') -and -not $PSBoundParameters.ContainsKey('ScheduledStartMinute'))     { $ScheduledStartMinute = $cfg.ScheduledStartMinute }
        if ((& $cfgHas 'ScheduledEndHour') -and -not $PSBoundParameters.ContainsKey('ScheduledEndHour'))             { $ScheduledEndHour = $cfg.ScheduledEndHour }
        if ((& $cfgHas 'ScheduledEndMinute') -and -not $PSBoundParameters.ContainsKey('ScheduledEndMinute'))         { $ScheduledEndMinute = $cfg.ScheduledEndMinute }
        if ((& $cfgHas 'ScheduledTimezone') -and -not $PSBoundParameters.ContainsKey('ScheduledTimezone'))           { $ScheduledTimezone = $cfg.ScheduledTimezone }

        # Function App sync interval: applies to both VM and VMSS topologies.
        if ((& $cfgHas 'SyncIntervalMinutes') -and -not $PSBoundParameters.ContainsKey('SyncIntervalMinutes')) { $SyncIntervalMinutes = $cfg.SyncIntervalMinutes }
        if (-not $SyncIntervalMinutes) { $SyncIntervalMinutes = 30 }

        # Health remediation. TerminateUnhealthyInstances mirrors the Zscaler reference setting,
        # so a config written against their module carries over unchanged.
        if ((& $cfgHas 'FunctionPackage') -and -not $PSBoundParameters.ContainsKey('FunctionPackage')) { $FunctionPackage = $cfg.FunctionPackage }
        if ((& $cfgHas 'DeployerIpCidr') -and -not $PSBoundParameters.ContainsKey('DeployerIpCidr')) { $DeployerIpCidr = $cfg.DeployerIpCidr }
        # Scripts and configs written for 5.4.1.0 pass these to open the Function App and the vault
        # to the deployer. Nothing is opened now; they are accepted and said to do nothing.
        if ($DeployerIpCidr) {
            Write-ZsLog "-DeployerIpCidr has no effect: nothing is opened to the deployer's address." -Level WARN
        }
        if ($AllowPublicSiteAccess -or @($AllowedSiteIpRanges | Where-Object { $_ }).Count -gt 0 -or @($AllowedScmIpRanges | Where-Object { $_ }).Count -gt 0) {
            Write-ZsLog ("-AllowPublicSiteAccess, -AllowedSiteIpRanges and -AllowedScmIpRanges have no effect: public network access is off " +
                "for the Function App and its SCM endpoint. Use -EnableFunctionPrivateEndpoint to reach it from inside the network.") -Level WARN
        }
        if ((& $cfgHas 'FunctionPackageUrl') -and -not $PSBoundParameters.ContainsKey('FunctionPackageUrl')) { $FunctionPackageUrl = [string]$cfg.FunctionPackageUrl }

        # Lockdown settings: parameter, then config, then the default the Terraform configuration has.
        $cfgStr = { param($k) Get-ZsConfigValue $cfg $k }
        if (-not $BastionSku)                       { $BastionSku = & $cfgStr 'BastionSku' }
        if (-not $BastionSku)                       { $BastionSku = 'Premium' }
        if ($BastionSku -notin @('Premium','Standard','Basic')) {
            Write-ZsError -Message "BastionSku '$BastionSku' is not one of Premium, Standard or Basic." -ErrorId 'ZsInvalidBastionSku' -Cmdlet $PSCmdlet
        }
        if (-not $BastionClientSourceAddressPrefix) { $BastionClientSourceAddressPrefix = & $cfgStr 'BastionClientSourceAddressPrefix' }
        if (-not $NatPublicIpMode)                  { $NatPublicIpMode = & $cfgStr 'NatPublicIpMode' }
        if (-not $NatPublicIpMode)                  { $NatPublicIpMode = 'ip' }
        if ($NatPublicIpMode -notin @('ip','prefix')) {
            Write-ZsError -Message "NatPublicIpMode '$NatPublicIpMode' is not 'ip' or 'prefix'." -ErrorId 'ZsInvalidNatMode' -Cmdlet $PSCmdlet
        }
        if (-not $NatExistingPublicIpId)            { $NatExistingPublicIpId = & $cfgStr 'NatExistingPublicIpId' }
        if (-not $NatPublicIpPrefixLength -and (& $cfgStr 'NatPublicIpPrefixLength')) { $NatPublicIpPrefixLength = [int](& $cfgStr 'NatPublicIpPrefixLength') }
        if (-not $NatPublicIpPrefixLength)          { $NatPublicIpPrefixLength = 31 }
        if ($NatPublicIpPrefixLength -lt 28 -or $NatPublicIpPrefixLength -gt 31) {
            Write-ZsError -Message "NatPublicIpPrefixLength $NatPublicIpPrefixLength is out of range: a NAT gateway takes a /28 to /31 prefix." -ErrorId 'ZsInvalidNatPrefixLength' -Cmdlet $PSCmdlet
        }
        if (-not $SupportServerIp)                  { $SupportServerIp = & $cfgStr 'SupportServerIp' }
        if (-not $RemediationRoleName)              { $RemediationRoleName = & $cfgStr 'RemediationRoleName' }
        if (-not $RemediationRoleName)              { $RemediationRoleName = 'Virtual Machine Contributor' }
        if (-not $PSBoundParameters.ContainsKey('ServiceAllowAllOutbound') -and (Get-ZsConfigFlag $cfg 'ServiceAllowAllOutbound')) { $ServiceAllowAllOutbound = [switch]$true }
        if (-not $PSBoundParameters.ContainsKey('CreateRemediationRole') -and (Get-ZsConfigFlag $cfg 'CreateRemediationRole')) { $CreateRemediationRole = [switch]$true }
        if (-not $PSBoundParameters.ContainsKey('DisableLegacyVmNvaTag') -and (& $cfgHas 'LegacyVmNvaTag')) {
            if (-not (Get-ZsConfigFlag $cfg 'LegacyVmNvaTag' -Default $true)) { $DisableLegacyVmNvaTag = [switch]$true }
        }
        if ((& $cfgHas 'TerminateUnhealthyInstances') -and -not $PSBoundParameters.ContainsKey('DisableHealthRemediation')) {
            if (-not [bool]$cfg.TerminateUnhealthyInstances) { $DisableHealthRemediation = [switch]$true }
        }
        if ((& $cfgHas 'HealthDataPoints') -and -not $PSBoundParameters.ContainsKey('HealthDataPoints'))                     { $HealthDataPoints = $cfg.HealthDataPoints }
        if ((& $cfgHas 'HealthUnhealthyThreshold') -and -not $PSBoundParameters.ContainsKey('HealthUnhealthyThreshold'))     { $HealthUnhealthyThreshold = $cfg.HealthUnhealthyThreshold }
        if ((& $cfgHas 'HealthConsecutiveThreshold') -and -not $PSBoundParameters.ContainsKey('HealthConsecutiveThreshold')) { $HealthConsecutiveThreshold = $cfg.HealthConsecutiveThreshold }
        if ((& $cfgHas 'HealthGracePeriodMinutes') -and -not $PSBoundParameters.ContainsKey('HealthGracePeriodMinutes'))     { $HealthGracePeriodMinutes = $cfg.HealthGracePeriodMinutes }
        if ((& $cfgHas 'MaxTerminationPercent') -and -not $PSBoundParameters.ContainsKey('MaxTerminationPercent'))           { $MaxTerminationPercent = $cfg.MaxTerminationPercent }
        if ((& $cfgHas 'TerminationPolicy') -and -not $PSBoundParameters.ContainsKey('TerminationPolicy'))                   { $TerminationPolicy = $cfg.TerminationPolicy }
        if ($HealthUnhealthyThreshold -gt $HealthDataPoints) {
            Write-ZsError -Message "HealthUnhealthyThreshold ($HealthUnhealthyThreshold) exceeds HealthDataPoints ($HealthDataPoints); the unhealthy verdict could never be reached." -ErrorId 'ZsInvalidHealthThreshold' -Cmdlet $PSCmdlet
        }

        # Lifecycle package resolution.
        # A configuration is honoured in full or the run refuses it; it is never half-applied.
        # 'Auto' picks the package that can honour everything: Zscaler's supported artifact
        # whenever it can, this module's function whenever the topology or an override needs it.
        $pkgConflicts = @()
        if ($SyncIntervalMinutes -ne 30)       { $pkgConflicts += "SyncIntervalMinutes=$SyncIntervalMinutes" }
        if ($HealthDataPoints -ne 10)          { $pkgConflicts += "HealthDataPoints=$HealthDataPoints" }
        if ($HealthUnhealthyThreshold -ne 7)   { $pkgConflicts += "HealthUnhealthyThreshold=$HealthUnhealthyThreshold" }
        if ($HealthConsecutiveThreshold -ne 5) { $pkgConflicts += "HealthConsecutiveThreshold=$HealthConsecutiveThreshold" }
        if ($HealthGracePeriodMinutes -ne 30)  { $pkgConflicts += "HealthGracePeriodMinutes=$HealthGracePeriodMinutes" }
        if ($MaxTerminationPercent -ne 0.2)    { $pkgConflicts += "MaxTerminationPercent=$MaxTerminationPercent" }
        if ($TerminationPolicy -ne 'oldest')   { $pkgConflicts += "TerminationPolicy=$TerminationPolicy" }
        $pkgStandalone = ($Topology -ne 'VMSS')

        if ($FunctionPackage -eq 'Auto') {
            if ($pkgStandalone) {
                $FunctionPackage = 'Module'
                Write-ZsLog "FunctionPackage resolved: Module ($Topology topology; the vendor package manages scale sets only)"
            } elseif ($pkgConflicts.Count -gt 0) {
                $FunctionPackage = 'Module'
                Write-ZsLog "FunctionPackage resolved: Module (config overrides the vendor package cannot honour: $($pkgConflicts -join ', '))"
            } else {
                $FunctionPackage = 'Vendor'
                Write-ZsLog "FunctionPackage resolved: Vendor (VMSS topology, default cadence and thresholds; running Zscaler's supported package)"
            }
        } elseif ($FunctionPackage -eq 'Vendor') {
            if ($pkgStandalone) {
                Write-ZsError -Message "FunctionPackage 'Vendor' cannot be honoured: Zscaler's package manages scale sets only, so a $Topology deployment would run a function that does nothing. Set FunctionPackage to 'Module' or 'Auto'. Nothing has been deployed." -ErrorId 'ZsConfigNotHonoured' -Cmdlet $PSCmdlet
            }
            if ($pkgConflicts.Count -gt 0) {
                Write-ZsError -Message "FunctionPackage 'Vendor' cannot honour this configuration: $($pkgConflicts -join ', '). Remove the overrides, or set FunctionPackage to 'Module' or 'Auto'. Nothing has been deployed." -ErrorId 'ZsConfigNotHonoured' -Cmdlet $PSCmdlet
            }
        }

        if ($FunctionPackage -eq 'Vendor' -and $FunctionPackageUrl) {
            if ($FunctionPackageUrl -notmatch '^https://') {
                Write-ZsError -Message "FunctionPackageUrl '$FunctionPackageUrl' must be an https:// URL, or empty to deploy the copy in FunctionApp/vendor." -ErrorId 'ZsInvalidPackageUrl' -Cmdlet $PSCmdlet
            }
            Write-ZsLog "The lifecycle function runs Zscaler's published package from $FunctionPackageUrl; nothing is deployed from this machine"
        } elseif ($FunctionPackage -eq 'Vendor') {
            # The resolved artifact must exist before anything is built, not fail at publish
            # time twenty minutes in.
            $vendorGate = Test-ZsVendorPackage
            if (-not $vendorGate.Valid) {
                Write-ZsError -Message ("FunctionPackage resolved to 'Vendor' but zscaler_cc_function_app.zip failed its check: $($vendorGate.Reason) ($($vendorGate.Path)). Copy the artifact from Zscaler's terraform module (modules/terraform-zscc-function-app-azure/zscaler_cc_function_app.zip) into this module's FunctionApp/vendor folder, leave FunctionPackageUrl at its default to run Zscaler's published copy, or set FunctionPackage to 'Module'. Nothing has been deployed.") -ErrorId 'ZsVendorPackageMissing' -Cmdlet $PSCmdlet
            }
        }
        if ($FunctionPackage -eq 'Module' -or -not $FunctionPackageUrl) {
            # Said up front: the app takes no public traffic, so the zip deploy only works from where
            # its private endpoint resolves, and that is not checkable until the endpoint exists.
            Write-ZsLog ("The $FunctionPackage function package is zip-deployed to the Function App through the app's private endpoint, " +
                "its only way in. Run this deployment from a host inside the network that resolves privatelink.azurewebsites.net " +
                "to that endpoint: the VNet, a network the zone is linked to, or on-premises through the hub's DNS. From any other host " +
                "the rest of the deployment completes, the run ends PartialSuccess, and a re-run from inside the network deploys the package.") -Level WARN
        }

        # Alerting receivers: config-supplied unless the parameter overrides, like every other
        # field. Config values bypass parameter binding, so the format check repeats here.
        if ((& $cfgHas 'NotificationEmail') -and -not $PSBoundParameters.ContainsKey('NotificationEmail')) { $NotificationEmail = @($cfg.NotificationEmail | Where-Object { $_ }) }
        foreach ($addr in @($NotificationEmail | Where-Object { $_ })) {
            if ($addr -notmatch '^[^@\s]+@[^@\s]+\.[^@\s]+$') {
                Write-ZsError -Message "NotificationEmail entry '$addr' is not an email address. Fix it in the config file or the -NotificationEmail parameter." -ErrorId 'ZsInvalidNotificationEmail' -Cmdlet $PSCmdlet
            }
        }

        $byo = $cfg.BringYourOwn

        # The platform's privatelink zones, in a hub-and-spoke network: private endpoints register
        # there instead of in zones this deployment creates and links (Terraform's
        # private_dns_resource_group_name / private_dns_subscription_id).
        $dnsHubRg  = Get-ZsConfigValue $byo 'PrivateDnsZoneResourceGroupName'
        $dnsHubSub = Get-ZsConfigValue $byo 'PrivateDnsZoneSubscriptionId'

        # Existing-network intent, read once and defensively (the block may be a hashtable or a
        # PSCustomObject, and older configs omit the name fields entirely). A named VNet — VnetName
        # the Terraform way, or a full VnetId — declares that the deployment attaches to a network
        # somebody else owns; the actual resolution happens just before anything is built against it.
        $byoNetIntent = [bool]((Get-ZsConfigValue $byo 'VnetId') -or (Get-ZsConfigValue $byo 'VnetName'))
        # Terraform's attach_nat_gateway: false where the platform already gives a brought network's
        # connector and Function App subnets their way out. No NAT gateway or egress address is then
        # created, and the platform's egress address is the one the Zscaler portal allowlists.
        $attachNat = if ($byoNetIntent) { Get-ZsConfigFlag $byo 'AttachNatGateway' -Default $true } else { $true }

        # Deployment scope
        # Settled before any other check runs. A BringYourOwn resource group declares brownfield
        # intent and is honoured only when the group exists; the session's resource group name is
        # rebound here so every path, check and manifest entry from this point targets the group the
        # deployment actually writes to. Resolving it later — after the prerequisite and permission
        # checks — would validate one resource group and deploy into another.
        $byoRgName = Get-ZsConfigValue $byo 'ResourceGroupName'
        $scope = Resolve-ZsDeploymentScope -ResourceGroupName $byoRgName -Cmdlet $PSCmdlet
        if ($scope.Mode -eq 'Brownfield') {
            Write-ZsLog "Brownfield: deploying into existing resource group $($scope.ResourceGroupName)"
        }

        # Access preflight
        # Effective permissions at that scope, plus any enforcing Azure Policy that would refuse the
        # result. A missing permission stops the run here, while nothing exists to unwind. Bastion is
        # probed whenever it is not switched off: a brought network can carry an AzureBastionSubnet,
        # and if it does the host is created into it, so the permission must hold there too. A
        # brought VNet's resource group, read with Resolve-ZsExistingNetwork's defaults, is checked
        # for the grants made on the connector subnets.
        if (-not $SkipPrerequisites) {
            $remediating = $Topology -eq 'VMSS' -and -not $DisableHealthRemediation
            $vnetRgId = ''
            if ($byoNetIntent) {
                $cfgVnetId = Get-ZsConfigValue $byo 'VnetId'
                $vnetRgId = if ($cfgVnetId) { ($cfgVnetId -split '/providers/')[0] } else {
                    $vnetRg  = Get-ZsConfigValue $byo 'VnetResourceGroupName'; if (-not $vnetRg) { $vnetRg = $script:ZsSession.ResourceGroupName }
                    $vnetSub = Get-ZsConfigValue $byo 'VnetSubscriptionId';    if (-not $vnetSub) { $vnetSub = $script:ZsSession.SubscriptionId }
                    "/subscriptions/$vnetSub/resourceGroups/$vnetRg"
                }
            }
            $null = Test-ZsAccess -ResourceGroupName $byoRgName -Topology $Topology `
                -IdentityRoleMode $cfg.IdentityRoleMode -FunctionRoleMode $FunctionRoleMode `
                -VmSize $cfg.VmSize `
                -Bastion:((-not $NoBastion) -and (-not $cfg.NoBastion)) `
                -Defender:$EnableDefender `
                -MonitorPrivateLink:(-not $DisableMonitorPrivateLink) `
                -BastionSku $BastionSku -NatPublicIpMode $NatPublicIpMode -NatExistingPublicIp:([bool]$NatExistingPublicIpId) -NoNatGateway:(-not $attachNat) `
                -CreateRemediationRole:($CreateRemediationRole -and $remediating) `
                -NetworkResourceGroupId $vnetRgId -GrantSubnetRemediation:($remediating -and $byoNetIntent -and (Get-ZsConfigFlag $byo 'GrantFunctionSubnetJoin' -Default $true)) `
                -LocalFunctionPackage:($FunctionPackage -eq 'Module' -or -not $FunctionPackageUrl)
        }

        # Collect the Zscaler-side requirements and report any that are missing together.
        $haveApiKey = [bool]$ApiKey -or [bool]$script:ZsSession.ZscalerApiKeySS
        $haveUser   = [bool]$AdminUser -or [bool]$script:ZsSession.ZscalerUsername
        $havePass   = [bool]$AdminPassword -or [bool]$script:ZsSession.ZscalerPasswordSS

        $missing = [System.Collections.Generic.List[string]]::new()
        if (-not $haveApiKey) { $missing.Add('Zscaler API key (-ApiKey, or run Connect-ZscalerCloud)') }
        if (-not $haveUser)   { $missing.Add('admin username (-AdminUser, or run Connect-ZscalerCloud)') }
        if (-not $havePass)   { $missing.Add('admin password (-AdminPassword, or run Connect-ZscalerCloud)') }
        if ($missing.Count -gt 0) {
            Write-ZsError -Message ("Cannot start deployment. Missing: " + ($missing -join '; ') + ". These come from your Zscaler portal; pass them to New-ZsDeployment or call Connect-ZscalerCloud first.") -ErrorId 'ZsMissingZscalerInput' -Cmdlet $PSCmdlet
        }

        if (-not $ProvisioningUrl -and $script:ZsSession.ZscalerConnected) {
            $ff = 'Small'; foreach ($k in $script:CcFormFactorMap.Keys) { if ($cfg.VmSize -in $script:CcFormFactorMap[$k]) { $ff = $k; break } }
            $ProvisioningUrl = (New-ZsProvisioningUrl -FormFactor $ff -ReleaseChannel $ReleaseChannel).ProvisioningUrl
        }
        if (-not $ProvisioningUrl) {
            Write-ZsError -Message 'No provisioning URL available. Either pass -ProvisioningUrl, or run Connect-ZscalerCloud so one can be generated automatically.' -ErrorId 'ZsMissingProvisioningUrl' -Cmdlet $PSCmdlet
        }
        # Baked into every connector's cloud-init: a URL for another Zscaler cloud boots connectors
        # that never register.
        if ($script:ZsSession.ZscalerConnected -and $script:ZsSession.ZscalerApiUrl) {
            $provHost = ((ConvertTo-ZsCcUrl -Url $ProvisioningUrl) -split '/')[0]
            $apiHost  = ((ConvertTo-ZsCcUrl -Url ([string]$script:ZsSession.ZscalerApiUrl)) -split '/')[0]
            if ($provHost -and $apiHost -and $provHost -ne $apiHost) {
                Write-ZsLog "Provisioning URL host $provHost differs from the connected Zscaler cloud ($apiHost); connectors provisioned against another cloud never register." -Level WARN
            }
        }

        # Select the credential source without decrypting. Both the parameter and the session field
        # are already SecureStrings, so the previous round trip — decrypt to a managed string here,
        # re-encrypt forty lines later — protected nothing and left the secrets in the heap for the
        # whole of preflight. The credentials are needed because they are written to the vault for
        # the lifecycle function to read, so an absence is named here rather than surfacing as a
        # parameter binding error at the vault call.
        $apiKeySS = if ($ApiKey) { $ApiKey } elseif ($script:ZsSession.ZscalerApiKeySS) { $script:ZsSession.ZscalerApiKeySS } else { $null }
        if (-not $AdminUser -and $script:ZsSession.ZscalerUsername) { $AdminUser = $script:ZsSession.ZscalerUsername }
        $passSS   = if ($AdminPassword) { $AdminPassword } elseif ($script:ZsSession.ZscalerPasswordSS) { $script:ZsSession.ZscalerPasswordSS } else { $null }

        $credGaps = [System.Collections.Generic.List[string]]::new()
        if (-not $apiKeySS)  { $credGaps.Add('-ApiKey') }
        if (-not $AdminUser) { $credGaps.Add('-AdminUser') }
        if (-not $passSS)    { $credGaps.Add('-AdminPassword') }
        if ($credGaps.Count -gt 0) {
            Write-ZsError -Message ("Missing Zscaler credential(s): " + ($credGaps -join ', ') +
                ". They are stored in the deployment's Key Vault for the lifecycle Function App to read, so the " +
                "deployment cannot proceed without them. Supply them directly, or run Connect-ZscalerCloud first " +
                "so the session carries them.") -ErrorId 'ZsMissingZscalerCredentials' -Cmdlet $PSCmdlet
        }

        if (-not $SshPublicKey) { $SshPublicKey = (New-ZsSshKey).PublicKey }
        if (-not $ManifestPath) { $ManifestPath = Get-ZsArtifactPath -FileName "zscc-manifest-$($script:ZsSession.ShortId).json" }

        # Resolve zones against subscription entitlements.
        if (-not $SkipPrerequisites) {
            $policy = if ($AdaptZones) { 'Adapt' } else { 'Strict' }
            $zoneRes = Resolve-ZsZones -Requested $cfg.Zones -VmSize $cfg.VmSize -Policy $policy
            if (-not $zoneRes.Ok) {
                Write-ZsError -Message "Zone selection cannot proceed. $($zoneRes.Reason)" -ErrorId 'ZsNoUsableZones' -Category 'InvalidOperation' -Cmdlet $PSCmdlet
            }
            if ($zoneRes.Changed) {
                $lvl = if ($zoneRes.Mode -eq 'Adapt') { 'WARN' } else { 'INFO' }
                Write-ZsLog $zoneRes.Reason -Level $lvl
            }
            $cfg.Zones = $zoneRes.Zones
            # Keep connector count sensible relative to the resolved zone count: at least one per zone.
            if ($cfg.CcCount -lt $cfg.Zones.Count) {
                Write-ZsLog "Raising CcCount from $($cfg.CcCount) to $($cfg.Zones.Count) so each zone has at least one connector." -Level WARN
                $cfg.CcCount = $cfg.Zones.Count
            }
        }

        # Each scale set starts at CcCount and autoscale falls back to it while no metrics arrive,
        # so it is the profile's default capacity, and Azure refuses an autoscale setting whose
        # default lies outside its minimum and maximum. The scheduled profile's floor has the same
        # ceiling. Checked once the count is final, before anything is written.
        if ($Topology -eq 'VMSS') {
            if ($MinInstances -lt 1 -or $cfg.CcCount -lt $MinInstances -or $cfg.CcCount -gt $MaxInstances) {
                Write-ZsError -Message ("CcCount=$($cfg.CcCount) is each scale set's starting capacity and its autoscale default, so it must lie " +
                    "between MinInstances=$MinInstances and MaxInstances=$MaxInstances, with MinInstances at least 1. Nothing has been deployed.") `
                    -ErrorId 'ZsInvalidInstanceRange' -Cmdlet $PSCmdlet
            }
            if ($ScheduledScaling -and ($ScheduledMinInstances -lt 1 -or $ScheduledMinInstances -gt $MaxInstances)) {
                Write-ZsError -Message ("ScheduledMinInstances=$ScheduledMinInstances must lie between 1 and MaxInstances=${MaxInstances}: it is the " +
                    "scheduled profile's floor, and that profile shares the same ceiling. Nothing has been deployed.") -ErrorId 'ZsInvalidInstanceRange' -Cmdlet $PSCmdlet
            }
        }

        if (-not $SkipPrerequisites) {
            $pre = Test-ZsPrerequisites -AcceptMarketplaceTerms -VmSize $cfg.VmSize -Zones $cfg.Zones -FunctionPackage $FunctionPackage -FunctionPackageUrl $FunctionPackageUrl -Mode $scope.Mode
            if (-not $pre.Ready) { Write-ZsError -Message "Prerequisites failed ($($pre.Failed) issues). Resolve them, or pass -SkipPrerequisites to override." -ErrorId 'ZsPrerequisitesFailed' -Category 'InvalidOperation' -Cmdlet $PSCmdlet }
        }

        Write-ZsLog "Deploying ($($cfg.Mode) mode)"
        if ($StateStorageAccount -and $PSCmdlet.ShouldProcess($StateStorageAccount, 'Acquire deployment state lock')) {
            Initialize-ZsRemoteState -AccountName $StateStorageAccount -ContainerName $StateContainerName -BreakLease:$BreakStateLock | Out-Null
        }
        Suspend-ZsSleep
        $status = 'Succeeded'
        $rg=$null; $nsgs=$null; $net=$null; $pub=$null; $id=$null; $kv=$null; $lb=$null; $vms=$null; $rt=$null; $faInfra=$null
        $pkgPending = $false

        try {
            $deployBastion = (-not $NoBastion) -and (-not $cfg.NoBastion) -and (-not $byoNetIntent)

            # Resolve the subnet plan for greenfield. Includes the Function App subnet.
            $subnetPlan = $null
            $bastionCidr = ''
            if (-not $byoNetIntent) {
                $supplied = @{
                    'AzureBastionSubnet'     = $cfg.BastionSubnetCidr
                    'snet-zscc-lb'           = $cfg.LbSubnetCidr
                    'snet-zscc-workload'     = $cfg.WorkloadSubnetCidr
                    'snet-zscc-funcapp'      = $cfg.FuncAppSubnetCidr
                    'snet-zscc-dns-inbound'  = $cfg.DnsInboundCidr
                    'snet-zscc-dns-outbound' = $cfg.DnsOutboundCidr
                }
                # StandardV2 architecture: one shared management and one shared service subnet.
                # A legacy config still carrying per-zone ZoneSubnetCidrs stops here by name,
                # rather than having one zone's addresses silently promoted to the new shape.
                $legacyZones = $false
                try { $legacyZones = [bool]($cfg.ZoneSubnetCidrs -and @($cfg.ZoneSubnetCidrs.Keys).Count -gt 0) } catch { }
                $hasNew = $false
                try { $hasNew = [bool]($cfg.MgmtSubnetCidr -and $cfg.ServiceSubnetCidr) } catch { }
                if ($legacyZones -and -not $hasNew) {
                    Write-ZsError -Message ("This configuration uses the per-zone ZoneSubnetCidrs schema. The deployment now uses one " +
                        "shared management and one shared service subnet (zone-redundant StandardV2 NAT removed the per-zone requirement). " +
                        "Replace ZoneSubnetCidrs with MgmtSubnetCidr and ServiceSubnetCidr - sized for every zone's connectors together - and re-run.") `
                        -ErrorId 'ZsLegacyZoneSubnetSchema' -Cmdlet $PSCmdlet
                }
                $supplied['snet-zscc-mgmt']    = [string]$cfg.MgmtSubnetCidr
                $supplied['snet-zscc-service'] = [string]$cfg.ServiceSubnetCidr
                $subnetPlan  = Resolve-ZsSubnetPlan -VnetCidr $cfg.VnetAddressSpace -SubnetCidrs $supplied -Zones $cfg.Zones -EnableBastion:$deployBastion

                # Shared subnets carry every zone's connectors at once, so capacity is checked
                # against the whole fleet's ceiling, not one zone's: max instances per zone times
                # zones for a scale set deployment, the connector count for standalone VMs, one
                # NIC per connector per subnet, minus Azure's five reserved addresses.
                $fleetCeiling = if ($Topology -eq 'VMSS') { [int]$MaxInstances * @($cfg.Zones).Count } else { [int]$cfg.CcCount }
                foreach ($capName in @('snet-zscc-mgmt','snet-zscc-service')) {
                    $capCidr = [string]$supplied[$capName]
                    if ($capCidr -match '/(\d+)$') {
                        $usable = [math]::Pow(2, 32 - [int]$Matches[1]) - 5
                        if ($usable -lt $fleetCeiling) {
                            Write-ZsError -Message ("$capName ($capCidr) has $usable usable addresses but the fleet can reach " +
                                "$fleetCeiling connectors across zones $($cfg.Zones -join ', '). Size the shared subnet for the whole " +
                                "fleet's ceiling, not one zone's.") -ErrorId 'ZsSharedSubnetTooSmall' -Cmdlet $PSCmdlet
                        }
                    }
                }
                $bastionCidr = if ($deployBastion) { $subnetPlan.'AzureBastionSubnet' } else { '' }
            }

            # Existing network. Resolved by name or by resource ID — the PowerShell twin of the
            # Terraform data sources: vnet_name / vnet_resource_group_name / network_subscription_id
            # and the per-role subnet names travel between the two tools unchanged. One ARM read
            # settles the whole lookup; every gap it finds is reported together, the way one
            # terraform plan reports them, before anything is created against the network.
            $byoNet = [bool]$byoNetIntent
            $exNet  = $null
            if ($byoNet) {
                $wantBastionByo = (-not $NoBastion) -and (-not $cfg.NoBastion)
                $exNet = Resolve-ZsExistingNetwork -BringYourOwn $byo -WantBastion:$wantBastionByo -Cmdlet $PSCmdlet
                # The vault and the function's storage answer only on their private endpoints, so
                # their names have to resolve to them from the connectors and the function. With
                # custom DNS servers on the VNet, a zone this deployment links to it is consulted
                # only if those servers forward to Azure DNS from here; in a hub-and-spoke network
                # they resolve through the hub's zones instead, and the records belong there.
                if (-not $dnsHubRg -and @($exNet.DnsServers).Count -gt 0) {
                    Write-ZsLog ("VNet $($exNet.VnetName) uses custom DNS servers ($(@($exNet.DnsServers) -join ', ')). The private endpoints will " +
                        "register in privatelink zones this deployment creates and links to the VNet, which those servers see only if they " +
                        "forward to Azure DNS (168.63.129.16) from a network linked to the zones. If they resolve privatelink names in the " +
                        "platform's hub zones, set BringYourOwn.PrivateDnsZoneResourceGroupName (and PrivateDnsZoneSubscriptionId) so the " +
                        "records are written there; otherwise connectors cannot reach the Key Vault and never register.") -Level WARN
                }
            }

            $api = $script:ApiVersions.Network

            # NSGs. Terraform's prod environment creates the module's own NSGs and associates them
            # onto subnets it did not create; this now does the same. Supplying MgmtNsgId and
            # ServiceNsgId in the config keeps the old contract and binds yours instead. Either way,
            # both connector subnets end this step carrying the chosen NSG. A different one already
            # on either subnet, or a NAT gateway that is not this deployment's, stops the run below
            # before anything is attached, as Terraform's associations refuse such a subnet.
            $byoMgmtNsgId    = if ($byoNet) { Get-ZsConfigValue $byo 'MgmtNsgId' }    else { '' }
            $byoServiceNsgId = if ($byoNet) { Get-ZsConfigValue $byo 'ServiceNsgId' } else { '' }
            # The Function App subnet's NSG: the module's own unless one is supplied, or unless the
            # platform team attaches theirs (AttachFuncAppNsg false, Terraform's attach_funcapp_nsg).
            $byoFuncNsgId    = if ($byoNet) { Get-ZsConfigValue $byo 'FuncAppNsgId' } else { '' }
            $attachFuncNsg   = if ($byoNet) { Get-ZsConfigFlag $byo 'AttachFuncAppNsg' -Default $true } else { $true }

            if ($byoNet) {
                Assert-ZsSubnetAttachment -Network $exNet -MgmtNsgId $byoMgmtNsgId -ServiceNsgId $byoServiceNsgId -AttachNatGateway $attachNat -Cmdlet $PSCmdlet
                if (-not $attachNat -and -not $exNet.Subnets.ContainsKey('snet-zscc-funcapp')) {
                    Write-ZsLog ("AttachNatGateway is false and no Function App subnet is named, so snet-zscc-funcapp is created in $($exNet.VnetName) with no " +
                        "NAT gateway or route table of its own. Unless the platform attaches its egress to new subnets, the lifecycle function cannot " +
                        "reach Azure or the Zscaler portal: name the platform's Function App subnet in BringYourOwn.FuncAppSubnetName instead.") -Level WARN
                }
            }

            # Scope was resolved and bound to the session during preflight. Brownfield reuses the
            # verified existing group; greenfield creates the module's own, once the checks above pass.
            $rg = if ($scope.Mode -eq 'Brownfield') {
                [PSCustomObject]@{ Name = $scope.ResourceGroupName; ResourceId = $scope.Scope; Status = 'Existing' }
            } else {
                New-ZsResourceGroup
            }

            # The private endpoints in the management subnet have two clients: the connectors in that
            # subnet, and the Function App through its integration subnet. Their ranges are the
            # sources of the management NSG's TCP 443 rule.
            $peClientCidrs = [System.Collections.Generic.List[string]]::new()
            if ($byoNet) {
                $peClientCidrs.Add([string]$exNet.Subnets['snet-zscc-mgmt'].Prefix)
                if ($exNet.Subnets.ContainsKey('snet-zscc-funcapp')) { $peClientCidrs.Add([string]$exNet.Subnets['snet-zscc-funcapp'].Prefix) }
                elseif ($cfg.FuncAppSubnetCidr) { $peClientCidrs.Add([string]$cfg.FuncAppSubnetCidr) }
            } else {
                $peClientCidrs.Add([string]$subnetPlan.'snet-zscc-mgmt')
                $peClientCidrs.Add([string]$subnetPlan.'snet-zscc-funcapp')
            }

            $nsgs = if ($byoNet -and $byoMgmtNsgId -and $byoServiceNsgId) {
                Write-ZsLog "Reusing supplied NSGs for the management and service subnets"
                if ($ServiceAllowAllOutbound) { Write-ZsLog "ServiceAllowAllOutbound changes nothing on the supplied service NSG; it allows what its owner allows" -Level WARN }
                $funcNsg = ''
                if ($byoFuncNsgId) { $funcNsg = $byoFuncNsgId }
                elseif ($attachFuncNsg) { $funcNsg = Set-ZsNsg -Name "nsg-zscc-func-$($script:ZsSession.Environment)-$($script:ZsSession.Location)" -Rules (Get-ZsFuncAppNsgRuleSet) -Role 'FunctionApp' }
                [PSCustomObject]@{ MgmtNsgId = $byoMgmtNsgId; ServiceNsgId = $byoServiceNsgId; FuncAppNsgId = $funcNsg }
            } else {
                # In a brought network the SSH source follows the network's own AzureBastionSubnet
                # range when there is one — read off the subnet rather than asked for again, the
                # same way the Terraform locals do.
                $nsgBastionCidr = if ($byoNet) { if ($exNet.BastionSubnet) { $exNet.BastionSubnet.Prefix } else { '' } } else { $bastionCidr }
                $made = New-ZsNetworkSecurity -EnableSupportTunnel:([bool]$cfg.EnableSupportTunnel) -SupportServerIp $SupportServerIp `
                    -SshSourceCidr $cfg.SshSourceCidr -HttpProbePort $cfg.HttpProbePort -WorkloadCidrs $cfg.WorkloadCidrs -BastionSubnetCidr $nsgBastionCidr `
                    -PrivateEndpointClientCidrs $peClientCidrs.ToArray() -FunctionAppNsg:($attachFuncNsg -and -not $byoFuncNsgId) -ServiceAllowAllOutbound:$ServiceAllowAllOutbound
                if ($byoFuncNsgId) { $made.FuncAppNsgId = $byoFuncNsgId }
                $made
            }

            $net = if ($byoNet) {
                $vn  = $exNet.VnetName; $vp = $exNet.VnetPath
                $sub = @{}
                foreach ($roleKey in @('snet-zscc-mgmt','snet-zscc-service','snet-zscc-workload','snet-zscc-lb')) {
                    $sub[$roleKey] = $exNet.Subnets[$roleKey].Id
                }
                $subnetPlan = $exNet.SubnetPlan

                # Shared subnets carry every zone's connectors at once, so the brought network gets
                # the same fleet-ceiling check the greenfield plan gets: max instances per zone
                # times zones for a scale set deployment, the connector count for standalone VMs,
                # minus Azure's five reserved addresses.
                $fleetCeiling = if ($Topology -eq 'VMSS') { [int]$MaxInstances * @($cfg.Zones).Count } else { [int]$cfg.CcCount }
                foreach ($capKey in @('snet-zscc-mgmt','snet-zscc-service')) {
                    $capCidr = [string]$exNet.Subnets[$capKey].Prefix
                    if ($capCidr -match '/(\d+)$') {
                        $usable = [math]::Pow(2, 32 - [int]$Matches[1]) - 5
                        if ($usable -lt $fleetCeiling) {
                            Write-ZsError -Message ("Existing $($exNet.Subnets[$capKey].Name) ($capCidr) has $usable usable addresses but the fleet " +
                                "can reach $fleetCeiling connectors across zones $($cfg.Zones -join ', '). Point at a larger subnet, or lower the fleet ceiling.") `
                                -ErrorId 'ZsSharedSubnetTooSmall' -Cmdlet $PSCmdlet
                        }
                    }
                }

                # Both private endpoints (Key Vault, and the Function App's when enabled) terminate
                # in the management subnet. With endpoint network policies enabled there, the NSG
                # on that subnet filters their traffic too — worth knowing, not worth stopping for.
                $mgmtObj = $exNet.Subnets['snet-zscc-mgmt'].Object
                $peState = ''
                if ($mgmtObj.properties.PSObject.Properties['privateEndpointNetworkPolicies']) { $peState = [string]$mgmtObj.properties.privateEndpointNetworkPolicies }
                if ($peState -and $peState -notlike 'Disabled') {
                    Write-ZsLog ("Management subnet $($exNet.Subnets['snet-zscc-mgmt'].Name) has privateEndpointNetworkPolicies='$peState': " +
                        "NSG rules on it will also apply to the private endpoints placed there. The platform team usually disables this on the endpoint subnet.") -Level WARN
                }

                # Attach-time NSG association, the azurerm_subnet_network_security_group_association
                # equivalent: whichever NSGs were chosen above — created or supplied — are bound to
                # the existing management and service subnets. Idempotent on re-runs.
                if ($nsgs.MgmtNsgId -and $nsgs.MgmtNsgId -notmatch '^\(') {
                    Set-ZsSubnetNsgAssociation -SubnetId $sub['snet-zscc-mgmt'] -NsgId $nsgs.MgmtNsgId -Label $exNet.Subnets['snet-zscc-mgmt'].Name | Out-Null
                }
                if ($nsgs.ServiceNsgId -and $nsgs.ServiceNsgId -notmatch '^\(') {
                    Set-ZsSubnetNsgAssociation -SubnetId $sub['snet-zscc-service'] -NsgId $nsgs.ServiceNsgId -Label $exNet.Subnets['snet-zscc-service'].Name | Out-Null
                }

                # The network is somebody else's. Recording it, and each subnet, as pre-existing is
                # what lets teardown detach the NAT gateway, route table and NSGs this run attached
                # while deleting nothing it did not create.
                Add-ZsManifestResource -Type 'VNet' -Name $vn -ResourceId $exNet.VnetId -Properties @{ AddressSpace = (@($exNet.AddressSpace) -join ',') } -PreExisting
                foreach ($roleKey in @('snet-zscc-mgmt','snet-zscc-service','snet-zscc-workload','snet-zscc-lb')) {
                    Add-ZsManifestResource -Type 'Subnet' -Name $exNet.Subnets[$roleKey].Name -ResourceId $sub[$roleKey] -PreExisting
                }
                if ($exNet.BastionSubnet) {
                    Add-ZsManifestResource -Type 'Subnet' -Name $exNet.BastionSubnet.Name -ResourceId $exNet.BastionSubnet.Id -PreExisting
                }

                # Function App subnet for lifecycle management (both topologies). An existing one —
                # named via FuncAppSubnetName or FuncAppSubnetId, the funcapp_subnet_name of the
                # Terraform side — is validated for its Microsoft.Web/serverFarms delegation and has
                # its Microsoft.Storage endpoint reconciled on. Without one, snet-zscc-funcapp is
                # created in the brought VNet from FuncAppSubnetCidr, as before.
                if ($exNet.Subnets.ContainsKey('snet-zscc-funcapp')) {
                    $fa = $exNet.Subnets['snet-zscc-funcapp']
                    $faDelegated = $false
                    if ($fa.Object.properties.PSObject.Properties['delegations']) {
                        foreach ($d in @($fa.Object.properties.delegations)) {
                            $svcName = ''
                            if ($d.PSObject.Properties['properties'] -and $d.properties.PSObject.Properties['serviceName']) { $svcName = [string]$d.properties.serviceName }
                            if ($svcName -like 'Microsoft.Web/serverFarms') { $faDelegated = $true; break }
                        }
                    }
                    if (-not $faDelegated) {
                        Write-ZsError -Message ("Existing Function App subnet '$($fa.Name)' is not delegated to Microsoft.Web/serverFarms. " +
                            "The Function App's VNet integration requires that delegation, and adding one to a subnet somebody else owns is their call. " +
                            "Ask the network's owner to delegate it, or clear FuncAppSubnetName/FuncAppSubnetId and set FuncAppSubnetCidr so the module creates its own. Nothing has been deployed.") `
                            -ErrorId 'ZsByoFuncAppNotDelegated' -Cmdlet $PSCmdlet
                    }
                    # No storage service endpoint: the storage account is private, and the app reaches
                    # it through private endpoints. One 5.4.1.0 added is left to the subnet's owner;
                    # it carries nothing once the account refuses public traffic.
                    if (@(Get-ZsPropertyValue $fa.Object 'properties.serviceEndpoints' | Where-Object { $_ -and [string]$_.service -eq 'Microsoft.Storage' }).Count -gt 0) {
                        Write-ZsLog "Function App subnet $($fa.Name) carries a Microsoft.Storage service endpoint the deployment no longer uses; remove it at the subnet owner's convenience."
                    }
                    # The subnet is the network owner's: an NSG of theirs on it stays.
                    if ($nsgs.FuncAppNsgId -and $nsgs.FuncAppNsgId -notmatch '^\(') {
                        Set-ZsSubnetNsgAssociation -SubnetId $fa.Id -NsgId $nsgs.FuncAppNsgId -Label $fa.Name -KeepForeignNsg | Out-Null
                    }
                    $sub['snet-zscc-funcapp'] = $fa.Id
                    Add-ZsManifestResource -Type 'Subnet' -Name $fa.Name -ResourceId $fa.Id -PreExisting
                    Write-ZsLog "Using existing Function App subnet $($fa.Name)"
                } else {
                    $funcAppCidr = $cfg.FuncAppSubnetCidr
                    if (-not $funcAppCidr) { Write-ZsError -Message 'A Function App subnet is required: name an existing delegated one with BringYourOwn.FuncAppSubnetName (or FuncAppSubnetId), or set FuncAppSubnetCidr so the module creates snet-zscc-funcapp in the existing VNet.' -ErrorId 'ZsMissingFuncAppCidr' -Cmdlet $PSCmdlet }
                    $funcSubUri = "$vp/subnets/snet-zscc-funcapp?api-version=$api"
                    if ($PSCmdlet.ShouldProcess('snet-zscc-funcapp', 'Create or update Function App subnet in BYO VNet')) {
                        $funcSubProps = @{
                            addressPrefix=$funcAppCidr
                            delegations=@(@{name='Microsoft.Web.serverFarms';properties=@{serviceName='Microsoft.Web/serverFarms'}})
                        }
                        if ($nsgs.FuncAppNsgId -and $nsgs.FuncAppNsgId -notmatch '^\(') { $funcSubProps.networkSecurityGroup = @{ id = $nsgs.FuncAppNsgId } }
                        # GET-merge-PUT: preserve existing subnet properties (NAT, NSG, route table, and
                        # service endpoints; a Microsoft.Storage one from 5.4.1.0 is removed in the
                        # Function App step, once the storage account's private endpoints are in place).
                        $existingSub = Invoke-ArmGet -Uri $funcSubUri -AllowNotFound
                        if ($existingSub -and $existingSub.PSObject.Properties.Name -contains 'properties') {
                            $ep = $existingSub.properties
                            if ($ep.PSObject.Properties.Name -contains 'natGateway' -and $ep.natGateway) { $funcSubProps.natGateway = $ep.natGateway }
                            if (-not $funcSubProps.ContainsKey('networkSecurityGroup') -and $ep.PSObject.Properties.Name -contains 'networkSecurityGroup' -and $ep.networkSecurityGroup) { $funcSubProps.networkSecurityGroup = $ep.networkSecurityGroup }
                            if ($ep.PSObject.Properties.Name -contains 'routeTable' -and $ep.routeTable) { $funcSubProps.routeTable = $ep.routeTable }
                            $haveSe = @(Get-ZsPropertyValue $ep 'serviceEndpoints' | Where-Object { $_ })
                            if ($haveSe.Count -gt 0) { $funcSubProps.serviceEndpoints = $haveSe }
                        }
                        Invoke-ArmPut -Uri $funcSubUri -Body @{ properties=$funcSubProps } | Out-Null
                        Wait-ArmProvision -Uri $funcSubUri -Label 'snet-zscc-funcapp' | Out-Null
                    }
                    $funcAppSubnetId = "$vp/subnets/snet-zscc-funcapp"
                    $sub['snet-zscc-funcapp'] = $funcAppSubnetId
                    # This one subnet is the module's own inside the brought VNet: recorded owned,
                    # so teardown deletes it (subnets first, then the NAT it references).
                    Add-ZsManifestResource -Type 'Subnet' -Name 'snet-zscc-funcapp' -ResourceId $funcAppSubnetId
                }
                Write-ZsLog "Attached to existing VNet $vn ($($exNet.VnetResourceGroupName)) with $($sub.Count) subnets"

                [PSCustomObject]@{ VnetName=$vn; VnetId=$exNet.VnetId; VnetPath=$vp; SubnetPlan=$subnetPlan; Subnets=$sub }
            } else { New-ZsNetworkFoundation -AddressSpace $cfg.VnetAddressSpace -SubnetPlan $subnetPlan -MgmtNsgId $nsgs.MgmtNsgId -ServiceNsgId $nsgs.ServiceNsgId -FuncAppNsgId $nsgs.FuncAppNsgId -EnableBastion:$deployBastion }

            if ($byoNet) {
                # Bastion in a brought network follows the Terraform contract: the host is created
                # only into an AzureBastionSubnet the network already carries — the module never
                # adds a subnet to somebody else's VNet. Wanted but absent is a logged skip.
                if ((-not $NoBastion) -and (-not $cfg.NoBastion)) {
                    if ($exNet.BastionSubnet) {
                        New-ZsBastion -VnetPath $net.VnetPath -SubnetId $exNet.BastionSubnet.Id -Sku $BastionSku `
                            -ClientSourceAddressPrefix $BastionClientSourceAddressPrefix `
                            -SkipNsg:(-not (Get-ZsConfigFlag $byo 'AttachBastionNsg' -Default $true)) | Out-Null
                    } else {
                        Write-ZsLog ("Bastion skipped: VNet $vn has no AzureBastionSubnet. Have the network's owner add one (/26 or larger) and re-run, " +
                            "or set NoBastion in the config to make the skip explicit.") -Level WARN
                    }
                }
            } elseif ($deployBastion) {
                New-ZsBastion -VnetPath $net.VnetPath -Sku $BastionSku -ClientSourceAddressPrefix $BastionClientSourceAddressPrefix | Out-Null
            }

            $id = New-ZsIdentity -RoleMode $cfg.IdentityRoleMode

            $kv = New-ZsKeyVault -IdentityPrincipalId $id.PrincipalId `
                -ApiKey $apiKeySS -AdminUser $AdminUser -AdminPassword $passSS `
                -EnablePurgeProtection:(-not $DisablePurgeProtection) `
                -VnetId $net.VnetId -PrivateEndpointSubnetId $net.Subnets['snet-zscc-mgmt'] `
                -PrivateDnsZoneResourceGroupName $dnsHubRg -PrivateDnsZoneSubscriptionId $dnsHubSub

            # Bastion + NAT + LB provides 6-12 min of RBAC propagation buffer.
            # The gateway is associated by subnet ID, not by name: existing subnets keep the names
            # their owners gave them, and greenfield's Subnets map carries full IDs anyway.
            if ($attachNat) {
                $natSubnetIds = [System.Collections.Generic.List[string]]::new()
                foreach ($natKey in @('snet-zscc-mgmt','snet-zscc-service','snet-zscc-funcapp')) {
                    if ($net.Subnets[$natKey]) { $natSubnetIds.Add([string]$net.Subnets[$natKey]) }
                }
                $pub = New-ZsPublicNetwork -SubnetPlan $subnetPlan -VnetPath $net.VnetPath -Zones $cfg.Zones -FuncAppSubnetName 'snet-zscc-funcapp' -AssociateSubnetIds $natSubnetIds `
                    -PublicIpMode $NatPublicIpMode -ExistingPublicIpId $NatExistingPublicIpId -PublicIpPrefixLength $NatPublicIpPrefixLength
            } else {
                Write-ZsLog ("No NAT gateway: AttachNatGateway is false, so the connectors and the function leave through $($exNet.VnetName)'s own egress. " +
                    "Its public address is the one to allowlist in the Zscaler portal.")
            }

            $lb = New-ZsLoadBalancer -SubnetId $net.Subnets['snet-zscc-lb'] -HttpProbePort $cfg.HttpProbePort -Zones $cfg.Zones

            # Marketplace terms are a prerequisite, and -SkipPrerequisites means all of them: a
            # brownfield deployer without subscription-scope MarketplaceOrdering rights passes the
            # switch precisely so the run makes no subscription-level writes, and this call is a
            # subscription-level write. With the switch set, the terms are assumed accepted out of
            # band; if they were not, the scale set create fails with the marketplace legal-terms
            # error, which names the fix.
            if (-not $SkipPrerequisites) {
                Approve-ZsMarketplaceTerms | Out-Null
            } else {
                Write-ZsLog "-SkipPrerequisites: not verifying or accepting marketplace terms; assuming the platform owner accepted them out of band" -Level WARN
            }

            # Shared subnets for every zone's connectors.
            $mgmtSubnetId    = $net.Subnets['snet-zscc-mgmt']
            $serviceSubnetId = $net.Subnets['snet-zscc-service']

            # Starting a replacement connector joins both subnets. The function's role on the
            # deployment resource group covers them when the VNet is in that group; when it is the
            # platform team's, the role is granted on the two subnets as well, unless
            # GrantFunctionSubnetJoin is false and the platform team makes that grant.
            $remediationSubnets = @()
            if ($byoNet) {
                $vnetElsewhere = ($exNet.VnetResourceGroupName -ne $script:ZsSession.ResourceGroupName) -or
                                 ($exNet.VnetSubscriptionId -ne $script:ZsSession.SubscriptionId)
                if ($vnetElsewhere -and (Get-ZsConfigFlag $byo 'GrantFunctionSubnetJoin' -Default $true)) {
                    $remediationSubnets = @($mgmtSubnetId, $serviceSubnetId)
                } elseif ($vnetElsewhere -and -not $DisableHealthRemediation -and $Topology -eq 'VMSS') {
                    Write-ZsLog ("GrantFunctionSubnetJoin is false: the function identity needs $RemediationRoleName (or subnets/join/action) on " +
                        "$($exNet.Subnets['snet-zscc-mgmt'].Name) and $($exNet.Subnets['snet-zscc-service'].Name) from the platform team, " +
                        "or an unhealthy connector is deleted and never replaced.") -Level WARN
                }
            }

            if ($Topology -eq 'VMSS') {
                $vms = New-ZsCloudConnectorVmss -VmSize $cfg.VmSize `
                    -CcIdentityClientId $id.ClientId `
                    -MgmtSubnetId $mgmtSubnetId -ServiceSubnetId $serviceSubnetId `
                    -LbBackendId $lb.BackendId -CcIdentityResourceId $($id.IdentityId) `
                    -KeyVaultUri $kv.VaultUri -KeyVaultId $(if($kv.VaultId){$kv.VaultId}else{''}) -ProvisioningUrl $ProvisioningUrl -SshPublicKey $SshPublicKey `
                    -HttpProbePort $cfg.HttpProbePort -Zones $cfg.Zones -EncryptAtHost:$EncryptAtHost `
                    -DesiredInstances $cfg.CcCount -MinInstances $MinInstances -MaxInstances $MaxInstances `
                    -ScaleOutThreshold $ScaleOutThreshold -ScaleInThreshold $ScaleInThreshold `
                    -ScaleOutCooldownMinutes $ScaleOutCooldownMinutes -ScaleInCooldownMinutes $ScaleInCooldownMinutes `
                    -ScheduledScaling:$ScheduledScaling -ScheduledMinInstances $ScheduledMinInstances `
                    -ScheduledDays $ScheduledDays -ScheduledStartHour $ScheduledStartHour -ScheduledStartMinute $ScheduledStartMinute `
                    -ScheduledEndHour $ScheduledEndHour -ScheduledEndMinute $ScheduledEndMinute `
                    -ScheduledTimezone $ScheduledTimezone `
                    -SyncIntervalMinutes $SyncIntervalMinutes `
                    -FuncAppSubnetId $(if($net.Subnets['snet-zscc-funcapp']){$net.Subnets['snet-zscc-funcapp']}else{''}) `
                    -FunctionRoleMode $FunctionRoleMode -FunctionPackage $FunctionPackage `
                    -DisableHealthRemediation:$DisableHealthRemediation `
                    -HealthDataPoints $HealthDataPoints -HealthUnhealthyThreshold $HealthUnhealthyThreshold `
                    -HealthConsecutiveThreshold $HealthConsecutiveThreshold `
                    -HealthGracePeriodMinutes $HealthGracePeriodMinutes `
                    -MaxTerminationPercent $MaxTerminationPercent -TerminationPolicy $TerminationPolicy `
                    -EnableFunctionPrivateEndpoint:$EnableFunctionPrivateEndpoint `
                    -PrivateEndpointSubnetId $net.Subnets['snet-zscc-mgmt'] -VnetId $net.VnetId `
                    -FunctionPackageUrl $FunctionPackageUrl `
                    -PrivateDnsZoneResourceGroupName $dnsHubRg -PrivateDnsZoneSubscriptionId $dnsHubSub `
                    -RemediationRoleName $RemediationRoleName -RemediationSubnetIds $remediationSubnets -CreateRemediationRole:$CreateRemediationRole `
                    -DisableLegacyVmNvaTag:$DisableLegacyVmNvaTag
            } else {
                $vms = New-ZsCloudConnector -Count $cfg.CcCount -VmSize $cfg.VmSize `
                    -MgmtSubnetId $mgmtSubnetId -ServiceSubnetId $serviceSubnetId `
                    -LbBackendId $lb.BackendId -IdentityResourceId $($id.IdentityId) -IdentityClientId $($id.ClientId) `
                    -KeyVaultUri $kv.VaultUri -ProvisioningUrl $ProvisioningUrl -SshPublicKey $SshPublicKey `
                    -HttpProbePort $cfg.HttpProbePort -Zones $cfg.Zones -EncryptAtHost:$EncryptAtHost `
                    -DisableLegacyVmNvaTag:$DisableLegacyVmNvaTag

                # Lifecycle Function App for standalone VMs.
                $faSubnet = if ($net.Subnets['snet-zscc-funcapp']) { $net.Subnets['snet-zscc-funcapp'] } else { '' }
                # Standalone VMs are not scale set members, so there is nothing to terminate into:
                # replacement is manual by definition. Health is still evaluated and alerted on.
                $faInfra = New-ZsLifecycleFunctionApp -KeyVaultUri $kv.VaultUri -KeyVaultId $(if($kv.VaultId){$kv.VaultId}else{''}) `
                    -ProvisioningUrl $ProvisioningUrl -VmssNames '' -FuncAppSubnetId $faSubnet -SyncIntervalMinutes $SyncIntervalMinutes `
                    -FunctionPackage $FunctionPackage -DisableHealthRemediation `
                    -HealthDataPoints $HealthDataPoints -HealthUnhealthyThreshold $HealthUnhealthyThreshold `
                    -HealthConsecutiveThreshold $HealthConsecutiveThreshold `
                    -HealthGracePeriodMinutes $HealthGracePeriodMinutes `
                    -FunctionRoleMode $FunctionRoleMode `
                    -EnablePrivateEndpoint:$EnableFunctionPrivateEndpoint `
                    -PrivateEndpointSubnetId $net.Subnets['snet-zscc-mgmt'] -VnetId $net.VnetId `
                    -FunctionPackageUrl $FunctionPackageUrl `
                    -PrivateDnsZoneResourceGroupName $dnsHubRg -PrivateDnsZoneSubscriptionId $dnsHubSub
                if ($faInfra.FuncAppSubnetId) { $vms | Add-Member -NotePropertyName 'FuncAppSubnetId' -NotePropertyValue $faInfra.FuncAppSubnetId -Force }
                if ($faInfra.StorageUri) { $vms | Add-Member -NotePropertyName 'StorageUri' -NotePropertyValue $faInfra.StorageUri -Force }
            }

            $wlCidr = if ($net.SubnetPlan) { $net.SubnetPlan.'snet-zscc-workload' } elseif ($subnetPlan) { $subnetPlan.'snet-zscc-workload' } else { $cfg.WorkloadSubnetCidr }
            # Bare resource IDs in both modes: Invoke-ArmGet prepends the ARM endpoint itself. (The
            # BYO branch used to prepend it here too, so the route-table association was sent to a
            # doubled https://... address no server answers. The resolved ID also frees the workload
            # subnet from having to be named snet-zscc-workload.)
            $wlSubnetPath = if ($byoNet) { [string]$net.Subnets['snet-zscc-workload'] } else { "$($net.VnetPath)/subnets/snet-zscc-workload" }
            $rt = New-ZsPrivateNetwork -NextHopIp $lb.FrontendIp -WorkloadSubnetCidr $wlCidr -WorkloadSubnetPath $wlSubnetPath -VnetPath $net.VnetPath
            if ($cfg.EnableZpa) {
                # The foundation's SubnetPlan only carries the subnets the foundation created;
                # the DNS pair belong to the resolver and are not on it, so an unguarded property
                # read here threw under strict mode - on real ZPA deployments, not just dry runs.
                # The chain matches the workload lookup above: deployment plan first, then config.
                # Plans arrive as a hashtable from parameters or a PSCustomObject from JSON
                # config, and the DNS keys may be absent from either; the lookup handles all of
                # it without ever touching a member that is not there.
                $planGet = {
                    param($o, $k)
                    if ($null -eq $o) { return $null }
                    if ($o -is [System.Collections.IDictionary]) { return $o[$k] }
                    $prop = $o.PSObject.Properties[$k]
                    if ($prop) { $prop.Value } else { $null }
                }
                $dnsIn  = & $planGet $subnetPlan 'snet-zscc-dns-inbound'
                if (-not $dnsIn)  { $dnsIn  = & $planGet $net.SubnetPlan 'snet-zscc-dns-inbound' }
                if (-not $dnsIn)  { $dnsIn  = $cfg.DnsInboundCidr }
                $dnsOut = & $planGet $subnetPlan 'snet-zscc-dns-outbound'
                if (-not $dnsOut) { $dnsOut = & $planGet $net.SubnetPlan 'snet-zscc-dns-outbound' }
                if (-not $dnsOut) { $dnsOut = $cfg.DnsOutboundCidr }
                $null = New-ZsDnsResolver -VnetId $net.VnetId -VnetPath $net.VnetPath -ForwardToIp $lb.FrontendIp -InboundSubnetCidr $dnsIn -OutboundSubnetCidr $dnsOut
            }
            if ($cfg.SpokeVnetIds -and $cfg.SpokeVnetIds.Count -gt 0) { New-ZsVnetPeering -HubVnetId $net.VnetId -SpokeVnetIds $cfg.SpokeVnetIds -AllowForwardedTraffic | Out-Null }

            if ($EnableDefender) {
                Set-ZsDefenderPlans -SecurityContactEmail $SecurityContactEmail | Out-Null
            }
            $faIdForAlerts = ''; $aiForAlerts = ''
            if ($Topology -eq 'VMSS') {
                $faIdForAlerts = "$($vms.FunctionAppId)"; $aiForAlerts = "$($vms.AppInsightsId)"
            } elseif ($faInfra) {
                $faIdForAlerts = "$($faInfra.FunctionAppId)"; $aiForAlerts = "$($faInfra.AppInsightsId)"
            }

            if ($EnableDiagnostics) {
                $diagTargets = @{ KeyVault = $kv.VaultId; LoadBalancer = $lb.LbId }
                if ($nsgs.MgmtNsgId    -and $nsgs.MgmtNsgId    -notmatch '^\(') { $diagTargets['ManagementNsg'] = $nsgs.MgmtNsgId }
                if ($nsgs.ServiceNsgId -and $nsgs.ServiceNsgId -notmatch '^\(') { $diagTargets['ServiceNsg']    = $nsgs.ServiceNsgId }
                if ($faIdForAlerts -and $faIdForAlerts -notmatch '^\(') { $diagTargets['FunctionApp'] = $faIdForAlerts }
                New-ZsDiagnostics -ResourceIds $diagTargets | Out-Null
            }

            New-ZsMonitorAlerts -AppInsightsId $aiForAlerts -LoadBalancerId $(if ($lb) { "$($lb.LbId)" } else { '' }) `
                -NotificationEmail $NotificationEmail `
                -SyncIntervalMinutes $(if ($FunctionPackage -eq 'Vendor') { 30 } else { $SyncIntervalMinutes }) | Out-Null

            if (-not $DisableMonitorPrivateLink -and $dnsHubRg) {
                # One Azure Monitor private link scope serves a DNS namespace: its endpoint writes
                # the global monitor names into the privatelink zones, so a second scope registering
                # in the platform's zones would take those names from the hub's own. The workspace and
                # component belong in the platform's scope instead.
                Write-ZsLog ("Monitor Private Link skipped: BringYourOwn.PrivateDnsZoneResourceGroupName names the platform's privatelink zones, " +
                    "and the Azure Monitor names in them belong to the platform's own private link scope. Have the platform team add " +
                    "appi-zscc-$($script:ZsSession.ShortId) and its workspace to that scope; telemetry uses public ingestion until then.") -Level WARN
            } elseif (-not $DisableMonitorPrivateLink) {
                if ($WhatIfPreference -or ($aiForAlerts -and $aiForAlerts -notmatch '^\(')) {
                    New-ZsMonitorPrivateLink -ComponentId $aiForAlerts `
                        -PrivateEndpointSubnetId $net.Subnets['snet-zscc-mgmt'] -VnetId $net.VnetId `
                        -PrivateQueryAccess:$PrivateQueryAccess | Out-Null
                } else {
                    Write-ZsLog "-EnableMonitorPrivateLink set but no Application Insights component exists to scope; skipping." -Level WARN
                }
            }

            # Lock critical infrastructure resources individually rather than the resource group.
            # Per-resource locks: VMSS unlocked for autoscale. A brought VNet is not locked — the
            # deployment did not create it, so it is not the deployment's to lock (the Terraform
            # locks module leaves it out for the same reason).
            $lockTargets = @()
            if ((-not $byoNet) -and $net.VnetId -and $net.VnetId -notmatch '^\(')  { $lockTargets += @{ Id=$net.VnetId; Label='VNet' } }
            if ($kv.VaultId -and $kv.VaultId -notmatch '^\(')  { $lockTargets += @{ Id=$kv.VaultId; Label='KeyVault' } }
            if ($lb.LbId -and $lb.LbId -notmatch '^\(')        { $lockTargets += @{ Id=$lb.LbId; Label='LoadBalancer' } }
            if ($id.IdentityId -and $id.IdentityId -notmatch '^\(') { $lockTargets += @{ Id=$id.IdentityId; Label='Identity' } }
            if ($rt -and $rt.RouteTableId -and $rt.RouteTableId -notmatch '^\(') { $lockTargets += @{ Id=$rt.RouteTableId; Label='RouteTable' } }
            # The NAT egress address, when this deployment made it: losing it means a new address
            # to allowlist in the Zscaler portal. One the platform team supplied is not ours to lock.
            if ($pub -and $pub.Egress -and $pub.Egress.Created -and $pub.Egress.EgressId -and $pub.Egress.EgressId -notmatch '^\(') {
                $lockTargets += @{ Id=$pub.Egress.EgressId; Label='NatEgress' }
            }
            # Only the resources not already carrying the lock are written, so a re-run, and a dry
            # run, names just those. Locking stays best-effort: a lock that cannot be read is written,
            # and a refused write is a warning.
            $lockUri = { param($target) "$($target.Id)/providers/Microsoft.Authorization/locks/$($script:ZsLockName)?api-version=$($script:ApiVersions.Lock)" }
            $toLock = [System.Collections.Generic.List[object]]::new()
            foreach ($target in $lockTargets) {
                $level = ''
                try { $level = [string](Get-ZsPropertyValue (Invoke-ArmGet -Uri (& $lockUri $target) -AllowNotFound) 'properties.level') }
                catch { Write-ZsLog "Could not read the lock on $($target.Label): $_" -Level DEBUG }
                if ($level -ne 'CanNotDelete') { $toLock.Add($target) }
            }
            if ($toLock.Count -gt 0 -and $PSCmdlet.ShouldProcess((@($toLock | ForEach-Object { $_.Label }) -join ', '), 'Apply CanNotDelete locks')) {
                foreach ($target in $toLock) {
                    try {
                        Invoke-ArmPut -Uri (& $lockUri $target) -Body @{properties=@{level='CanNotDelete';notes="Zscaler CC - $($target.Label)"}} | Out-Null
                    } catch { Write-ZsLog "Could not lock $($target.Label): $_" -Level WARN }
                }
            }

            # A local function package this host could not deploy. Everything else is in place, and a
            # re-run of the same configuration from inside the network deploys it.
            $pkgPending = if ($Topology -eq 'VMSS') { [bool](Get-ZsPropertyValue $vms 'FunctionPackagePending') } else { [bool](Get-ZsPropertyValue $faInfra 'PackagePending') }
            if ($pkgPending) {
                $status = 'PartialSuccess'
                Add-ZsManifestOutput -Key 'FunctionPackagePending' -Value $true
            }

            # A dry run leaves the last real run's manifest as it is: teardown reads that file.
            Complete-ZsManifest -Status $status
            if (-not $WhatIfPreference) { Export-ZsManifest -Path $ManifestPath | Out-Null }
        } catch {
            # "$_" on a rethrown terminating error can stringify as just 'ScriptHalted',
            # burying the ARM message that actually stopped the run. Walk to the innermost
            # real message so the FATAL line and the manifest carry the cause, not the wrapper.
            $failText = "$_"
            if ($failText -match '^(ScriptHalted|System error\.)$') {
                $cand = @()
                if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $cand += [string]$_.ErrorDetails.Message }
                $ex = $_.Exception
                while ($ex) { if ($ex.Message -and $ex.Message -notmatch '^(ScriptHalted|System error\.)$') { $cand += $ex.Message }; $ex = $ex.InnerException }
                if ($cand.Count -gt 0) { $failText = $cand[0] }
            }
            $status = 'Failed'; Add-ZsManifestError -Message $failText; Write-ZsLog "FAILED: $failText" -Level FATAL
            Complete-ZsManifest -Status $status
            if (-not $WhatIfPreference) { Export-ZsManifest -Path $ManifestPath | Out-Null }
            # Re-throw from this cmdlet's scope. Validation records carry ErrorDetails for a
            # readable message; ARM failures keep their original detail for troubleshooting.
            $PSCmdlet.ThrowTerminatingError($_)
        } finally {
            Close-ZsRemoteState
            Resume-ZsSleep
        }

        if ($pkgPending) {
            Write-ZsLog ("Deployment complete except the lifecycle function's package: re-run New-ZsDeployment with the same configuration " +
                "from a host inside the network, one that resolves privatelink.azurewebsites.net, to deploy it") -Level WARN
        } else {
            Write-ZsLog 'Deployment complete'
        }
        Write-ZsLog "RG=$($rg.Name) LB=$($lb.FrontendIp) CCs=$($cfg.CcCount)"
        # Empty without a NAT gateway of the deployment's own (AttachNatGateway false).
        $natIps = [System.Collections.Generic.List[string]]::new()
        if ($pub) {
            foreach ($z in $cfg.Zones) {
                $e = $pub.ZoneEgress[$z]
                # One zone-redundant gateway means every zone reports the same address or range.
                $egressAddr = if ($e -and $e.PublicIp) { [string]$e.PublicIp } elseif ($e -and $e.PSObject.Properties['PublicIpPrefix'] -and $e.PublicIpPrefix) { [string]$e.PublicIpPrefix } else { '' }
                if ($egressAddr -and $egressAddr -ne 'byo' -and -not $natIps.Contains($egressAddr)) { $natIps.Add($egressAddr) }
            }
        }
        if ($Topology -eq 'VMSS') {
            foreach ($cc in $vms.Zones) { Write-ZsLog "  $($cc.VmssName) zone=$($cc.Zone)" }
        } else {
            foreach ($cc in $vms) { Write-ZsLog "  $($cc.VmName) svc=$($cc.ServiceIp) zone=$($cc.Zone)" }
        }

        return [PSCustomObject]@{ Status=$status; Mode=$cfg.Mode; ResourceGroup=$rg.Name; LbFrontendIp=$lb.FrontendIp
            NatGatewayIps=@($natIps); CloudConnectors=$vms; ManifestPath=$ManifestPath; FunctionPackagePending=$pkgPending }
    }
}
