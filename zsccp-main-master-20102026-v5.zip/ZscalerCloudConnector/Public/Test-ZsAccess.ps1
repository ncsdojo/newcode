<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Test-ZsAccess).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Test-ZsAccess {
    <#
    .SYNOPSIS Verifies that the connected identity holds the permissions this deployment needs, at
        the scope it will actually write to, and that no enforcing Azure Policy will refuse it.
    .DESCRIPTION Runs before anything is built, and answers three questions in order.

        Which scope? A BringYourOwn resource group in the config declares brownfield intent, honoured
        only when that group exists — the subscription is the scope when the module creates its own
        group, the resource group is the scope when it is given one. A named group that is absent or
        unreadable stops the run here rather than later.

        Which permissions are actually held? The identity's effective actions are read at that scope
        from the Permissions API, which already aggregates direct, group-inherited and higher-scope
        assignments, and deny assignments are subtracted from the result.

        What will policy refuse? Enforcing Deny policies are discovered ahead of time and reported by
        assignment and definition name, so a refusal arrives as a name to take to the policy owner
        rather than as an opaque failure mid-run.

        Missing permissions stop the deployment. A preflight that warns and proceeds only moves the
        failure later, after resources exist and a partial deployment has to be unwound.

        Brownfield deployments are additionally checked against the operations that are subscription
        level by nature — marketplace terms, provider and feature registration, custom role
        definitions — because no amount of permission on a resource group can satisfy them, and that
        is worth saying plainly rather than discovering at the point of use.
    .PARAMETER ResourceGroupName The BringYourOwn resource group name. Omit for greenfield.
    .PARAMETER Topology VM or VMSS. Shapes which compute actions are required.
    .PARAMETER IdentityRoleMode Connector identity role mode; LeastPrivilege requires custom role writes.
    .PARAMETER FunctionRoleMode Function identity role mode.
    .PARAMETER VmSize VM size, used when probing SKU-restricting policies.
    .PARAMETER Bastion Include Bastion actions.
    .PARAMETER Defender Include Defender for Cloud actions.
    .PARAMETER MonitorPrivateLink Include Azure Monitor private link actions.
    .PARAMETER BastionSku The Bastion SKU the deployment creates: Premium is private-only and needs no public IP.
    .PARAMETER NatPublicIpMode ip or prefix: the NAT gateway's egress address type.
    .PARAMETER NatExistingPublicIp The NAT egress address is supplied, so none is created.
    .PARAMETER NoNatGateway The platform's egress serves a brought network's subnets, so no NAT gateway is created.
    .PARAMETER CreateRemediationRole The deployment defines its own connector replacement role at the resource group.
    .PARAMETER NetworkResourceGroupId Resource ID of a brought VNet's resource group. Where the deployment scope
        does not cover it, what the deployment grants on the connector subnets is checked there too.
    .PARAMETER GrantSubnetRemediation The function identity's remediation role is granted on the connector
        subnets (BringYourOwn.GrantFunctionSubnetJoin), and with CreateRemediationRole that role is defined
        assignable at the VNet's resource group.
    .PARAMETER LocalFunctionPackage The function package is zip-deployed to the Function App by the deployer.
    .PARAMETER SkipPolicyCheck Skip the Azure Policy probe and check permissions only.
    .PARAMETER Quiet Suppress the console summary and return the result object only.
    .OUTPUTS PSCustomObject: Ready, Scope, Mode, Missing, Denied, PolicyBlockers, Unverified, Identity.
    .EXAMPLE
    Test-ZsAccess
    Checks subscription-scope permissions for a greenfield deployment.
    .EXAMPLE
    Test-ZsAccess -ResourceGroupName rg-network-prod -Topology VMSS
    Checks resource-group-scope permissions for a brownfield VMSS deployment into an existing group.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [string]$ResourceGroupName = '',
        [ValidateSet('VM','VMSS')][string]$Topology = 'VM',
        [ValidateSet('LeastPrivilege','NetworkContributor','None')][string]$IdentityRoleMode = 'LeastPrivilege',
        [ValidateSet('Reader','LeastPrivilege','NetworkContributor','None')][string]$FunctionRoleMode = 'Reader',
        [string]$VmSize = '',
        [switch]$Bastion,
        [switch]$Defender,
        [switch]$MonitorPrivateLink,
        [ValidateSet('Premium','Standard','Basic')][string]$BastionSku = 'Premium',
        [ValidateSet('ip','prefix')][string]$NatPublicIpMode = 'ip',
        [switch]$NatExistingPublicIp,
        [switch]$NoNatGateway,
        [switch]$CreateRemediationRole,
        [string]$NetworkResourceGroupId = '',
        [switch]$GrantSubnetRemediation,
        [switch]$LocalFunctionPackage,
        [switch]$SkipPolicyCheck,
        [switch]$Quiet
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        if (-not $VmSize) { $VmSize = $script:CcImage.DefaultVmSize }

        $scope    = Resolve-ZsDeploymentScope -ResourceGroupName $ResourceGroupName -Cmdlet $PSCmdlet
        $identity = Get-ZsTokenClaims
        $who      = if ($identity.DisplayName) { $identity.DisplayName } elseif ($identity.AppId) { $identity.AppId } else { 'the connected identity' }

        Write-ZsLog "Access preflight: $($scope.Mode) deployment, checking $($scope.Kind.ToLower()) scope $($scope.Scope)"
        Write-ZsLog "Identity: $who (object id $($identity.ObjectId), type $($identity.IdentityType))" -Level DEBUG

        # Effective permissions
        $perms = Get-ZsEffectivePermissions -Scope $scope.Scope
        if (-not $perms.Available) {
            Write-ZsError -Cmdlet $PSCmdlet -ErrorId 'ZsPermissionsUnreadable' -Category PermissionDenied -Message (
                "Cannot verify permissions for $who at $($scope.Scope).`n" +
                "  $($perms.Reason)`n" +
                "  Grant a role containing Microsoft.Authorization/permissions/read at this scope — the built-in Reader role includes it — then re-run.`n" +
                "  Nothing has been deployed.")
        }

        # Subscription-level operations still need checking in brownfield, at the subscription, since
        # a resource group scope cannot express them at all.
        $subPerms = $perms
        if ($scope.Kind -eq 'ResourceGroup') {
            $subPerms = Get-ZsEffectivePermissions -Scope "/subscriptions/$($scope.SubscriptionId)"
        }

        $deny    = Get-ZsDenyAssignments -Scope $scope.Scope
        $subDeny = if ($scope.Kind -eq 'ResourceGroup') { Get-ZsDenyAssignments -Scope "/subscriptions/$($scope.SubscriptionId)" } else { $deny }

        # Wrapped for the same reason the other collection returns are: an empty array return
        # unrolls to $null, and .Count on $null throws under Set-StrictMode.
        $required = @(Get-ZsRequiredActions -Mode $scope.Mode -Topology $Topology `
            -IdentityRoleMode $IdentityRoleMode -FunctionRoleMode $FunctionRoleMode `
            -Bastion:$Bastion -Defender:$Defender -MonitorPrivateLink:$MonitorPrivateLink `
            -BastionSku $BastionSku -NatPublicIpMode $NatPublicIpMode -NatExistingPublicIp:$NatExistingPublicIp -NoNatGateway:$NoNatGateway -RemediationRole:$CreateRemediationRole -LocalFunctionPackage:$LocalFunctionPackage)

        $missing    = [System.Collections.Generic.List[PSCustomObject]]::new()
        $denied     = [System.Collections.Generic.List[PSCustomObject]]::new()
        $unverified = [System.Collections.Generic.List[string]]::new()
        $granted    = 0

        foreach ($req in $required) {
            $atSubscription = ($req.RequiredScope -eq 'Subscription')
            $useSets  = if ($atSubscription -and $scope.Kind -eq 'ResourceGroup') { $subPerms } else { $perms }
            $useDeny  = if ($atSubscription -and $scope.Kind -eq 'ResourceGroup') { $subDeny } else { $deny }
            $atScope  = if ($atSubscription) { "/subscriptions/$($scope.SubscriptionId)" } else { $scope.Scope }

            if (-not $useSets.Available) {
                $unverified.Add("$($req.Action) (subscription permissions unreadable)")
                continue
            }

            $verdict = Test-ZsActionGranted -Action $req.Action -Sets $useSets.Sets `
                -DenyAssignments $useDeny.Assignments -PrincipalId $identity.ObjectId -DataAction:$req.DataAction

            if ($verdict.Denied) {
                $denied.Add([PSCustomObject]@{ Action=$req.Action; Purpose=$req.Purpose; Scope=$atScope; DeniedBy=$verdict.DeniedBy })
            } elseif ($verdict.Granted) {
                $granted++
            } else {
                $missing.Add([PSCustomObject]@{ Action=$req.Action; Purpose=$req.Purpose; Scope=$atScope; SubscriptionLevel=$atSubscription })
            }
        }

        if (-not $deny.Available) { $unverified.Add('deny assignments could not be read at the deployment scope') }

        # A brought VNet in a resource group the deployment scope does not cover. The function's
        # remediation role is granted on the connector subnets there, and with CreateRemediationRole
        # the role is assignable there, which Azure requires roleDefinitions/write on as well.
        $netScope = $NetworkResourceGroupId.TrimEnd('/')
        if ($netScope -and $GrantSubnetRemediation -and -not ($netScope -ieq $scope.Scope -or
                $netScope.StartsWith("$($scope.Scope)/", [System.StringComparison]::OrdinalIgnoreCase))) {
            $netNeeds = @(@{ Action='Microsoft.Authorization/roleAssignments/write'; Purpose='Grant the function identity its remediation role on the connector subnets' })
            if ($CreateRemediationRole) {
                $netNeeds += @{ Action='Microsoft.Authorization/roleDefinitions/write'; Purpose='Make the connector replacement role assignable at the VNet''s resource group' }
            }
            $netPerms = Get-ZsEffectivePermissions -Scope $netScope
            if (-not $netPerms.Available) {
                $unverified.Add("$(($netNeeds | ForEach-Object { $_.Action }) -join ' and ') at $netScope ($($netPerms.Reason))")
            } else {
                $netDeny = Get-ZsDenyAssignments -Scope $netScope
                foreach ($n in $netNeeds) {
                    $verdict = Test-ZsActionGranted -Action $n.Action -Sets $netPerms.Sets -DenyAssignments $netDeny.Assignments -PrincipalId $identity.ObjectId
                    if ($verdict.Denied) {
                        $denied.Add([PSCustomObject]@{ Action=$n.Action; Purpose=$n.Purpose; Scope=$netScope; DeniedBy=$verdict.DeniedBy })
                    } elseif (-not $verdict.Granted) {
                        $missing.Add([PSCustomObject]@{ Action=$n.Action; Purpose=$n.Purpose; Scope=$netScope; SubscriptionLevel=$false })
                    }
                }
            }
        }

        # Azure Policy
        $policy = [PSCustomObject]@{ Available=$false; Blockers=@(); Checked=0; Reason='skipped' }
        if (-not $SkipPolicyCheck) {
            # A NAT egress address or Bastion public IP from an earlier run is reused, not created, so
            # probing its creation would stop a re-run under a public IP deny on its own address.
            $natEgressExists = $false; $bastionIpExists = $false
            if ($scope.IsExisting) {
                $rgPath = "/subscriptions/$($scope.SubscriptionId)/resourceGroups/$($scope.ResourceGroupName)"
                $env = $script:ZsSession.Environment; $loc = $script:ZsSession.Location
                $netApi = $script:ApiVersions.NatGateway
                $egressPath = if ($NatPublicIpMode -eq 'prefix') { "publicIPPrefixes/ippre-natgw-zscc-$env-$loc" } else { "publicIPAddresses/pip-natgw-zscc-$env-$loc" }
                if (-not $NatExistingPublicIp -and -not $NoNatGateway) {
                    $natEgressExists = [bool](Invoke-ArmGet -Uri "$rgPath/providers/Microsoft.Network/$egressPath`?api-version=$netApi" -AllowNotFound)
                    if ($natEgressExists) { Write-ZsLog "NAT egress address $(($egressPath -split '/')[-1]) already exists and is reused; its creation is not probed" }
                }
                if ($Bastion -and $BastionSku -ne 'Premium') {
                    $basPip = New-ZsResourceName -Prefix 'pip-bas-zscc' -Environment $env -Location $loc
                    $bastionIpExists = [bool](Invoke-ArmGet -Uri "$rgPath/providers/Microsoft.Network/publicIPAddresses/$basPip`?api-version=$netApi" -AllowNotFound)
                    if ($bastionIpExists) { Write-ZsLog "Bastion public IP $basPip already exists and is reused; its creation is not probed" }
                }
            }
            $policy = Test-ZsPolicyRestrictions -Scope $scope.Scope -Location $script:ZsSession.Location -Topology $Topology -VmSize $VmSize `
                -Bastion:$Bastion -BastionSku $BastionSku -BastionPublicIpExists:$bastionIpExists `
                -NatPublicIpMode $NatPublicIpMode -NatExistingPublicIp:($NatExistingPublicIp -or $natEgressExists) -NoNatGateway:$NoNatGateway
            if (-not $policy.Available -and $policy.Reason) { $unverified.Add($policy.Reason) }
        }

        $ready = ($missing.Count -eq 0 -and $denied.Count -eq 0 -and @($policy.Blockers).Count -eq 0)

        # Report
        if (-not $Quiet) {
            if ($ready) {
                $extra = if (@($policy.Blockers).Count -eq 0 -and $policy.Available) { ", no blocking policies among $($policy.Checked) resource types" } else { '' }
                Write-ZsLog "Access preflight passed: $granted of $($required.Count) required actions held at $($scope.Kind.ToLower()) scope$extra"
            }
            foreach ($u in $unverified) { Write-ZsLog "Not verified: $u" -Level WARN }
        }

        if (-not $ready) {
            $lines = [System.Collections.Generic.List[string]]::new()
            $lines.Add("Access preflight failed for $who at $($scope.Scope) ($($scope.Mode)).")

            if ($denied.Count -gt 0) {
                $lines.Add('')
                $lines.Add('Blocked by a deny assignment (these override every role grant):')
                foreach ($d in $denied) { $lines.Add("  $($d.Action)  — $($d.Purpose)$(if ($d.DeniedBy) { " [deny assignment: $($d.DeniedBy)]" })") }
            }

            if ($missing.Count -gt 0) {
                $atNetwork    = @($missing | Where-Object { $netScope -and $_.Scope -eq $netScope })
                $atDeployment = @($missing | Where-Object { -not $_.SubscriptionLevel -and -not ($netScope -and $_.Scope -eq $netScope) })
                $atSub        = @($missing | Where-Object { $_.SubscriptionLevel })

                if ($atDeployment.Count -gt 0) {
                    $lines.Add('')
                    $lines.Add("Missing at $($scope.Scope):")
                    foreach ($mm in $atDeployment) { $lines.Add("  $($mm.Action)  — $($mm.Purpose)") }
                }
                if ($atSub.Count -gt 0) {
                    $lines.Add('')
                    $lines.Add("Missing at /subscriptions/$($scope.SubscriptionId) — these operations are subscription level and cannot be granted on a resource group:")
                    foreach ($mm in $atSub) { $lines.Add("  $($mm.Action)  — $($mm.Purpose)") }
                }
                if ($atNetwork.Count -gt 0) {
                    $lines.Add('')
                    $lines.Add("Missing at $netScope, the VNet's resource group:")
                    foreach ($mm in $atNetwork) { $lines.Add("  $($mm.Action)  — $($mm.Purpose)") }
                    $lines.Add('  Have the platform team give the deployer Role Based Access Control Administrator there' +
                        $(if ($atNetwork.Action -contains 'Microsoft.Authorization/roleDefinitions/write') { ' and a role carrying roleDefinitions/write, or leave CreateRemediationRole off' } else { '' }) +
                        '; or set BringYourOwn.GrantFunctionSubnetJoin to false and have them grant Microsoft.Network/virtualNetworks/subnets/join/action on both connector subnets themselves.')
                }

                # Name the way out for the gaps that have a specific, non-obvious remedy.
                $hints = [System.Collections.Generic.List[string]]::new()
                $hintActions = @($atDeployment | ForEach-Object { $_.Action }) + @($atSub | ForEach-Object { $_.Action })
                if ($hintActions -contains 'Microsoft.Authorization/roleAssignments/write') {
                    $hints.Add("Role assignment writes are not in Contributor, and the deployment always makes some: the identities' Key Vault and storage data roles and the function's health-remediation roles. Assign Role Based Access Control Administrator, User Access Administrator, or Owner at this scope.")
                }
                if ($hintActions -contains 'Microsoft.Authorization/roleDefinitions/write') {
                    $hints.Add("Custom role definitions are written at subscription scope, or at the resource group for a brought one and for the connector replacement role. Without that permission, set IdentityRoleMode to NetworkContributor or None instead of LeastPrivilege, and leave CreateRemediationRole off.")
                }
                if ($hintActions -contains 'Microsoft.MarketplaceOrdering/offertypes/publishers/offers/plans/agreements/write') {
                    $hints.Add("Marketplace terms are accepted at subscription scope only. Have a subscription Contributor or Owner accept the Cloud Connector image terms once, then re-run.")
                }
                if ($hintActions -contains 'Microsoft.Resources/subscriptions/providers/register/action') {
                    $hints.Add("Provider registration is a subscription-level action. Have a subscription Contributor register the providers listed by Test-ZsPrerequisites, then re-run.")
                }
                if ($hintActions -contains 'Microsoft.Features/providers/features/register/action') {
                    $hints.Add("The EncryptionAtHost feature is registered once per subscription by a subscription Contributor or Owner.")
                }
                if ($hints.Count -gt 0) {
                    $lines.Add('')
                    foreach ($h in $hints) { $lines.Add("  $h") }
                }
            }

            if (@($policy.Blockers).Count -gt 0) {
                $lines.Add('')
                $lines.Add('Blocked by Azure Policy:')
                foreach ($b in $policy.Blockers) {
                    $name = if ($b.PolicyAssignmentDisplayName) { $b.PolicyAssignmentDisplayName } else { $b.PolicyDefinitionDisplayName }
                    $lines.Add("  $($b.Resource): '$name' $($b.Reason)")
                    if ($b.PolicyDefinitionDisplayName -and $b.PolicyAssignmentDisplayName -and
                        $b.PolicyDefinitionDisplayName -ne $b.PolicyAssignmentDisplayName) {
                        $lines.Add("      definition: $($b.PolicyDefinitionDisplayName)")
                    }
                    if ($b.PolicyAssignmentScope) { $lines.Add("      assigned at: $($b.PolicyAssignmentScope)") }
                }
                $lines.Add('')
                $lines.Add('  Request an exemption at this scope from the policy owner, or change the deployment to satisfy the policy.')
                if (@($policy.Blockers | Where-Object { $_.Resource -like 'NAT egress*' }).Count -gt 0) {
                    $lines.Add('  The NAT gateway cannot work without a public address: get this one exempted, use -NatPublicIpMode prefix where')
                    $lines.Add('  prefixes are allowed, or attach one the platform team created with -NatExistingPublicIpId. In a brought network')
                    $lines.Add('  whose subnets already leave through the platform''s egress, BringYourOwn.AttachNatGateway false creates none.')
                }
                if (@($policy.Blockers | Where-Object { $_.Resource -like '*IP forwarding*' }).Count -gt 0) {
                    $lines.Add('  The connectors route traffic, so their service NICs need IP forwarding: the deployment resource group needs')
                    $lines.Add('  an exemption from that policy, or no connector can be created.')
                }
            }

            if ($unverified.Count -gt 0) {
                $lines.Add('')
                $lines.Add('Could not be verified:')
                foreach ($u in $unverified) { $lines.Add("  $u") }
            }

            $lines.Add('')
            $lines.Add('Nothing has been deployed.')

            Write-ZsError -Cmdlet $PSCmdlet -ErrorId 'ZsAccessPreflightFailed' -Category PermissionDenied -Message ($lines -join "`n")
        }

        return [PSCustomObject]@{
            Ready             = $ready
            Scope             = $scope.Scope
            ScopeKind         = $scope.Kind
            Mode              = $scope.Mode
            ResourceGroupName = $scope.ResourceGroupName
            Identity          = $identity
            Required          = $required.Count
            Granted           = $granted
            Missing           = $missing.ToArray()
            Denied            = $denied.ToArray()
            PolicyBlockers    = @($policy.Blockers)
            PolicyChecked     = $policy.Checked
            Unverified        = $unverified.ToArray()
        }
    }
}
