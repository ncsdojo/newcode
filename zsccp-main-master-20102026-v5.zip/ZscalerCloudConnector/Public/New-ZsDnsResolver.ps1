<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (New-ZsDnsResolver).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
    .PARAMETER VnetId VNet resource ID for the DNS resolver.
    .PARAMETER VnetPath VNet ARM path.
    .PARAMETER ForwardToIp IP address to forward DNS queries to.
    .PARAMETER InboundSubnetCidr CIDR for the DNS resolver inbound subnet.
    .PARAMETER OutboundSubnetCidr CIDR for the DNS resolver outbound subnet.
    .PARAMETER Domains DNS domains to forward.
    #>

function New-ZsDnsResolver {
    <#
    .SYNOPSIS Creates Private DNS Resolver with forwarding rules for ZPA domains.
    .EXAMPLE
    New-ZsDnsResolver -InboundSubnetId $in -OutboundSubnetId $out
    Creates an Azure DNS Private Resolver for ZPA domain forwarding.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][string]$VnetId,    [Parameter(Mandatory)][string]$VnetPath,
        [Parameter(Mandatory)][string]$ForwardToIp,
        [ValidatePattern('^\d+\.\d+\.\d+\.\d+/\d+$')][string]$InboundSubnetCidr = '10.1.5.0/28',
        [ValidatePattern('^\d+\.\d+\.\d+\.\d+/\d+$')][string]$OutboundSubnetCidr = '10.1.6.0/28',
        [string[]]$Domains = @()
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $env=$script:ZsSession.Environment; $loc=$script:ZsSession.Location; $tags=Get-ZsTags
        $rgPath=Get-ZsRgPath; $dApi=$script:ApiVersions.DnsResolver; $nApi=$script:ApiVersions.Network
        if ($Domains.Count -eq 0) { $Domains = $script:ZpaDomains }
        $rName = New-ZsResourceName -Prefix 'dnspr-zscc' -Environment $env -Location $loc
        $rsName = New-ZsResourceName -Prefix 'dnsfrs-zscc' -Environment $env -Location $loc
        $deleg = @(@{ name='Microsoft.Network.dnsResolvers'; properties=@{ serviceName='Microsoft.Network/dnsResolvers' } })

        foreach ($pair in @(@{N='snet-zscc-dns-inbound';C=$InboundSubnetCidr}, @{N='snet-zscc-dns-outbound';C=$OutboundSubnetCidr})) {
            if ($PSCmdlet.ShouldProcess($pair.N, 'Create DNS subnet')) {
                Invoke-ArmPut -Uri "$VnetPath/subnets/$($pair.N)?api-version=$nApi" -Body @{ properties=@{ addressPrefix=$pair.C; delegations=$deleg } } | Out-Null
                Wait-ArmProvision -Uri "$VnetPath/subnets/$($pair.N)?api-version=$nApi" -Label $pair.N | Out-Null
                Add-ZsManifestResource -Type 'Subnet' -Name $pair.N -ResourceId "$VnetPath/subnets/$($pair.N)"
            }
        }

        $rPath = "$rgPath/providers/Microsoft.Network/dnsResolvers/$rName"
        if ($PSCmdlet.ShouldProcess($rName, 'Create DNS Resolver')) {
            # DNS Private Resolver and its endpoints routinely take ten to twenty minutes; both
            # the async ceiling and the resource waits are sized for that, or the create times out
            # while the build is healthy - the same failure Bastion had.
            Invoke-ArmPut -AsyncTimeoutSeconds 1800 -Uri "$rPath`?api-version=$dApi" -Body @{ location=$loc; tags=$tags; properties=@{ virtualNetwork=@{id=$VnetId} } } | Out-Null
            Wait-ArmProvision -Uri "$rPath`?api-version=$dApi" -Label $rName -TimeoutSeconds 1800 | Out-Null

            Invoke-ArmPut -AsyncTimeoutSeconds 1800 -Uri "$rPath/inboundEndpoints/ep-in?api-version=$dApi" -Body @{
                location=$loc; tags=$tags; properties=@{ ipConfigurations=@(@{ privateIpAllocationMethod='Dynamic'; subnet=@{id="$VnetId/subnets/snet-zscc-dns-inbound"} }) }
            } | Out-Null
            $inEp = Wait-ArmProvision -Uri "$rPath/inboundEndpoints/ep-in?api-version=$dApi" -Label 'dns-inbound-ep' -TimeoutSeconds 1800
            # Endpoints are recorded in their own right: the resolver cannot be deleted while its
            # inbound endpoints exist, and the outbound endpoint cannot be deleted while the
            # forwarding ruleset references it, so teardown needs each as a step of its own.
            Add-ZsManifestResource -Type 'DnsResolverEndpoint' -Name 'ep-in' -ResourceId "$rPath/inboundEndpoints/ep-in"

            Invoke-ArmPut -AsyncTimeoutSeconds 1800 -Uri "$rPath/outboundEndpoints/ep-out?api-version=$dApi" -Body @{
                location=$loc; tags=$tags; properties=@{ subnet=@{id="$VnetId/subnets/snet-zscc-dns-outbound"} }
            } | Out-Null
            Wait-ArmProvision -Uri "$rPath/outboundEndpoints/ep-out?api-version=$dApi" -Label 'dns-outbound-ep' -TimeoutSeconds 1800 | Out-Null
            Add-ZsManifestResource -Type 'DnsResolverEndpoint' -Name 'ep-out' -ResourceId "$rPath/outboundEndpoints/ep-out"
        }

        $rsPath = "$rgPath/providers/Microsoft.Network/dnsForwardingRulesets/$rsName"
        if ($PSCmdlet.ShouldProcess($rsName, 'Create forwarding ruleset')) {
            Invoke-ArmPut -Uri "$rsPath`?api-version=$dApi" -Body @{
                location=$loc; tags=$tags; properties=@{ dnsResolverOutboundEndpoints=@(@{id="$rPath/outboundEndpoints/ep-out"}) }
            } | Out-Null
            Wait-ArmProvision -Uri "$rsPath`?api-version=$dApi" -Label $rsName -TimeoutSeconds 300 | Out-Null

            $vnetN = ($VnetPath -split '/')[-1]
            Invoke-ArmPut -Uri "$rsPath/virtualNetworkLinks/link-$vnetN`?api-version=$dApi" -Body @{ properties=@{virtualNetwork=@{id=$VnetId}} } | Out-Null
            Wait-ArmProvision -Uri "$rsPath/virtualNetworkLinks/link-$vnetN`?api-version=$dApi" -Label 'vnet-link' -TimeoutSeconds 300 | Out-Null
            # The link is deleted before its ruleset, the ruleset before the outbound endpoint it
            # references - Microsoft's prescribed teardown order for the resolver family.
            Add-ZsManifestResource -Type 'DnsForwardingRulesetLink' -Name "link-$vnetN" -ResourceId "$rsPath/virtualNetworkLinks/link-$vnetN"

            $idx = 0
            foreach ($d in $Domains) {
                $idx++
                Invoke-ArmPut -Uri "$rsPath/forwardingRules/zpa-$idx`?api-version=$dApi" -Body @{
                    properties=@{ domainName="${d}."; state='Enabled'; targetDnsServers=@(@{ipAddress=$ForwardToIp;port=53}) }
                } | Out-Null
            }
        }
        Add-ZsManifestResource -Type 'DnsResolver' -Name $rName -ResourceId $rPath
        # The ruleset is a sibling resource, not a child of the resolver, so deleting the resolver
        # does not take it with it. Unrecorded it survived teardown, and its virtual network link
        # then blocked the deletion of the network it was linked to.
        Add-ZsManifestResource -Type 'DnsForwardingRuleset' -Name $rsName -ResourceId $rsPath
        $inIp = ''; try { if ($inEp.properties.ipConfigurations) { $inIp = $inEp.properties.ipConfigurations[0].privateIpAddress } } catch { }
        return [PSCustomObject]@{ ResolverName=$rName; InboundIp=$inIp; RulesetName=$rsName; DomainCount=$Domains.Count; ForwardTo=$ForwardToIp }
    }
}
