<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Disconnect-ZscalerAzure).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
    .PARAMETER ExportLog Export the session log to disk before disconnecting.
    #>

function Disconnect-ZscalerAzure {
    <#
    .SYNOPSIS Clears all tokens and secrets from memory. Optionally exports log.
    .EXAMPLE
    Disconnect-ZscalerAzure
    Clears the session, including any cached SecureString credentials and tokens.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param([switch]$ExportLog)

    if (-not $script:ZsSession) { Write-Warning 'No active session'; return }

    $logPath = $null
    if ($ExportLog -and $script:ZsSession.LogBuffer.Count -gt 0) {
        $logPath = Get-ZsArtifactPath -FileName "ZscalerCloudConnector-session$(Get-Date -Format 'ddMMyyyy').log"
        $script:ZsSession.LogBuffer | Set-Content -Path $logPath -Encoding utf8
    }
    Write-ZsLog "Disconnecting $($script:ZsSession.DeploymentId)"

    $script:ZsSession.Tokens = @{}
    $script:ZsSession.ClientSecretSS = $null
    $script:ZsSession.ZscalerApiKeySS = $null
    $script:ZsSession.ZscalerPasswordSS = $null
    $script:ZsSession.ZscalerSession = $null
    $id = $script:ZsSession.DeploymentId
    $script:ZsSession = $null

    return [PSCustomObject]@{ Disconnected = $true; DeploymentId = $id; LogExported = $logPath }
}
