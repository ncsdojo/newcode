<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (New-ZsPublicNetwork).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function New-ZsPublicNetwork {
    <#
    .SYNOPSIS Creates the zone-redundant StandardV2 NAT gateway and its egress address, and associates
        the gateway with the connector and Function App subnets.
    .DESCRIPTION The NAT gateway is how the connectors, and the lifecycle function through its VNet
        integration, reach the internet: the internal load balancer gives them no way out, and a NAT
        gateway only ever carries connections that start inside the VNet. It cannot work without a
        public address, and a policy that refuses Microsoft.Network/publicIPAddresses (Org-Delta's
        "Not allowed resource types") refuses the default one. Three ways to give it one:

          -PublicIpMode ip       a StandardV2 public IP (the default). Needs the policy exemption
                                 for this one resource.
          -PublicIpMode prefix   a StandardV2 public IP prefix instead, where the platform team
                                 allows prefixes but not addresses. The gateway uses every address
                                 in it, so allowlist the whole range in the Zscaler portal.
          -ExistingPublicIpId    attach an address (ip mode) or prefix (prefix mode) the platform
                                 team created under whatever exemption they hold.

        An address or prefix this module creates is locked by the orchestrator, because losing it
        means a new egress address to allowlist. One supplied through -ExistingPublicIpId is not ours
        to lock.
    .PARAMETER SubnetPlan Subnet plan object from New-ZsNetworkFoundation.
    .PARAMETER VnetPath VNet ARM path.
    .PARAMETER Zones Availability zones in the deployment; every zone reports the same gateway.
    .PARAMETER IdleTimeout NAT gateway idle timeout in minutes. Ten, as in Zscaler's own module,
        rather than Azure's four-minute default: Azure drops a flow silently once it has been idle
        that long.
    .PARAMETER FuncAppSubnetName Name of the Function App subnet for NAT association.
    .PARAMETER PublicIpMode ip (StandardV2 public IP) or prefix (StandardV2 public IP prefix).
    .PARAMETER ExistingPublicIpId Resource ID of an existing StandardV2 public IP (ip mode) or public IP
        prefix (prefix mode) to attach instead of creating one.
    .PARAMETER PublicIpPrefixLength Prefix length in prefix mode, 28 to 31. /31 gives two addresses.
    .EXAMPLE
    New-ZsPublicNetwork -SubnetPlan $plan -VnetPath $vnetPath -AssociateSubnetIds $ids
    Creates the NAT gateway and its StandardV2 public IP and associates the gateway with the subnets.
    .EXAMPLE
    New-ZsPublicNetwork -SubnetPlan $plan -VnetPath $vnetPath -AssociateSubnetIds $ids -PublicIpMode prefix
    Gives the gateway a /31 StandardV2 public IP prefix instead of a single address.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][PSCustomObject]$SubnetPlan,
        [Parameter(Mandatory)][string]$VnetPath,
        [string[]]$Zones = @('1','2'),
        [ValidateRange(4,120)][int]$IdleTimeout = 10,
        [string]$FuncAppSubnetName = '',
        # Explicit subnet resource IDs to associate the gateway with. When supplied, association is
        # by ID — required for brownfield networks whose subnets carry their owners' names, and used
        # for greenfield too since the foundation's Subnets map holds full IDs. Empty falls back to
        # the legacy name-based association under VnetPath, keeping direct callers working.
        [string[]]$AssociateSubnetIds = @(),
        [ValidateSet('ip','prefix')][string]$PublicIpMode = 'ip',
        [string]$ExistingPublicIpId = '',
        [ValidateRange(28,31)][int]$PublicIpPrefixLength = 31
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $env=$script:ZsSession.Environment; $loc=$script:ZsSession.Location; $tags=Get-ZsTags; $rgPath=Get-ZsRgPath; $api=$script:ApiVersions.Network
        $natApi = $script:ApiVersions.NatGateway

        # One StandardV2 NAT gateway for the whole deployment. StandardV2 is zone-redundant by
        # itself — instances spread across every zone in the region — so one gateway serves every
        # subnet and egress survives any single zone. StandardV2 takes only a StandardV2 public IP
        # or prefix, which is zone-redundant too, so none of these resources carries a zones property.
        $pipName    = "pip-natgw-zscc-$env-$loc"
        $prefixName = "ippre-natgw-zscc-$env-$loc"
        $natName    = "natgw-zscc-$env-$loc"

        if ($ExistingPublicIpId) {
            $ExistingPublicIpId = $ExistingPublicIpId.Trim()
            if ($ExistingPublicIpId -notmatch '(?i)^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\.Network/(publicIPAddresses|publicIPPrefixes)/[^/]+$') {
                Write-ZsError -Message "ExistingPublicIpId '$ExistingPublicIpId' is not the full resource ID of a public IP or public IP prefix." -ErrorId 'ZsInvalidNatPublicIpId' -Cmdlet $PSCmdlet
            }
            $isPrefix = $ExistingPublicIpId -match '(?i)/publicIPPrefixes/'
            if ($PublicIpMode -eq 'ip' -and $isPrefix) {
                Write-ZsError -Message "PublicIpMode is 'ip' but ExistingPublicIpId names a public IP prefix. Pass a publicIPAddresses ID, or set PublicIpMode to 'prefix'." -ErrorId 'ZsNatPublicIpModeMismatch' -Cmdlet $PSCmdlet
            }
            if ($PublicIpMode -eq 'prefix' -and -not $isPrefix) {
                Write-ZsError -Message "PublicIpMode is 'prefix' but ExistingPublicIpId names a public IP address. Pass a publicIPPrefixes ID, or set PublicIpMode to 'ip'." -ErrorId 'ZsNatPublicIpModeMismatch' -Cmdlet $PSCmdlet
            }
        }

        # A dry run against a deployment that has its gateway goes through the reconcile below, where
        # every write asks first, so it shows what an upgrade would change. Without one there is
        # nothing to compare with, and placeholders stand in for what would be created.
        $natPath = "$rgPath/providers/Microsoft.Network/natGateways/$natName"; $natUri = "$natPath`?api-version=$natApi"
        $natCheck = Test-ArmResource -Uri $natUri
        if ($WhatIfPreference -and -not $natCheck.Exists) {
            $egressName = if ($ExistingPublicIpId) { ($ExistingPublicIpId -split '/')[-1] } elseif ($PublicIpMode -eq 'prefix') { $prefixName } else { $pipName }
            $egress = [PSCustomObject]@{
                PipName=$egressName; PublicIp=$(if ($PublicIpMode -eq 'ip') { '(IP allocated at deploy time)' } else { '' })
                PublicIpPrefix=$(if ($PublicIpMode -eq 'prefix') { "(/$PublicIpPrefixLength prefix allocated at deploy time)" } else { '' })
                Mode=$PublicIpMode; EgressId='(egress address created at deploy time)'; Created=(-not $ExistingPublicIpId)
                NatGwName=$natName; NatGwId='(NAT created at deploy time)'
            }
            $zoneEgress = @{}
            foreach ($z in $Zones) { $zoneEgress[$z] = $egress }
            return [PSCustomObject]@{ ZoneEgress = $zoneEgress; Egress = $egress }
        }

        # The egress address: supplied, or created here in the chosen form.
        $egressRes = $null; $egressCreated = $false
        if ($ExistingPublicIpId) {
            $egressRes = Invoke-ArmGet -Uri "$ExistingPublicIpId`?api-version=$natApi" -AllowNotFound
            if (-not $egressRes) {
                Write-ZsError -Message "ExistingPublicIpId $ExistingPublicIpId was not found, or this identity cannot read it." -ErrorId 'ZsNatPublicIpNotFound' -Cmdlet $PSCmdlet
            }
            $sku = [string](Get-ZsPropertyValue $egressRes 'sku.name')
            if ($sku -and $sku -ne 'StandardV2') {
                Write-ZsError -Message ("ExistingPublicIpId $ExistingPublicIpId is SKU '$sku'. The NAT gateway is StandardV2 and accepts only a " +
                    "StandardV2 public IP or prefix; ask for one in that SKU.") -ErrorId 'ZsNatPublicIpSku' -Cmdlet $PSCmdlet
            }
            Add-ZsManifestResource -Type $(if ($PublicIpMode -eq 'prefix') { 'PublicIPPrefix' } else { 'PublicIP' }) -Name ($ExistingPublicIpId -split '/')[-1] `
                -ResourceId $egressRes.id -Properties @{ Role='NatEgress' } -PreExisting
            Write-ZsLog "NAT egress: using the existing $PublicIpMode $(($ExistingPublicIpId -split '/')[-1])"
        } elseif ($PublicIpMode -eq 'prefix') {
            $prefixPath = "$rgPath/providers/Microsoft.Network/publicIPPrefixes/$prefixName"; $prefixUri = "$prefixPath`?api-version=$natApi"
            $prefixCheck = Test-ArmResource -Uri $prefixUri
            if ($prefixCheck.Exists) {
                $egressRes = $prefixCheck.Resource
                Add-ZsManifestResource -Type 'PublicIPPrefix' -Name $prefixName -ResourceId $egressRes.id -Properties @{ Role='NatEgress' } -PreExisting:(-not (Test-ZsModuleOwned -Resource $egressRes))
                $egressCreated = Test-ZsModuleOwned -Resource $egressRes
                $liveLen = [int](Get-ZsPropertyValue $egressRes 'properties.prefixLength')
                if ($liveLen -and $liveLen -ne $PublicIpPrefixLength) {
                    Write-ZsLog ("Public IP prefix $prefixName is /$liveLen, not the /$PublicIpPrefixLength asked for. A prefix cannot be resized; " +
                        "it is kept, since replacing it would change the egress range allowlisted in the Zscaler portal.") -Level WARN
                }
            } elseif ($PSCmdlet.ShouldProcess($prefixName, "Create /$PublicIpPrefixLength StandardV2 public IP prefix")) {
                Invoke-ArmPut -Uri $prefixUri -Body @{ location=$loc; tags=$tags; sku=@{ name='StandardV2' }; properties=@{ prefixLength=$PublicIpPrefixLength; publicIPAddressVersion='IPv4' } } | Out-Null
                $egressRes = Wait-ArmProvision -Uri $prefixUri -Label $prefixName
                Add-ZsManifestResource -Type 'PublicIPPrefix' -Name $prefixName -ResourceId $egressRes.id -Properties @{ Role='NatEgress'; IpPrefix=[string](Get-ZsPropertyValue $egressRes 'properties.ipPrefix') }
                $egressCreated = $true
            } else { return [PSCustomObject]@{ ZoneEgress = @{}; Egress = $null } }
        } else {
            $pipPath = "$rgPath/providers/Microsoft.Network/publicIPAddresses/$pipName"; $pipUri = "$pipPath`?api-version=$natApi"
            $pipCheck = Test-ArmResource -Uri $pipUri
            if ($pipCheck.Exists) {
                $egressRes = $pipCheck.Resource
                Add-ZsManifestResource -Type 'PublicIP' -Name $pipName -ResourceId $egressRes.id -Properties @{ Role='NatEgress'; IpAddress=[string](Get-ZsPropertyValue $egressRes 'properties.ipAddress') } -PreExisting:(-not (Test-ZsModuleOwned -Resource $egressRes))
                $egressCreated = Test-ZsModuleOwned -Resource $egressRes
            } elseif ($PSCmdlet.ShouldProcess($pipName, 'Create StandardV2 Public IP')) {
                Invoke-ArmPut -Uri $pipUri -Body @{ location=$loc; tags=$tags; sku=@{name='StandardV2'}; properties=@{ publicIPAllocationMethod='Static'; publicIPAddressVersion='IPv4' } } | Out-Null
                $egressRes = Wait-ArmProvision -Uri $pipUri -Label $pipName
                Add-ZsManifestResource -Type 'PublicIP' -Name $pipName -ResourceId $egressRes.id -Properties @{ Role='NatEgress'; IpAddress=[string](Get-ZsPropertyValue $egressRes 'properties.ipAddress') }
                $egressCreated = $true
            } else { return [PSCustomObject]@{ ZoneEgress = @{}; Egress = $null } }
        }

        $ipRefs     = if ($PublicIpMode -eq 'ip')     { @(@{ id = $egressRes.id }) } else { @() }
        $prefixRefs = if ($PublicIpMode -eq 'prefix') { @(@{ id = $egressRes.id }) } else { @() }

        if ($natCheck.Exists) {
            $nat = $natCheck.Resource
            $natOwned = Test-ZsModuleOwned -Resource $nat
            Add-ZsManifestResource -Type 'NatGateway' -Name $natName -ResourceId $nat.id -PreExisting:(-not $natOwned)
            # Brought to the address and idle timeout this run asks for: 5.4.1.0's four-minute
            # timeout, or a switch between ip and prefix mode, is a change to the gateway, not a
            # reason to build another one.
            $liveIdle = [int](Get-ZsPropertyValue $nat 'properties.idleTimeoutInMinutes')
            $liveIps  = @(Get-ZsPropertyValue $nat 'properties.publicIpAddresses' | Where-Object { $_ } | ForEach-Object { [string]$_.id })
            $livePfx  = @(Get-ZsPropertyValue $nat 'properties.publicIpPrefixes'  | Where-Object { $_ } | ForEach-Object { [string]$_.id })
            $wantIps = @($ipRefs | ForEach-Object { [string]$_.id }); $wantPfx = @($prefixRefs | ForEach-Object { [string]$_.id })
            $sameIps = (@($liveIps | Sort-Object) -join ',').ToLowerInvariant() -eq (@($wantIps | Sort-Object) -join ',').ToLowerInvariant()
            $samePfx = (@($livePfx | Sort-Object) -join ',').ToLowerInvariant() -eq (@($wantPfx | Sort-Object) -join ',').ToLowerInvariant()
            if ($liveIdle -eq $IdleTimeout -and $sameIps -and $samePfx) {
                Write-ZsLog "NAT gateway $natName verified"
            } elseif (-not $natOwned) {
                Write-ZsLog ("NAT gateway $natName differs from this run (idle timeout $liveIdle, $($liveIps.Count) address(es), $($livePfx.Count) prefix(es)) " +
                    "but carries no managed-by tag of this deployment, so it is left as it is. The egress to allowlist is whatever it uses.") -Level WARN
            } elseif ($PSCmdlet.ShouldProcess($natName, 'Reconcile NAT gateway egress address and idle timeout')) {
                Invoke-ArmPut -Uri $natUri -Body @{
                    location=$nat.location; tags=$tags; sku=@{name='StandardV2'}
                    properties=@{ idleTimeoutInMinutes=$IdleTimeout; publicIpAddresses=$ipRefs; publicIpPrefixes=$prefixRefs }
                } | Out-Null
                $nat = Wait-ArmProvision -Uri $natUri -Label $natName
                Write-ZsLog "NAT gateway $natName reconciled (idle timeout $IdleTimeout min, $PublicIpMode egress)"
                # An address or prefix it no longer uses, after a change of NatPublicIpMode, stays with
                # its lock until teardown, which it is recorded for.
                foreach ($old in @(@($liveIps) + @($livePfx) | Where-Object { $_ -notin (@($wantIps) + @($wantPfx)) })) {
                    $oldRes = Invoke-ArmGet -Uri "$old`?api-version=$natApi" -AllowNotFound
                    if (-not ($oldRes -and (Test-ZsModuleOwned -Resource $oldRes))) { continue }
                    $oldType = if ($old -match '/publicIPPrefixes/') { 'PublicIPPrefix' } else { 'PublicIP' }
                    Add-ZsManifestResource -Type $oldType -Name ($old -split '/')[-1] -ResourceId $oldRes.id -Properties @{ Role='ReleasedNatEgress' }
                    Write-ZsLog ("NAT gateway $natName no longer uses $(($old -split '/')[-1]); it is kept until Remove-ZsDeployment removes it. " +
                        "Allowlist the new egress in the Zscaler portal.") -Level WARN
                }
            }
        } elseif ($PSCmdlet.ShouldProcess($natName, 'Create StandardV2 NAT Gateway')) {
            Invoke-ArmPut -Uri $natUri -Body @{
                location=$loc; tags=$tags; sku=@{name='StandardV2'}
                properties=@{ idleTimeoutInMinutes=$IdleTimeout; publicIpAddresses=$ipRefs; publicIpPrefixes=$prefixRefs }
            } | Out-Null
            $nat = Wait-ArmProvision -Uri $natUri -Label $natName
            Add-ZsManifestResource -Type 'NatGateway' -Name $natName -ResourceId $nat.id
        } else { return [PSCustomObject]@{ ZoneEgress = @{}; Egress = $null } }

        # Associate the one gateway with every connector subnet and the Function App subnet
        # (GET-merge-PUT to preserve existing subnet properties). Explicit IDs win: a brownfield
        # network's subnets carry whatever names their owners chose, so the snet-zscc-* convention
        # only holds for subnets this module created. Placeholders from a declined create (they
        # start with '(') never form a request. The load balancer's subnet is deliberately not
        # associated: its frontend only receives, and a NAT gateway only carries connections that
        # start in its subnets.
        $assocTargets = [System.Collections.Generic.List[object]]::new()
        $idTargets = @($AssociateSubnetIds | Where-Object { $_ -and $_ -match '(?i)^/subscriptions/' })
        if ($idTargets.Count -gt 0) {
            foreach ($sid in $idTargets) {
                $assocTargets.Add([PSCustomObject]@{ Uri = "$sid`?api-version=$api"; Label = ($sid -split '/')[-1] })
            }
        } else {
            $assocNames = [System.Collections.Generic.List[string]]::new()
            $assocNames.Add('snet-zscc-mgmt'); $assocNames.Add('snet-zscc-service')
            if ($FuncAppSubnetName -and $SubnetPlan.$FuncAppSubnetName) { $assocNames.Add($FuncAppSubnetName) }
            foreach ($name in $assocNames) {
                $assocTargets.Add([PSCustomObject]@{ Uri = "$VnetPath/subnets/$name`?api-version=$api"; Label = $name })
            }
        }
        foreach ($target in $assocTargets) {
            # In a dry run a subnet the run would create is not there yet to read.
            $sRes = Invoke-ArmGet -Uri $target.Uri -AllowNotFound:$WhatIfPreference
            $existingNat = [string](Get-ZsPropertyValue $sRes 'properties.natGateway.id')
            if ($existingNat -and ($existingNat -like $nat.id)) {
                Write-ZsLog "Subnet $($target.Label) already carries the NAT gateway; association verified"
                continue
            }
            if ($PSCmdlet.ShouldProcess($target.Label, 'Associate NAT Gateway')) {
                if ($existingNat) {
                    Write-ZsLog "Subnet $($target.Label) carried a different NAT gateway ($existingNat); it is being replaced. Confirm with the subnet's owner if that gateway was theirs." -Level WARN
                }
                $sRes.properties | Add-Member -NotePropertyName 'natGateway' -NotePropertyValue @{id=$nat.id} -Force
                Invoke-ArmPut -Uri $target.Uri -Body @{ properties=$sRes.properties } | Out-Null
                Wait-ArmProvision -Uri $target.Uri -Label "NAT-assoc-$($target.Label)" | Out-Null
            }
        }

        $ipAddress = ''; $ipPrefix = ''
        if ($PublicIpMode -eq 'ip') { $ipAddress = [string](Get-ZsPropertyValue $egressRes 'properties.ipAddress') }
        else { $ipPrefix = [string](Get-ZsPropertyValue $egressRes 'properties.ipPrefix') }
        if ($ipAddress) { Add-ZsManifestOutput -Key 'NatGatewayPublicIp' -Value $ipAddress }
        if ($ipPrefix)  { Add-ZsManifestOutput -Key 'NatGatewayPublicIpPrefix' -Value $ipPrefix }
        Write-ZsLog "NAT egress to allowlist in the Zscaler portal: $(if ($ipAddress) { $ipAddress } else { $ipPrefix })"

        # ZoneEgress keeps its shape for existing consumers: every zone now reports the same
        # gateway, which is the truthful description of a zone-redundant egress path.
        $egress = [PSCustomObject]@{
            PipName=($egressRes.id -split '/')[-1]; PublicIp=$ipAddress; PublicIpPrefix=$ipPrefix; Mode=$PublicIpMode
            EgressId=$egressRes.id; Created=$egressCreated; NatGwName=$natName; NatGwId=$nat.id
        }
        $zoneEgress = @{}
        foreach ($z in $Zones) { $zoneEgress[$z] = $egress }
        return [PSCustomObject]@{ ZoneEgress = $zoneEgress; Egress = $egress }
    }
}
