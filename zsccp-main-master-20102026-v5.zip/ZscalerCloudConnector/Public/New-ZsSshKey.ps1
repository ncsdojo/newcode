<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (New-ZsSshKey).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
    .PARAMETER Path File path for the SSH private key (auto-generated if omitted).
    #>

function New-ZsSshKey {
    <#
    .SYNOPSIS Generates an RSA-4096 SSH keypair. Reuses existing if found.
    .OUTPUTS PSCustomObject with PublicKey, PrivateKeyPath, PublicKeyPath.
    .EXAMPLE
    New-ZsSshKey
    Generates an RSA-4096 keypair in the artifact directory and returns the public key.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param([string]$Path = '')

    if (-not $Path) {
        $dir = if ($script:ZsSession) { Split-Path (Get-ZsArtifactPath -FileName 'x') -Parent } else { (Get-Location).Path }
        $sid = if ($script:ZsSession) { $script:ZsSession.ShortId } else { '' }

        # This deployment's own key first. Falling straight to a directory scan meant every
        # deployment run from one machine silently adopted whichever zscc_*.pub the filesystem
        # happened to return first, so one passphrase-less key ended up authorised on unrelated
        # fleets. The scan remains as a fallback for a re-run whose session id differs.
        $ownKey = if ($sid) { Join-Path $dir "zscc_$sid" } else { '' }
        if ($ownKey -and (Test-Path "$ownKey.pub")) {
            $Path = $ownKey
        } else {
            $existingPub = Get-ChildItem -Path $dir -Filter 'zscc_*.pub' -ErrorAction SilentlyContinue |
                Sort-Object Name | Select-Object -First 1
            if ($existingPub) {
                $Path = $existingPub.FullName -replace '\.pub$',''
                Write-ZsLog "Reusing the existing SSH key $($existingPub.Name) found in $dir" -Level WARN
            } else {
                if (-not $sid) { $sid = (Get-Random -Maximum 99999999).ToString('D8') }
                $Path = if ($script:ZsSession) { Get-ZsArtifactPath -FileName "zscc_$sid" } else { Join-Path $dir "zscc_$sid" }
            }
        }
    }
    $dir = Split-Path $Path -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $pub = "${Path}.pub"

    if (Test-Path $pub) {
        Write-ZsLog "SSH key exists at $pub"
        return [PSCustomObject]@{ PublicKey = ([System.IO.File]::ReadAllText($pub).Trim()); PrivateKeyPath = $Path; PublicKeyPath = $pub; WhatIf = $false }
    }

    if (-not $PSCmdlet.ShouldProcess($Path, 'Generate RSA-4096 SSH keypair')) {
        # Under -WhatIf, return a placeholder with the same shape so callers that read
        # .PublicKey can continue the dry run rather than dereferencing $null.
        return [PSCustomObject]@{ PublicKey = '(generated at deploy time)'; PrivateKeyPath = $Path; PublicKeyPath = $pub; WhatIf = $true }
    }

    Write-ZsLog "Generating RSA-4096 SSH keypair"
    & ssh-keygen -t rsa -b 4096 -f $Path -N '' -q 2>$null
    if (-not (Test-Path $pub)) { Write-ZsError -Message "SSH key generation failed at $Path. Confirm ssh-keygen is installed and on PATH." -ErrorId 'ZsSshKeygenFailed' -Category 'InvalidResult' -Cmdlet $PSCmdlet }

    # Restrict the private key to its owner. The claim in the log has to match what was actually
    # done: chmod does not exist on Windows, where a key written under the artifact directory
    # inherits that directory's ACL and is readable by every user with access to it.
    $permsRestricted = $false
    if ($IsWindows) {
        try {
            $acl = Get-Acl -Path $Path
            $acl.SetAccessRuleProtection($true, $false)   # break inheritance, drop inherited ACEs
            foreach ($rule in @($acl.Access)) { $acl.RemoveAccessRule($rule) | Out-Null }
            $me = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
            $acl.AddAccessRule([System.Security.AccessControl.FileSystemAccessRule]::new(
                $me, 'FullControl', 'None', 'None', 'Allow'))
            Set-Acl -Path $Path -AclObject $acl
            $permsRestricted = $true
        } catch {
            Write-ZsLog "Could not restrict the ACL on $Path`: $($_.Exception.Message)" -Level WARN
        }
    } else {
        & chmod 600 $Path 2>$null
        $permsRestricted = ($LASTEXITCODE -eq 0)
        if (-not $permsRestricted) { Write-ZsLog "chmod 600 failed on $Path (exit $LASTEXITCODE)" -Level WARN }
    }

    if ($permsRestricted) {
        Write-ZsLog "Private key written to $Path (permissions restricted to owner)" -Level WARN
    } else {
        Write-ZsLog ("SECURITY: private key written to $Path but owner-only permissions could not be applied. " +
            "Restrict it yourself before this key is used.") -Level ERROR
    }

    Add-ZsManifestOutput -Key 'SshPrivateKeyPath' -Value $Path

    return [PSCustomObject]@{ PublicKey = ([System.IO.File]::ReadAllText($pub).Trim()); PrivateKeyPath = $Path; PublicKeyPath = $pub; WhatIf = $false }
}
