<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (New-ZsResourceGroup).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
    .PARAMETER Name Resource group name (auto-generated from session if omitted).
    .PARAMETER ExtraTags Additional tags to apply to the resource group.
    #>

function New-ZsResourceGroup {
    <#
    .SYNOPSIS Creates the deployment resource group with standard tags.
    .EXAMPLE
    New-ZsResourceGroup
    Creates the deployment resource group in the session's region, tagged and idempotent.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param([string]$Name = '', [hashtable]$ExtraTags = @{})

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        if (-not $Name) { $Name = $script:ZsSession.ResourceGroupName }
        $path = "$(Get-ZsSubscriptionPath)/resourceGroups/$Name"
        $uri  = "$path`?api-version=$($script:ApiVersions.ResourceGroup)"

        $check = Test-ArmResource -Uri $uri
        if ($check.Exists) { Write-ZsLog "Resource group $Name verified"; return [PSCustomObject]@{ Name = $Name; ResourceId = $check.Resource.id; Status = 'Existing' } }

        if ($PSCmdlet.ShouldProcess($Name, 'Create resource group')) {
            Invoke-ArmPut -Uri $uri -Body @{ location = $script:ZsSession.Location; tags = Get-ZsTags -Extra $ExtraTags } | Out-Null
            $rg = Invoke-ArmGet -Uri $uri
            Add-ZsManifestResource -Type 'ResourceGroup' -Name $Name -ResourceId $rg.id
            Write-ZsLog "Resource group $Name created"
            return [PSCustomObject]@{ Name = $Name; ResourceId = $rg.id; Status = 'Created' }
        }
        return [PSCustomObject]@{ Name = $Name; ResourceId = "(resource group $Name created at deploy time)"; Status = 'WhatIf' }
    }
}
