<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Reset-ZsConnectors).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Reset-ZsConnectors {
    <#
    .SYNOPSIS Reimages all Cloud Connector scale sets, forcing a clean provisioning boot.
    .DESCRIPTION Triggers a reimage on each per-zone VMSS, which resets cloud-init and re-runs the
        full provisioning sequence (read config, read vault secrets, call Zscaler provisioning URL,
        start zagent). Use after whitelisting NAT egress IPs in the Zscaler portal to let connectors
        register on the next boot without redeploying.
    .PARAMETER ResourceGroupName Resource group containing the VMSS (defaults to the connected session's RG).
    .PARAMETER Zones Zones to reimage (defaults to all zones with a deployed VMSS).
    .PARAMETER Wait Wait for the reimage to complete before returning.
    .EXAMPLE
    Reset-ZsConnectors
    Reimages all connector scale sets in the connected resource group.
    .EXAMPLE
    Reset-ZsConnectors -Zones '1'
    Reimages only the zone-1 scale set.
    #>
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High', PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [string]$ResourceGroupName = '',
        [string[]]$Zones = @(),
        [switch]$Wait
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        if (-not $ResourceGroupName) { $ResourceGroupName = $script:ZsSession.ResourceGroupName }
        $rgPath = "$(Get-ZsSubscriptionPath)/resourceGroups/$ResourceGroupName"
        $cApi   = $script:ApiVersions.Compute
        $results = [System.Collections.Generic.List[PSCustomObject]]::new()

        # Discover VMSS.
        $vmssAll = @()
        try { $vmssAll = @((Invoke-ArmGet -Uri "$rgPath/providers/Microsoft.Compute/virtualMachineScaleSets?api-version=$cApi").value) } catch { }
        $vmssZones = @($vmssAll | ForEach-Object { if ($_.name -match '-z(\d+)-') { $Matches[1] } } | Sort-Object -Unique)

        if ($vmssZones.Count -gt 0) {
            # VMSS topology: reimage each per-zone scale set.
            $targetZones = if ($Zones -and $Zones.Count -gt 0) { $Zones } else { $vmssZones }
            foreach ($z in $targetZones) {
                $vmssName = "vmss-zscc-z$z-$($script:ZsSession.Environment)-$($script:ZsSession.Location)"
                $reimageUri = "$rgPath/providers/Microsoft.Compute/virtualMachineScaleSets/$vmssName/reimage?api-version=$cApi"
                if ($PSCmdlet.ShouldProcess($vmssName, 'Reimage (reset cloud-init, re-provision)')) {
                    try {
                        Invoke-ArmPost -Uri $reimageUri | Out-Null
                        Write-ZsLog "Reimaging $vmssName (zone $z)"
                        $results.Add([PSCustomObject]@{ Zone=$z; Name=$vmssName; Status='Reimaging' })
                    } catch {
                        Write-ZsLog "Reimage failed for $vmssName`: $_" -Level WARN
                        $results.Add([PSCustomObject]@{ Zone=$z; Name=$vmssName; Status="Failed: $_" })
                    }
                }
            }
        } else {
            # Standalone VM topology: redeploy each VM to re-run cloud-init.
            $shortId = $script:ZsSession.ShortId
            $allVms = @()
            try {
                $vmList = Invoke-ArmGet -Uri "$rgPath/providers/Microsoft.Compute/virtualMachines?api-version=$cApi"
                if ($vmList -and $vmList.PSObject.Properties.Name -contains 'value') { $allVms = @($vmList.value) }
            } catch { }
            $ccVms = @($allVms | Where-Object { try { $_.name -match "^vm-zscc-$shortId" } catch { $false } })
            if ($ccVms.Count -eq 0) {
                Write-ZsLog "No VMSS or standalone VMs found in $ResourceGroupName"
                return $results
            }
            foreach ($vm in $ccVms) {
                $vmName = [string]$vm.name
                $reimageUri = "$rgPath/providers/Microsoft.Compute/virtualMachines/$vmName/reimage?api-version=$cApi"
                if ($PSCmdlet.ShouldProcess($vmName, 'Reimage (reset cloud-init, re-provision)')) {
                    try {
                        Invoke-ArmPost -Uri $reimageUri | Out-Null
                        Write-ZsLog "Reimaging $vmName"
                        $results.Add([PSCustomObject]@{ Zone=''; Name=$vmName; Status='Reimaging' })
                    } catch {
                        Write-ZsLog "Reimage failed for $vmName`: $_" -Level WARN
                        $results.Add([PSCustomObject]@{ Zone=''; Name=$vmName; Status="Failed: $_" })
                    }
                }
            }
        }

        if ($Wait -and $results.Count -gt 0) {
            Write-ZsLog "Waiting for reimage to complete (typically 5-10 minutes)..."
            Start-Sleep -Seconds 120
            foreach ($r in $results) {
                if ($r.Status -eq 'Reimaging') {
                    try {
                        if ($r.Name -match '^vmss-') {
                            $uri = "$rgPath/providers/Microsoft.Compute/virtualMachineScaleSets/$($r.Name)?api-version=$cApi"
                        } else {
                            $uri = "$rgPath/providers/Microsoft.Compute/virtualMachines/$($r.Name)?api-version=$cApi"
                        }
                        $null = Wait-ArmProvision -Uri $uri -Label $r.Name -TimeoutSeconds 600
                        $r.Status = 'Completed'
                    } catch { $r.Status = "Timeout: $_" }
                }
            }
        }

        Write-ZsLog "Reimage initiated for $($results.Count) scale set(s). Connectors will re-provision on boot."
        Write-ZsLog "Run 'Test-ZsDeployment' after ~10 minutes to verify zone coverage."
        return $results
    }
}
