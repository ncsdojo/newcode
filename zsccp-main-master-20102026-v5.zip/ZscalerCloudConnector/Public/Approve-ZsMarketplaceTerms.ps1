<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Approve-ZsMarketplaceTerms).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Approve-ZsMarketplaceTerms {
    <#
    .SYNOPSIS Accepts the Zscaler Cloud Connector marketplace image terms.
    .EXAMPLE
    Approve-ZsMarketplaceTerms
    Accepts the Zscaler Cloud Connector marketplace image terms for the subscription if not already accepted.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param()

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $img  = $script:CcImage
        $path = "$(Get-ZsSubscriptionPath)/providers/Microsoft.MarketplaceOrdering/offerTypes/VirtualMachine/publishers/$($img.Publisher)/offers/$($img.Offer)/plans/$($img.Sku)/agreements/current"
        $uri  = "$path`?api-version=$($script:ApiVersions.Marketplace)"

        # Only a confirmed 404 means no agreement yet. A refused or failed read stops here rather
        # than turning into an acceptance attempt that would be refused for the same reason.
        $existing = (Test-ArmResource -Uri $uri).Resource
        if ((Get-ZsPropertyValue $existing 'properties.accepted') -eq $true) {
            Write-ZsLog 'Marketplace terms already accepted'
            return [PSCustomObject]@{ Accepted = $true; Status = 'Existing' }
        }

        if ($PSCmdlet.ShouldProcess("$($img.Publisher)/$($img.Offer)/$($img.Sku)", 'Accept marketplace terms')) {
            if ($existing) { $existing.properties.accepted = $true; Invoke-ArmPut -Uri $uri -Body $existing | Out-Null }
            else { Invoke-ArmPut -Uri $uri -Body @{ properties = @{ accepted = $true; publisher = $img.Publisher; product = $img.Offer; plan = $img.Sku } } | Out-Null }
            # Deliberately NOT recorded on the manifest. The acceptance is subscription-level
            # platform state - a prerequisite of deploying, not a resource of the deployment -
            # and the manifest is teardown's shopping list. Recording it once put a 405
            # MethodNotAllowed into every teardown for an endpoint that does not support
            # delete, protecting against which the teardown now carries a platform-state
            # guard; not creating the entry is the actual fix. The acceptance is noted in the
            # manifest outputs instead, where it informs without ever becoming a delete target.
            Add-ZsManifestOutput -Key 'MarketplaceTermsAccepted' -Value "$($img.Publisher)/$($img.Offer)/$($img.Sku)"
            Write-ZsLog 'Marketplace terms accepted'
            return [PSCustomObject]@{ Accepted = $true; Status = 'Accepted' }
        }
    }
}
