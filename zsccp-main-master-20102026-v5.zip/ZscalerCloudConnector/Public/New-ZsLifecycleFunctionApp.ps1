<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (New-ZsLifecycleFunctionApp).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function New-ZsLifecycleFunctionApp {
    <#
    .SYNOPSIS Creates the lifecycle Function App infrastructure (Storage, ASP, identity, App Insights, Function App).
    .DESCRIPTION The storage account has public network access disabled in its create request (what a
        "Storage accounts should disable public network access" policy checks), a default-deny
        firewall with no IP or VNet rules, and shared keys off. The host reaches its blobs, queues
        and tables as its managed identity, through private endpoints in the management subnet.

        The app has public network access off for the site and its SCM endpoint from creation. It
        is timer-triggered and nothing calls it. All its outbound traffic is routed into the VNet
        and leaves through the NAT gateway, under the Function App subnet's NSG.

        By default the app runs Zscaler's package from its commit-pinned URL, which the platform
        fetches at every start, so the URL has to stay reachable. A local package (this module's
        function, or Zscaler's zip with -FunctionPackageUrl '') is zip-deployed onto the plan's
        disk instead (WEBSITE_RUN_FROM_PACKAGE=1) through the app's private endpoint, so the run
        has to be inside the network; from anywhere else everything else is built and
        PackagePending is set. The package cannot sit in the storage account: the platform fetches
        it outside the app's VNet integration, and the account refuses public traffic.
    .PARAMETER KeyVaultUri Vault URI for connector credentials.
    .PARAMETER KeyVaultId Vault resource ID for RBAC assignment.
    .PARAMETER ProvisioningUrl Zscaler provisioning URL. Passed to the function without a scheme.
    .PARAMETER VmssNames Comma-separated VMSS names (empty for standalone VM topology).
    .PARAMETER FuncAppSubnetId Subnet for VNet integration. Required: the app reaches its storage only through it.
    .PARAMETER AppServicePlanSku A Dedicated SKU: P0v3 (default), P1v3, P2v3 or B1. Consumption (Y1) and
        Elastic Premium (EP1, EP2) mount an Azure Files content share from outside the VNet, which a
        storage account private from creation cannot serve, and are refused.
    .PARAMETER FunctionRoleMode Control-plane role for the function identity. Reader (default) assigns
        the built-in Reader role plus a scoped custom role recording the exact compute read actions
        the sync uses. LeastPrivilege assigns only the custom role. NetworkContributor grants network
        write and delete the function never calls, available only as an explicit opt-in. None skips
        the assignment for out-of-band role management.
    .PARAMETER FunctionPackageUrl Where the Vendor package runs from: Zscaler's published 1.0.3 zip,
        pinned to the commit that released it, by default. Empty zip-deploys the copy in
        FunctionApp/vendor onto the plan's disk instead.
    .PARAMETER EnablePrivateEndpoint Gives the Function App a private endpoint, for operators inside
        the network who want the portal's function views. Public access is off either way. A local
        package turns it on, because its zip deploy goes through the endpoint.
    .PARAMETER PrivateEndpointSubnetId Subnet for the storage and Function App private endpoints. Required.
    .PARAMETER VnetId VNet resource ID for the private DNS zone links. Required.
    .PARAMETER PrivateDnsZoneResourceGroupName Resource group of the platform's privatelink zones, in a
        hub-and-spoke network; the endpoints register there instead of in zones this deployment creates.
    .PARAMETER PrivateDnsZoneSubscriptionId Subscription of those zones, when not the deployment's.
    .PARAMETER AllowSharedKeyStorageAccess Leaves storage account key authentication enabled, for
        pipelines with external tooling that still needs key access.
    .OUTPUTS PSCustomObject with FunctionApp, FunctionAppId, StorageAccount, StorageUri, AppInsightsId, FuncAppSubnetId,
        and PackagePending: true when a local package could not be deployed from this host.
    .EXAMPLE
    New-ZsLifecycleFunctionApp -KeyVaultUri $kv.VaultUri -KeyVaultId $kv.VaultId -ProvisioningUrl $url -VmssNames 'vmss-zscc-z1-prod-westus2' -FuncAppSubnetId $fa -PrivateEndpointSubnetId $mgmt -VnetId $vnet
    Builds the private storage account, its endpoints and the Function App running Zscaler's published package.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [string]$KeyVaultUri = '',
        [string]$KeyVaultId = '',
        [string]$ProvisioningUrl = '',
        [string]$VmssNames = '',
        [string]$FuncAppSubnetId = '',
        [ValidateSet('B1','P0v3','P1v3','P2v3','EP1','EP2','Y1')][string]$AppServicePlanSku = 'P0v3',
        [ValidateRange(1,1440)][int]$SyncIntervalMinutes = 30,
        # Health remediation follows the Zscaler reference: evaluate cloud_connector_aggr_health
        # every minute and replace connectors that fail. -DisableHealthRemediation keeps the
        # evaluation and its logging but never terminates, for environments where instance
        # deletion must stay in human hands.
        [switch]$DisableHealthRemediation,
        [ValidateRange(3,60)][int]$HealthDataPoints = 10,
        [ValidateRange(1,60)][int]$HealthUnhealthyThreshold = 7,
        [ValidateRange(1,60)][int]$HealthConsecutiveThreshold = 5,
        [ValidateRange(5,240)][int]$HealthGracePeriodMinutes = 30,
        [ValidateRange(0.05,1.0)][double]$MaxTerminationPercent = 0.2,
        [ValidateSet('oldest','newest')][string]$TerminationPolicy = 'oldest',
        # 'Vendor' (the default, and the Zscaler-supported position) runs Zscaler's official
        # package. 'Module' runs this module's function instead. Both run under the same
        # Zscaler-named app settings; Vendor suppresses the HC_* tunables, which the reference code
        # cannot parse.
        [ValidateSet('Vendor','Module')][string]$FunctionPackage = 'Vendor',
        [AllowEmptyString()][string]$FunctionPackageUrl = $script:ZsVendorPackageUrl,
        [ValidateSet('Reader','LeastPrivilege','NetworkContributor','None')][string]$FunctionRoleMode = 'Reader',
        [switch]$EnablePrivateEndpoint,
        [string]$PrivateEndpointSubnetId = '',
        [string]$VnetId = '',
        [string]$PrivateDnsZoneResourceGroupName = '',
        [string]$PrivateDnsZoneSubscriptionId = '',
        [switch]$AllowSharedKeyStorageAccess,
        [switch]$SkipAppInsights
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $loc = $script:ZsSession.Location; $env = $script:ZsSession.Environment; $tags = Get-ZsTags; $rgPath = Get-ZsRgPath
        $shortId = $script:ZsSession.ShortId
        $webApi = $script:ApiVersions.Web

        # Health monitor cadence is fixed at one minute to match the reference: the evaluator
        # reasons over per-minute samples, so a slower timer would compare stale windows.
        $healthCron = '0 * * * * *'
        # TERMINATE_UNHEALTHY_INSTANCES is deliberately not in this dictionary: it is part of
        # Zscaler's own contract, parsed safely by their code, and must be honoured under both
        # packages. Everything here is Module-only, because the vendor code crashes on set HC_*
        # values and hardcodes its schedules.
        $healthSettings = [ordered]@{
            HEALTH_CRON                        = $healthCron
            HC_DATA_POINTS                     = "$HealthDataPoints"
            HC_UNHEALTHY_THRESHOLD             = "$HealthUnhealthyThreshold"
            HC_CONSECUTIVE_UNHEALTHY_THRESHOLD = "$HealthConsecutiveThreshold"
            GRACE_PERIOD_TIME_MIN              = "$HealthGracePeriodMinutes"
            MAX_TERMINATION_PERCENT            = "$MaxTerminationPercent"
            TERMINATION_POLICY                 = $TerminationPolicy
        }

        if ($FunctionPackage -eq 'Vendor') {
            # The vendor package hardcodes its schedules and health thresholds. Surface any
            # requested value it will ignore, rather than letting the config lie quietly.
            if ($SyncIntervalMinutes -ne 30) {
                Write-ZsLog "SyncIntervalMinutes=$SyncIntervalMinutes is ignored by the vendor package, which syncs on a fixed 30 minute schedule. Changing the cadence requires -FunctionPackage Module." -Level WARN
            }
            $ignored = @()
            if ($HealthDataPoints -ne 10)          { $ignored += "HealthDataPoints=$HealthDataPoints" }
            if ($HealthUnhealthyThreshold -ne 7)   { $ignored += "HealthUnhealthyThreshold=$HealthUnhealthyThreshold" }
            if ($HealthConsecutiveThreshold -ne 5) { $ignored += "HealthConsecutiveThreshold=$HealthConsecutiveThreshold" }
            if ($HealthGracePeriodMinutes -ne 30)  { $ignored += "HealthGracePeriodMinutes=$HealthGracePeriodMinutes" }
            if ($MaxTerminationPercent -ne 0.2)    { $ignored += "MaxTerminationPercent=$MaxTerminationPercent" }
            if ($TerminationPolicy -ne 'oldest')   { $ignored += "TerminationPolicy=$TerminationPolicy" }
            if ($ignored.Count -gt 0) {
                Write-ZsLog "The vendor package uses its built-in health defaults (10 samples, 7 unhealthy or 5 consecutive, 30 minute grace, 20 percent per pass, oldest first); ignored: $($ignored -join ', '). Tunables require -FunctionPackage Module." -Level WARN
            }
            if ($FunctionPackageUrl -and $FunctionPackageUrl -notmatch '^https://') {
                Write-ZsError -Message "FunctionPackageUrl '$FunctionPackageUrl' must be an https:// URL, or empty to deploy the copy in FunctionApp/vendor." -ErrorId 'ZsInvalidPackageUrl' -Cmdlet $PSCmdlet
            }
        }
        # A local package is zip-deployed onto the plan's disk; a URL is fetched by the platform.
        $localPackage = ($FunctionPackage -eq 'Module') -or (-not $FunctionPackageUrl)

        # Translate SyncIntervalMinutes into an NCRONTAB expression for the timer trigger.
        # The function's decorator reads this via the SYNC_CRON app setting.
        $syncCron = if ($SyncIntervalMinutes -le 59) {
            if (60 % $SyncIntervalMinutes -ne 0) {
                Write-ZsLog "SyncIntervalMinutes=$SyncIntervalMinutes does not divide 60 evenly; cron '*/$SyncIntervalMinutes' fires at uneven gaps across hour boundaries" -Level WARN
            }
            "0 */$SyncIntervalMinutes * * * *"
        } elseif ($SyncIntervalMinutes -ge 1440) {
            "0 0 0 * * *"
        } elseif ($SyncIntervalMinutes % 60 -eq 0) {
            "0 0 */$([int]($SyncIntervalMinutes / 60)) * * *"
        } else {
            $roundedHours = [math]::Max(1, [math]::Round($SyncIntervalMinutes / 60))
            Write-ZsLog "SyncIntervalMinutes=$SyncIntervalMinutes is not cron-expressible; rounding to every $roundedHours hour(s)" -Level WARN
            if ($roundedHours -ge 24) { "0 0 0 * * *" } else { "0 0 */$roundedHours * * *" }
        }

        # The plan. A Dedicated plan holds the host filesystem on the plan itself; Consumption and
        # Elastic Premium mount an Azure Files content share instead, which the platform creates and
        # reaches from outside the VNet - impossible on an account private from creation.
        $aspTier = switch -Regex ($AppServicePlanSku) {
            '^Y1$'      { 'Dynamic' }
            '^EP\d$'    { 'ElasticPremium' }
            # ARM reports P0v3 as its own tier, not PremiumV3. Matching it against PremiumV3
            # makes a correct plan look mismatched, and every re-run attempts a migration off it.
            '^P0v3$'    { 'Premium0V3' }
            '^B\d$'     { 'Basic' }
            default     { 'PremiumV3' }
        }
        if ($aspTier -in @('Dynamic','ElasticPremium')) {
            Write-ZsError -Message ("App Service Plan SKU $AppServicePlanSku ($aspTier) mounts an Azure Files content share on the function's " +
                "storage account, which the platform creates and reaches from outside the VNet. The account has public network access " +
                "disabled from creation, so the share cannot be made and the host would never start. Use a Dedicated SKU (P0v3, P1v3, " +
                "P2v3 or B1), which needs no file share. Nothing has been created.") -ErrorId 'ZsPlanNeedsPublicStorage' -Cmdlet $PSCmdlet
        }

        # A dry run over an existing app goes through the reconcile below, where every write asks
        # first, so it shows what an upgrade would change. Without one, placeholders stand in.
        $faSiteChk = Test-ArmResource -Uri "$rgPath/providers/Microsoft.Web/sites/func-zscc-$shortId`?api-version=$($script:ApiVersions.AppService)"
        if ($WhatIfPreference -and -not $faSiteChk.Exists) {
            $wStorName = "stzscc$shortId".ToLower(); if ($wStorName.Length -gt 24) { $wStorName = $wStorName.Substring(0,24) }
            return [PSCustomObject]@{
                FunctionApp="func-zscc-$shortId"; FunctionAppId='(created at deploy time)'; StorageAccount=$wStorName
                StorageUri='(created at deploy time)'; StoragePath='(created at deploy time)'
                AppInsightsId='(created at deploy time)'; IdentityPrincipalId='(whatif)'
                FuncAppSubnetId=$FuncAppSubnetId; PackagePending=$false
            }
        }

        $missing = @()
        if (-not $FuncAppSubnetId)         { $missing += '-FuncAppSubnetId (VNet integration: the only way the app reaches its storage)' }
        if (-not $PrivateEndpointSubnetId) { $missing += '-PrivateEndpointSubnetId (where the storage private endpoints go)' }
        if (-not $VnetId)                  { $missing += '-VnetId (for the private DNS zone links)' }
        if ($missing.Count -gt 0) {
            Write-ZsError -Message ("The Function App's storage account has public network access disabled, so the host reaches it only through " +
                "private endpoints over VNet integration. Missing: $($missing -join '; ').") -ErrorId 'ZsFunctionNeedsNetwork' -Cmdlet $PSCmdlet
        }

        # Storage account
        # Private in the create request itself: a policy that denies public network access refuses an
        # account created open and closed afterwards. The firewall behind it denies everything too, so
        # nothing changes should public access ever be switched back on. No IP or VNet rules: nothing
        # reaches this account except through its private endpoints.
        $storName = "stzscc$shortId".ToLower()
        if ($storName.Length -gt 24) { $storName = $storName.Substring(0,24) }
        $storPath = "$rgPath/providers/Microsoft.Storage/storageAccounts/$storName"
        $storUri  = "$storPath`?api-version=$($script:ApiVersions.Storage)"
        $privateAcls = @{ defaultAction='Deny'; bypass='AzureServices'; ipRules=@(); virtualNetworkRules=@() }
        $storChk  = Test-ArmResource -Uri $storUri
        $storPatch = @{}
        if ($storChk.Exists) {
            $stor = $storChk.Resource
            Add-ZsManifestResource -Type 'StorageAccount' -Name $storName -ResourceId $stor.id -PreExisting:(-not (Test-ZsModuleOwned -Resource $stor))
            # The 5.4.1.0 release created the account open, then restricted it to the function subnet
            # and the app's outbound addresses. Such an account is closed below, once its private
            # endpoints exist.
            $pna        = [string](Get-ZsPropertyValue $stor 'properties.publicNetworkAccess')
            $aclDefault = [string](Get-ZsPropertyValue $stor 'properties.networkAcls.defaultAction')
            $aclRules   = @(Get-ZsPropertyValue $stor 'properties.networkAcls.ipRules' | Where-Object { $_ }).Count +
                          @(Get-ZsPropertyValue $stor 'properties.networkAcls.virtualNetworkRules' | Where-Object { $_ }).Count
            $keyed      = ((Get-ZsPropertyValue $stor 'properties.allowSharedKeyAccess') -ne $false)
            if ($pna -ne 'Disabled' -or $aclDefault -ne 'Deny' -or $aclRules -gt 0) {
                $storPatch.publicNetworkAccess = 'Disabled'
                $storPatch.networkAcls = $privateAcls
            }
            if ($keyed -and -not $AllowSharedKeyStorageAccess) {
                $storPatch.allowSharedKeyAccess = $false
                $storPatch.defaultToOAuthAuthentication = $true
            }
        } elseif ($PSCmdlet.ShouldProcess($storName, 'Create storage account')) {
            Invoke-ArmPut -Uri $storUri -Body @{
                location=$loc; tags=$tags; kind='StorageV2'
                sku=@{name='Standard_ZRS'}
                properties=@{
                    supportsHttpsTrafficOnly=$true; minimumTlsVersion='TLS1_2'; allowBlobPublicAccess=$false
                    allowSharedKeyAccess=[bool]$AllowSharedKeyStorageAccess
                    defaultToOAuthAuthentication=$true
                    publicNetworkAccess='Disabled'
                    networkAcls=$privateAcls
                }
            } | Out-Null
            $stor = Wait-ArmProvision -Uri $storUri -Label $storName
            Add-ZsManifestResource -Type 'StorageAccount' -Name $storName -ResourceId $stor.id
        }

        # The host keeps timer schedules, locks and bookkeeping in blobs, queues and tables. No file
        # endpoint: a Dedicated plan has no Azure Files content share. pe-blob-<account> is the name
        # 5.4.1.0's New-ZsMonitorPrivateLink used, so an existing blob endpoint is reused.
        foreach ($svc in @('blob','queue','table')) {
            $zoneId = Resolve-ZsPrivateDnsZone -ZoneName $script:ZsPrivateDnsZones[$svc] -VnetId $VnetId `
                -HubResourceGroupName $PrivateDnsZoneResourceGroupName -HubSubscriptionId $PrivateDnsZoneSubscriptionId
            Set-ZsPrivateEndpoint -Name "pe-$svc-$storName" -TargetId $stor.id -GroupId $svc `
                -SubnetId $PrivateEndpointSubnetId -ZoneIds @($zoneId) -Properties @{ DnsZone=$script:ZsPrivateDnsZones[$svc] } | Out-Null
        }

        # Closed only now, so the host kept reaching its queues and tables through the subnet rule
        # until the endpoints existed. A PATCH leaves the tags and other properties alone. The
        # Microsoft.Storage service endpoint the rule needed then comes off the Function App subnet
        # if this module created the subnet; a brought subnet keeps its owner's settings.
        if ($storPatch.Count -gt 0 -and $PSCmdlet.ShouldProcess($storName, 'Close public network access and shared keys')) {
            Invoke-ArmRequest -Uri $storUri -Method Patch -Body @{ properties = $storPatch } | Out-Null
            $stor = Invoke-ArmGet -Uri $storUri
            Write-ZsLog "Storage $storName closed: public network access disabled, default-deny firewall with no rules$(if ($storPatch.ContainsKey('allowSharedKeyAccess')) { ', shared keys off' })"
        }
        # Created by this module: in its own VNet, or recorded as an owned subnet of a brought one.
        $subnetOwned = $false
        foreach ($e in @(Get-ZsPropertyValue (Get-ZsPropertyValue $script:ZsManifest 'Resources') 'Subnet' | Where-Object { $_ })) {
            if ([string](Get-ZsPropertyValue $e 'ResourceId') -eq $FuncAppSubnetId -and -not (Get-ZsPropertyValue $e 'PreExisting')) { $subnetOwned = $true }
        }
        if (-not $subnetOwned) {
            $vnetLive = Invoke-ArmGet -Uri "$VnetId`?api-version=$($script:ApiVersions.Network)" -AllowNotFound
            $subnetOwned = [bool]($vnetLive -and (Test-ZsModuleOwned -Resource $vnetLive))
        }
        if ($subnetOwned) {
            Remove-ZsSubnetServiceEndpoint -SubnetId $FuncAppSubnetId -Services @('Microsoft.Storage') | Out-Null
        }
        Write-ZsLog "Storage $storName reachable through its blob, queue and table private endpoints only"

        $aspName = "asp-zscc-$env-$loc"
        $aspUri  = "$rgPath/providers/Microsoft.Web/serverfarms/$aspName`?api-version=$($script:ApiVersions.AppService)"
        $aspChk  = Test-ArmResource -Uri $aspUri

        # A plan's tier cannot be changed in place. When the existing plan does not match, build a
        # correctly tiered one beside it and move the app onto it further down.
        if ($aspChk.Exists) {
            $existingTier = [string](Get-ZsPropertyValue $aspChk.Resource 'sku.tier'); $existingSku = [string](Get-ZsPropertyValue $aspChk.Resource 'sku.name')
            if ($existingSku -and $existingSku -ne $AppServicePlanSku) {
                $aspName = "asp-zscc-$env-$loc-$($AppServicePlanSku.ToLower())"
                $aspUri  = "$rgPath/providers/Microsoft.Web/serverfarms/$aspName`?api-version=$($script:ApiVersions.AppService)"
                $aspChk  = Test-ArmResource -Uri $aspUri
                Write-ZsLog "Existing App Service Plan is $existingSku ($existingTier) but the deployment requires $AppServicePlanSku ($aspTier); using $aspName instead (a plan's tier cannot be changed in place)"
            }
        }

        if ($aspChk.Exists) {
            $asp = $aspChk.Resource
        } elseif ($PSCmdlet.ShouldProcess($aspName, 'Create App Service Plan')) {
            Invoke-ArmPut -Uri $aspUri -Body @{
                location=$loc; tags=$tags; kind='linux'
                sku=@{name=$AppServicePlanSku; tier=$aspTier}
                properties=@{reserved=$true}
            } | Out-Null
            $asp = Wait-ArmProvision -Uri $aspUri -Label $aspName
            Add-ZsManifestResource -Type 'AppServicePlan' -Name $aspName -ResourceId $asp.id
        }

        # Function App identity.
        $faIdName = "id-zscc-funcapp-$env-$loc"
        $faIdUri  = "$rgPath/providers/Microsoft.ManagedIdentity/userAssignedIdentities/$faIdName`?api-version=$($script:ApiVersions.Identity)"
        $faIdChk  = Test-ArmResource -Uri $faIdUri
        if ($faIdChk.Exists) {
            $faId = $faIdChk.Resource
        } elseif ($PSCmdlet.ShouldProcess($faIdName, 'Create Function App identity')) {
            Invoke-ArmPut -Uri $faIdUri -Body @{location=$loc;tags=$tags} | Out-Null
            Start-Sleep -Seconds 15
            $faId = Invoke-ArmGet -Uri $faIdUri
            Add-ZsManifestResource -Type 'ManagedIdentity' -Name $faIdName -ResourceId $faId.id -Properties @{Role='FunctionApp'}
        }

        $faIdPrincipal = [string](Get-ZsPropertyValue $faId 'properties.principalId')
        $faIdClientId  = [string](Get-ZsPropertyValue $faId 'properties.clientId')

        # Control-plane role. The function reads virtualMachines and scale-set instances and
        # reads Key Vault secrets. Replacing an unhealthy connector is granted separately, with the
        # scale sets (Set-ZsHealthRemediationRole).
        Set-ZsFunctionAppRole -RoleMode $FunctionRoleMode -Scope $rgPath -PrincipalId $faIdPrincipal

        if ($DisableHealthRemediation) {
            Write-ZsLog "Health remediation disabled: unhealthy connectors are evaluated and logged but never terminated. The function identity keeps read-only compute rights."
        }

        if ($KeyVaultId) {
            $kvRoleDefId = "$(Get-ZsSubscriptionPath)/providers/Microsoft.Authorization/roleDefinitions/$($script:Roles.KvSecretsUser)"
            Set-ZsRoleAssignment -Scope $KeyVaultId -RoleDefinitionId $kvRoleDefId -PrincipalId $faIdPrincipal
            if (-not $WhatIfPreference) { Write-ZsLog "Function App identity holds Key Vault Secrets User" }
        }

        # Storage data-plane roles. Identity-based AzureWebJobsStorage requires the host to hold
        # these directly. Blob Data Owner rather than Contributor because the host manages blob
        # leases for its singleton locks, and Contributor cannot break a lease it did not create.
        $subPath = Get-ZsSubscriptionPath
        $storRoles = @(
            @{ Id=$script:Roles.StorageBlobDataOwner;        Label='Storage Blob Data Owner' }
            @{ Id=$script:Roles.StorageQueueDataContributor; Label='Storage Queue Data Contributor' }
            @{ Id=$script:Roles.StorageTableDataContributor; Label='Storage Table Data Contributor' }
        )
        if ($faIdPrincipal) {
            foreach ($r in $storRoles) {
                try {
                    Set-ZsRoleAssignment -Scope $storPath -RoleDefinitionId "$subPath/providers/Microsoft.Authorization/roleDefinitions/$($r.Id)" -PrincipalId $faIdPrincipal
                } catch { Write-ZsLog "Could not assign $($r.Label) on $storName`: $($_.Exception.Message)" -Level WARN }
            }
            Set-ZsRoleAssignment -Scope $storPath -PrincipalId $faIdPrincipal `
                -RoleDefinitionId "$subPath/providers/Microsoft.Authorization/roleDefinitions/$($script:Roles.StorageAccountContributor)"
            if (-not $WhatIfPreference) { Write-ZsLog "Function identity holds blob/queue/table data roles and Storage Account Contributor on $storName (account scope only)" }
        }

        # Application Insights. Timer functions fail silently without it: logs go nowhere
        # queryable and nothing exists for the heartbeat and error alerts to evaluate.
        $aiId = ''; $aiConnStr = ''
        $aiName = "appi-zscc-$shortId"
        if (-not $SkipAppInsights -and $WhatIfPreference) {
            # A dry run reads the component that is there; it is written only for real.
            $aiChk = Test-ArmResource -Uri "$rgPath/providers/Microsoft.Insights/components/$aiName`?api-version=$($script:ApiVersions.AppInsights)"
            if ($aiChk.Exists) {
                $aiId = [string]$aiChk.Resource.id
                $aiConnStr = [string](Get-ZsPropertyValue $aiChk.Resource 'properties.ConnectionString')
            } else {
                $null = $PSCmdlet.ShouldProcess($aiName, 'Create Application Insights')
                $aiId = "($aiName created at deploy time)"
            }
        } elseif (-not $SkipAppInsights -and $PSCmdlet.ShouldProcess($aiName, 'Create Application Insights')) {
            try {
                $wa = New-ZsWorkspace
                $ai = New-ZsAppInsights -Name "appi-zscc-$shortId" -WorkspaceId $wa.id
                $aiId = $ai.id
                $aiConnStr = $ai.properties.ConnectionString
                Write-ZsLog "Application Insights appi-zscc-$shortId ready (workspace-backed)"
            } catch {
                Write-ZsLog "Could not provision Application Insights: $($_.Exception.Message). The function will run without telemetry." -Level WARN
            }
        }

        # The package the app runs from: Zscaler's URL, or ('1') a zip deployed onto the plan's disk,
        # which happens once the app and its private endpoint exist (below).
        $packageUrl = if ($localPackage) { '1' } else { $FunctionPackageUrl }
        if ($localPackage) {
            Write-ZsLog "Function package: the $FunctionPackage package, zip-deployed onto the plan's disk through the app's private endpoint"
        } else {
            Write-ZsLog "Function package: Zscaler's published package, run from $FunctionPackageUrl"
        }

        # Function App. AzureWebJobsStorage uses the identity-based connection form: the host
        # resolves AzureWebJobsStorage__accountName with the managed identity credential, so no
        # account key appears in app settings. App-setting names follow Zscaler's reference module
        # exactly, so a config, a runbook, or Zscaler's own package reads unchanged here.
        $vmssList = @($VmssNames -split ',' | Where-Object { $_ })
        $vmssNamesJson = if ($vmssList.Count -gt 0) { ConvertTo-Json -InputObject $vmssList -Compress } else { '[]' }
        $faName = "func-zscc-$shortId"
        $faPath = "$rgPath/providers/Microsoft.Web/sites/$faName"
        $faUri  = "$faPath`?api-version=$webApi"
        $faChk  = Test-ArmResource -Uri $faUri
        $ccUrl  = ConvertTo-ZsCcUrl -Url $ProvisioningUrl

        $want = [ordered]@{
            FUNCTIONS_EXTENSION_VERSION = '~4'
            FUNCTIONS_WORKER_RUNTIME    = 'python'
            SUBSCRIPTION_ID             = "/subscriptions/$($script:ZsSession.SubscriptionId)"
            MANAGED_IDENTITY            = $faIdClientId
            RESOURCE_GROUP              = $script:ZsSession.ResourceGroupName
            VMSS_NAME                   = $vmssNamesJson
            VAULT_URL                   = $KeyVaultUri
            # Without a scheme, as Zscaler's own module passes it: the package prefixes https://
            # itself, and given the scheme it resolves the host as "https" and every sync fails.
            CC_URL                      = $ccUrl
            TERMINATE_UNHEALTHY_INSTANCES = $(if ($DisableHealthRemediation) { 'false' } else { 'true' })
            WEBSITE_RUN_FROM_PACKAGE    = $packageUrl
            AzureWebJobsStorage__accountName = $storName
            AzureWebJobsStorage__credential  = 'managedidentity'
            AzureWebJobsStorage__clientId    = $faIdClientId
            ApplicationInsightsAgent_EXTENSION_VERSION = '~3'
            XDT_MicrosoftApplicationInsights_Mode      = 'recommended'
        }
        if ($vmssList.Count -eq 0) { $want['CC_COMPUTER_PREFIX'] = "vm-zscc-$($script:ZsSession.ShortId)" }
        if ($FunctionPackage -eq 'Module' -and $SyncIntervalMinutes -ne 30) { $want['SYNC_CRON'] = $syncCron }
        if ($FunctionPackage -eq 'Module') { foreach ($k in $healthSettings.Keys) { $want[$k] = $healthSettings[$k] } }
        if ($aiConnStr) { $want['APPLICATIONINSIGHTS_CONNECTION_STRING'] = $aiConnStr }

        # Site settings the Terraform module sends explicitly, so a policy that appends them finds
        # them already set.
        $webCfg = @{
            alwaysOn = $true
            http20Enabled = $true
            minTlsVersion = '1.2'
            ftpsState = 'Disabled'
            vnetRouteAllEnabled = $true
            ipSecurityRestrictionsDefaultAction = 'Deny'
            scmIpSecurityRestrictionsDefaultAction = 'Deny'
        }

        $hostTouched = $false
        if ($faChk.Exists) {
            $site = $faChk.Resource
            Write-ZsLog "Function App $faName verified"
            Add-ZsManifestResource -Type 'FunctionApp' -Name $faName -ResourceId $faPath -PreExisting:(-not (Test-ZsModuleOwned -Resource $site))
            if ($PSCmdlet.ShouldProcess($faName, 'Reconcile Function App')) {
                # Public network access off. On Linux a change to it restarts the app.
                $sitePna = [string](Get-ZsPropertyValue $site 'properties.publicNetworkAccess')
                if ($sitePna -ne 'Disabled') {
                    Invoke-ArmRequest -Uri $faUri -Method Patch -Body @{ properties=@{ publicNetworkAccess='Disabled' } } | Out-Null
                    Write-ZsLog "Function App $faName closed: public network access disabled for the site and its SCM endpoint"
                    $hostTouched = $true
                }

                # Move the app onto the reconciled plan if it is sitting on another one.
                try {
                    $siteLive = Invoke-ArmGet -Uri $faUri
                    if ("$($siteLive.properties.serverFarmId)" -ne "$($asp.id)") {
                        Write-ZsLog "Moving $faName from its current plan to $aspName ($aspTier)"
                        # The platform refuses a plan change while regional VNet integration is
                        # attached. Detach for the move; the integration reconcile below re-attaches it.
                        if ("$(Get-ZsPropertyValue $siteLive 'properties.virtualNetworkSubnetId')") {
                            Write-ZsLog "Detaching VNet integration for the plan move; it is re-attached in the next step"
                            Invoke-ArmRequest -Uri $faUri -Method Patch -Body @{
                                properties = @{ virtualNetworkSubnetId = $null }
                            } | Out-Null
                            Start-Sleep -Seconds 10
                        }
                        Invoke-ArmRequest -Uri $faUri -Method Patch -Body @{
                            properties = @{ serverFarmId = $asp.id }
                        } | Out-Null
                        Wait-ArmProvision -Uri $faUri -Label $faName -TimeoutSeconds 600 | Out-Null
                        $hostTouched = $true
                    }
                } catch { Write-ZsLog "Could not reconcile the App Service Plan for $faName`: $($_.Exception.Message)" -Level WARN }

                # VNet integration and route-all. Without both the app has no path to its storage.
                $siteLive = Invoke-ArmGet -Uri $faUri
                if ("$(Get-ZsPropertyValue $siteLive 'properties.virtualNetworkSubnetId')" -ne $FuncAppSubnetId) {
                    Invoke-ArmPut -Uri "$faPath/networkConfig/virtualNetwork?api-version=$webApi" -Body @{
                        properties=@{ subnetResourceId=$FuncAppSubnetId; swiftSupported=$true }
                    } | Out-Null
                    Write-ZsLog "Function App VNet integration reconciled"
                    $hostTouched = $true
                }
                Invoke-ArmPut -Uri "$faPath/config/web?api-version=$webApi" -Body @{ properties = $webCfg } | Out-Null

                # App settings. The provisioning URL, the package or the scale set names may have
                # changed, and settings older versions wrote are removed.
                $configUri = "$faPath/config/appsettings?api-version=$webApi"
                $currentSettings = Invoke-ArmPost -Uri "$faPath/config/appsettings/list?api-version=$webApi"
                $props = @{}
                if ($currentSettings -and $currentSettings.PSObject.Properties.Name -contains 'properties') {
                    $currentSettings.properties.PSObject.Properties | ForEach-Object { $props[$_.Name] = [string]$_.Value }
                }
                $before = ($props.GetEnumerator() | Sort-Object Name | ForEach-Object { "$($_.Name)=$($_.Value)" }) -join "`n"
                foreach ($k in $want.Keys) { $props[$k] = [string]$want[$k] }
                # Set by 5.4.1.0 for the identity-based fetch of a package blob; no package is in
                # storage now.
                $props.Remove('WEBSITE_RUN_FROM_PACKAGE_BLOB_MI_RESOURCE_ID')
                if ($vmssList.Count -gt 0) { $props.Remove('CC_COMPUTER_PREFIX') }
                if (-not ($FunctionPackage -eq 'Module' -and $SyncIntervalMinutes -ne 30)) { $props.Remove('SYNC_CRON') }
                if ($FunctionPackage -ne 'Module') { foreach ($k in $healthSettings.Keys) { $props.Remove($k) } }
                # Names this module used before adopting the Zscaler contract, a key-based
                # AzureWebJobsStorage, and an earlier elastic plan's Azure Files content share,
                # whose connection string a key-disabled account can no longer authenticate.
                foreach ($stale in @('AZURE_SUBSCRIPTION_ID','AZURE_RESOURCE_GROUP','AZURE_VAULT_URL','AZURE_CLIENT_ID',
                                     'ZS_CC_BASE_URL','ZS_CC_PROV_URL','CC_RESOURCE_GROUP','SYNC_INTERVAL_MINUTES','AzureWebJobsStorage',
                                     'WEBSITE_CONTENTAZUREFILECONNECTIONSTRING','WEBSITE_CONTENTSHARE','WEBSITE_CONTENTOVERVNET')) {
                    if ($props.ContainsKey($stale)) { $props.Remove($stale) }
                }
                $after = ($props.GetEnumerator() | Sort-Object Name | ForEach-Object { "$($_.Name)=$($_.Value)" }) -join "`n"
                if ($after -ne $before) {
                    # A settings change restarts the app, which is the trigger sync a package URL needs.
                    Invoke-ArmPut -Uri $configUri -Body @{ properties = $props } | Out-Null
                    Write-ZsLog "Function App settings reconciled (package, CC_URL without scheme, identity-based storage)"
                    $hostTouched = $true
                } else {
                    Write-ZsLog "Function App settings verified"
                }
            }
        } elseif ($PSCmdlet.ShouldProcess($faName, 'Create Function App')) {
            $appSettings = @()
            foreach ($k in $want.Keys) { $appSettings += @{ name=$k; value=[string]$want[$k] } }
            $siteConfig = @{ linuxFxVersion='Python|3.11'; appSettings=$appSettings }
            foreach ($k in $webCfg.Keys) { $siteConfig[$k] = $webCfg[$k] }
            Invoke-ArmPut -Uri $faUri -Body @{
                location=$loc; tags=$tags; kind='functionapp,linux'
                identity=@{type='UserAssigned';userAssignedIdentities=@{"$($faId.id)"=@{}}}
                properties=@{
                    serverFarmId=$asp.id; reserved=$true
                    httpsOnly=$true
                    # No inbound path from the internet, whether or not the private endpoint is on.
                    # The timers fire inside the host, and Always On is the platform's own request.
                    publicNetworkAccess='Disabled'
                    # VNet integration from the first start: the host reaches its storage only
                    # through the private endpoints.
                    virtualNetworkSubnetId=$FuncAppSubnetId
                    keyVaultReferenceIdentity=$faId.id
                    siteConfig=$siteConfig
                }
            } | Out-Null
            Wait-ArmProvision -Uri $faUri -Label $faName -TimeoutSeconds 900 | Out-Null
            Add-ZsManifestResource -Type 'FunctionApp' -Name $faName -ResourceId "$faPath"
            Write-ZsLog "Function App $faName created: public network access off, VNet-integrated with route-all"
            $hostTouched = $true
        }

        # No basic auth for deployments - Entra only.
        if ($PSCmdlet.ShouldProcess($faName, 'Disable basic publishing credentials')) {
            foreach ($pol in 'scm','ftp') {
                try {
                    Invoke-ArmPut -Uri "$faPath/basicPublishingCredentialsPolicies/$pol`?api-version=$webApi" -Body @{ properties = @{ allow = $false } } | Out-Null
                } catch { Write-ZsLog "Could not disable $pol basic publishing credentials: $($_.Exception.Message)" -Level WARN }
            }
        }

        # Private endpoint: optional, for operators inside the network, and required for a local
        # package, whose zip deploy reaches the SCM endpoint through it. It is also the path the
        # host's own trigger sync takes to the platform once public access is off, which is what
        # fills the portal's and Resource Manager's function list.
        if ($EnablePrivateEndpoint -or $localPackage) {
            try {
                $sitesZone = Resolve-ZsPrivateDnsZone -ZoneName $script:ZsPrivateDnsZones.sites -VnetId $VnetId `
                    -HubResourceGroupName $PrivateDnsZoneResourceGroupName -HubSubscriptionId $PrivateDnsZoneSubscriptionId
                $faPe = Set-ZsPrivateEndpoint -Name "pe-$faName" -TargetId $faPath -GroupId 'sites' -SubnetId $PrivateEndpointSubnetId `
                    -ZoneIds @($sitesZone) -Properties @{ DnsZone=$script:ZsPrivateDnsZones.sites }
                if ([string]$faPe.Id -notmatch '^\(') { Write-ZsLog "Function App Private Endpoint pe-$faName in place" }
            } catch {
                $why = if ($localPackage) { 'The package cannot be deployed without it.' } else { "The app stays private; only the portal's function views need the endpoint." }
                Write-ZsLog "Function App Private Endpoint step failed: $($_.Exception.Message). $why" -Level WARN
            }
        }

        # A local package: zip-deployed onto the plan's disk through that endpoint, unless the app
        # already has it. The app carries the hash of the package it last received, so an unchanged
        # package is not deployed again, and a run from outside the network can tell whether the app
        # has its code. From such a host the deployment carries on without it and says so; a re-run
        # from inside the network deploys it.
        $packagePending = $false
        if ($localPackage -and $PSCmdlet.ShouldProcess($faName, "Deploy the $FunctionPackage function package")) {
            $pkg = Build-ZsFunctionPackage -FunctionPackage $FunctionPackage
            try {
                $siteTags = Get-ZsPropertyValue (Invoke-ArmGet -Uri $faUri) 'tags'
                if ([string](Get-ZsPropertyValue $siteTags $script:ZsPackageTag) -eq $pkg.Hash) {
                    Write-ZsLog "Function package $($pkg.Hash) is already deployed to $faName"
                } else {
                    try {
                        Publish-ZsPackageToScm -FunctionAppName $faName -ZipPath $pkg.Path | Out-Null
                        $hostTouched = $true
                        try {
                            Invoke-ArmRequest -Uri "$faPath/providers/Microsoft.Resources/tags/default?api-version=$($script:ApiVersions.Tags)" -Method Patch -Body @{
                                operation = 'Merge'; properties = @{ tags = @{ $script:ZsPackageTag = $pkg.Hash } }
                            } | Out-Null
                        } catch { Write-ZsLog "Could not record the deployed package on $faName ($($_.Exception.Message)); the next run deploys it again" -Level WARN }
                    } catch {
                        if ("$($_.Exception.Message)" -notmatch '^ZsPackagePushNeedsNetwork') { throw }
                        $packagePending = $true
                        Write-ZsLog ("$($_.Exception.Message) The deployment carries on without it. Until then the app runs the package it " +
                            "already had, if any; a new app has none, and its heartbeat alert reports that.") -Level WARN
                    }
                }
            } finally {
                if ($pkg.Temporary) { Remove-Item -LiteralPath $pkg.Path -Force -ErrorAction SilentlyContinue }
            }
        }

        # Host check. Resource Manager lists the app's functions once the host has synced its
        # triggers, so a listed function means the host started, loaded the package and reached its
        # storage. The host syncs through its own hostname, which public network access off refuses
        # unless a private endpoint (-EnablePrivateEndpoint, or a local package) carries it. Without
        # one the list can stay empty while the timers run, so it is read once, nothing is
        # restarted, and the run says where to look instead.
        $hasPe = [bool]($EnablePrivateEndpoint -or $localPackage)
        if ($packagePending) {
            Write-ZsLog "Function host check skipped: this run could not deploy $faName's package" -Level DEBUG
        } elseif ($PSCmdlet.ShouldProcess($faName, 'Check the function host')) {
            $hostOk = $false; $lastHostError = ''
            $fnNames = @()
            # With the endpoint, budgeted for a greenfield run: data-plane role assignments on storage
            # can take several minutes to propagate, and a host refused at startup does not always
            # retry. A restart re-runs startup with the propagated roles and is the trigger sync
            # Microsoft accepts for a package URL. A run that changed nothing on the app looks once
            # and restarts nothing.
            $restartAt = if ($hostTouched -and $hasPe) { @(120, 300) } else { @() }
            $budget    = if ($hostTouched -and $hasPe) { 420 } else { 0 }
            $restartsDone = 0
            $hostSw = [System.Diagnostics.Stopwatch]::StartNew()
            while ($true) {
                try {
                    $fns = Invoke-ArmGet -Uri "$faPath/functions?api-version=$webApi"
                    $fnNames = @($fns.value | Where-Object { $_ } | ForEach-Object { ($_.name -split '/')[-1] })
                } catch { $lastHostError = "functions list: $($_.Exception.Message)" }
                if ($fnNames.Count -gt 0) {
                    Write-ZsLog "Function host healthy: indexed $($fnNames -join ', ') ($([int]$hostSw.Elapsed.TotalSeconds)s)"
                    $hostOk = $true; break
                }
                if ($hostSw.Elapsed.TotalSeconds -ge $budget) { break }
                if ($restartsDone -lt $restartAt.Count -and $hostSw.Elapsed.TotalSeconds -ge $restartAt[$restartsDone]) {
                    try {
                        Invoke-ArmRequest -Uri "$faPath/restart?api-version=$webApi" -Method Post | Out-Null
                        Write-ZsLog "Functions not listed yet; restart $($restartsDone + 1) of $($restartAt.Count) to retry with propagated role assignments"
                    } catch { $lastHostError = "restart: $($_.Exception.Message)" }
                    $restartsDone++
                }
                Start-Sleep -Seconds 15
            }
            if (-not $hostOk) {
                $aiHint = if ($aiId) { " In Application Insights appi-zscc-$shortId, 'requests | where name in (""healthMonitor"", ""synchronizeCloudResources"")' shows executions within a few minutes of a healthy start, and the heartbeat alert reports a sync that never runs." } else { '' }
                $diagHint = " If nothing runs, open Diagnose and solve problems > 'Function App Down or Reporting Errors', which runs at the platform plane: " +
                    "a storage 403 there means role propagation or the storage private endpoints, and a package error means the app could not load " +
                    "its package (the URL unreachable, or no zip deployed)."
                if ($hasPe) {
                    Write-ZsLog ("Resource Manager does not list $faName's functions after $([int]$hostSw.Elapsed.TotalSeconds)s, through its private endpoint.$aiHint$diagHint" +
                        $(if ($lastHostError) { " Last error: $lastHostError" } else { '' })) -Level WARN
                } else {
                    Write-ZsLog ("Function host not confirmed: Resource Manager lists $faName's functions only through a private endpoint " +
                        "(-EnableFunctionPrivateEndpoint), so an empty list here proves nothing.$aiHint$diagHint")
                }
            }
        }

        return [PSCustomObject]@{
            FunctionApp=$faName; FunctionAppId=$faPath; StorageAccount=$storName
            StorageUri="$storUri"; StoragePath=$storPath
            AppInsightsId=$aiId; IdentityPrincipalId=$faIdPrincipal
            FuncAppSubnetId=$FuncAppSubnetId; PackagePending=$packagePending
        }
    }
}

function Set-ZsHealthRemediationRole {
    <#
    .SYNOPSIS Grants the function identity what replacing an unhealthy connector takes.
    .DESCRIPTION Zscaler's package (1.0.3, health_monitor.py), and this module's function alike, delete
        a connector whose health samples fail, then read the scale set back and write it with the
        capacity it had, so a new connector takes the old one's place. These are Flexible scale sets:
        each connector is a VM in its own right, with its own NICs and disk, in the resource group, and
        Microsoft lists Compute VM Write and Network beside the scale set write as what Flexible
        orchestration needs. So the caller needs rights over all of it and over everything the scale
        set model references:

          scale set           Microsoft.Compute/virtualMachineScaleSets/write and delete/action
          connector VMs       Microsoft.Compute/virtualMachines/write and delete
          their NICs          Microsoft.Network/networkInterfaces/write, delete and join/action
          their OS disks      Microsoft.Compute/disks/write and delete
          backend pool        Microsoft.Network/loadBalancers/backendAddressPools/join/action
          both subnets        Microsoft.Network/virtualNetworks/subnets/join/action
          connector identity  Microsoft.ManagedIdentity/userAssignedIdentities/*/assign/action

        The VMs, NICs and disks get names nobody knows in advance, so the role goes on the resource
        group, which also holds the scale sets and the load balancer and covers the subnets when the
        VNet is in the group too. Where the VNet is in another group the same role goes on the two
        connector subnets. Managed Identity Operator on the connector identity is the built-in role for
        the assign action. Without these the delete or the write after it fails, and the unhealthy
        connector stays in the backend pool failing the probe, or is deleted and never replaced.

        Virtual Machine Contributor by default, which is broad on a resource group: besides the above it
        can run commands on and add extensions to any VM in the group, delete the scale sets and list
        storage account keys. It cannot change the load balancer, the VNet, the Key Vault or any role
        assignment. Where that is too wide, name a custom role carrying exactly the actions above,
        assignable at this group and at the subnets.

        5.4.1.0 granted a custom role at each scale set instead, which could delete a connector but
        not start its replacement. Those assignments are removed here.
    .PARAMETER PrincipalId Object ID of the Function App's user-assigned identity.
    .PARAMETER ConnectorIdentityId Resource ID of the connectors' user-assigned identity.
    .PARAMETER SubnetIds Connector subnets to grant the role on as well: the management and service
        subnets, when their VNet is in another resource group. Empty grants none.
    .PARAMETER RoleName The role, by name: a built-in role or an existing custom role.
    .PARAMETER CreateRole Define a custom role with exactly the actions above in place of RoleName, at the
        resource group and assignable there and at the subnets' group. Needs
        Microsoft.Authorization/roleDefinitions/write at both.
    .PARAMETER VmssIds The scale sets, whose 5.4.1.0 per-scale-set grants are removed.
    .OUTPUTS None.
    .EXAMPLE
    Set-ZsHealthRemediationRole -PrincipalId $faPrincipal -ConnectorIdentityId $id.IdentityId -VmssIds $ids
    Grants Virtual Machine Contributor on the resource group and Managed Identity Operator on the connector identity.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    param(
        [Parameter(Mandatory)][string]$PrincipalId,
        [Parameter(Mandatory)][string]$ConnectorIdentityId,
        [string[]]$SubnetIds = @(),
        [string]$RoleName = 'Virtual Machine Contributor',
        [string[]]$VmssIds = @(),
        [switch]$CreateRole
    )
    if ($PrincipalId -match '^\(') { return }
    $subPath = Get-ZsSubscriptionPath
    $rgPath  = Get-ZsRgPath
    $authApi = $script:ApiVersions.Authorization

    # The deployment's own replacement role, which CreateRole defines. Role names are unique across
    # the tenant, so it carries the deployment's short id.
    $ownRoleName = "ZSCC Connector Replacement $($script:ZsSession.ShortId)"
    $ownRoleId = (Resolve-ZsRoleDefinitionScope -RoleName $ownRoleName -AtResourceGroup).ResourceId
    $ownRole   = Invoke-ArmGet -Uri "$ownRoleId`?api-version=$authApi" -AllowNotFound
    $ownDefined = [bool]$ownRole
    $vmcRoleId = "$subPath/providers/Microsoft.Authorization/roleDefinitions/$($script:Roles.VirtualMachineContributor)"

    # The role by name, so a custom role the platform team defined is used the same way a
    # built-in one is; or, with CreateRole, the deployment's own.
    $roleDefId = ''
    if ($CreateRole) {
        $RoleName  = $ownRoleName
        $roleDefId = $ownRoleId
        $assignable = [System.Collections.Generic.List[string]]::new()
        $assignable.Add($rgPath)
        foreach ($sid in @($SubnetIds | Where-Object { $_ -and $_ -notmatch '^\(' })) {
            $subnetRg = ($sid -split '/providers/')[0]
            if ($assignable -notcontains $subnetRg) { $assignable.Add($subnetRg) }
        }
        if (Test-ZsRoleDefinitionCurrent -Definition $ownRole -Actions $script:RemediationActions -AssignableScopes $assignable.ToArray()) {
            Write-ZsLog "Custom role '$RoleName' verified" -Level DEBUG
        } elseif ($PSCmdlet.ShouldProcess($RoleName, $(if ($ownDefined) { 'Reconcile custom role permissions' } else { 'Create custom role' }))) {
            Invoke-ArmPut -Uri "$roleDefId`?api-version=$authApi" -Body @{ properties = @{
                roleName = $RoleName; type = 'CustomRole'
                description = 'Replaces an unhealthy Zscaler Cloud Connector in its Flexible scale set: deletes it, and lets the scale set start another.'
                permissions = @(@{ actions = $script:RemediationActions; notActions = @(); dataActions = @(); notDataActions = @() })
                assignableScopes = $assignable.ToArray()
            } } | Out-Null
            # A new definition takes a few seconds to become assignable.
            if (-not $ownDefined) { Start-Sleep -Seconds 10 }
            $ownDefined = $true
        }
    } elseif (-not $RoleName -or $RoleName -eq 'Virtual Machine Contributor') {
        $RoleName = 'Virtual Machine Contributor'
        $roleDefId = $vmcRoleId
    } else {
        $filter = [uri]::EscapeDataString("roleName eq '$RoleName'")
        $found = $null
        foreach ($at in @($subPath, $rgPath)) {
            $found = @(Get-ZsPropertyValue (Invoke-ArmGet -Uri "$at/providers/Microsoft.Authorization/roleDefinitions?api-version=$authApi&`$filter=$filter") 'value') | Select-Object -First 1
            if ($found) { break }
        }
        if (-not $found) {
            throw [System.InvalidOperationException]::new(
                "RemediationRoleName '$RoleName' is not a role definition visible at $subPath or the deployment resource group. " +
                "Name a built-in role, or a custom role assignable at the resource group$(if (@($SubnetIds).Count) { ' and at the connector subnets' }).")
        }
        $roleDefId = [string]$found.id
    }

    # Each grant asks first (Set-ZsRoleAssignment), so a dry run names only the ones missing.
    $scopes = [System.Collections.Generic.List[string]]::new()
    $scopes.Add($rgPath)
    foreach ($sid in @($SubnetIds | Where-Object { $_ -and $_ -notmatch '^\(' })) { $scopes.Add([string]$sid) }
    foreach ($scope in $scopes) {
        try {
            Set-ZsRoleAssignment -Scope $scope -RoleDefinitionId $roleDefId -PrincipalId $PrincipalId
        } catch {
            $cls = Resolve-ZsArmFailure -ErrorRecord $_
            $why = if ($cls.Summary) { $cls.Summary } else { $_.Exception.Message }
            $where = if ($scope -eq $rgPath) { 'the deployment resource group' } else { "subnet $(($scope -split '/')[-1])" }
            throw [System.InvalidOperationException]::new(
                "Could not grant $RoleName to the function identity on $where`: $why. Replacing an unhealthy connector needs it. " +
                $(if ($where -ne 'the deployment resource group') {
                    "The subnet is in the platform's resource group: grant it there out of band and set GrantFunctionSubnetJoin to false, or give the deployer Role Based Access Control Administrator on the VNet's resource group. "
                } else { '' }) +
                "Or re-run with -DisableHealthRemediation to leave replacement to an operator.", $_.Exception)
        }
    }

    if ($ConnectorIdentityId -and $ConnectorIdentityId -notmatch '^\(') {
        Set-ZsRoleAssignment -Scope $ConnectorIdentityId -PrincipalId $PrincipalId `
            -RoleDefinitionId "$subPath/providers/Microsoft.Authorization/roleDefinitions/$($script:Roles.ManagedIdentityOperator)"
    }

    # A change of role takes back what the one before granted, as Terraform replaces the
    # assignment: Virtual Machine Contributor once another role is granted in its place, or the
    # deployment's own role once it is no longer asked for. Only the grants this module made go,
    # found under the names Set-ZsRoleAssignment gives them. Roles compare on their GUID: a role
    # named in RemediationRoleName comes back under the subscription, the deployment's own under
    # the resource group.
    $grantedGuid = ($roleDefId -split '/')[-1]
    foreach ($earlier in @($vmcRoleId, $ownRoleId) | Where-Object { ($_ -split '/')[-1] -ne $grantedGuid }) {
        $label = if ($earlier -eq $vmcRoleId) { 'Virtual Machine Contributor' } else { $ownRoleName }
        foreach ($scope in $scopes) {
            $name = Get-ZsRoleAssignmentName -Scope $scope -RoleDefinitionId $earlier -PrincipalId $PrincipalId
            $uri = "$scope/providers/Microsoft.Authorization/roleAssignments/$name`?api-version=$authApi"
            if (-not (Invoke-ArmGet -Uri $uri -AllowNotFound)) { continue }
            $where = ($scope -split '/')[-1]
            if (-not $PSCmdlet.ShouldProcess($where, "Remove the function's $label grant, which $RoleName replaces")) { continue }
            try {
                Invoke-ArmDelete -Uri $uri -AllowNotFound | Out-Null
                Write-ZsLog "Removed the function's $label grant on $where; $RoleName replaces it"
            } catch { Write-ZsLog "Could not remove the function's $label grant on $where`: $($_.Exception.Message)" -Level WARN }
        }
    }
    # The deployment's own role is this deployment's whichever run defined it, and whether or not
    # this run still grants it: teardown deletes it once nothing is assigned to it.
    if ($ownDefined -and -not (Test-ZsManifestHas -Type 'RoleDefinition' -ResourceId $ownRoleId)) {
        Add-ZsManifestResource -Type 'RoleDefinition' -Name $ownRoleName -ResourceId $ownRoleId
    }

    if (-not $WhatIfPreference) {
        Write-ZsLog ("Health remediation: $RoleName on the resource group$(if ($scopes.Count -gt 1) { " and $($scopes.Count - 1) connector subnet(s)" }), " +
            "Managed Identity Operator on the connector identity")
    }

    # 5.4.1.0's per-scale-set custom role. Its assignments are redundant now and are removed; the
    # definition is recorded so teardown deletes it once nothing is assigned to it.
    $legacy = Resolve-ZsRoleDefinitionScope -RoleName $script:ZsLegacyRemediationRoleName
    try { $legacyDef = Invoke-ArmGet -Uri "$($legacy.ResourceId)?api-version=$authApi" -AllowNotFound }
    catch {
        Write-ZsLog "Could not read the 5.4.1.0 remediation role, so any per-scale-set grants of it stay in place: $($_.Exception.Message)" -Level WARN
        return
    }
    if (-not $legacyDef) { return }
    $legacyGuid = ($legacy.ResourceId -split '/')[-1]
    foreach ($vmssId in @($VmssIds | Where-Object { $_ -and $_ -notmatch '^\(' })) {
        # A scale set this run has not created yet has nothing to remove.
        $filter = [uri]::EscapeDataString("principalId eq '$PrincipalId'")
        $list = Invoke-ArmGet -Uri "$vmssId/providers/Microsoft.Authorization/roleAssignments?api-version=$authApi&`$filter=$filter" -AllowNotFound
        if (-not $list) { continue }
        foreach ($a in @($list.value | Where-Object { $_ })) {
            $defGuid = ([string]$a.properties.roleDefinitionId -split '/')[-1]
            # The list also returns grants inherited from above; only the one on the scale set goes.
            # An assignment's id is its scope followed by the assignment segment.
            $aScope = [string]$a.id -replace '/providers/Microsoft\.Authorization/roleAssignments/[^/]+$', ''
            if ($defGuid -ne $legacyGuid -or $aScope -ne $vmssId) { continue }
            if (-not $PSCmdlet.ShouldProcess(($vmssId -split '/')[-1], 'Remove the 5.4.1.0 remediation grant')) { continue }
            try {
                Invoke-ArmDelete -Uri "$($a.id)?api-version=$authApi" -AllowNotFound | Out-Null
                Write-ZsLog "Removed the 5.4.1.0 remediation grant on $(($vmssId -split '/')[-1]); the resource group grant replaces it"
            } catch { Write-ZsLog "Could not remove the 5.4.1.0 remediation grant on $(($vmssId -split '/')[-1]): $($_.Exception.Message)" -Level WARN }
        }
    }
    if (-not (Test-ZsManifestHas -Type 'RoleDefinition' -ResourceId $legacy.ResourceId)) {
        Add-ZsManifestResource -Type 'RoleDefinition' -Name $script:ZsLegacyRemediationRoleName -ResourceId $legacy.ResourceId
    }
}

function Set-ZsFunctionAppRole {
    <#
    .SYNOPSIS Assigns the control-plane role for the lifecycle Function App identity.
    .DESCRIPTION Reader assigns the built-in Reader role plus a custom role holding the exact
        compute read actions the sync calls; the custom role is redundant beside Reader today,
        but it survives Reader being removed later and records in RBAC precisely what the
        function depends on. LeastPrivilege assigns only the custom role, and requires the
        deployer to hold roleDefinitions/write. NetworkContributor grants network write far beyond the function's reads.
        None skips assignment for environments where roles are managed out of band.
    .PARAMETER RoleMode Reader, LeastPrivilege, NetworkContributor, or None.
    .PARAMETER Scope Assignment scope, normally the resource group.
    .PARAMETER PrincipalId Object ID of the function's managed identity.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    param(
        [Parameter(Mandatory)][ValidateSet('Reader','LeastPrivilege','NetworkContributor','None')][string]$RoleMode,
        [Parameter(Mandatory)][string]$Scope,
        [string]$PrincipalId
    )

    if ($RoleMode -eq 'None') {
        Write-ZsLog "Function App role assignment skipped; grant principal $PrincipalId read access to compute resources out of band or the sync will fail" -Level WARN
        return
    }
    if (-not $PrincipalId) {
        Write-ZsLog "No principal ID for the Function App identity; skipping role assignment" -Level WARN
        return
    }

    $subPath = Get-ZsSubscriptionPath

    if ($RoleMode -eq 'NetworkContributor') {
        Write-ZsLog ("FunctionRoleMode=NetworkContributor grants write and delete over every network " +
            "resource in $Scope, including the route table carrying workload traffic, and the " +
            "function performs only compute reads. Use Reader or LeastPrivilege unless an existing " +
            "deployment depends on it.") -Level WARN
        Set-ZsRoleAssignment -Scope $Scope -RoleDefinitionId "$subPath/providers/Microsoft.Authorization/roleDefinitions/$($script:Roles.NetworkContributor)" -PrincipalId $PrincipalId
        return
    }

    if ($RoleMode -eq 'Reader') {
        Set-ZsRoleAssignment -Scope $Scope -RoleDefinitionId "$subPath/providers/Microsoft.Authorization/roleDefinitions/$($script:Roles.Reader)" -PrincipalId $PrincipalId
        if (-not $WhatIfPreference) { Write-ZsLog "Function App identity holds built-in Reader at $Scope" }
    }

    # Deterministic GUID at the scope the deployment's mode allows, matching the connector
    # identity's custom role in New-ZsIdentity.
    $roleName  = 'ZSCC Lifecycle Function Compute Reader'
    $roleScope = Resolve-ZsRoleDefinitionScope -RoleName $roleName
    $roleGuid  = $roleScope.Guid
    $roleUri   = "$($roleScope.ResourceId)`?api-version=$($script:ApiVersions.Authorization)"

    $roleBody = @{
        properties = @{
            roleName    = $roleName
            description = 'Read-only access to virtual machines and scale set instances, required by the Zscaler Cloud Connector lifecycle sync function. No write actions.'
            type        = 'CustomRole'
            permissions = @(@{ actions = $script:FuncIdentityActions; notActions = @(); dataActions = @(); notDataActions = @() })
            assignableScopes = @($roleScope.Scope)
        }
    }

    if ($script:ZsCustomRoleDenial -and $RoleMode -eq 'Reader') {
        Write-ZsLog ("Custom role creation is denied in this environment ($script:ZsCustomRoleDenial); " +
            "not attempting the scoped custom role. Built-in Reader is assigned and sufficient.") -Level WARN
        return
    }
    try {
        $roleLive = Invoke-ArmGet -Uri $roleUri -AllowNotFound
        if (Test-ZsRoleDefinitionCurrent -Definition $roleLive -Actions $script:FuncIdentityActions -AssignableScopes @($roleScope.Scope)) {
            Write-ZsLog "Custom role '$roleName' verified" -Level DEBUG
        } elseif ($PSCmdlet.ShouldProcess($roleName, $(if ($roleLive) { 'Reconcile custom role permissions' } else { 'Create custom role' }))) {
            Invoke-ArmPut -Uri $roleUri -Body $roleBody | Out-Null
            Start-Sleep -Seconds 5
            # Recorded so teardown removes it once nothing is assigned to it. Without this the
            # definition outlived every deployment that used it, and only the connector identity's
            # role was ever cleaned up.
            if ($null -eq $roleLive) {
                Add-ZsManifestResource -Type 'RoleDefinition' -Name $roleName -ResourceId $roleScope.ResourceId
            }
        }
        Set-ZsRoleAssignment -Scope $Scope -RoleDefinitionId $roleScope.ResourceId -PrincipalId $PrincipalId
        if (-not $WhatIfPreference) { Write-ZsLog "Function App identity holds custom role '$roleName' at $Scope" }
    } catch {
        # The old message guessed at missing RBAC; the run in front of the operator may actually be
        # an Azure Policy deny (RequestDisallowedByPolicy), which no role grant will ever fix. The
        # classifier tells them apart and the remedy is stated with the cause.
        $cls = Resolve-ZsArmFailure -ErrorRecord $_
        if ($cls.Kind -eq 'Policy') { $script:ZsCustomRoleDenial = $cls.Summary }
        $why = switch ($cls.Kind) {
            'Policy'     { $cls.Summary }
            'Permission' { 'the deployer lacks Microsoft.Authorization/roleDefinitions/write' }
            default      { $cls.Summary }
        }
        if (-not $why) { $why = $_.Exception.Message }
        if ($RoleMode -eq 'Reader') {
            Write-ZsLog "Could not create the scoped custom role: $why. Built-in Reader is assigned and sufficient." -Level WARN
        } else {
            $remedy = if ($cls.Kind -eq 'Policy') {
                'Have the platform team exempt this deployment from the policy, or re-run with -FunctionRoleMode Reader.'
            } else {
                'The deployer needs Microsoft.Authorization/roleDefinitions/write, or re-run with -FunctionRoleMode Reader.'
            }
            throw [System.InvalidOperationException]::new("Could not create or assign '$roleName': $why. $remedy")
        }
    }
}
