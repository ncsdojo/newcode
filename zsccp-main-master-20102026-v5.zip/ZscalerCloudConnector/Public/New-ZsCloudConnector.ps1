<#
.SYNOPSIS
    Deploys standalone dual-NIC Cloud Connector virtual machines across availability zones.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
    .PARAMETER Count Number of connector VMs to create.
    .PARAMETER VmSize Azure VM size for each connector.
    .PARAMETER MgmtSubnetId Shared management subnet ID for every connector's management NIC.
    .PARAMETER ServiceSubnetId Shared service subnet ID for every connector's service NIC.
    .PARAMETER LbBackendId Load balancer backend pool ID.
    .PARAMETER IdentityResourceId Managed identity resource ID to assign to the VMs.
    .PARAMETER KeyVaultUri Base URI of the Key Vault containing connector credentials.
    .PARAMETER ProvisioningUrl Zscaler provisioning URL for connector registration.
    #>

function New-ZsCloudConnector {
    <#
    .SYNOPSIS Deploys Cloud Connector VMs with dual NICs, marketplace plan, managed identity, and cloud-init.
    .DESCRIPTION Creates management NIC (primary, no IP forwarding) and service NIC (secondary, IP forwarding,
        LB backend pool) per CC, then the VM with correct NIC ordering. Checks accelerated networking support
        before NIC creation. Existing VMs are detected and skipped for idempotency.
    .EXAMPLE
    New-ZsCloudConnector -MgmtSubnetId $mgmt -ServiceSubnetId $svc -KeyVaultUri $kv -ProvisioningUrl $url -SshPublicKey $key
    Deploys a single standalone Cloud Connector VM (non-VMSS topology).
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([System.Collections.Generic.List[PSCustomObject]])]
    param(
        [ValidateRange(1,20)][int]$Count = 2,
        [ValidateNotNullOrEmpty()][string]$VmSize = 'Standard_D2s_v3',
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$MgmtSubnetId,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$ServiceSubnetId,
        [Parameter(Mandatory)][string]$LbBackendId,      [Parameter(Mandatory)][string]$IdentityResourceId,
        [string]$IdentityClientId = '',
        [Parameter(Mandatory)][string]$KeyVaultUri,      [Parameter(Mandatory)][string]$ProvisioningUrl,
        [Parameter(Mandatory)][string]$SshPublicKey,
        [ValidateRange(1,65535)][int]$HttpProbePort = 50000,
        [string[]]$Zones = @('1','2'),
        [string]$AdminUsername = 'zsroot', [string]$OsDiskType = 'Premium_LRS',
        [switch]$EncryptAtHost,
        # LegacyVMNVA keeps the connectors off Azure hosts with the MANA network adapter, as the
        # scale sets are kept; see New-ZsCloudConnectorVmss.
        [switch]$DisableLegacyVmNvaTag
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $loc=$script:ZsSession.Location; $tags=Get-ZsTags
        $rgPath=Get-ZsRgPath; $netApi=$script:ApiVersions.Network; $vmApi=$script:ApiVersions.Compute; $img=$script:CcImage

        $accelNet = Test-AcceleratedNetworkingSupport -VmSize $VmSize
        Write-ZsLog "Accelerated networking: $accelNet ($VmSize)"

        $encHost = $false
        if ($EncryptAtHost) {
            $encHost = Test-EncryptionAtHostSupport -VmSize $VmSize
            Write-ZsLog "Encryption at host: $encHost ($VmSize)"
        }

        $ud64 = Get-ZsConnectorUserData -ProvisioningUrl $ProvisioningUrl -KeyVaultUri $KeyVaultUri -HttpProbePort $HttpProbePort -IdentityClientId $IdentityClientId
        $vmTags = @{}; foreach ($k in $tags.Keys) { $vmTags[$k] = $tags[$k] }
        if (-not $DisableLegacyVmNvaTag) { $vmTags['LegacyVMNVA'] = 'true' }

        $results = [System.Collections.Generic.List[PSCustomObject]]::new()

        for ($i = 0; $i -lt $Count; $i++) {
            $idx = $i + 1; $zone = $Zones[$i % $Zones.Count]
            $iMgmtSubnetId = $MgmtSubnetId; $iServiceSubnetId = $ServiceSubnetId
            $ccPrefix = "vm-zscc-$($script:ZsSession.ShortId)"
            $vmN = "$ccPrefix-$idx"; $mNic = "nic-zscc-mgmt-$idx"; $sNic = "nic-zscc-svc-$idx"
            Write-Progress -Activity 'Deploying Cloud Connectors' -Status "$vmN (zone $zone)" -PercentComplete ([int](($i / $Count) * 100))

            $vmUri = "$rgPath/providers/Microsoft.Compute/virtualMachines/$vmN`?api-version=$vmApi"
            $vmChk = Test-ArmResource -Uri $vmUri
            if ($vmChk.Exists -and $vmChk.State -eq 'Succeeded') {
                Write-ZsLog "[$idx/$Count] $vmN exists, skipping"
                # Azure reads LegacyVMNVA when it places a VM; a running connector picks it up after
                # 'az vm reapply' or a redeploy.
                $liveTags = @{}
                $liveTagObj = Get-ZsPropertyValue $vmChk.Resource 'tags'
                if ($liveTagObj) { foreach ($p in $liveTagObj.PSObject.Properties) { $liveTags[$p.Name] = [string]$p.Value } }
                $wantNva = -not $DisableLegacyVmNvaTag
                $hasNva = ($liveTags['LegacyVMNVA'] -eq 'true')
                if ($wantNva -ne $hasNva -and (Test-ZsModuleOwned -Resource $vmChk.Resource) -and $PSCmdlet.ShouldProcess($vmN, 'Reconcile LegacyVMNVA tag')) {
                    if ($wantNva) { $liveTags['LegacyVMNVA'] = 'true' } else { $liveTags.Remove('LegacyVMNVA') }
                    Invoke-ArmRequest -Uri $vmUri -Method Patch -Body @{ tags = $liveTags } | Out-Null
                    Write-ZsLog "$vmN LegacyVMNVA tag $(if ($wantNva) { "set; it applies after 'az vm reapply' or a redeploy" } else { 'removed' })"
                }
                $existSvc = Invoke-ArmGet -Uri "$rgPath/providers/Microsoft.Network/networkInterfaces/$sNic`?api-version=$netApi"
                $results.Add([PSCustomObject]@{ VmName=$vmN; VmId=$vmChk.Resource.id; Zone=$zone; ServiceIp=$(try{$existSvc.properties.ipConfigurations[0].properties.privateIPAddress}catch{''}); Status='Existing' })
                continue
            }

            if (-not $PSCmdlet.ShouldProcess($vmN, 'Create Cloud Connector VM')) { continue }

            $mPath = "$rgPath/providers/Microsoft.Network/networkInterfaces/$mNic"
            Invoke-ArmPut -Uri "$mPath`?api-version=$netApi" -Body @{
                location=$loc; tags=$tags
                properties=@{ ipConfigurations=@(@{ name='ipconfig-mgmt'; properties=@{ privateIPAllocationMethod='Dynamic'; subnet=@{id=$iMgmtSubnetId}; primary=$true } })
                    enableIPForwarding=$false; enableAcceleratedNetworking=$false }
            } | Out-Null
            $mObj = Wait-ArmProvision -Uri "$mPath`?api-version=$netApi" -Label $mNic
            # Recorded even though the VM's deleteOption cascades to it: a run that stops between
            # NIC and VM creation leaves a NIC no cascade will ever reach, invisible to a
            # manifest-driven teardown, and the subnet delete then fails InUse. Once the VM exists
            # and cascades, the teardown's own delete finds the NIC already gone, which
            # -AllowNotFound treats as the success it is.
            Add-ZsManifestResource -Type 'NetworkInterface' -Name $mNic -ResourceId $mObj.id

            $sPath = "$rgPath/providers/Microsoft.Network/networkInterfaces/$sNic"
            Invoke-ArmPut -Uri "$sPath`?api-version=$netApi" -Body @{
                location=$loc; tags=$tags
                properties=@{ ipConfigurations=@(@{ name='ipconfig-svc'; properties=@{ privateIPAllocationMethod='Dynamic'; subnet=@{id=$iServiceSubnetId}; primary=$true
                    loadBalancerBackendAddressPools=@(@{id=$LbBackendId}) } })
                    enableIPForwarding=$true; enableAcceleratedNetworking=$accelNet }
            } | Out-Null
            $sObj = Wait-ArmProvision -Uri "$sPath`?api-version=$netApi" -Label $sNic
            Add-ZsManifestResource -Type 'NetworkInterface' -Name $sNic -ResourceId $sObj.id

            Invoke-ArmPut -AsyncTimeoutSeconds 900 -Uri $vmUri -Body @{
                location=$loc; tags=($vmTags + @{'zscaler-cc-index'="$i"}); zones=@($zone)
                plan=@{ name=$img.Sku; publisher=$img.Publisher; product=$img.Offer }
                identity=@{ type='UserAssigned'; userAssignedIdentities=@{ "$IdentityResourceId"=@{} } }
                properties=@{
                    hardwareProfile=@{ vmSize=$VmSize }
                    osProfile=@{ computerName=$vmN; adminUsername=$AdminUsername; customData=$ud64
                        linuxConfiguration=@{ disablePasswordAuthentication=$true; ssh=@{ publicKeys=@(@{ path="/home/$AdminUsername/.ssh/authorized_keys"; keyData=$SshPublicKey }) } } }
                    storageProfile=@{
                        imageReference=@{ publisher=$img.Publisher; offer=$img.Offer; sku=$img.Sku; version=$img.Version }
                        osDisk=@{ createOption='FromImage'; caching='ReadWrite'; managedDisk=@{storageAccountType=$OsDiskType}; deleteOption='Delete' } }
                    networkProfile=@{ networkInterfaces=@(
                        @{ id=$mObj.id; properties=@{ primary=$true; deleteOption='Delete' } }
                        @{ id=$sObj.id; properties=@{ primary=$false; deleteOption='Delete' } } ) }
                    diagnosticsProfile=@{ bootDiagnostics=@{ enabled=$true } }
                    securityProfile=@{ encryptionAtHost=$encHost }
                }
            } | Out-Null

            $vm = Wait-ArmProvision -Uri $vmUri -Label $vmN -TimeoutSeconds 900
            $svcIp = ''; try { $svcIp = $sObj.properties.ipConfigurations[0].properties.privateIPAddress } catch { }
            Add-ZsManifestResource -Type 'VirtualMachine' -Name $vmN -ResourceId $vm.id -Properties @{ Zone=$zone; ServiceIp=$svcIp; VmSize=$VmSize }
            $results.Add([PSCustomObject]@{ VmName=$vmN; VmId=$vm.id; Zone=$zone; ServiceIp=$svcIp; Status='Created' })
            Write-ZsLog "[$idx/$Count] $vmN ready (svc=$svcIp zone=$zone)"
        }
        Write-Progress -Activity 'Deploying Cloud Connectors' -Completed
        # @() so a dry run's empty result set binds as an empty array; a bare empty pipeline
        # yields null, which a Mandatory -Value refuses - an error only -WhatIf could produce.
        Add-ZsManifestOutput -Key 'CloudConnectorServiceIps' -Value @($results | ForEach-Object { $_.ServiceIp })
        return $results
    }
}
