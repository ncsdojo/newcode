<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (New-ZsPrivateNetwork).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
    .PARAMETER NextHopIp IP address of the load balancer frontend (next hop for workload traffic).
    .PARAMETER WorkloadSubnetCidr CIDR of the workload subnet.
    .PARAMETER VnetPath VNet ARM path.
    .PARAMETER WorkloadSubnetPath Full ARM path to the workload subnet (optional, derived if omitted).
    .PARAMETER RouteTableName Name for the route table (optional, auto-generated if omitted).
    #>

function New-ZsPrivateNetwork {
    <#
    .SYNOPSIS Creates route table with default route to LB and associates with workload subnet.
    .DESCRIPTION Creates a route table with a 0.0.0.0/0 UDR pointing to the load balancer frontend,
    then associates it with the workload subnet using a GET-merge-PUT to preserve existing subnet
    properties (NSG, service endpoints, delegations). Accepts an explicit subnet path for BYO VNets
    where the workload subnet may not be named snet-zscc-workload.
    .EXAMPLE
    New-ZsPrivateNetwork -NextHopIp 10.1.3.4 -WorkloadSubnetCidr 10.1.10.0/24 -VnetPath $net.VnetPath
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][ValidatePattern('^\d+\.\d+\.\d+\.\d+$')][string]$NextHopIp,
        [Parameter(Mandatory)][string]$WorkloadSubnetCidr,
        [Parameter(Mandatory)][string]$VnetPath,
        [string]$WorkloadSubnetPath = '',
        [string]$RouteTableName = ''
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $env=$script:ZsSession.Environment; $loc=$script:ZsSession.Location; $tags=Get-ZsTags; $rgPath=Get-ZsRgPath; $api=$script:ApiVersions.Network
        if (-not $RouteTableName) { $RouteTableName = New-ZsResourceName -Prefix 'rt-zscc-wl' -Environment $env -Location $loc }
        if (-not $WorkloadSubnetPath) { $WorkloadSubnetPath = "$VnetPath/subnets/snet-zscc-workload" }
        $subnetUri = "$WorkloadSubnetPath`?api-version=$api"

        $rtPath="$rgPath/providers/Microsoft.Network/routeTables/$RouteTableName"; $rtUri="$rtPath`?api-version=$api"
        $defaultRoute = @{ name='default-to-zscc'; properties=@{ addressPrefix='0.0.0.0/0'; nextHopType='VirtualAppliance'; nextHopIpAddress=$NextHopIp } }
        $check = Test-ArmResource -Uri $rtUri
        # A dry run over an existing table goes through the reconcile, where every write asks first.
        if ($WhatIfPreference -and -not $check.Exists) { return [PSCustomObject]@{ RouteTableName=$RouteTableName; RouteTableId='(route table created at deploy time)'; NextHop=$NextHopIp } }
        if ($check.Exists) {
            $rt = $check.Resource
            $rtOwned = Test-ZsModuleOwned -Resource $rt
            Add-ZsManifestResource -Type 'RouteTable' -Name $RouteTableName -ResourceId $rt.id -Properties @{ NextHop=$NextHopIp } -PreExisting:(-not $rtOwned)

            # The default route has to point at the load balancer's frontend as it is now, and BGP
            # propagation has to stay off, or a learned prefix takes traffic around the connectors.
            # A table this module made is brought back to both; its other routes are kept.
            $liveRoutes = @(Get-ZsPropertyValue $rt 'properties.routes' | Where-Object { $_ })
            $liveDefault = @($liveRoutes | Where-Object { [string](Get-ZsPropertyValue $_ 'properties.addressPrefix') -eq '0.0.0.0/0' }) | Select-Object -First 1
            $drift = [System.Collections.Generic.List[string]]::new()
            if (-not $liveDefault) { $drift.Add('no 0.0.0.0/0 route') }
            else {
                $hopType = [string](Get-ZsPropertyValue $liveDefault 'properties.nextHopType')
                $hopIp   = [string](Get-ZsPropertyValue $liveDefault 'properties.nextHopIpAddress')
                if ($hopType -ne 'VirtualAppliance' -or $hopIp -ne $NextHopIp) { $drift.Add("0.0.0.0/0 to $hopType $hopIp") }
            }
            if (-not [bool](Get-ZsPropertyValue $rt 'properties.disableBgpRoutePropagation')) { $drift.Add('BGP route propagation on') }

            if ($drift.Count -eq 0) {
                Write-ZsLog "Route table $RouteTableName verified"
            } elseif (-not $rtOwned) {
                Write-ZsLog ("Route table $RouteTableName differs ($($drift -join '; ')) but carries no managed-by tag of this deployment, " +
                    "so it is left as it is. Workload traffic reaches the connectors only through a 0.0.0.0/0 route to $NextHopIp.") -Level WARN
            } elseif ($PSCmdlet.ShouldProcess($RouteTableName, "Reconcile route table ($($drift -join '; '))")) {
                $routes = [System.Collections.Generic.List[object]]::new()
                foreach ($r in $liveRoutes) {
                    if ([string](Get-ZsPropertyValue $r 'properties.addressPrefix') -eq '0.0.0.0/0' -or [string]$r.name -eq 'default-to-zscc') { continue }
                    $routes.Add($r)
                }
                $routes.Add($defaultRoute)
                Invoke-ArmPut -Uri $rtUri -Body @{ location=$rt.location; tags=$tags; properties=@{ disableBgpRoutePropagation=$true; routes=$routes.ToArray() } } | Out-Null
                $rt = Wait-ArmProvision -Uri $rtUri -Label $RouteTableName
                Write-ZsLog "Route table $RouteTableName reconciled: $($drift -join '; ') -> 0.0.0.0/0 to $NextHopIp, BGP propagation off"
            }
        }
        elseif ($PSCmdlet.ShouldProcess($RouteTableName, 'Create route table')) {
            Invoke-ArmPut -Uri $rtUri -Body @{
                location=$loc; tags=$tags
                properties=@{ disableBgpRoutePropagation=$true; routes=@($defaultRoute) }
            } | Out-Null
            $rt = Wait-ArmProvision -Uri $rtUri -Label $RouteTableName
            Add-ZsManifestResource -Type 'RouteTable' -Name $RouteTableName -ResourceId $rt.id -Properties @{ NextHop=$NextHopIp }
        } else { return }

        # GET-merge-PUT: read existing subnet properties so the route table association does not
        # strip NSG bindings, service endpoints, delegations, or other config on a BYO subnet. In a
        # dry run a subnet the run would create is not there yet to read.
        $subnetLeaf = Split-Path $WorkloadSubnetPath -Leaf
        $existing = Invoke-ArmGet -Uri $subnetUri -AllowNotFound:$WhatIfPreference
        $liveRtId = [string](Get-ZsPropertyValue $existing 'properties.routeTable.id')
        if ($liveRtId -and $liveRtId -eq [string]$rt.id) {
            Write-ZsLog "Subnet $subnetLeaf already uses route table $RouteTableName"
        } elseif ($PSCmdlet.ShouldProcess($subnetLeaf, 'Associate route table')) {
            if ($liveRtId) {
                Write-ZsLog ("Subnet $subnetLeaf carried a different route table ($liveRtId); it is being replaced. " +
                    "Confirm with the subnet's owner if that table was theirs.") -Level WARN
            }
            if ($existing.properties) {
                $existing.properties | Add-Member -NotePropertyName 'routeTable' -NotePropertyValue @{ id=$rt.id } -Force
                $props = $existing.properties
            } else {
                $props = @{ addressPrefix=$WorkloadSubnetCidr; routeTable=@{ id=$rt.id } }
            }
            Invoke-ArmPut -Uri $subnetUri -Body @{ properties=$props } | Out-Null
            Wait-ArmProvision -Uri $subnetUri -Label 'RT-subnet-assoc' | Out-Null
        }
        return [PSCustomObject]@{ RouteTableName=$RouteTableName; RouteTableId=$rt.id; NextHop=$NextHopIp }
    }
}
