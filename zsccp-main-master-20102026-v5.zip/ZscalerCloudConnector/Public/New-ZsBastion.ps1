<#
.SYNOPSIS
    Deploys Azure Bastion for management access to the Cloud Connectors: Premium and private-only
    by default, with Microsoft's NSG on AzureBastionSubnet.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function New-ZsBastion {
    <#
    .SYNOPSIS Deploys Azure Bastion for SSH access to the Cloud Connectors without a public address on any of them.
    .DESCRIPTION Premium and private-only by default, with no public IP, which is what a policy refusing
        Microsoft.Network/publicIPAddresses (Org-Delta's "Not allowed resource types") allows. It answers
        only on its private address, so operators reach it over ExpressRoute, VPN or peering, with the
        Azure CLI native client:

          az network bastion ssh --name <bastion> --resource-group <rg> `
            --target-ip-address <connector management IP> `
            --auth-type ssh-key --username zsroot --ssh-key <private key file>

        Native-client tunnelling and IP-based connection are on for that (Microsoft requires IP-based
        connection for clients coming from on-premises); shareable links, file copy and Kerberos are
        off. Basic and Standard, where public IPs are allowed, get one.

        AzureBastionSubnet gets an NSG with Microsoft's Bastion rules before the host is deployed into
        it, taking sessions on 443 from VirtualNetwork for a private-only Bastion and from Internet for
        a public SKU, unless -ClientSourceAddressPrefix narrows it. An NSG this module did not create
        stays, and a subnet that already serves another Bastion is left alone and that Bastion used.

        Azure cannot convert a Bastion between public and private-only, so a Bastion this module created
        on the other side of that line is deleted and rebuilt, and its public IP removed.
    .PARAMETER VnetPath ARM path of the VNet containing the AzureBastionSubnet.
    .PARAMETER SubnetId Full ID of the AzureBastionSubnet, for a VNet whose path is not under this
        deployment. Defaults to AzureBastionSubnet under VnetPath.
    .PARAMETER Sku Premium (default, private-only, no public IP), Standard or Basic (both with a public IP).
    .PARAMETER ClientSourceAddressPrefix Source allowed to open sessions on 443. Empty uses VirtualNetwork
        for private-only and Internet for a public SKU. Narrow it to your admin range if you have one.
    .PARAMETER SkipNsg Leave AzureBastionSubnet's NSG to its owner, for a platform team that attaches its own.
    .PARAMETER ScaleUnits Bastion scale units (Standard and Premium support 2 to 50). Default 2.
    .OUTPUTS PSCustomObject with the Bastion name, resource ID, SKU, whether it is private-only, and any public IP.
    .EXAMPLE
    New-ZsBastion -VnetPath $vnetPath
    Deploys a private-only Premium Bastion with Microsoft's NSG on AzureBastionSubnet.
    .EXAMPLE
    New-ZsBastion -VnetPath $vnetPath -Sku Standard
    Deploys a Standard Bastion with a public IP, where the platform allows one.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$VnetPath,
        [string]$SubnetId = '',
        [ValidateSet('Premium','Standard','Basic')][string]$Sku = 'Premium',
        [string]$ClientSourceAddressPrefix = '',
        [switch]$SkipNsg,
        [ValidateRange(2,50)][int]$ScaleUnits = 2
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $env=$script:ZsSession.Environment; $loc=$script:ZsSession.Location; $tags=Get-ZsTags
        $rgPath=Get-ZsRgPath; $api=$script:ApiVersions.Network; $basApi=$script:ApiVersions.Bastion

        $bastionName = New-ZsResourceName -Prefix 'bas-zscc' -Environment $env -Location $loc
        $pipName     = New-ZsResourceName -Prefix 'pip-bas-zscc' -Environment $env -Location $loc
        $nsgName     = New-ZsResourceName -Prefix 'nsg-zscc-bas' -Environment $env -Location $loc
        if (-not $SubnetId) { $SubnetId = "$VnetPath/subnets/AzureBastionSubnet" }

        $public = $Sku -in @('Basic','Standard')
        $clientSource = if ($ClientSourceAddressPrefix) { $ClientSourceAddressPrefix } elseif ($public) { 'Internet' } else { 'VirtualNetwork' }
        if ($ClientSourceAddressPrefix -match '^\d' -and -not (Test-ZsCidr -Cidr $ClientSourceAddressPrefix)) {
            Write-ZsError -Message "ClientSourceAddressPrefix '$ClientSourceAddressPrefix' is not valid IPv4 CIDR notation or a service tag." -ErrorId 'ZsInvalidBastionSource' -Cmdlet $PSCmdlet
        }

        # A brought network's AzureBastionSubnet may already serve a Bastion, or carry its owner's
        # NSG. A second Bastion cannot share the subnet, so an existing one is used as it is; and an
        # NSG this module did not create stays, since the owner's rules govern their subnet.
        $subLive = $null
        if ($SubnetId -notmatch '^\(' -and -not $WhatIfPreference) { $subLive = Invoke-ArmGet -Uri "$SubnetId`?api-version=$api" -AllowNotFound }
        $otherHosts = @(@(Get-ZsPropertyValue $subLive 'properties.ipConfigurations') | Where-Object { $_ } | ForEach-Object {
            if ([string](Get-ZsPropertyValue $_ 'id') -match '/bastionHosts/([^/]+)/') { $Matches[1] }
        } | Where-Object { $_ -and $_ -ne $bastionName } | Select-Object -Unique)
        if ($otherHosts.Count -gt 0) {
            Write-ZsLog "AzureBastionSubnet already serves Bastion $($otherHosts -join ', '); that one is used, and this deployment creates no Bastion and leaves the subnet as it is"
            return [PSCustomObject]@{ BastionName=$otherHosts[0]; BastionId=''; Sku=''; PrivateOnly=$false; PublicIp='' }
        }
        $liveNsg = [string](Get-ZsPropertyValue $subLive 'properties.networkSecurityGroup.id')
        if (-not $SkipNsg -and $liveNsg -and $liveNsg -notmatch "/networkSecurityGroups/$([regex]::Escape($nsgName))$" -and (Test-ZsForeignNsg -NsgId $liveNsg)) {
            Write-ZsLog ("AzureBastionSubnet carries NSG $(($liveNsg -split '/')[-1]), which this deployment did not create; it is left in place. " +
                "Azure checks it against Bastion's required rules when the host is deployed.") -Level WARN
            $SkipNsg = [switch]$true
        }

        # The NSG goes on the subnet before Bastion is deployed into it, so the two never update
        # the subnet at the same time.
        if (-not $SkipNsg) {
            $nsgId = Set-ZsNsg -Name $nsgName -Rules (Get-ZsBastionNsgRuleSet -ClientSource $clientSource) -Role 'Bastion'
            if ($nsgId -and $nsgId -notmatch '^\(' -and $SubnetId -notmatch '^\(') {
                Set-ZsSubnetNsgAssociation -SubnetId $SubnetId -NsgId $nsgId -Label 'AzureBastionSubnet' -KeepForeignNsg | Out-Null
            }
        }

        $basPath = "$rgPath/providers/Microsoft.Network/bastionHosts/$bastionName"
        $basUri  = "$basPath`?api-version=$basApi"
        $pipPath = "$rgPath/providers/Microsoft.Network/publicIPAddresses/$pipName"
        $pipUri  = "$pipPath`?api-version=$api"

        $basChk  = Test-ArmResource -Uri $basUri
        if ($basChk.Exists) {
            $live = $basChk.Resource
            $liveOwned = Test-ZsModuleOwned -Resource $live
            $liveSku = [string](Get-ZsPropertyValue $live 'sku.name')
            $cfg0 = @(Get-ZsPropertyValue $live 'properties.ipConfigurations')[0]
            $livePip = [string](Get-ZsPropertyValue $cfg0 'properties.publicIPAddress.id')
            $livePublic = [bool]$livePip
            if ($livePublic -ne $public) {
                $from = if ($livePublic) { "$liveSku with a public IP" } else { "$liveSku private-only" }
                $to   = if ($public) { "$Sku with a public IP" } else { "$Sku private-only" }
                if (-not $liveOwned) {
                    Write-ZsLog ("Bastion $bastionName is $from, not $to, but it carries no managed-by tag of this deployment, so it is " +
                        "left as it is. Azure cannot convert between the two in place.") -Level WARN
                    Add-ZsManifestResource -Type 'Bastion' -Name $bastionName -ResourceId $live.id -PreExisting
                    return [PSCustomObject]@{ BastionName=$bastionName; BastionId=$live.id; Sku=$liveSku; PrivateOnly=(-not $livePublic); PublicIp='' }
                }
                if (-not $PSCmdlet.ShouldProcess($bastionName, "Replace Bastion ($from -> $to)")) {
                    return [PSCustomObject]@{ BastionName=$bastionName; BastionId=$live.id; Sku=$liveSku; PrivateOnly=(-not $livePublic); PublicIp='' }
                }
                Write-ZsLog "Bastion $bastionName is $from; replacing it with $to. Azure cannot convert between the two in place, so it is deleted and rebuilt (expect twenty minutes or more)." -Level WARN
                Invoke-ArmDelete -AsyncTimeoutSeconds 1800 -Uri $basUri -AllowNotFound | Out-Null
                $goneSw = [System.Diagnostics.Stopwatch]::StartNew()
                while ($goneSw.Elapsed.TotalSeconds -lt 1800) {
                    if (-not (Invoke-ArmGet -Uri $basUri -AllowNotFound)) { break }
                    Start-Sleep -Seconds 15
                }
                if ($livePublic -and -not $public) {
                    # Its public IP was this module's and nothing else uses it.
                    $oldPip = Invoke-ArmGet -Uri "$livePip`?api-version=$api" -AllowNotFound
                    if ($oldPip -and (Test-ZsModuleOwned -Resource $oldPip)) {
                        try {
                            Invoke-ArmDelete -Uri "$livePip`?api-version=$api" -AllowNotFound | Out-Null
                            Write-ZsLog "Removed the old Bastion public IP $(($livePip -split '/')[-1])"
                        } catch { Write-ZsLog "Could not remove the old Bastion public IP $(($livePip -split '/')[-1]): $($_.Exception.Message)" -Level WARN }
                    }
                }
                $basChk = @{ Exists = $false; Resource = $null; State = $null }
            }
        }

        $pip = $null
        if ($public) {
            $pipChk = Test-ArmResource -Uri $pipUri
            if ($pipChk.Exists) {
                $pip = $pipChk.Resource
                Add-ZsManifestResource -Type 'PublicIP' -Name $pipName -ResourceId $pip.id -Properties @{ Role='Bastion' } -PreExisting:(-not (Test-ZsModuleOwned -Resource $pip))
            } elseif ($PSCmdlet.ShouldProcess($pipName, 'Create Bastion Public IP')) {
                Invoke-ArmPut -Uri $pipUri -Body @{
                    location=$loc; tags=$tags; sku=@{name='Standard'}
                    properties=@{ publicIPAllocationMethod='Static'; publicIPAddressVersion='IPv4' }
                } | Out-Null
                $pip = Wait-ArmProvision -Uri $pipUri -Label $pipName
                Add-ZsManifestResource -Type 'PublicIP' -Name $pipName -ResourceId $pip.id -Properties @{ Role='Bastion' }
            } else { return }
        }

        $ipCfgProps = @{ subnet=@{ id=$SubnetId } }
        if ($public) { $ipCfgProps.publicIPAddress = @{ id=$pip.id } }
        $wantProps = @{
            scaleUnits=$ScaleUnits
            # Native client and IP-based connection: how a private-only Bastion is used from
            # on-premises. Neither exists on Basic.
            enableTunneling=($Sku -ne 'Basic')
            enableIpConnect=($Sku -ne 'Basic')
            # Nothing that hands out access by link or moves files.
            enableShareableLink=$false
            enableFileCopy=$false
            enableKerberos=$false
            enablePrivateOnlyBastion=(-not $public)
            ipConfigurations=@(@{ name='bastion-ipcfg'; properties=$ipCfgProps })
        }

        if ($basChk.Exists) {
            $bas = $basChk.Resource
            Add-ZsManifestResource -Type 'Bastion' -Name $bastionName -ResourceId $bas.id -Properties @{ Sku=$Sku } -PreExisting:(-not (Test-ZsModuleOwned -Resource $bas))
            $drift = [System.Collections.Generic.List[string]]::new()
            $liveSku = [string](Get-ZsPropertyValue $bas 'sku.name')
            if ($liveSku -ne $Sku) { $drift.Add("SKU $liveSku") }
            foreach ($k in @('scaleUnits','enableTunneling','enableIpConnect','enableShareableLink','enableFileCopy','enableKerberos')) {
                $v = Get-ZsPropertyValue $bas "properties.$k"
                # ARM can leave a false setting out of the response.
                if ($null -eq $v -and $wantProps[$k] -is [bool]) { $v = $false }
                if ("$v" -ne "$($wantProps[$k])") { $drift.Add("$k=$v") }
            }
            if ($drift.Count -eq 0) {
                Write-ZsLog "Bastion $bastionName verified ($Sku$(if (-not $public) { ', private-only' }))"
            } elseif (-not (Test-ZsModuleOwned -Resource $bas)) {
                Write-ZsLog "Bastion $bastionName differs from this module's settings ($($drift -join '; ')) but is not this deployment's; left as it is." -Level WARN
            } elseif ($PSCmdlet.ShouldProcess($bastionName, "Reconcile Bastion settings ($($drift -join '; '))")) {
                try {
                    Invoke-ArmPut -AsyncTimeoutSeconds 2400 -Uri $basUri -Body @{ location=$bas.location; tags=$tags; sku=@{ name=$Sku }; properties=$wantProps } | Out-Null
                    $bas = Wait-ArmProvision -Uri $basUri -Label $bastionName -TimeoutSeconds 2400
                    Write-ZsLog "Bastion $bastionName reconciled: $($drift -join '; ')"
                } catch {
                    Write-ZsLog "Could not reconcile Bastion $bastionName ($($drift -join '; ')): $($_.Exception.Message). A SKU can be raised in place but not lowered." -Level WARN
                }
            }
        } elseif ($PSCmdlet.ShouldProcess($bastionName, "Create Azure Bastion ($Sku$(if (-not $public) { ', private-only' }))")) {
            # Bastion is the slowest create in the deployment: ten minutes is a good day and
            # twenty-five is normal. The PUT's async poll gets the same budget as the resource
            # wait below, or it times out first and the longer wait never runs.
            Invoke-ArmPut -AsyncTimeoutSeconds 2400 -Uri $basUri -Body @{
                location=$loc; tags=$tags
                sku=@{ name=$Sku }
                properties=$wantProps
            } | Out-Null
            $bas = Wait-ArmProvision -Uri $basUri -Label $bastionName -TimeoutSeconds 2400
            Add-ZsManifestResource -Type 'Bastion' -Name $bastionName -ResourceId $bas.id -Properties @{ Sku=$Sku; ScaleUnits=$ScaleUnits; PrivateOnly=(-not $public) }
        } else { return }

        Add-ZsManifestOutput -Key 'BastionName' -Value $bastionName
        $pipAddress = [string](Get-ZsPropertyValue $pip 'properties.ipAddress')
        if ($public) {
            Write-ZsLog "Bastion $bastionName ready ($Sku, $ScaleUnits scale units, public IP $pipAddress)"
        } else {
            Write-ZsLog "Bastion $bastionName ready ($Sku, private-only, $ScaleUnits scale units): reach it over ExpressRoute, VPN or peering with 'az network bastion ssh'"
        }

        return [PSCustomObject]@{ BastionName=$bastionName; BastionId=$bas.id; Sku=$Sku; PrivateOnly=(-not $public); PublicIp=$pipAddress }
    }
}
