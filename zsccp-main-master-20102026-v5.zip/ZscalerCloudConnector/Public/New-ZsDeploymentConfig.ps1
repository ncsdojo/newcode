<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (New-ZsDeploymentConfig).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function New-ZsDeploymentConfig {
    <#
    .SYNOPSIS Builds a deployment configuration object. Interactive mode prompts for brownfield resource IDs.
    .PARAMETER Mode Greenfield creates all resources. Brownfield reuses existing infrastructure.
    .PARAMETER ConfigFile Path to a JSON config file. Overrides interactive prompts.
    .EXAMPLE
    $cfg = New-ZsDeploymentConfig -Mode Greenfield
    Builds a greenfield configuration object with the default network plan.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([hashtable])]
    param(
        [ValidateSet('Greenfield','Brownfield')][string]$Mode = 'Greenfield',
        [string]$ConfigFile = '', [switch]$Interactive
    )

    if ($ConfigFile) {
        # .NET resolves relative paths against the process CWD, not PS location.
        $resolved = $PSCmdlet.GetUnresolvedProviderPathFromPSPath($ConfigFile)
        if (-not (Test-Path -LiteralPath $resolved)) {
            Write-ZsError -Message "Config file not found: $ConfigFile (looked at $resolved)." -ErrorId 'ZsConfigNotFound' -Category 'ObjectNotFound' -Cmdlet $PSCmdlet
        }
        Write-ZsLog "Loading config: $resolved"
        return ([System.IO.File]::ReadAllText($resolved) | ConvertFrom-Json -AsHashtable)
    }

    $cfg = [ordered]@{
        Mode='Greenfield'; VnetAddressSpace='10.1.0.0/16'
        # Blank CIDR = unset. The deployment exits naming all missing subnets.
        # One shared management and one shared service subnet for every zone's connectors:
        # StandardV2 NAT is zone-redundant, so the per-zone subnet split no longer exists.
        # Size each for the whole fleet's ceiling, not one zone's.
        MgmtSubnetCidr=''; ServiceSubnetCidr=''
        WorkloadSubnetCidr=''; LbSubnetCidr=''; FuncAppSubnetCidr=''
        BastionSubnetCidr=''
        DnsInboundCidr=''; DnsOutboundCidr=''
        NoBastion=$false
        IdentityRoleMode='LeastPrivilege'
        VmSize='Standard_D2s_v3'; CcCount=2; Zones=@('1','2')
        HttpProbePort=50000; EnableSupportTunnel=$false; EnableZpa=$false
        SshSourceCidr='VirtualNetwork'; WorkloadCidrs=@(); SpokeVnetIds=@()
        # Every port out of the service subnet, for a forwarding policy that sends traffic DIRECT on
        # ports the service NSG does not otherwise allow.
        ServiceAllowAllOutbound=$false
        # Remote-support server for EnableSupportTunnel (remotesupport.<cloud>.net). The default
        # is the commercial cloud's.
        SupportServerIp=$script:ZsSupportServerIp
        # Premium is private-only, with no public IP. Standard and Basic need one.
        BastionSku='Premium'; BastionClientSourceAddressPrefix=''
        # The NAT gateway's egress address: ip (a StandardV2 public IP) or prefix (a StandardV2
        # public IP prefix), created here unless NatExistingPublicIpId names one.
        NatPublicIpMode='ip'; NatExistingPublicIpId=''; NatPublicIpPrefixLength=31
        # Zscaler's published lifecycle package, pinned to its 1.0.3 commit. Empty zip-deploys the
        # copy in FunctionApp/vendor through the app's private endpoint, from inside the network.
        FunctionPackageUrl=$script:ZsVendorPackageUrl
        # Role the lifecycle function gets on the resource group to replace unhealthy connectors.
        RemediationRoleName='Virtual Machine Contributor'
        # True defines a custom role with exactly what replacing a connector needs, in place of it.
        CreateRemediationRole=$false
        LegacyVmNvaTag=$true
        BringYourOwn=[ordered]@{
            ResourceGroupName=''
            # Name-based references, matching the Terraform variables one for one:
            # vnet_name / vnet_resource_group_name / network_subscription_id and the
            # *_subnet_name set. VnetResourceGroupName defaults to the deployment group;
            # VnetSubscriptionId defaults to the session's subscription. Subnets keep the
            # names their owners gave them — no snet-zscc-* convention is expected.
            VnetName=''; VnetResourceGroupName=''; VnetSubscriptionId=''
            MgmtSubnetName=''; ServiceSubnetName=''; WorkloadSubnetName=''; LbSubnetName=''
            # Optional: an existing Function App subnet (delegated to Microsoft.Web/serverFarms).
            # Left blank, the module creates snet-zscc-funcapp from FuncAppSubnetCidr instead.
            FuncAppSubnetName=''
            # Resource-ID references, kept for existing configs. A name and an ID for the same
            # thing must agree; either alone is enough.
            VnetId=''; WorkloadSubnetId=''; LbSubnetId=''
            MgmtSubnetId=''; ServiceSubnetId=''; FuncAppSubnetId=''
            # Optional: reuse your own NSGs. Left blank, the module creates its hardened pair and
            # associates them onto the existing subnets, as the Terraform nsg module does.
            MgmtNsgId=''; ServiceNsgId=''
            # The Function App subnet's NSG: the module's own unless one is named here, or none
            # from the module at all with AttachFuncAppNsg false (the platform team attaches theirs,
            # which must allow HTTPS, HTTP and DNS out). AttachBastionNsg likewise for AzureBastionSubnet.
            FuncAppNsgId=''; AttachFuncAppNsg=$true; AttachBastionNsg=$true
            # Terraform's attach_nat_gateway. False creates no NAT gateway, for subnets that already
            # leave through the platform's egress; its public address is then the one to allowlist.
            AttachNatGateway=$true
            # The platform's privatelink zones, in a hub-and-spoke network. Set, the private
            # endpoints register there and no zone is created or linked by the deployment.
            PrivateDnsZoneResourceGroupName=''; PrivateDnsZoneSubscriptionId=''
            # Grant the lifecycle function its remediation role on the connector subnets too, which
            # replacing a connector needs when the VNet is in another resource group. False leaves
            # that grant to the platform team.
            GrantFunctionSubnetJoin=$true
        }
    }
    $cfg.Mode = $Mode

    if (-not $Interactive) {
        if ($Mode -eq 'Brownfield') { Write-ZsError -Message 'Brownfield mode needs a configuration. Pass -ConfigFile with your resource IDs, or use -Interactive.' -ErrorId 'ZsBrownfieldNeedsConfig' -Cmdlet $PSCmdlet }
        return $cfg
    }

    $v = Read-Host "CC count [2]"; if ($v) { $cfg.CcCount = [int]$v }
    $v = Read-Host "VM size [Standard_D2s_v3]"; if ($v) { $cfg.VmSize = $v }
    $v = Read-Host "Zones (comma-sep) [1,2]"; if ($v) { $cfg.Zones = $v -split ',' | ForEach-Object { $_.Trim() } }
    $v = Read-Host "HTTP probe port [50000]"; if ($v) { $cfg.HttpProbePort = [int]$v }
    $cfg.EnableSupportTunnel = (Read-Host "Support tunnel? (y/n) [n]") -match '^[yY]'
    $cfg.EnableZpa = (Read-Host "ZPA DNS Resolver? (y/n) [n]") -match '^[yY]'
    $cfg.NoBastion = (Read-Host "Skip Azure Bastion? (y/n) [n]") -match '^[yY]'
    $v = Read-Host "SSH source CIDR [VirtualNetwork]"; if ($v) { $cfg.SshSourceCidr = $v }

    # Mandatory subnet CIDRs.
    $v = Read-Host "VNet address space [$($cfg.VnetAddressSpace)]"; if ($v) { $cfg.VnetAddressSpace = $v }
    # Shared connector subnets, sized for every zone's connectors together.
    $v = Read-Host "Management subnet CIDR (required, shared across zones, /28 or larger)"; if ($v) { $cfg.MgmtSubnetCidr = $v }
    $v = Read-Host "Service subnet CIDR (required, shared across zones, /28 or larger)";    if ($v) { $cfg.ServiceSubnetCidr = $v }
    $v = Read-Host "Workload subnet CIDR (required)";    if ($v) { $cfg.WorkloadSubnetCidr = $v }
    $v = Read-Host "Load balancer subnet CIDR (required)"; if ($v) { $cfg.LbSubnetCidr = $v }
    if (-not $cfg.NoBastion) { $v = Read-Host "AzureBastionSubnet CIDR (required, /26 or larger)"; if ($v) { $cfg.BastionSubnetCidr = $v } }
    if ($cfg.EnableZpa) {
        $v = Read-Host "DNS inbound subnet CIDR (required for ZPA, /28)";  if ($v) { $cfg.DnsInboundCidr = $v }
        $v = Read-Host "DNS outbound subnet CIDR (required for ZPA, /28)"; if ($v) { $cfg.DnsOutboundCidr = $v }
    }

    if ($Mode -eq 'Brownfield') {
        Write-Information "`n--- Existing Resources (blank = create new) ---" -InformationAction Continue
        $byo = $cfg.BringYourOwn
        $byo.ResourceGroupName = Read-Host 'Resource Group name (pre-created; everything deploys into it)'
        # Names first, the way the Terraform variables ask: VNet by name and group, subnets by
        # their own names inside it. An operator holding resource IDs instead can leave the name
        # blank and paste the VNet ID; the per-role subnet IDs are then collected.
        $byo.VnetName = Read-Host 'Existing VNet name (blank to paste resource IDs instead, or to create a new VNet)'
        if ($byo.VnetName) {
            $byo.VnetResourceGroupName = Read-Host "  VNet resource group [$($byo.ResourceGroupName)]"
            $byo.VnetSubscriptionId    = Read-Host '  VNet subscription ID (blank = this session''s)'
            $byo.MgmtSubnetName     = Read-Host '  Management subnet name'
            $byo.ServiceSubnetName  = Read-Host '  Service subnet name'
            $byo.WorkloadSubnetName = Read-Host '  Workload subnet name'
            $byo.LbSubnetName       = Read-Host '  Load balancer subnet name'
            $byo.FuncAppSubnetName  = Read-Host '  Function App subnet name (delegated to Microsoft.Web/serverFarms; blank = module creates snet-zscc-funcapp from FuncAppSubnetCidr)'
            $byo.MgmtNsgId          = Read-Host '  Management NSG ID (blank = module creates and attaches its own)'
            $byo.ServiceNsgId       = Read-Host '  Service NSG ID (blank = module creates and attaches its own)'
        } else {
            $byo.VnetId = Read-Host 'VNet resource ID'
            if ($byo.VnetId) {
                $byo.MgmtSubnetId    = Read-Host '  Shared management subnet ID'
                $byo.ServiceSubnetId = Read-Host '  Shared service subnet ID'
                $byo.WorkloadSubnetId = Read-Host '  Workload subnet ID'; $byo.LbSubnetId = Read-Host '  LB subnet ID'
                $byo.FuncAppSubnetId = Read-Host '  Function App subnet ID (blank = module creates snet-zscc-funcapp from FuncAppSubnetCidr)'
                $byo.MgmtNsgId       = Read-Host '  Management NSG ID (blank = module creates and attaches its own)'
                $byo.ServiceNsgId    = Read-Host '  Service NSG ID (blank = module creates and attaches its own)'
            }
        }
        $v = Read-Host 'Workload CIDRs for NSG (comma-sep)'; if ($v) { $cfg.WorkloadCidrs = $v -split ',' | ForEach-Object { $_.Trim() } }
        $v = Read-Host 'Spoke VNet IDs for peering (comma-sep)'; if ($v) { $cfg.SpokeVnetIds = $v -split ',' | ForEach-Object { $_.Trim() } }
        $cfg.BringYourOwn = $byo
    }

    $save = Read-Host "`nSave config to file? (path, directory, or blank)"
    if ($save) {
        $resolved = Resolve-ZsOutputFile -Path $save -DefaultFileName 'zscc-config.json'
        [System.IO.File]::WriteAllText($resolved, ($cfg | ConvertTo-Json -Depth 5))
        Write-Information "Saved: $resolved" -InformationAction Continue
    }
    return $cfg
}

function Export-ZsDeploymentConfig {
    <#
    .SYNOPSIS Writes a template config JSON to disk for offline editing.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([string])]
    param(
        [string]$Path = '',
        [ValidateSet('Greenfield','Brownfield')][string]$Mode = 'Greenfield',
        [string]$FileName = 'zscc-config.json'
    )
    $cfg = New-ZsDeploymentConfig -Mode $Mode
    $resolved = Resolve-ZsOutputFile -Path $Path -DefaultFileName $FileName
    [System.IO.File]::WriteAllText($resolved, ($cfg | ConvertTo-Json -Depth 5))
    Write-ZsLog "Template config written: $resolved"
    return $resolved
}
