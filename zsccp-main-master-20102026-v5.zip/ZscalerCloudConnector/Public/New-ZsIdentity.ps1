<#
.SYNOPSIS
    Creates the user-assigned managed identity for the Cloud Connectors and assigns its role.

.DESCRIPTION
    Creates a user-assigned managed identity and, by default, grants it a least-privilege custom role
    containing only the network read actions the connector needs to discover its interfaces at boot.
    The role behaviour is selectable, and role assignment can be skipped entirely for environments where
    an administrator assigns the role out of band (so the deploying service principal needs no
    authorization-write permission).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function New-ZsIdentity {
    <#
    .SYNOPSIS Creates the user-assigned managed identity and assigns its role.
    .DESCRIPTION By default assigns a least-privilege custom role (network read actions only). Set
        -RoleMode to choose the broad built-in Network Contributor instead, or None to create the
        identity without any assignment. -SkipRoleAssignment is equivalent to RoleMode None and is the
        path to use when an administrator assigns the role separately; in that case the deploying service
        principal does not need Microsoft.Authorization/roleAssignments/write.
    .PARAMETER IdentityName Optional explicit name; generated if omitted.
    .PARAMETER RoleScope Scope for the role assignment. Defaults to the resource group.
    .PARAMETER RoleMode LeastPrivilege (default), NetworkContributor, or None.
    .PARAMETER SkipRoleAssignment Create the identity but assign no role. Same effect as RoleMode None.
    .OUTPUTS PSCustomObject with the identity name, resource ID, principal ID, client ID and role mode.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    .EXAMPLE
    New-ZsIdentity -RoleMode LeastPrivilege
    Creates the connector managed identity and assigns it a least-privilege custom network-read role.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [string]$IdentityName = '',
        [string]$RoleScope = '',
        [ValidateSet('LeastPrivilege','NetworkContributor','None')][string]$RoleMode = 'LeastPrivilege',
        [switch]$SkipRoleAssignment
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $env=$script:ZsSession.Environment; $loc=$script:ZsSession.Location; $tags=Get-ZsTags; $rgPath=Get-ZsRgPath
        if (-not $IdentityName) { $IdentityName = New-ZsResourceName -Prefix 'id-zscc' -Environment $env -Location $loc }
        if (-not $RoleScope)    { $RoleScope = $rgPath }
        if ($SkipRoleAssignment) { $RoleMode = 'None' }

        $idPath="$rgPath/providers/Microsoft.ManagedIdentity/userAssignedIdentities/$IdentityName"
        $idUri ="$idPath`?api-version=$($script:ApiVersions.Identity)"
        $check  = Test-ArmResource -Uri $idUri
        if ($check.Exists) {
            $id = $check.Resource; Write-ZsLog "Identity $IdentityName verified"
            Add-ZsManifestResource -Type 'ManagedIdentity' -Name $IdentityName -ResourceId $id.id -Properties @{ PrincipalId=$id.properties.principalId } -PreExisting:(-not (Test-ZsModuleOwned -Resource $id))
        } elseif ($PSCmdlet.ShouldProcess($IdentityName, 'Create managed identity')) {
            Invoke-ArmPut -Uri $idUri -Body @{ location=$loc; tags=$tags } | Out-Null
            Start-Sleep -Seconds 20
            $id = Invoke-ArmGet -Uri $idUri
            Add-ZsManifestResource -Type 'ManagedIdentity' -Name $IdentityName -ResourceId $id.id -Properties @{ PrincipalId=$id.properties.principalId }
        } else { return [PSCustomObject]@{ IdentityName=$IdentityName; IdentityId='(identity created at deploy time)'; PrincipalId='(whatif)'; ClientId='(whatif)'; RoleMode=$RoleMode } }

        $pid2 = $id.properties.principalId

        if ($RoleMode -eq 'None') {
            Write-ZsLog "Role assignment skipped; assign a role to principal $pid2 out of band before deploying connectors" -Level WARN
        } else {
            $roleDefId = Resolve-ZsCcRoleDefinitionId -RoleMode $RoleMode
            Set-ZsRoleAssignment -Scope $RoleScope -RoleDefinitionId $roleDefId -PrincipalId $pid2
            if (-not $WhatIfPreference) { Write-ZsLog "Identity $IdentityName holds its $RoleMode role" }
            # Publishing smedge_metrics, the metric autoscale scales on, is the data action
            # Microsoft.Insights/Metrics/Write. The least-privilege custom role carries it;
            # Network Contributor does not - whether asked for, or the fallback when custom
            # roles are refused - and without it autoscale never acts. Monitoring Metrics
            # Publisher, as the Terraform identity module grants, closes that gap.
            if (($roleDefId -split '/')[-1] -eq $script:Roles.NetworkContributor) {
                Set-ZsRoleAssignment -Scope $RoleScope -PrincipalId $pid2 `
                    -RoleDefinitionId "$(Get-ZsSubscriptionPath)/providers/Microsoft.Authorization/roleDefinitions/$($script:Roles.MonitoringMetricsPublisher)"
                if (-not $WhatIfPreference) { Write-ZsLog "Identity $IdentityName holds Monitoring Metrics Publisher, so the connectors can publish the autoscale metric" }
            }
            Start-Sleep -Seconds 15
        }

        return [PSCustomObject]@{ IdentityName=$IdentityName; IdentityId=$id.id; PrincipalId=$pid2; ClientId=$id.properties.clientId; RoleMode=$RoleMode }
    }
}

function Resolve-ZsCcRoleDefinitionId {
    <#
    .SYNOPSIS Returns the role definition ID to assign to the CC identity, creating a custom role if needed.
    .DESCRIPTION For NetworkContributor, returns the built-in role definition ID. For LeastPrivilege,
        ensures a custom role definition containing only the connector's required network read actions
        exists at the subscription scope, creating it idempotently, and returns its ID.
    .PARAMETER RoleMode LeastPrivilege or NetworkContributor.
    .OUTPUTS [string] Fully qualified role definition resource ID.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)][ValidateSet('LeastPrivilege','NetworkContributor')][string]$RoleMode
    )

    $subPath = Get-ZsSubscriptionPath
    if ($RoleMode -eq 'NetworkContributor') {
        return "$subPath/providers/Microsoft.Authorization/roleDefinitions/$($script:Roles.NetworkContributor)"
    }

    # LeastPrivilege: deterministic GUID so the role is idempotent, at the scope the deployment's
    # mode allows. Greenfield writes it at the subscription; brownfield writes it at the resource
    # group, where a group-scoped deployer's roleDefinitions/write actually reaches.
    $roleName  = 'ZSCC Connector Network Reader'
    $roleScope = Resolve-ZsRoleDefinitionScope -RoleName $roleName
    $roleGuid  = $roleScope.Guid
    $roleUri   = "$($roleScope.ResourceId)`?api-version=$($script:ApiVersions.Authorization)"

    # A policy denial earlier in this run means this PUT gets the same 403; skip straight to
    # the built-in fallback rather than reproducing the refusal.
    if ($script:ZsCustomRoleDenial) {
        Write-ZsLog ("Custom role creation is denied in this environment ($script:ZsCustomRoleDenial); " +
            "assigning built-in Network Contributor to the connector identity instead. Least privilege " +
            "requires a policy exemption for this deployment's custom roles.") -Level WARN
        return "$subPath/providers/Microsoft.Authorization/roleDefinitions/$($script:Roles.NetworkContributor)"
    }

    $existing = Test-ArmResource -Uri $roleUri
    # A role-definition PUT at a fixed GUID is an upsert, so re-runs bring the permission set of
    # an existing deployment's role to this one's (e.g. adding Metrics/Write for autoscale
    # telemetry) instead of freezing it at first create.
    $roleBody = @{
        properties = @{
            roleName    = $roleName
            description = 'Network read actions and Azure Monitor metric publishing required by Zscaler Cloud Connector instances.'
            type        = 'CustomRole'
            permissions = @(@{ actions = $script:CcIdentityActions; notActions = @(); dataActions = $script:CcIdentityDataActions; notDataActions = @() })
            assignableScopes = @($roleScope.Scope)
        }
    }
    if ($existing.Exists) {
        if (Test-ZsRoleDefinitionCurrent -Definition $existing.Resource -Actions $script:CcIdentityActions `
                -DataActions $script:CcIdentityDataActions -AssignableScopes @($roleScope.Scope)) {
            Write-ZsLog "Least-privilege custom role '$roleName' verified"
        } elseif ($PSCmdlet.ShouldProcess($roleName, 'Reconcile custom role permissions')) {
            # Reconcile is best-effort: deployers whose roleDefinitions/write was revoked
            # after first deploy should not have every subsequent run blocked by it.
            try {
                Invoke-ArmPut -Uri $roleUri -Body $roleBody | Out-Null
                Write-ZsLog "Reconciled least-privilege custom role '$roleName'"
            } catch {
                $cls = Resolve-ZsArmFailure -ErrorRecord $_
                if ($cls.Kind -eq 'Policy') { $script:ZsCustomRoleDenial = $cls.Summary }
                $why = switch ($cls.Kind) {
                    'Policy'     { $cls.Summary + '; the existing definition stays in force unmodified' }
                    'Permission' { 'the deployer lacks Microsoft.Authorization/roleDefinitions/write' }
                    default      { $cls.Summary }
                }
                Write-ZsLog ("Could not reconcile custom role '$roleName': $why. Verify the role definition " +
                    "includes dataAction Microsoft.Insights/Metrics/Write, or VMSS autoscale telemetry will not flow.") -Level WARN
            }
        }
    } elseif ($PSCmdlet.ShouldProcess($roleName, 'Create least-privilege custom role')) {
        Write-ZsLog "Creating least-privilege custom role '$roleName'"
        try {
            Invoke-ArmPut -Uri $roleUri -Body $roleBody | Out-Null
        } catch {
            # This create previously had no handler at all: an environment whose Azure Policy
            # denies custom role creation (RequestDisallowedByPolicy) killed the whole deployment
            # here, before anything else was even attempted. Policy and permission refusals now
            # fall back to the built-in Network Contributor role - the module's own alternate
            # RoleMode - which every Zscaler reference deployment runs on. Anything else is a
            # real failure and still throws.
            $cls = Resolve-ZsArmFailure -ErrorRecord $_
            if ($cls.Kind -in @('Policy','Permission')) {
                if ($cls.Kind -eq 'Policy') { $script:ZsCustomRoleDenial = $cls.Summary }
                $why = if ($cls.Kind -eq 'Policy') { $cls.Summary } else { 'the deployer lacks Microsoft.Authorization/roleDefinitions/write' }
                Write-ZsLog ("Could not create the least-privilege custom role '$roleName': $why. " +
                    "Falling back to the built-in Network Contributor role for the connector identity. " +
                    "For least privilege, have the platform team exempt this deployment's custom roles " +
                    "or grant roleDefinitions/write, then re-run.") -Level WARN
                return "$subPath/providers/Microsoft.Authorization/roleDefinitions/$($script:Roles.NetworkContributor)"
            }
            throw
        }
        Start-Sleep -Seconds 10
        # Recorded so teardown can remove it once nothing is assigned to it any more. Only a role
        # this run created is recorded; one that was already there is left to whoever made it.
        Add-ZsManifestResource -Type 'RoleDefinition' -Name $roleName -ResourceId $roleScope.ResourceId
    }
    return $roleScope.ResourceId
}
