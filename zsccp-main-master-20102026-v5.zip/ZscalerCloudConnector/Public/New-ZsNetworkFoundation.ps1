<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (New-ZsNetworkFoundation).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

<#
.SYNOPSIS
    Creates the virtual network and all subnets from an explicitly supplied, pre-validated subnet plan.

.DESCRIPTION
    Provisions the VNet with the management, service, workload, and load balancer subnets, plus the
    AzureBastionSubnet when Bastion is enabled and the delegated DNS resolver subnets when ZPA is enabled.
    Subnet CIDRs are supplied by the caller as a validated plan (see Resolve-ZsSubnetPlan); this function
    does not derive, default, or carve any address space. Idempotent: an existing, successfully provisioned
    VNet of the same name is reused.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function New-ZsNetworkFoundation {
    <#
    .SYNOPSIS Creates the VNet and all subnets from an explicit, validated subnet plan.
    .PARAMETER AddressSpace VNet CIDR, such as 10.157.108.0/23. New-ZsDeployment checks it against the subnet plan as well.
    .PARAMETER SubnetPlan PSCustomObject mapping each required subnet name to its validated CIDR.
    .PARAMETER MgmtNsgId Resource ID of the management NSG, bound to the shared management subnet.
    .PARAMETER ServiceNsgId Resource ID of the service NSG, bound to the shared service subnet.
    .PARAMETER FuncAppNsgId Resource ID of the Function App subnet's NSG. Optional.
    .PARAMETER EnableBastion Create the AzureBastionSubnet from the plan.
    .PARAMETER ServiceEndpoints Service endpoints for the Function App subnet. None by default.
    .PARAMETER VnetName Optional explicit VNet name; generated if omitted.
    .OUTPUTS PSCustomObject with VnetName, VnetId, VnetPath, AddressSpace, SubnetPlan, and Subnets map.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    .EXAMPLE
    New-ZsNetworkFoundation -AddressSpace 10.157.108.0/23 -SubnetPlan $plan -MgmtNsgId $nsgs.MgmtNsgId -ServiceNsgId $nsgs.ServiceNsgId
    Creates the VNet and the subnets in the plan, with the connector NSGs bound to their subnets.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][ValidateScript({ Test-ZsCidr -Cidr $_ })][string]$AddressSpace,
        [Parameter(Mandatory)][ValidateNotNull()][PSCustomObject]$SubnetPlan,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$MgmtNsgId,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$ServiceNsgId,
        # The Function App subnet's NSG, bound to snet-zscc-funcapp. Empty leaves that subnet bare.
        [string]$FuncAppNsgId = '',
        [switch]$EnableBastion,
        # Service endpoints for snet-zscc-funcapp. None by default: the function storage account
        # has public network access disabled, and the app reaches it through private endpoints.
        [hashtable[]]$ServiceEndpoints = @(),
        [string]$VnetName = ''
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $loc = $script:ZsSession.Location; $tags = Get-ZsTags; $rgPath = Get-ZsRgPath; $api = $script:ApiVersions.Network
        if (-not $VnetName) { $VnetName = New-ZsResourceName -Prefix 'vnet-zscc' -Environment $script:ZsSession.Environment -Location $loc }

        $vnetPath = "$rgPath/providers/Microsoft.Network/virtualNetworks/$VnetName"
        $vnetUri  = "$vnetPath`?api-version=$api"
        $check    = Test-ArmResource -Uri $vnetUri
        if ($check.Exists -and $check.State -eq 'Succeeded') {
            Write-ZsLog "VNet $VnetName verified"
            $vnet = $check.Resource
            $vnetOwned = Test-ZsModuleOwned -Resource $vnet
            Add-ZsManifestResource -Type 'VNet' -Name $VnetName -ResourceId $vnet.id -Properties @{ AddressSpace=$AddressSpace } -PreExisting:(-not $vnetOwned)
            # On reuse, the plan's subnets already exist (a re-run of this module, or a network
            # brought to it). Record each so teardown can delete them explicitly before the NAT
            # gateway, route tables and NSGs they reference. Subnets carry no tags of their own,
            # so ownership follows the network that contains them: subnets in a network this
            # module created are this module's; subnets in a brought network are recorded
            # PreExisting only if the plan finds them already present - which here it has.
            foreach ($snName in @($SubnetPlan.PSObject.Properties.Name)) {
                $live = $vnet.properties.subnets | Where-Object { $_.name -eq $snName } | Select-Object -First 1
                if ($live) {
                    Add-ZsManifestResource -Type 'Subnet' -Name $snName -ResourceId $live.id -PreExisting:(-not $vnetOwned)
                }
            }

            # On reuse the subnets are brought to the shape a fresh create gives them: the chosen
            # NSG on each, endpoint network policies off where the private endpoints sit, and any
            # service endpoints asked for on the Function App subnet. The Microsoft.Storage endpoint
            # 5.4.1.0 put there is left for the Function App step, which removes it once the storage
            # account's private endpoints are in place: until then the host reaches its queues and
            # tables through it. Only a network this module created is reshaped; a brought one keeps
            # its owner's settings.
            if ($vnetOwned) {
                $nsgFor = @{ 'snet-zscc-mgmt' = $MgmtNsgId; 'snet-zscc-service' = $ServiceNsgId }
                if ($FuncAppNsgId) { $nsgFor['snet-zscc-funcapp'] = $FuncAppNsgId }
                foreach ($snName in @($nsgFor.Keys | Sort-Object)) {
                    $liveSub = $vnet.properties.subnets | Where-Object { $_.name -eq $snName } | Select-Object -First 1
                    if (-not $liveSub -or -not $nsgFor[$snName] -or $nsgFor[$snName] -match '^\(') { continue }
                    Set-ZsSubnetNsgAssociation -SubnetId $liveSub.id -NsgId $nsgFor[$snName] -Label $snName | Out-Null
                }

                $mgmtLive = $vnet.properties.subnets | Where-Object { $_.name -eq 'snet-zscc-mgmt' } | Select-Object -First 1
                if ($mgmtLive) {
                    $pePolicy = [string](Get-ZsPropertyValue $mgmtLive 'properties.privateEndpointNetworkPolicies')
                    if ($pePolicy -ne 'Disabled' -and $PSCmdlet.ShouldProcess('snet-zscc-mgmt', 'Disable private endpoint network policies')) {
                        $mUri = "$vnetPath/subnets/snet-zscc-mgmt`?api-version=$api"
                        $mLive = Invoke-ArmGet -Uri $mUri
                        $mLive.properties | Add-Member -NotePropertyName 'privateEndpointNetworkPolicies' -NotePropertyValue 'Disabled' -Force
                        Invoke-ArmPut -Uri $mUri -Body @{ properties = $mLive.properties } | Out-Null
                        Wait-ArmProvision -Uri $mUri -Label 'snet-zscc-mgmt (endpoint policies)' | Out-Null
                        Write-ZsLog 'Private endpoint network policies disabled on snet-zscc-mgmt'
                    }
                }

                $faLive = $vnet.properties.subnets | Where-Object { $_.name -eq 'snet-zscc-funcapp' } | Select-Object -First 1
                $wantSvc = @($ServiceEndpoints | ForEach-Object { [string]$_.service } | Where-Object { $_ })
                if ($faLive -and $wantSvc.Count -gt 0) {
                    Add-ZsSubnetServiceEndpoint -SubnetId $faLive.id -Services $wantSvc -Label 'snet-zscc-funcapp' | Out-Null
                }
                $vnet = Invoke-ArmGet -Uri $vnetUri
            }
        } elseif ($PSCmdlet.ShouldProcess($VnetName, 'Create VNet')) {
            $subnetDefs = [System.Collections.Generic.List[object]]::new()
            if ($EnableBastion) {
                $subnetDefs.Add(@{ name='AzureBastionSubnet'; properties=@{ addressPrefix=$SubnetPlan.'AzureBastionSubnet' } })
            }
            # One management and one service subnet shared by every zone: subnets are regional,
            # the NAT gateway is zone-redundant StandardV2, and zonal resilience is the compute's
            # and the load balancer's job, not the subnet layout's.
            # The Key Vault, storage and optional Function App private endpoints sit in the
            # management subnet, so endpoint network policies are off there, as in Terraform.
            $subnetDefs.Add(@{ name='snet-zscc-mgmt';    properties=@{ addressPrefix=$SubnetPlan.'snet-zscc-mgmt';    networkSecurityGroup=@{ id=$MgmtNsgId }; privateEndpointNetworkPolicies='Disabled' } })
            $subnetDefs.Add(@{ name='snet-zscc-service'; properties=@{ addressPrefix=$SubnetPlan.'snet-zscc-service'; networkSecurityGroup=@{ id=$ServiceNsgId } } })
            $subnetDefs.Add(@{ name='snet-zscc-workload';properties=@{ addressPrefix=$SubnetPlan.'snet-zscc-workload' } })
            $subnetDefs.Add(@{ name='snet-zscc-lb';      properties=@{ addressPrefix=$SubnetPlan.'snet-zscc-lb' } })
            if ($SubnetPlan.'snet-zscc-funcapp') {
                $faSubProps = @{
                    addressPrefix=$SubnetPlan.'snet-zscc-funcapp'
                    delegations=@(@{name='Microsoft.Web.serverFarms';properties=@{serviceName='Microsoft.Web/serverFarms'}})
                }
                if ($ServiceEndpoints.Count -gt 0) { $faSubProps.serviceEndpoints = $ServiceEndpoints }
                if ($FuncAppNsgId -and $FuncAppNsgId -notmatch '^\(') { $faSubProps.networkSecurityGroup = @{ id=$FuncAppNsgId } }
                $subnetDefs.Add(@{ name='snet-zscc-funcapp'; properties=$faSubProps })
            }

            $body = @{ location=$loc; tags=$tags; properties=@{ addressSpace=@{ addressPrefixes=@($AddressSpace) }; subnets=$subnetDefs } }
            Invoke-ArmPut -Uri $vnetUri -Body $body | Out-Null
            $vnet = Wait-ArmProvision -Uri $vnetUri -Label $VnetName
            Add-ZsManifestResource -Type 'VNet' -Name $VnetName -ResourceId $vnet.id -Properties @{ AddressSpace=$AddressSpace }
            # Each subnet is recorded individually. Teardown deletes subnets explicitly, one by
            # one, before the reference-holding resources (NAT gateway, route tables, NSGs),
            # because deleting the subnet is what clears its references to them - and it is the
            # one order that works identically whether the network itself is deleted (here) or
            # kept (brownfield reuse of someone else's network).
            foreach ($sd in $subnetDefs) {
                Add-ZsManifestResource -Type 'Subnet' -Name $sd.name -ResourceId "$vnetPath/subnets/$($sd.name)"
            }
        } else {
            $ph = @{}
            $phNames = [System.Collections.Generic.List[string]]::new()
            if ($EnableBastion) { $phNames.Add('AzureBastionSubnet') }
            $phNames.Add('snet-zscc-mgmt'); $phNames.Add('snet-zscc-service')
            $phNames.Add('snet-zscc-workload'); $phNames.Add('snet-zscc-lb')
            if ($SubnetPlan.'snet-zscc-funcapp') { $phNames.Add('snet-zscc-funcapp') }
            foreach ($sp in $phNames) {
                $cidr = $SubnetPlan.$sp
                if ($cidr) { $ph[$sp] = "(subnet $sp at $cidr, created at deploy time)" }
            }
            return [PSCustomObject]@{
                VnetName=$VnetName; VnetId='(vnet created at deploy time)'; VnetPath=$vnetPath; AddressSpace=$AddressSpace
                SubnetPlan=$SubnetPlan; Subnets=$ph
            }
        }

        $subnets = @{}; foreach ($s in $vnet.properties.subnets) { $subnets[$s.name] = $s.id }
        return [PSCustomObject]@{
            VnetName=$VnetName; VnetId=$vnet.id; VnetPath=$vnetPath; AddressSpace=$AddressSpace
            SubnetPlan=$SubnetPlan; Subnets=$subnets
        }
    }
}
