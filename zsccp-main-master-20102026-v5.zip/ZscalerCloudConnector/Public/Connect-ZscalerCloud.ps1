<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Connect-ZscalerCloud).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Connect-ZscalerCloud {
    <#
    .SYNOPSIS Authenticates to the Zscaler Cloud & Branch Connector API (legacy key).
    .PARAMETER Cloud Zscaler cloud instance name.
    .PARAMETER ApiKey Organization API key as SecureString.
    .PARAMETER Password Admin password as SecureString.
    .EXAMPLE
    $key = Read-Host 'API key' -AsSecureString; $pass = Read-Host 'Password' -AsSecureString
    Connect-ZscalerCloud -Cloud zscaler -ApiKey $key -Username 'cc-admin@contoso.com' -Password $pass
    Authenticates to the Zscaler Cloud & Branch Connector API so provisioning URLs can be generated.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][ValidateSet('zscaler','zscalerone','zscalertwo','zscalerthree','zscloud','zscalergov')][string]$Cloud,
        [Parameter(Mandatory)][object]$ApiKey,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Username,
        [Parameter(Mandatory)][object]$Password
    )

    $ep = $script:ZscalerClouds[$Cloud]
    if (-not $script:ZsSession) { $script:ZsSession = @{} }

    # Accept both plain strings and SecureStrings for ApiKey and Password.
    $ApiKey   = ConvertTo-ZsSecureString -Value $ApiKey   -Name 'ApiKey'
    $Password = ConvertTo-ZsSecureString -Value $Password -Name 'Password'

    Write-ZsLog "Authenticating to Zscaler $Cloud (Cloud & Branch Connector API)"
    $plainKey  = ConvertFrom-ZsSecureString -Secure $ApiKey
    $plainPass = ConvertFrom-ZsSecureString -Secure $Password
    try {
        $sess = Connect-ZscalerLegacy -BaseUrl $ep.Connector -ApiKey $plainKey -Username $Username -Password $plainPass
    } catch {
        $plainKey = $null; $plainPass = $null
        $code = ''; $raw = ''; $status = 0
        try {
            try { $status = [int]$_.Exception.Response.StatusCode } catch { }
            try { $raw = $_.ErrorDetails.Message } catch { }
            if (-not $raw) {
                try { $raw = (New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())).ReadToEnd() } catch { }
            }
            if ($raw) { try { $code = (($raw | ConvertFrom-Json -ErrorAction SilentlyContinue).code) } catch { } }
        } catch { }
        $hint = switch ($code) {
            'INVALID_API_KEY'       { "The API key was rejected. Re-copy the Cloud & Branch Connector API key from the Zscaler portal (Administration, API Key Management) with no extra whitespace, confirm your org is on the '$Cloud' cloud, and check your machine clock is accurate (the key is timestamp-bound)." }
            'AUTHENTICATION_FAILED' { 'The username or password was rejected. Confirm the admin account and password, and that the account has Cloud & Branch Connector API access.' }
            'INVALID_AUTH_TYPE'     { 'This account or cloud does not accept legacy API authentication. Confirm Cloud & Branch Connector API access is enabled for the org.' }
            default                 {
                $detail = if ($raw) { $raw.Trim() } else { '(no response body)' }
                "Zscaler rejected the request. HTTP status: $(if($status){$status}else{'unknown'}). Response: $detail"
            }
        }
        Write-ZsError -Message "Zscaler authentication failed. $hint" -ErrorId "ZsAuth.$(if($code){$code}else{'Failed'})" -Category 'AuthenticationError' -Cmdlet $PSCmdlet
    }
    $plainKey = $null; $plainPass = $null
    $script:ZsSession.ZscalerAuth = 'Legacy'; $script:ZsSession.ZscalerSession = $sess

    # Credentials are held as SecureString and converted per call at the point of use,
    # not cached as plaintext for the life of the session.
    $script:ZsSession.ZscalerApiUrl     = $ep.Connector
    $script:ZsSession.ZscalerApiKeySS   = $ApiKey
    $script:ZsSession.ZscalerUsername   = $Username
    $script:ZsSession.ZscalerPasswordSS = $Password
    $script:ZsSession.ZscalerConnected  = $true
    Write-ZsLog "Zscaler $Cloud OK"

    return [PSCustomObject]@{ PSTypeName = 'ZsCloudSession'; Cloud = $Cloud; AuthType = $script:ZsSession.ZscalerAuth; Connected = $true }
}
