<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Get-ZsDeploymentManifest).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
    .PARAMETER Path Path to a saved manifest file. If omitted, returns the in-memory manifest from the active deployment.
    .PARAMETER Export Write the current manifest to disk.
    #>

function Get-ZsDeploymentManifest {
    <#
    .SYNOPSIS Returns the active deployment manifest or reads one from disk. Use -Export to write to file.
    .PARAMETER StateStorageAccount Read the manifest from the remote state blob in this storage
        account instead of local disk or memory. Requires an active Azure session.
    .EXAMPLE
    Get-ZsDeploymentManifest
    Returns the as-built manifest of every resource the current deployment created.
    .EXAMPLE
    Get-ZsDeploymentManifest -StateStorageAccount stzsccstate
    Reads the deployment state that another operator's run wrote to the shared backend.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([hashtable])]
    param(
        [string]$Path = '', [switch]$Export,
        [string]$StateStorageAccount = '', [string]$StateContainerName = 'zscc-state', [string]$StateKey = ''
    )

    if ($StateStorageAccount) {
        Assert-ZsConnected -Cmdlet $PSCmdlet
        $remote = Get-ZsRemoteState -AccountName $StateStorageAccount -ContainerName $StateContainerName -StateKey $StateKey
        if (-not $remote) { Write-ZsError -Message "No state blob found in $StateStorageAccount/$StateContainerName. Check the account name, or pass -StateKey for a non-default key." -ErrorId 'ZsNoRemoteState' -Cmdlet $PSCmdlet }
        return $remote
    }
    if ($Path) {
        $resolved = $PSCmdlet.GetUnresolvedProviderPathFromPSPath($Path)
        if (Test-Path -LiteralPath $resolved) { return ([System.IO.File]::ReadAllText($resolved) | ConvertFrom-Json -AsHashtable) }
    }
    $m = Get-ZsManifest
    if (-not $m) { Write-ZsError -Message 'No active deployment manifest found. Run a deployment first, or pass -Path to a saved manifest.' -ErrorId 'ZsNoManifest' -Cmdlet $PSCmdlet }
    if ($Export) {
        if (-not $Path) { $Path = Get-ZsArtifactPath -FileName "zscc-manifest-$(if($script:ZsSession){$script:ZsSession.ShortId}else{(Get-Date -Format 'HHmmss')}).json" }
        Export-ZsManifest -Path $Path | Out-Null
    }
    return $m
}
