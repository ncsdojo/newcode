<#
.SYNOPSIS
    Enables Microsoft Defender for Cloud plans at subscription scope.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Set-ZsDefenderPlans {
    <#
    .SYNOPSIS Enables Microsoft Defender for Cloud plans at subscription scope.
    .DESCRIPTION Sets the Standard tier on the plans relevant to this deployment: VirtualMachines,
        StorageAccounts, KeyVaults, and Arm. Optionally configures a security contact for alerts.
    .PARAMETER Plans Plan names to enable.
    .PARAMETER SecurityContactEmail Email for high-severity alert notifications.
    .EXAMPLE
    Set-ZsDefenderPlans -SecurityContactEmail soc@contoso.com
    Enables Microsoft Defender for Cloud plans at subscription scope with alert notifications.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [ValidateSet('VirtualMachines','StorageAccounts','KeyVaults','Arm','Containers')]
        [string[]]$Plans = @('VirtualMachines','StorageAccounts','KeyVaults','Arm'),
        [string]$SecurityContactEmail = ''
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $subPath = Get-ZsSubscriptionPath
        $api = $script:ApiVersions.Security
        $results = @{}

        foreach ($plan in $Plans) {
            if ($PSCmdlet.ShouldProcess($plan, 'Enable Defender plan (Standard)')) {
                try {
                    Invoke-ArmPut -Uri "$subPath/providers/Microsoft.Security/pricings/$plan`?api-version=$api" -Body @{
                        properties = @{ pricingTier = 'Standard' }
                    } | Out-Null
                    $results[$plan] = 'Standard'
                    Write-ZsLog "Defender for $plan enabled (Standard)"
                } catch {
                    Write-ZsLog "Defender plan $plan failed: $_" -Level WARN
                    $results[$plan] = 'Failed'
                }
            }
        }

        if ($SecurityContactEmail) {
            if ($PSCmdlet.ShouldProcess($SecurityContactEmail, 'Set security contact')) {
                try {
                    Invoke-ArmPut -Uri "$subPath/providers/Microsoft.Security/securityContacts/default?api-version=$($script:ApiVersions.SecurityContact)" -Body @{
                        properties = @{
                            emails = $SecurityContactEmail
                            notificationsByRole = @{ state = 'On'; roles = @('Owner') }
                            alertNotifications = @{ state = 'On'; minimalSeverity = 'High' }
                        }
                    } | Out-Null
                    Write-ZsLog "Security contact set: $SecurityContactEmail"
                } catch {
                    Write-ZsLog "Security contact failed: $_" -Level WARN
                }
            }
        }

        return [PSCustomObject]@{ Plans = $results; SecurityContact = $SecurityContactEmail }
    }
}
