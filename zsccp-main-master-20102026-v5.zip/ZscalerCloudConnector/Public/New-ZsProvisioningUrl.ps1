<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (New-ZsProvisioningUrl).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
    .PARAMETER FormFactor Cloud Connector form factor: Small, Medium, or Large.
    .PARAMETER ReleaseChannel Release channel for the connector image: STABLE, LATEST, or BETA.
    .PARAMETER TemplateName Name for the provisioning URL template in the Zscaler portal.
    #>

function New-ZsProvisioningUrl {
    <#
    .SYNOPSIS Generates a Cloud Connector provisioning URL via the ZTC API. Reuses existing Azure URLs.
    .EXAMPLE
    New-ZsProvisioningUrl -FormFactor Small
    Returns an Azure Cloud Connector provisioning URL, reusing an existing one if present.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [ValidateSet('Small','Medium','Large')][string]$FormFactor = 'Small',
        [ValidateSet('STABLE','LATEST','BETA')][string]$ReleaseChannel = 'STABLE',
        [string]$TemplateName = 'ZSCC-Azure-Provisioning'
    )

    begin { Assert-ZsConnected -Cloud -Cmdlet $PSCmdlet }
    process {
        $base = $script:ZsSession.ZscalerApiUrl

        try {
            $existing = Invoke-ZscalerRequest -Uri "$base/api/v1/provUrl" -Method Get
            $azure = @($existing | Where-Object { $_.provUrlData.cloudProviderType -eq 'AZURE' -or $_.cloudProvider -eq 'AZURE' })
            if ($azure.Count -gt 0) {
                $url = if ($azure[0].provUrl) { $azure[0].provUrl } else { "$base/api/v1/provUrl/$($azure[0].id)" }
                Write-ZsLog "Reusing existing Azure provisioning URL"
                Add-ZsManifestOutput -Key 'ProvisioningUrl' -Value $url
                return [PSCustomObject]@{ ProvisioningUrl=$url; Source='Existing'; FormFactor=$FormFactor }
            }
        } catch { Write-Verbose "No existing Azure provisioning URL found; a new one will be generated: $_" }

        if ($PSCmdlet.ShouldProcess('Azure Cloud Connector', 'Create provisioning URL')) {
            $created = Invoke-ZscalerRequest -Uri "$base/api/v1/provUrl" -Method Post -Body @{
                name=$TemplateName; provUrlType='CLOUD'; provUrlData=@{ cloudProviderType='AZURE'; formFactor=$FormFactor.ToUpper(); releaseChannel=$ReleaseChannel }
            }
            $url = if ($created.provUrl) { $created.provUrl } else { "$base/api/v1/provUrl/$($created.id)" }
            Add-ZsManifestOutput -Key 'ProvisioningUrl' -Value $url
            Write-ZsLog "Provisioning URL created"
            return [PSCustomObject]@{ ProvisioningUrl=$url; Source='Created'; FormFactor=$FormFactor }
        }
        # WhatIf placeholder.
        return [PSCustomObject]@{ ProvisioningUrl='(provisioning URL created at deploy time)'; Source='WhatIf'; FormFactor=$FormFactor }
    }
}
