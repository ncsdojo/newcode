<#
.SYNOPSIS
    Creates the action group and alert rules that make the deployment observable.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function New-ZsMonitorAlerts {
    <#
    .SYNOPSIS Creates an action group, a load balancer health alert, and three log alerts on the lifecycle function.
    .DESCRIPTION The same rules as the Terraform monitoring module:

        - Load balancer health. Fewer than half the connectors passing the health probe
          (DipAvailability). The workload default route points at this load balancer, so this is the
          alert that means traffic is at risk. A platform metric, so it reports continuously.
        - Function heartbeat. No synchronizeCloudResources execution across two sync intervals.
          The package's host.json keeps requests out of sampling, so every execution is a request,
          and the plan emits no execution-count metric to alert on instead.
        - Health verdicts. The monitor judged a connector unhealthy, or terminated or replaced one.
        - Function errors. The function catches its own exceptions and exits cleanly, so only its
          traces show that anything went wrong.

        Each log rule counts the rows its query returns, so the queries filter and stop there: a
        trailing summarize would always return exactly one row, and a "greater than 0" rule over it
        would fire on every evaluation. The message text is matched as the vendor package (1.0.3)
        writes it, typos included, together with this module's function's own wording.

        There are no metric alerts on what the connectors publish. Azure records a custom metric that
        stops arriving as no data rather than zero, so a "samples stopped" rule never fires, and the
        per-connector health metric is published on each VM, which a rule scoped to the scale set
        does not see. The 5.4.1.0 rules of those kinds are removed.
    .PARAMETER AppInsightsId Resource ID of the Application Insights component backing the function.
    .PARAMETER LoadBalancerId Resource ID of the connectors' internal load balancer.
    .PARAMETER NotificationEmail Addresses for the action group. Rules are created and fire either
        way, but without an address nothing is delivered.
    .PARAMETER SyncIntervalMinutes The function's sync cadence; sizes the heartbeat window.
    .PARAMETER Severity Severity of the three log alerts, 0 (critical) to 4 (verbose). The load balancer
        alert is severity 1.
    .OUTPUTS PSCustomObject with ActionGroupId and the created rule names.
    .EXAMPLE
    New-ZsMonitorAlerts -AppInsightsId $fa.AppInsightsId -LoadBalancerId $lb.LbId -NotificationEmail 'ops@example.com'
    Creates the action group and the four rules, delivering to ops@example.com.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [string]$AppInsightsId = '',
        [string]$LoadBalancerId = '',
        [ValidatePattern('^[^@\s]+@[^@\s]+\.[^@\s]+$', ErrorMessage = "NotificationEmail entries must be email addresses (name@domain.tld); received: '{0}'")]
        [string[]]$NotificationEmail = @(),
        [ValidateRange(1,1440)][int]$SyncIntervalMinutes = 30,
        [ValidateRange(0,4)][int]$Severity = 2
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $loc=$script:ZsSession.Location; $tags=Get-ZsTags; $rgPath=Get-ZsRgPath
        $shortId=$script:ZsSession.ShortId
        $created = @()

        if (-not $NotificationEmail -or @($NotificationEmail | Where-Object { $_ }).Count -eq 0) {
            Write-ZsLog "No notification address configured; alert rules are created but nothing is on the receiving end. Set NotificationEmail in the config file, pass -NotificationEmail, or attach receivers to the action group." -Level WARN
        }

        # Action group. Location is Global for action groups regardless of where the rules live.
        $agName = "ag-zscc-$shortId"
        $agPath = "$rgPath/providers/Microsoft.Insights/actionGroups/$agName"
        # Every rule below is written on each run, as Terraform applies it; the verb says whether
        # the write creates it or updates one already there.
        $verbFor = { param([string]$Uri) if ((Test-ArmResource -Uri $Uri).Exists) { 'Update' } else { 'Create' } }
        if ($PSCmdlet.ShouldProcess($agName, "$(& $verbFor "$agPath`?api-version=$($script:ApiVersions.ActionGroup)") action group")) {
            $receivers = @(); $i = 0
            foreach ($addr in $NotificationEmail) {
                if (-not $addr) { continue }
                $i++
                $receivers += @{ name="email$i"; emailAddress=$addr; useCommonAlertSchema=$true }
            }
            Invoke-ArmPut -Uri "$agPath`?api-version=$($script:ApiVersions.ActionGroup)" -Body @{
                location='Global'; tags=$tags
                properties=@{
                    groupShortName="zscc$($shortId.Substring(0, [math]::Min(7, $shortId.Length)))"
                    enabled=$true; emailReceivers=$receivers
                }
            } | Out-Null
            Add-ZsManifestResource -Type 'ActionGroup' -Name $agName -ResourceId $agPath
            Write-ZsLog "Action group $agName ready"
        }

        # The 5.4.1.0 metric rules, which cannot do their job: custom metrics that stop arriving
        # (no data never fires), a per-VM metric read from scale set scope, and a heartbeat on an
        # execution-count metric this plan does not emit, which fired regardless.
        $metricApi = $script:ApiVersions.MetricAlert
        $existingRules = @()
        try { $existingRules = @(Get-ZsPropertyValue (Invoke-ArmGet -Uri "$rgPath/providers/Microsoft.Insights/metricAlerts?api-version=$metricApi" -AllowNotFound) 'value' | Where-Object { $_ }) }
        catch { Write-ZsLog "Could not list existing metric alerts: $($_.Exception.Message)" -Level WARN }
        foreach ($r in $existingRules) {
            $n = [string]$r.name
            if ($n -notmatch '^alert-zscc-(smedge-stale-|cc-unhealthy-|func-heartbeat-)') { continue }
            if (-not (Test-ZsModuleOwned -Resource $r)) { continue }
            if (-not $PSCmdlet.ShouldProcess($n, 'Remove 5.4.1.0 metric alert that cannot fire correctly')) { continue }
            try {
                Invoke-ArmDelete -Uri "$($r.id)?api-version=$metricApi" -AllowNotFound | Out-Null
                Write-ZsLog "Removed metric alert $n, which could not fire correctly"
            } catch { Write-ZsLog "Could not remove metric alert $n`: $($_.Exception.Message)" -Level WARN }
        }

        # Load balancer health. Fewer than half the connectors answering the probe. An ID in
        # parentheses is a placeholder for a resource this run did not create (-WhatIf).
        $lbName = "alert-zscc-lb-health-$shortId"
        if (-not $LoadBalancerId) {
            Write-ZsLog "No load balancer ID supplied; skipping the load balancer health alert." -Level WARN
        } elseif ($PSCmdlet.ShouldProcess($lbName, "$(& $verbFor "$rgPath/providers/Microsoft.Insights/metricAlerts/$lbName`?api-version=$metricApi") load balancer health alert") -and $LoadBalancerId -notmatch '^\(') {
            try {
                Invoke-ArmPut -Uri "$rgPath/providers/Microsoft.Insights/metricAlerts/$lbName`?api-version=$metricApi" -Body @{
                    location='global'; tags=$tags
                    properties=@{
                        description='Fewer than half the connectors are passing the load balancer health probe.'
                        severity=1; enabled=$true; scopes=@($LoadBalancerId)
                        evaluationFrequency='PT1M'; windowSize='PT5M'
                        autoMitigate=$true
                        criteria=@{
                            'odata.type'='Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria'
                            allOf=@(@{
                                criterionType='StaticThresholdCriterion'; name='HealthProbeBelowHalf'
                                metricName='DipAvailability'; metricNamespace='Microsoft.Network/loadBalancers'
                                operator='LessThan'; threshold=50; timeAggregation='Average'
                            })
                        }
                        actions=@(@{ actionGroupId=$agPath; webHookProperties=@{} })
                    }
                } | Out-Null
                Add-ZsManifestResource -Type 'MetricAlert' -Name $lbName -ResourceId "$rgPath/providers/Microsoft.Insights/metricAlerts/$lbName"
                $created += $lbName
                Write-ZsLog "Alert: fewer than half the connectors passing the load balancer health probe"
            } catch { Write-ZsLog "Could not create the load balancer health alert: $($_.Exception.Message)" -Level WARN }
        }

        if (-not $AppInsightsId) {
            Write-ZsLog "No Application Insights component; the function heartbeat, health verdict and error alerts are skipped." -Level WARN
            return [PSCustomObject]@{ ActionGroupName=$agName; ActionGroupId=$agPath; Rules=$created }
        }

        # Windows a log alert accepts at a 15-minute frequency, shortest first. The heartbeat takes
        # the shortest one covering two sync intervals, so one late tick does not page anyone.
        $hbWindow = 'P2D'
        foreach ($w in @(
                @{ M=15; D='PT15M' }; @{ M=30; D='PT30M' }; @{ M=45; D='PT45M' }; @{ M=60; D='PT1H' }
                @{ M=120; D='PT2H' }; @{ M=180; D='PT3H' }; @{ M=240; D='PT4H' }; @{ M=300; D='PT5H' }
                @{ M=360; D='PT6H' }; @{ M=1440; D='P1D' }; @{ M=2880; D='P2D' })) {
            if ($w.M -ge ($SyncIntervalMinutes * 2)) { $hbWindow = $w.D; break }
        }

        # Only the sync function: healthMonitor runs every minute, so counting every request would
        # hide a sync that had stopped.
        $heartbeatKql = @'
requests
| where name == "synchronizeCloudResources"
'@
        # The vendor package's messages (1.0.3), as written, and this module's function's.
        $verdictKql = @'
traces
| where message has_any ("Instance is unhealthy, adding it to the termination list", "Failed provisioning state", "Successfully initiated termination", "evaluated unhealthy", "Terminating unhealthy instance")
'@
        # No severity filter: the packages log these at error level, but matching on the text alone
        # does not depend on how the host maps that level.
        $errorsKql = @'
traces
| where message has_any ("Failed to synchronize resources", "Failed to clean up stale instance", "Failed to update VMSS Config", "Failed to monitor health", "Failed to terminate instance", "Failed to evaluate health", "Authentication failed", "API request failed", "Error occurred during API request", "Maximum number of retries reached", "does not exist", "Missing ENV Varibales", "Failed to load", "Failed to query", "Failed to read credentials", "Missing required app settings", "refusing to prune", "Failed to terminate", "Could not restore capacity", "Failed to enumerate", "Failed to authenticate")
'@
        $logRules = @(
            @{ Name="alert-zscc-func-heartbeat-$shortId"; What='function heartbeat'; Window=$hbWindow; Query=$heartbeatKql; Operator='LessThan'; Threshold=1
               Description="The lifecycle function produced no synchronizeCloudResources execution across two sync intervals ($hbWindow). Stale portal connector entries accumulate until it resumes." }
            @{ Name="alert-zscc-health-verdict-$shortId"; What='connector health verdicts'; Window='PT15M'; Query=$verdictKql; Operator='GreaterThan'; Threshold=0
               Description='The health monitor judged a connector unhealthy or terminated one. Replacement is automatic; this reports that it happened.' }
            @{ Name="alert-zscc-func-errors-$shortId"; What='function errors'; Window='PT15M'; Query=$errorsKql; Operator='GreaterThan'; Threshold=0
               Description='The lifecycle function logged an error. It exits cleanly on these paths, so nothing else shows a failure.' }
        )
        foreach ($rule in $logRules) {
            $ruleUri = "$rgPath/providers/Microsoft.Insights/scheduledQueryRules/$($rule.Name)`?api-version=$($script:ApiVersions.ScheduledQuery)"
            if (-not $PSCmdlet.ShouldProcess($rule.Name, "$(& $verbFor $ruleUri) $($rule.What) log alert") -or $AppInsightsId -match '^\(') { continue }
            try {
                Invoke-ArmPut -Uri $ruleUri -Body @{
                    location=$loc; tags=$tags
                    properties=@{
                        description=$rule.Description
                        severity=$Severity; enabled=$true; scopes=@($AppInsightsId)
                        evaluationFrequency='PT15M'; windowSize=$rule.Window; autoMitigate=$true
                        criteria=@{
                            allOf=@(@{
                                query=$rule.Query; timeAggregation='Count'
                                operator=$rule.Operator; threshold=$rule.Threshold
                                failingPeriods=@{ numberOfEvaluationPeriods=1; minFailingPeriodsToAlert=1 }
                            })
                        }
                        actions=@{ actionGroups=@($agPath) }
                    }
                } | Out-Null
                Add-ZsManifestResource -Type 'ScheduledQueryRule' -Name $rule.Name -ResourceId "$rgPath/providers/Microsoft.Insights/scheduledQueryRules/$($rule.Name)"
                $created += $rule.Name
                Write-ZsLog "Alert: $($rule.What)$(if ($rule.Name -like '*heartbeat*') { " (no sync in $hbWindow)" })"
            } catch { Write-ZsLog "Could not create the $($rule.What) alert: $($_.Exception.Message)" -Level WARN }
        }

        return [PSCustomObject]@{ ActionGroupName=$agName; ActionGroupId=$agPath; Rules=$created }
    }
}

function ConvertTo-ZsIsoDuration {
    <#
    .SYNOPSIS Converts minutes to the ISO 8601 duration Azure Monitor accepts for windowSize.
    .DESCRIPTION Metric alerts accept a fixed set of windows and reject anything else at PUT
        time, so an arbitrary interval is snapped up to the next supported window rather than
        failing the deployment.
    .OUTPUTS [string]
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([string])]
    param([Parameter(Mandatory)][int]$Minutes)
    foreach ($step in @(
            @{ Max=5;    Iso='PT5M'  }
            @{ Max=15;   Iso='PT15M' }
            @{ Max=30;   Iso='PT30M' }
            @{ Max=60;   Iso='PT1H'  }
            @{ Max=360;  Iso='PT6H'  }
            @{ Max=720;  Iso='PT12H' }
            @{ Max=1440; Iso='P1D'   }
        )) {
        if ($Minutes -le $step.Max) { return $step.Iso }
    }
    return 'P1D'
}
