<#
.SYNOPSIS
    Deploys a Flexible Orchestration VMSS of Cloud Connectors with a lifecycle Function App.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function New-ZsCloudConnectorVmss {
    <#
    .SYNOPSIS Deploys Cloud Connectors as a Flexible Orchestration VMSS with lifecycle Function App.
    .DESCRIPTION Creates a Storage Account, App Service Plan, Function App (Python runtime for CC resource
        sync), and a Flexible Orchestration VMSS with auto-scaling. The Function App reconciles VMSS instance
        state with the Zscaler Cloud Connector Portal every 30 minutes.
    .PARAMETER MinInstances Minimum VMSS instance count (scale-in floor).
    .PARAMETER MaxInstances Maximum VMSS instance count (scale-out ceiling).
    .PARAMETER DesiredInstances Initial desired instance count.
    .PARAMETER AppServicePlanSku App Service Plan SKU, a Dedicated tier: P0v3 (default), P1v3, P2v3 or B1. Y1, EP1
        and EP2 need an Azure Files content share the private storage account cannot serve, and are refused.
    .PARAMETER FunctionRoleMode Control-plane role for the Function App identity; see New-ZsLifecycleFunctionApp.
    .PARAMETER EnableFunctionPrivateEndpoint Private Endpoint on the Function App, for operators inside the network.
    .PARAMETER RemediationRoleName Role the function identity gets on the resource group (and RemediationSubnetIds)
        to replace an unhealthy connector. Virtual Machine Contributor by default; see Set-ZsHealthRemediationRole.
    .PARAMETER RemediationSubnetIds The management and service subnets, when their VNet is in another resource
        group: the same role is granted on them, since starting a replacement joins both.
    .PARAMETER CreateRemediationRole Define a custom role with exactly what replacing a connector needs and grant
        it in place of RemediationRoleName; see Set-ZsHealthRemediationRole.
    .PARAMETER DisableLegacyVmNvaTag Leave the LegacyVMNVA tag off the scale sets. It keeps the connectors off
        Azure hosts with the MANA network adapter until Zscaler's image supports MANA.
    .EXAMPLE
    New-ZsCloudConnectorVmss -MgmtSubnetId $mgmt -ServiceSubnetId $svc -LbBackendId $lb -CcIdentityResourceId $id -KeyVaultUri $kv -ProvisioningUrl $url -SshPublicKey $key
    Deploys a Flexible Orchestration VMSS of connectors with the lifecycle Function App.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        # One EC group per scale set, and Zscaler takes at most 16 connectors in a group.
        [ValidateRange(1,16)][int]$MinInstances     = 2,
        [ValidateRange(1,16)][int]$MaxInstances     = 4,
        [ValidateRange(1,16)][int]$DesiredInstances = 2,
        [ValidateNotNullOrEmpty()][string]$VmSize = 'Standard_D2s_v3',
        # The shared management and service subnets every zone's scale set uses.
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$MgmtSubnetId,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$ServiceSubnetId,
        [Parameter(Mandatory)][string]$LbBackendId,
        [Parameter(Mandatory)][string]$CcIdentityResourceId,
        [string]$CcIdentityClientId = '',
        [Parameter(Mandatory)][string]$KeyVaultUri,      [Parameter(Mandatory)][string]$ProvisioningUrl,
        [string]$KeyVaultId = '',
        [Parameter(Mandatory)][string]$SshPublicKey,
        [ValidateRange(1,65535)][int]$HttpProbePort = 50000,
        [string[]]$Zones = @('1','2'),
        [string]$AdminUsername = 'zsroot',
        [ValidateSet('B1','P0v3','P1v3','P2v3','EP1','EP2','Y1')][string]$AppServicePlanSku = 'P0v3',
        [switch]$EncryptAtHost,
        [string]$FuncAppSubnetId = '',
        [ValidateRange(1,100)][int]$ScaleOutThreshold = 70,
        [ValidateRange(1,100)][int]$ScaleInThreshold = 30,
        [ValidateRange(1,60)][int]$ScaleOutCooldownMinutes = 5,
        [ValidateRange(1,60)][int]$ScaleInCooldownMinutes = 10,
        [switch]$ScheduledScaling,
        [ValidateRange(1,16)][int]$ScheduledMinInstances = 1,
        [string[]]$ScheduledDays = @('Monday','Tuesday','Wednesday','Thursday','Friday'),
        [ValidateRange(0,23)][int]$ScheduledStartHour = 9,
        [ValidateRange(0,59)][int]$ScheduledStartMinute = 0,
        [ValidateRange(0,23)][int]$ScheduledEndHour = 17,
        [ValidateRange(0,59)][int]$ScheduledEndMinute = 0,
        [string]$ScheduledTimezone = 'Pacific Standard Time',
        [ValidateRange(1,1440)][int]$SyncIntervalMinutes = 30,
        [ValidateSet('Vendor','Module')][string]$FunctionPackage = 'Vendor',
        [switch]$DisableHealthRemediation,
        [ValidateRange(3,60)][int]$HealthDataPoints = 10,
        [ValidateRange(1,60)][int]$HealthUnhealthyThreshold = 7,
        [ValidateRange(1,60)][int]$HealthConsecutiveThreshold = 5,
        [ValidateRange(5,240)][int]$HealthGracePeriodMinutes = 30,
        [ValidateRange(0.05,1.0)][double]$MaxTerminationPercent = 0.2,
        [ValidateSet('oldest','newest')][string]$TerminationPolicy = 'oldest',
        [ValidateSet('Reader','LeastPrivilege','NetworkContributor','None')][string]$FunctionRoleMode = 'Reader',
        [switch]$EnableFunctionPrivateEndpoint,
        [string]$PrivateEndpointSubnetId = '',
        [string]$VnetId = '',
        [AllowEmptyString()][string]$FunctionPackageUrl = $script:ZsVendorPackageUrl,
        [string]$PrivateDnsZoneResourceGroupName = '',
        [string]$PrivateDnsZoneSubscriptionId = '',
        [string]$RemediationRoleName = 'Virtual Machine Contributor',
        [string[]]$RemediationSubnetIds = @(),
        [switch]$CreateRemediationRole,
        [switch]$DisableLegacyVmNvaTag
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $env=$script:ZsSession.Environment; $loc=$script:ZsSession.Location; $tags=Get-ZsTags
        $rgPath=Get-ZsRgPath; $img=$script:CcImage
        $cmpApi=$script:ApiVersions.Compute
        $shortId=$script:ZsSession.ShortId

        # Azure refuses an autoscale profile whose default capacity lies outside its minimum and
        # maximum, so the capacities are checked before anything is created.
        if ($MinInstances -gt $DesiredInstances -or $DesiredInstances -gt $MaxInstances) {
            Write-ZsError -Message ("Capacity must satisfy MinInstances <= DesiredInstances <= MaxInstances; got " +
                "$MinInstances/$DesiredInstances/$MaxInstances. Nothing has been created.") -ErrorId 'ZsInvalidInstanceRange' -Cmdlet $PSCmdlet
        }
        if ($ScheduledScaling -and $ScheduledMinInstances -gt $MaxInstances) {
            Write-ZsError -Message ("ScheduledMinInstances ($ScheduledMinInstances) cannot exceed MaxInstances ($MaxInstances). " +
                "Nothing has been created.") -ErrorId 'ZsInvalidInstanceRange' -Cmdlet $PSCmdlet
        }

        # A dry run over existing scale sets goes through the reconcile below, where every write asks
        # first, so it shows what an upgrade would change. With none there is nothing to compare
        # with, and placeholders stand in for what would be created.
        $existingVmss = @($Zones | Where-Object { (Test-ArmResource -Uri "$rgPath/providers/Microsoft.Compute/virtualMachineScaleSets/vmss-zscc-z$_-$env-$loc`?api-version=$cmpApi").Exists })
        if ($WhatIfPreference -and $existingVmss.Count -eq 0) {
            $whatIfZones = foreach ($z in $Zones) { [PSCustomObject]@{ Zone=$z; VmssName="vmss-zscc-z$z-$env-$loc"; VmssId="(VMSS z$z created at deploy time)"; Autoscale="autoscale-zscc-z$z-$env-$loc" } }
            return [PSCustomObject]@{
                Zones=@($whatIfZones); VmssNames=@($Zones | ForEach-Object { "vmss-zscc-z$_-$env-$loc" }); FunctionApp="(created at deploy time)"
                FunctionAppId='(created at deploy time)'; AppInsightsId='(created at deploy time)'
                Instances=$DesiredInstances; MinInstances=$MinInstances; MaxInstances=$MaxInstances
                StorageAccount="(created at deploy time)"
                # Same key set as the real return below: a caller reads whichever shape it gets,
                # and under StrictMode a key present on one return and absent on the other is a
                # "property cannot be found" error that only fires in a -WhatIf run.
                StorageUri='(created at deploy time)'; StoragePath='(created at deploy time)'
                FuncAppSubnetId=$FuncAppSubnetId; FunctionPackagePending=$false
            }
        }

        $accelNet = Test-AcceleratedNetworkingSupport -VmSize $VmSize
        $encHost = $false
        if ($EncryptAtHost) { $encHost = Test-EncryptionAtHostSupport -VmSize $VmSize; Write-ZsLog "Encryption at host: $encHost ($VmSize)" }

        # Cloud-init bootstrap (INI format, Zscaler Terraform reference).
        $ud64 = Get-ZsConnectorUserData -ProvisioningUrl $ProvisioningUrl -KeyVaultUri $KeyVaultUri -HttpProbePort $HttpProbePort -IdentityClientId $CcIdentityClientId

        # LegacyVMNVA keeps the connectors off Azure hosts with the MANA network adapter. Microsoft
        # is moving the general-purpose families, Dsv3 included, onto MANA hardware, and an
        # appliance image without a MANA driver falls back to the slower synthetic NIC there, which
        # Microsoft warns can mean intermittent connectivity and lower throughput. Zscaler's own
        # module sets the tag until its image supports MANA. Azure reads it when it places a VM, so
        # a running connector picks it up after 'az vm reapply', a redeploy or its replacement.
        $vmssTags = @{}; foreach ($k in $tags.Keys) { $vmssTags[$k] = $tags[$k] }
        if (-not $DisableLegacyVmNvaTag) { $vmssTags['LegacyVMNVA'] = 'true' }

        # Completion is emitted however this ends, so a failure mid-deployment does not strand the
        # bar on the console. A finally block rather than a trap: a trap that rethrows with a bare
        # throw replaces the error with ScriptHalted, and the operator loses the reason.
        try {
            Write-Progress -Activity 'VMSS Deployment' -Status 'Lifecycle Function App' -PercentComplete 10

            $vmssNamePlanned = (($Zones | ForEach-Object { "vmss-zscc-z$_-$env-$loc" }) -join ',')
            $faInfra = New-ZsLifecycleFunctionApp -KeyVaultUri $KeyVaultUri -KeyVaultId $KeyVaultId `
                -ProvisioningUrl $ProvisioningUrl -VmssNames $vmssNamePlanned -FuncAppSubnetId $FuncAppSubnetId `
                -AppServicePlanSku $AppServicePlanSku -SyncIntervalMinutes $SyncIntervalMinutes `
                -FunctionRoleMode $FunctionRoleMode -FunctionPackage $FunctionPackage `
                -DisableHealthRemediation:$DisableHealthRemediation `
                -HealthDataPoints $HealthDataPoints -HealthUnhealthyThreshold $HealthUnhealthyThreshold `
                -HealthConsecutiveThreshold $HealthConsecutiveThreshold `
                -HealthGracePeriodMinutes $HealthGracePeriodMinutes `
                -MaxTerminationPercent $MaxTerminationPercent -TerminationPolicy $TerminationPolicy `
                -EnablePrivateEndpoint:$EnableFunctionPrivateEndpoint `
                -PrivateEndpointSubnetId $PrivateEndpointSubnetId -VnetId $VnetId `
                -FunctionPackageUrl $FunctionPackageUrl `
                -PrivateDnsZoneResourceGroupName $PrivateDnsZoneResourceGroupName -PrivateDnsZoneSubscriptionId $PrivateDnsZoneSubscriptionId
            $storName = $faInfra.StorageAccount; $storPath = $faInfra.StoragePath; $storUri = $faInfra.StorageUri
            $faName = $faInfra.FunctionApp

            # What replacing an unhealthy connector takes: the role on the resource group (and the
            # connector subnets when their VNet is elsewhere), and Managed Identity Operator on the
            # connector identity. Granted before the scale sets, so a grant the deployer cannot make
            # stops the run before any connector is built.
            if (-not $DisableHealthRemediation) {
                Set-ZsHealthRemediationRole -PrincipalId "$($faInfra.IdentityPrincipalId)" -ConnectorIdentityId $CcIdentityResourceId `
                    -SubnetIds $RemediationSubnetIds -RoleName $RemediationRoleName -CreateRole:$CreateRemediationRole `
                    -VmssIds @($Zones | ForEach-Object { "$rgPath/providers/Microsoft.Compute/virtualMachineScaleSets/vmss-zscc-z$_-$env-$loc" })
            }

            Write-Progress -Activity 'VMSS Deployment' -Status 'Virtual Machine Scale Set' -PercentComplete 60

            # One VMSS per availability zone, each pinned to that zone and its own subnets, so a zone
            # failure removes only its scale set. The shared Function App (above) reconciles all of them.
            $zoneResults = [System.Collections.Generic.List[object]]::new()
            $vmssNames   = [System.Collections.Generic.List[string]]::new()
            foreach ($z in $Zones) {
                # Every zone's scale set lands its NICs in the same shared subnets; the zonal
                # split lives in the scale sets themselves, not the network.
                $zMgmtSubnetId    = $MgmtSubnetId
                $zServiceSubnetId = $ServiceSubnetId

                $vmssName = "vmss-zscc-z$z-$env-$loc"
                $vmssNames.Add($vmssName)
                $vmssPath = "$rgPath/providers/Microsoft.Compute/virtualMachineScaleSets/$vmssName"
                $vmssUri  = "$vmssPath`?api-version=$cmpApi"
                $vmssChk  = Test-ArmResource -Uri $vmssUri

                if ($vmssChk.Exists) {
                    Write-ZsLog "VMSS $vmssName verified"
                    $vmss = $vmssChk.Resource
                    $vmssOwned = Test-ZsModuleOwned -Resource $vmss
                    Add-ZsManifestResource -Type 'VMSS' -Name $vmssName -ResourceId $vmss.id -Properties @{ OrchestrationMode='Flexible' } -PreExisting:(-not $vmssOwned)

                    # The scale set model is brought to this run's bootstrap and tags, as an apply of the
                    # Terraform configuration updates it in place: a PATCH, so autoscale's capacity and
                    # every running connector are left alone. Connectors created from now on - by
                    # autoscale, or replacing an unhealthy one - get the new model.
                    $liveUd = [string](Get-ZsPropertyValue (Invoke-ArmGet -Uri "$vmssPath`?api-version=$cmpApi&`$expand=userData") 'properties.virtualMachineProfile.userData')
                    $liveTags = @{}
                    if ($vmss.PSObject.Properties['tags'] -and $vmss.tags) { foreach ($p in $vmss.tags.PSObject.Properties) { $liveTags[$p.Name] = [string]$p.Value } }
                    $wantNva = -not $DisableLegacyVmNvaTag
                    $tagDrift = ($liveTags['LegacyVMNVA'] -eq 'true') -ne $wantNva
                    $udDrift  = ($liveUd -ne $ud64)
                    if (($tagDrift -or $udDrift) -and $vmssOwned -and $PSCmdlet.ShouldProcess($vmssName, 'Update scale set model (bootstrap, tags)')) {
                        $patch = @{}
                        if ($tagDrift) {
                            if ($wantNva) { $liveTags['LegacyVMNVA'] = 'true' } else { $liveTags.Remove('LegacyVMNVA') }
                            $patch.tags = $liveTags
                        }
                        if ($udDrift) {
                            # userData and customData carry the same bootstrap; customData is never
                            # returned by a read, so both are written together.
                            $patch.properties = @{ virtualMachineProfile = @{ userData = $ud64; osProfile = @{ customData = $ud64 } } }
                        }
                        Invoke-ArmRequest -Uri $vmssUri -Method Patch -Body $patch -AsyncTimeoutSeconds 900 | Out-Null
                        $vmss = Wait-ArmProvision -Uri $vmssUri -Label $vmssName -TimeoutSeconds 900
                        $what = @()
                        if ($udDrift) { $what += 'bootstrap (CC_URL without scheme, FIPS_ENABLED=False)' }
                        if ($tagDrift) { $what += "LegacyVMNVA tag $(if ($wantNva) { 'set' } else { 'removed' })" }
                        Write-ZsLog ("VMSS $vmssName model updated: $($what -join '; '). Running connectors keep their bootstrap until replaced" +
                            $(if ($tagDrift -and $wantNva) { ", and take the tag after 'az vm reapply'." } else { '.' }))
                    }
                } elseif ($PSCmdlet.ShouldProcess($vmssName, 'Create VMSS')) {
                    $vmssBody = @{
                        location=$loc; tags=$vmssTags; zones=@($z)
                        sku=@{name=$VmSize;capacity=$DesiredInstances}
                    plan=@{name=$img.Sku;publisher=$img.Publisher;product=$img.Offer}
                    identity=@{type='UserAssigned';userAssignedIdentities=@{"$CcIdentityResourceId"=@{}}}
                    properties=@{
                        orchestrationMode='Flexible'
                        platformFaultDomainCount=1
                        virtualMachineProfile=@{
                            userData=$ud64
                            scheduledEventsProfile=@{terminateNotificationProfile=@{enable=$true;notBeforeTimeout='PT5M'}}
                            osProfile=@{
                                computerNamePrefix="zscc-$shortId"
                                adminUsername=$AdminUsername
                                customData=$ud64
                                linuxConfiguration=@{
                                    disablePasswordAuthentication=$true
                                    ssh=@{publicKeys=@(@{path="/home/$AdminUsername/.ssh/authorized_keys";keyData=$SshPublicKey})}
                                }
                            }
                            storageProfile=@{
                                imageReference=@{publisher=$img.Publisher;offer=$img.Offer;sku=$img.Sku;version=$img.Version}
                                osDisk=@{createOption='FromImage';caching='ReadWrite';managedDisk=@{storageAccountType='Premium_LRS'};deleteOption='Delete'}
                            }
                            networkProfile=@{
                                networkApiVersion=$script:ApiVersions.Network
                                networkInterfaceConfigurations=@(
                                    @{
                                        name='nic-mgmt'; properties=@{
                                            primary=$true; enableIPForwarding=$false; enableAcceleratedNetworking=$false
                                            ipConfigurations=@(@{name='ipconfig-mgmt';properties=@{primary=$true;subnet=@{id=$zMgmtSubnetId}}})
                                        }
                                    }
                                    @{
                                        name='nic-svc'; properties=@{
                                            primary=$false; enableIPForwarding=$true; enableAcceleratedNetworking=$accelNet
                                            ipConfigurations=@(@{name='ipconfig-svc';properties=@{
                                                primary=$true; subnet=@{id=$zServiceSubnetId}
                                                loadBalancerBackendAddressPools=@(@{id=$LbBackendId})
                                            }})
                                        }
                                    }
                                )
                            }
                            diagnosticsProfile=@{bootDiagnostics=@{enabled=$true}}
                            securityProfile=@{encryptionAtHost=$encHost}
                        }
                        scaleInPolicy=@{rules=@('Default')}
                    }
                }
                # A scale set of marketplace-image instances across zones can honestly take past ten
                # minutes; the async ceiling matches the resource wait below so the slower of the two
                # is what decides, not the layer underneath it.
                Invoke-ArmPut -AsyncTimeoutSeconds 900 -Uri $vmssUri -Body $vmssBody | Out-Null
                $vmss = Wait-ArmProvision -Uri $vmssUri -Label $vmssName -TimeoutSeconds 900
                Add-ZsManifestResource -Type 'VMSS' -Name $vmssName -ResourceId $vmss.id -Properties @{
                    MinInstances=$MinInstances; MaxInstances=$MaxInstances; VmSize=$VmSize; OrchestrationMode='Flexible'
                }
            } else { $vmss = [PSCustomObject]@{ id = "(VMSS z$z created at deploy time)" } }

                $autoscaleName = "autoscale-zscc-z$z-$env-$loc"
                $asPath = "$rgPath/providers/Microsoft.Insights/autoscaleSettings/$autoscaleName"
                $asUri  = "$asPath`?api-version=$($script:ApiVersions.Insights)"
                $asChk  = Test-ArmResource -Uri $asUri

                # Written on every run, as Terraform applies it: thresholds, cooldowns, capacity and the
                # schedule follow this run's settings. Capacity bounds apply at once; the instance count
                # itself stays autoscale's.
                if ($PSCmdlet.ShouldProcess($autoscaleName, $(if ($asChk.Exists) { 'Reconcile autoscale policy' } else { 'Create autoscale policy' }))) {
                    $scaleRules = @(
                        @{
                            metricTrigger=@{
                                metricName='smedge_metrics'; metricNamespace='Zscaler/CloudConnectors'; metricResourceUri=$vmss.id
                                dimensions=@(@{DimensionName='metric_name';Operator='Equals';Values=@('smedge_cpu_utilization')})
                                timeGrain='PT1M'; statistic='Average'; timeWindow='PT5M'; timeAggregation='Average'
                                operator='GreaterThan'; threshold=$ScaleOutThreshold
                            }
                            scaleAction=@{direction='Increase';type='ChangeCount';value='1';cooldown="PT$($ScaleOutCooldownMinutes)M"}
                        }
                        @{
                            metricTrigger=@{
                                metricName='smedge_metrics'; metricNamespace='Zscaler/CloudConnectors'; metricResourceUri=$vmss.id
                                dimensions=@(@{DimensionName='metric_name';Operator='Equals';Values=@('smedge_cpu_utilization')})
                                timeGrain='PT1M'; statistic='Average'; timeWindow='PT10M'; timeAggregation='Average'
                                operator='LessThan'; threshold=$ScaleInThreshold
                            }
                            scaleAction=@{direction='Decrease';type='ChangeCount';value='1';cooldown="PT$($ScaleInCooldownMinutes)M"}
                        }
                    )

                    $defaultProfile = @{
                        name='default-profile'
                        capacity=@{minimum="$MinInstances";maximum="$MaxInstances";default="$DesiredInstances"}
                        rules=$scaleRules
                    }

                    $profiles = @($defaultProfile)

                    if ($ScheduledScaling) {
                        # Scheduled scaling: default profile recurrence + scheduled off-hours profile.
                        $allDays = @('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday')
                        $defaultProfile.recurrence = @{
                            frequency='Week'
                            schedule=@{ timeZone=$ScheduledTimezone; days=$allDays; hours=@($ScheduledEndHour); minutes=@($ScheduledEndMinute) }
                        }
                        $scheduledProfile = @{
                            name='scheduled-profile'
                            capacity=@{minimum="$ScheduledMinInstances";maximum="$MaxInstances";default="$ScheduledMinInstances"}
                            rules=$scaleRules
                            recurrence=@{
                                frequency='Week'
                                schedule=@{ timeZone=$ScheduledTimezone; days=$ScheduledDays; hours=@($ScheduledStartHour); minutes=@($ScheduledStartMinute) }
                            }
                        }
                        $profiles += $scheduledProfile
                        Write-ZsLog "Scheduled scaling: $($ScheduledDays -join ',') $ScheduledStartHour`:$($ScheduledStartMinute.ToString('D2'))-$ScheduledEndHour`:$($ScheduledEndMinute.ToString('D2')) $ScheduledTimezone (min=$ScheduledMinInstances)"
                    }

                    Invoke-ArmPut -Uri $asUri -Body @{
                        location=$loc; tags=$tags
                        properties=@{ enabled=$true; targetResourceUri=$vmss.id; profiles=$profiles }
                    } | Out-Null
                    Add-ZsManifestResource -Type 'AutoscalePolicy' -Name $autoscaleName -ResourceId $asPath -PreExisting:($asChk.Exists -and -not (Test-ZsModuleOwned -Resource $asChk.Resource))
                }

                $zoneResults.Add([PSCustomObject]@{ Zone=$z; VmssName=$vmssName; VmssId=$vmss.id; Autoscale=$autoscaleName })
            }

        } finally {
            Write-Progress -Activity 'VMSS Deployment' -Completed
        }

        Write-ZsLog "Deployed $($zoneResults.Count) VMSS across zones $($Zones -join ', ') ($DesiredInstances instances each, range $MinInstances-$MaxInstances)"
        Add-ZsManifestOutput -Key 'VmssNames' -Value ($vmssNames -join ',')

        return [PSCustomObject]@{
            Zones=$zoneResults; VmssNames=@($vmssNames); FunctionApp=$faName
            FunctionAppId=$faInfra.FunctionAppId; AppInsightsId=$faInfra.AppInsightsId
            Instances=$DesiredInstances; MinInstances=$MinInstances; MaxInstances=$MaxInstances
            StorageAccount=$storName; StoragePath=$storPath; StorageUri=$storUri
            FuncAppSubnetId=$FuncAppSubnetId; FunctionPackagePending=[bool](Get-ZsPropertyValue $faInfra 'PackagePending')
        }
    }
}
