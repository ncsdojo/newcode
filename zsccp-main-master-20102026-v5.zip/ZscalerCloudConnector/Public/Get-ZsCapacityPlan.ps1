<#
.SYNOPSIS
    Translates a throughput target into a recommended connector count and autoscale bounds.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Get-ZsCapacityPlan {
    <#
    .SYNOPSIS Computes Cloud Connector count and autoscale bounds from a throughput target.
    .DESCRIPTION Translates a monthly data volume (or a direct peak Gbps figure) into a recommended
        connector count, minimum count, and autoscale ceiling, sizing for peak rather than average.

        IMPORTANT: The per-connector throughput figure is an input you must confirm with Zscaler for the
        current Cloud Connector version. The default below is a labeled placeholder, not an authoritative
        Zscaler specification. Current Zscaler guidance is to scale horizontally with the Small form factor
        (Medium and Large are deprecated). Final capacity must be validated with a load test; this function
        produces a planning estimate only.
    .PARAMETER MonthlyTB Target monthly data volume in terabytes. Used if PeakGbps is not supplied.
    .PARAMETER PeakGbps Direct peak throughput target in Gbps. Overrides MonthlyTB-derived peak.
    .PARAMETER PeakToAverageRatio Ratio of peak to average throughput. Default 3.5 for business-hours traffic.
    .PARAMETER PerConnectorMbps Sustained throughput per connector in Mbps. PLACEHOLDER default; confirm with Zscaler.
    .PARAMETER TargetUtilization Fraction of per-connector capacity to plan against, leaving headroom. Default 0.6.
    .PARAMETER Redundancy Extra connectors for N+ resilience. Default 1 (N+1).
    .OUTPUTS PSCustomObject with the derived peak, recommended count, min, and autoscale max.
    .EXAMPLE
    Get-ZsCapacityPlan -MonthlyTB 115 -PerConnectorMbps 500
    Derives the recommended connector count and autoscale bounds from a monthly volume and a confirmed per-connector throughput.
    #>
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [double]$MonthlyTB = 0,
        [double]$PeakGbps = 0,
        [ValidateRange(1.0, 10.0)][double]$PeakToAverageRatio = 3.5,
        [ValidateRange(1, 100000)][int]$PerConnectorMbps = 500,
        [ValidateRange(0.1, 1.0)][double]$TargetUtilization = 0.6,
        [ValidateRange(0, 10)][int]$Redundancy = 1
    )

    if ($PeakGbps -le 0 -and $MonthlyTB -le 0) {
        Write-ZsError -Message 'Provide a target: either -MonthlyTB or -PeakGbps.' -ErrorId 'ZsCapacityNoTarget' -Cmdlet $PSCmdlet
    }

    $secondsPerMonth = 30.4 * 24 * 3600
    $derivedAvgGbps = 0.0
    if ($MonthlyTB -gt 0) {
        $derivedAvgGbps = ($MonthlyTB * 8000) / $secondsPerMonth
    }
    if ($PeakGbps -le 0) {
        $PeakGbps = $derivedAvgGbps * $PeakToAverageRatio
    }

    $peakMbps          = $PeakGbps * 1000
    $effectivePerCc    = $PerConnectorMbps * $TargetUtilization
    $connectorsForPeak = [math]::Ceiling($peakMbps / $effectivePerCc)
    $recommended       = [int]$connectorsForPeak + $Redundancy
    if ($recommended -lt 2) { $recommended = 2 }

    $minCount = [int]$connectorsForPeak
    if ($minCount -lt 2) { $minCount = 2 }
    $maxCount = $recommended * 2

    # The portal refuses joins past 16 VMs per EC group (one group per scale set), so a
    # recommendation above 16 per zone is capacity that can never register. Capacity beyond
    # the cap comes from additional zones, not a larger ceiling.
    $portalCapped = $false
    if ($maxCount -gt 16) { $maxCount = 16; $portalCapped = $true }
    if ($minCount -gt 16) { $minCount = 16; $portalCapped = $true }

    return [PSCustomObject]@{
        MonthlyTB            = $MonthlyTB
        DerivedAvgGbps       = [math]::Round($derivedAvgGbps, 3)
        PeakToAverageRatio   = $PeakToAverageRatio
        PlannedPeakGbps      = [math]::Round($PeakGbps, 3)
        PerConnectorMbps     = $PerConnectorMbps
        TargetUtilization    = $TargetUtilization
        EffectivePerCcMbps   = [math]::Round($effectivePerCc, 1)
        ConnectorsForPeak    = [int]$connectorsForPeak
        RecommendedCount     = $recommended
        AutoscaleMin         = $minCount
        AutoscaleMax         = $maxCount
        PortalGroupLimit     = 16
        Caveat               = $(if ($portalCapped) { 'Autoscale numbers are capped at the portal limit of 16 VMs per EC group; meet the remaining demand with additional zones. PerConnectorMbps is a placeholder. Confirm with Zscaler and validate with a load test.' } else { 'PerConnectorMbps is a placeholder. Confirm with Zscaler and validate with a load test.' })
    }
}
