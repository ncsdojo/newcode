<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (New-ZsMonitorPrivateLink).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function New-ZsMonitorPrivateLink {
    <#
    .SYNOPSIS Places the deployment's telemetry path behind Azure Monitor Private Link.
    .DESCRIPTION Creates an Azure Monitor Private Link Scope with ingestion in PrivateOnly mode,
        scopes the Log Analytics workspace and Application Insights component into it, provisions
        a Private Endpoint with the four Azure Monitor privatelink DNS zones, and then disables
        public ingestion on both resources — in that order, so telemetry never has a window with
        no accepted path.

        Query access stays public — Entra-authenticated and RBAC-scoped either way — unless
        -PrivateQueryAccess closes it. Connector custom metrics (smedge_metrics) are the stated
        boundary: Azure Monitor does not support them over Private Link, so that path remains
        managed-identity-authenticated over TLS through the NAT egress.

    .PARAMETER ComponentId Resource ID of the Application Insights component to scope. The
        backing workspace is resolved from it.
    .PARAMETER PrivateEndpointSubnetId Subnet for the Private Endpoint NICs.
    .PARAMETER VnetId VNet resource ID for the privatelink zone links.
    .PARAMETER PrivateQueryAccess Also closes public query access on the scope, workspace, and
        component. Portal and CLI queries then work only from inside the VNet.
    .PARAMETER PrivateDnsZoneResourceGroupName Resource group of the platform's privatelink zones, in a
        hub-and-spoke network; the endpoint registers there instead of in zones this deployment creates.
    .PARAMETER PrivateDnsZoneSubscriptionId Subscription of those zones, when not the deployment's.
    .OUTPUTS PSCustomObject with ScopeId, PrivateEndpointId, and the zones linked.
    .EXAMPLE
    New-ZsMonitorPrivateLink -ComponentId $appi.Id -PrivateEndpointSubnetId $subnet -VnetId $vnet
    Scopes the deployment's telemetry behind Private Link with public ingestion disabled.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$ComponentId,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$PrivateEndpointSubnetId,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$VnetId,
        [switch]$PrivateQueryAccess,
        [string]$PrivateDnsZoneResourceGroupName = '',
        [string]$PrivateDnsZoneSubscriptionId = ''
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $tags = Get-ZsTags; $rgPath = Get-ZsRgPath
        $shortId = $script:ZsSession.ShortId
        $plsApi = $script:ApiVersions.PrivateLinkScope
        $queryMode = if ($PrivateQueryAccess) { 'PrivateOnly' } else { 'Open' }

        $scopeName = "ampls-zscc-$shortId"
        $scopePath = "$rgPath/providers/microsoft.insights/privateLinkScopes/$scopeName"

        $monitorZones = @(
            'privatelink.monitor.azure.com'
            'privatelink.oms.opinsights.azure.com'
            'privatelink.ods.opinsights.azure.com'
            'privatelink.agentsvc.azure-automation.net'
        )

        # A dry run over an existing scope goes through the writes below, each of which asks first.
        # Without one, or before the component exists, placeholders stand in for what would be created.
        $scopeCheck = Test-ArmResource -Uri "$scopePath`?api-version=$plsApi"
        if ($WhatIfPreference -and ($ComponentId -match '^\(' -or -not $scopeCheck.Exists)) {
            return [PSCustomObject]@{
                ScopeName=$scopeName; ScopeId='(created at deploy time)'
                PrivateEndpointId='(created at deploy time)'
                Zones=$monitorZones
                IngestionAccess='PrivateOnly'; QueryAccess=$queryMode
            }
        }

        # Resolve the workspace from the component so both land in the scope together.
        $comp = Invoke-ArmGet -Uri "$ComponentId`?api-version=$($script:ApiVersions.AppInsights)"
        # A classic (non-workspace) component omits WorkspaceResourceId from the response
        # entirely, and under strict mode an absent property throws before the intended
        # message below could ever fire. The guarded read lets the real explanation win.
        $wsProp = $comp.properties.PSObject.Properties['WorkspaceResourceId']
        $workspaceId = if ($wsProp) { "$($wsProp.Value)" } else { '' }
        if (-not $workspaceId) {
            throw [System.InvalidOperationException]::new("Component $ComponentId has no backing workspace; a workspace-based component is required for Private Link.")
        }

        # The scope. Ingestion is the control being bought; query mode follows the parameter.
        if ($PSCmdlet.ShouldProcess($scopeName, "$(if ($scopeCheck.Exists) { 'Update' } else { 'Create' }) Azure Monitor Private Link Scope")) {
            Invoke-ArmPut -Uri "$scopePath`?api-version=$plsApi" -Body @{
                location='global'; tags=$tags
                properties=@{
                    accessModeSettings=@{ ingestionAccessMode='PrivateOnly'; queryAccessMode=$queryMode }
                }
            } | Out-Null
            Add-ZsManifestResource -Type 'PrivateLinkScope' -Name $scopeName -ResourceId $scopePath
            Write-ZsLog "Private Link Scope $scopeName ready (ingestion=PrivateOnly, query=$queryMode)"

            foreach ($scoped in @(
                    @{ Name='scoped-workspace'; Id=$workspaceId }
                    @{ Name='scoped-component'; Id=$ComponentId }
                )) {
                Invoke-ArmPut -Uri "$scopePath/scopedResources/$($scoped.Name)`?api-version=$plsApi" -Body @{
                    properties=@{ linkedResourceId=$scoped.Id }
                } | Out-Null
            }
            Write-ZsLog "Workspace and component scoped into $scopeName"
        }

        # Private Endpoint for the scope, with the four Azure Monitor zones. The zone group
        # populates each zone's records; DNS must exist before ingestion goes private.
        # Set-ZsPrivateEndpoint and Resolve-ZsPrivateDnsZone ask before each write they make.
        $peName = "pe-$scopeName"
        $pePath = "$rgPath/providers/Microsoft.Network/privateEndpoints/$peName"
        $zoneIds = @(foreach ($zone in $monitorZones) {
            Resolve-ZsPrivateDnsZone -ZoneName $zone -VnetId $VnetId `
                -HubResourceGroupName $PrivateDnsZoneResourceGroupName -HubSubscriptionId $PrivateDnsZoneSubscriptionId
        })
        $pe = Set-ZsPrivateEndpoint -Name $peName -TargetId $scopePath -GroupId 'azuremonitor' -SubnetId $PrivateEndpointSubnetId `
            -ZoneIds $zoneIds -Properties @{ DnsZones=($monitorZones -join ',') }
        if ([string]$pe.Id -notmatch '^\(') { Write-ZsLog "Azure Monitor Private Endpoint $peName in place with $($monitorZones.Count) DNS zones" }

        # Only now, with the private path standing, close the public ingestion doors.
        if ($PSCmdlet.ShouldProcess('workspace and component', 'Disable public ingestion')) {
            $queryFlag = if ($PrivateQueryAccess) { 'Disabled' } else { 'Enabled' }

            $waUri = "$workspaceId`?api-version=$($script:ApiVersions.LogAnalytics)"
            $wa = Invoke-ArmGet -Uri $waUri
            $wa.properties | Add-Member -NotePropertyName 'publicNetworkAccessForIngestion' -NotePropertyValue 'Disabled' -Force
            $wa.properties | Add-Member -NotePropertyName 'publicNetworkAccessForQuery' -NotePropertyValue $queryFlag -Force
            Invoke-ArmPut -Uri $waUri -Body @{ location=$wa.location; tags=$wa.tags; properties=$wa.properties } | Out-Null

            $aiUri = "$ComponentId`?api-version=$($script:ApiVersions.AppInsights)"
            $ai = Invoke-ArmGet -Uri $aiUri
            $ai.properties | Add-Member -NotePropertyName 'publicNetworkAccessForIngestion' -NotePropertyValue 'Disabled' -Force
            $ai.properties | Add-Member -NotePropertyName 'publicNetworkAccessForQuery' -NotePropertyValue $queryFlag -Force
            Invoke-ArmPut -Uri $aiUri -Body @{ location=$ai.location; tags=$ai.tags; kind=$ai.kind; properties=$ai.properties } | Out-Null

            Write-ZsLog "Public ingestion disabled on workspace and component; telemetry accepted only via $peName (query=$queryFlag)"
        }

        return [PSCustomObject]@{
            ScopeName=$scopeName; ScopeId=$scopePath; PrivateEndpointId=$pePath
            Zones=$monitorZones
            IngestionAccess='PrivateOnly'; QueryAccess=$queryMode
        }
    }
}
