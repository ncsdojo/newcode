<#
.SYNOPSIS
    Creates the hardened management, service and Function App network security groups.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function New-ZsNetworkSecurity {
    <#
    .SYNOPSIS Creates hardened management and service NSGs per Zscaler reference architecture, and the
        Function App subnet's NSG when asked.
    .DESCRIPTION The rule sets are the Terraform nsg module's, rule for rule. Groups this module created
        are brought back to these rules on every run, so a 5.4.1.0 deployment picks up the rules added
        since.
    .PARAMETER SshSourceCidr Source CIDR for SSH inbound. Restrict to bastion/jump host CIDR in production.
    .PARAMETER WorkloadCidrs Specific workload CIDRs for service NSG inbound. Defaults to VirtualNetwork.
    .PARAMETER EnableSupportTunnel Allow the connectors' outbound TCP 12002 to Zscaler's remote-support server.
    .PARAMETER SupportServerIp The remote-support server's address (remotesupport.<cloud>.net). Defaults to
        the commercial-cloud address Zscaler's own module uses.
    .PARAMETER PrivateEndpointClientCidrs The management and Function App subnet ranges: the only clients of
        the private endpoints in the management subnet, allowed in on TCP 443 there. Empty leaves the rule out.
    .PARAMETER FunctionAppNsg Also create the Function App subnet's NSG: its outbound firewall under
        route-all VNet integration, allowing HTTPS, HTTP and DNS only.
    .PARAMETER ServiceAllowAllOutbound Allow every port outbound from the service subnet to the internet,
        as Zscaler's own module does. Without it the service NSG allows only what tunnelled and Azure
        Virtual Desktop traffic need, and drops traffic the forwarding policy sends DIRECT on any other port.
    .EXAMPLE
    New-ZsNetworkSecurity -PrivateEndpointClientCidrs 10.0.1.0/26,10.0.4.0/27 -FunctionAppNsg
    Creates the management, service and Function App NSGs with the deny-by-default rule sets.
    #>
    [CmdletBinding(SupportsShouldProcess, PositionalBinding = $false)]
    [OutputType([PSCustomObject])]
    param(
        [switch]$EnableSupportTunnel,
        [string]$SupportServerIp = '',
        [ValidateNotNullOrEmpty()][string]$SshSourceCidr = 'VirtualNetwork',
        [string[]]$WorkloadCidrs = @(),
        [ValidateRange(1,65535)][int]$HttpProbePort = 50000,
        [string]$BastionSubnetCidr = '',
        [string[]]$PrivateEndpointClientCidrs = @(),
        [switch]$FunctionAppNsg,
        [switch]$ServiceAllowAllOutbound
    )

    begin { Assert-ZsConnected -Cmdlet $PSCmdlet }
    process {
        $env = $script:ZsSession.Environment; $loc = $script:ZsSession.Location

        # SSH source: Bastion subnet when deployed, otherwise configurable.
        $sshSource = if ($BastionSubnetCidr) { $BastionSubnetCidr } else { $SshSourceCidr }
        if (-not $SupportServerIp) { $SupportServerIp = $script:ZsSupportServerIp }
        $peClients = @($PrivateEndpointClientCidrs | Where-Object { $_ } | ForEach-Object { [string]$_ } | Select-Object -Unique)

        # These reach ARM as address prefixes but never went through the CIDR validation every
        # subnet gets, so a typo surfaced as an ARM rejection partway through the deployment.
        # Service tags (VirtualNetwork, Internet, AzureLoadBalancer) are legal values here too,
        # so only dotted-quad-looking values are checked.
        $badCidrs = [System.Collections.Generic.List[string]]::new()
        if ($sshSource -match '^\d' -and -not (Test-ZsCidr -Cidr $sshSource)) { $badCidrs.Add("SshSourceCidr='$sshSource'") }
        foreach ($wc in $WorkloadCidrs) {
            if (-not (Test-ZsCidr -Cidr ([string]$wc))) { $badCidrs.Add("WorkloadCidrs entry '$wc'") }
        }
        foreach ($pc in $peClients) {
            if (-not (Test-ZsCidr -Cidr $pc)) { $badCidrs.Add("PrivateEndpointClientCidrs entry '$pc'") }
        }
        if ($SupportServerIp -notmatch '^\d{1,3}(\.\d{1,3}){3}$' -or -not (Test-ZsCidr -Cidr "$SupportServerIp/32")) {
            $badCidrs.Add("SupportServerIp='$SupportServerIp' (a single IPv4 address, without a prefix length)")
        }
        if ($badCidrs.Count -gt 0) {
            Write-ZsError -Message ("Invalid NSG address prefix(es): " + ($badCidrs -join ', ') + ". Each must be valid IPv4 CIDR notation (for example 10.20.0.0/24).") -ErrorId 'ZsInvalidNsgCidr' -Cmdlet $PSCmdlet
        }

        # An NSG rule carries either sourceAddressPrefix (one value) or sourceAddressPrefixes (a
        # list). Joining a list into the singular field produces a string ARM rejects outright with
        # InvalidAddressPrefix, so the shape follows the count.
        $svcSrcProps = if ($WorkloadCidrs.Count -gt 1) {
            @{ sourceAddressPrefixes = @($WorkloadCidrs) }
        } elseif ($WorkloadCidrs.Count -eq 1) {
            @{ sourceAddressPrefix = [string]$WorkloadCidrs[0] }
        } else {
            @{ sourceAddressPrefix = 'VirtualNetwork' }
        }

        $mgmtRules = [System.Collections.Generic.List[object]]::new()
        $mgmtRules.Add(@{ name = 'AllowSSH';          properties = @{ priority=100; direction='Inbound';  access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='22';            sourceAddressPrefix=$sshSource;   destinationAddressPrefix='*' } })
        $mgmtRules.Add(@{ name = 'AllowLBProbeIn';    properties = @{ priority=110; direction='Inbound';  access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange="$HttpProbePort"; sourceAddressPrefix='AzureLoadBalancer'; destinationAddressPrefix='*' } })
        $mgmtRules.Add(@{ name = 'AllowICMP';         properties = @{ priority=120; direction='Inbound';  access='Allow'; protocol='Icmp'; sourcePortRange='*'; destinationPortRange='*';             sourceAddressPrefix='VirtualNetwork'; destinationAddressPrefix='VirtualNetwork' } })
        # The Key Vault, function storage and optional Function App private endpoints sit in this
        # subnet. With endpoint network policies off, as this deployment sets them, the NSG does
        # not apply to them; if they are ever turned on, this rule keeps the connectors and the
        # function reaching the endpoints instead of DenyAllIn cutting them off. Its sources are
        # those two subnets only, so TCP 443 on the connectors' management NICs opens to nothing else.
        if ($peClients.Count -gt 0) {
            $mgmtRules.Add(@{ name = 'AllowPrivateEndpointsIn'; properties = @{ priority=130; direction='Inbound'; access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='443'; sourceAddressPrefixes=@($peClients); destinationAddressPrefix='*' } })
        }
        $mgmtRules.Add(@{ name = 'DenyAllIn';         properties = @{ priority=4096; direction='Inbound'; access='Deny';  protocol='*';   sourcePortRange='*'; destinationPortRange='*';              sourceAddressPrefix='*'; destinationAddressPrefix='*' } })
        $mgmtRules.Add(@{ name = 'AllowDTLS';         properties = @{ priority=100; direction='Outbound'; access='Allow'; protocol='Udp'; sourcePortRange='*'; destinationPortRange='443';            sourceAddressPrefix='*'; destinationAddressPrefix='Internet' } })
        $mgmtRules.Add(@{ name = 'AllowTLS';          properties = @{ priority=110; direction='Outbound'; access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='443';            sourceAddressPrefix='*'; destinationAddressPrefix='Internet' } })
        $mgmtRules.Add(@{ name = 'AllowHTTP';         properties = @{ priority=120; direction='Outbound'; access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='80';             sourceAddressPrefix='*'; destinationAddressPrefix='Internet' } })
        $mgmtRules.Add(@{ name = 'AllowDNSTcp';       properties = @{ priority=130; direction='Outbound'; access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='53';             sourceAddressPrefix='*'; destinationAddressPrefix='*' } })
        $mgmtRules.Add(@{ name = 'AllowDNSUdp';       properties = @{ priority=131; direction='Outbound'; access='Allow'; protocol='Udp'; sourcePortRange='*'; destinationPortRange='53';             sourceAddressPrefix='*'; destinationAddressPrefix='*' } })
        $mgmtRules.Add(@{ name = 'AllowNTP';          properties = @{ priority=140; direction='Outbound'; access='Allow'; protocol='Udp'; sourcePortRange='*'; destinationPortRange='123';            sourceAddressPrefix='*'; destinationAddressPrefix='*' } })
        $mgmtRules.Add(@{ name = 'AllowVnetOut';      properties = @{ priority=150; direction='Outbound'; access='Allow'; protocol='*';   sourcePortRange='*'; destinationPortRange='*';              sourceAddressPrefix='VirtualNetwork'; destinationAddressPrefix='VirtualNetwork' } })
        $mgmtRules.Add(@{ name = 'DenyAllOut';        properties = @{ priority=4096; direction='Outbound'; access='Deny'; protocol='*';   sourcePortRange='*'; destinationPortRange='*';              sourceAddressPrefix='*'; destinationAddressPrefix='*' } })
        if ($EnableSupportTunnel) {
            # How Zscaler Support reaches a connector to assist: the connector connects out to the
            # remote-support server on TCP 12002. Limited to that one address, as in Zscaler's module.
            $mgmtRules.Add(@{ name = 'AllowSupport'; properties = @{ priority=145; direction='Outbound'; access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='12002'; sourceAddressPrefix='*'; destinationAddressPrefix=$SupportServerIp } })
        }

        $svcRules = @(
            @{ name = 'AllowWorkload';     properties = (@{ priority=100;  direction='Inbound';  access='Allow'; protocol='*';   sourcePortRange='*'; destinationPortRange='*';              destinationAddressPrefix='*' } + $svcSrcProps) }
            @{ name = 'AllowLBProbeIn';    properties = @{ priority=110;  direction='Inbound';  access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange="$HttpProbePort"; sourceAddressPrefix='AzureLoadBalancer'; destinationAddressPrefix='*' } }
            @{ name = 'DenyInternetIn';    properties = @{ priority=4096; direction='Inbound';  access='Deny';  protocol='*';   sourcePortRange='*'; destinationPortRange='*';              sourceAddressPrefix='Internet';       destinationAddressPrefix='*' } }
            @{ name = 'AllowDTLS';         properties = @{ priority=100;  direction='Outbound'; access='Allow'; protocol='Udp'; sourcePortRange='*'; destinationPortRange='443';            sourceAddressPrefix='*'; destinationAddressPrefix='Internet' } }
            @{ name = 'AllowTLS';          properties = @{ priority=110;  direction='Outbound'; access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='443';            sourceAddressPrefix='*'; destinationAddressPrefix='Internet' } }
            @{ name = 'AllowVnetOut';      properties = @{ priority=120;  direction='Outbound'; access='Allow'; protocol='*';   sourcePortRange='*'; destinationPortRange='*';              sourceAddressPrefix='VirtualNetwork'; destinationAddressPrefix='VirtualNetwork' } }
            # Tunnelled traffic leaves on 443 whatever the workload asked for. Traffic the forwarding
            # policy sends DIRECT leaves on its own destination port, and three endpoints Azure
            # Virtual Desktop session hosts need are not on 443: certificate checks on TCP 80,
            # Windows activation (azkms.core.windows.net) on TCP 1688, and relayed RDP on UDP 3478.
            # AllowHTTP is a hard requirement beyond AVD: certificate revocation lookups (CRL and
            # OCSP) are plain HTTP, from the connectors and from every workload whose traffic leaves
            # through them. Keep it on any NSG the platform team attaches in place of this one.
            @{ name = 'AllowHTTP';         properties = @{ priority=130;  direction='Outbound'; access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='80';             sourceAddressPrefix='*'; destinationAddressPrefix='Internet' } }
            @{ name = 'AllowKMS';          properties = @{ priority=140;  direction='Outbound'; access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='1688';           sourceAddressPrefix='*'; destinationAddressPrefix='Internet' } }
            @{ name = 'AllowRDPRelay';     properties = @{ priority=150;  direction='Outbound'; access='Allow'; protocol='Udp'; sourcePortRange='*'; destinationPortRange='3478';           sourceAddressPrefix='*'; destinationAddressPrefix='WindowsVirtualDesktop' } }
            @{ name = 'DenyAllOut';        properties = @{ priority=4096; direction='Outbound'; access='Deny';  protocol='*';   sourcePortRange='*'; destinationPortRange='*';              sourceAddressPrefix='*'; destinationAddressPrefix='*' } }
        )
        if ($ServiceAllowAllOutbound) {
            # For a forwarding policy that sends traffic DIRECT on other ports: every port to the
            # internet, as Zscaler's own module allows out of the service subnet.
            $svcRules += @{ name = 'AllowAllOut'; properties = @{ priority=160; direction='Outbound'; access='Allow'; protocol='*'; sourcePortRange='*'; destinationPortRange='*'; sourceAddressPrefix='*'; destinationAddressPrefix='Internet' } }
        }

        # One management and one service NSG for the whole deployment, shared by every zone's
        # connectors, the way the StandardV2 NAT gateway and the shared subnets are.
        $mgmtName = "nsg-zscc-mgmt-$env-$loc"
        $svcName  = "nsg-zscc-svc-$env-$loc"
        $funcName = "nsg-zscc-func-$env-$loc"

        $mgmtId = Set-ZsNsg -Name $mgmtName -Rules $mgmtRules.ToArray() -Role 'Management'
        $svcId  = Set-ZsNsg -Name $svcName  -Rules $svcRules -Role 'Service'
        $funcId = ''
        if ($FunctionAppNsg) { $funcId = Set-ZsNsg -Name $funcName -Rules (Get-ZsFuncAppNsgRuleSet) -Role 'FunctionApp' }

        # Under -WhatIf, Set-ZsNsg returns the ID of a group that exists and a placeholder for one it
        # would create, so a dry run over an existing deployment previews the associations too.
        return [PSCustomObject]@{ MgmtNsgId=$mgmtId; ServiceNsgId=$svcId; FuncAppNsgId=$funcId }
    }
}
