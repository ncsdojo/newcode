<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module — environment validation and capability checks.

.DESCRIPTION
    Read-only checks against Azure and the Zscaler cloud that a deployment consults before or after
    it builds resources: VM-size capabilities (accelerated networking, encryption-at-host), region and
    availability-zone support, Key Vault reachability from the connector's network path, and post-deploy
    connector registration. None of these mutate state; they return structured results the caller acts on.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Test-AcceleratedNetworkingSupport {
    [CmdletBinding()]
    [OutputType([bool])]
    param([Parameter(Mandatory)][string]$VmSize)

    $uri = "$(Get-ZsSubscriptionPath)/providers/Microsoft.Compute/locations/$($script:ZsSession.Location)/vmSizes?api-version=$($script:ApiVersions.Compute)"
    try {
        $skus = Invoke-ArmGet -Uri $uri
        $match = $skus.value | Where-Object { $_.name -eq $VmSize }
        if (-not $match) {
            Write-ZsLog "$VmSize not found in $($script:ZsSession.Location), disabling accelerated networking" -Level WARN
            return $false
        }
        return ($match.numberOfCores -ge 2 -and $match.memoryInMB -ge 3584)
    } catch {
        Write-ZsLog "Accelerated networking check failed, defaulting to enabled" -Level WARN
        return $true
    }
}

function Test-EncryptionAtHostSupport {
    [CmdletBinding()]
    [OutputType([bool])]
    param([Parameter(Mandatory)][string]$VmSize)

    $uri = "$(Get-ZsSubscriptionPath)/providers/Microsoft.Compute/skus?api-version=$($script:ApiVersions.Compute)&`$filter=location eq '$($script:ZsSession.Location)'"
    try {
        $skus = Invoke-ArmGet -Uri $uri
        $match = $skus.value | Where-Object { $_.resourceType -eq 'virtualMachines' -and $_.name -eq $VmSize } | Select-Object -First 1
        if (-not $match) {
            Write-ZsLog "$VmSize capabilities not found, leaving encryption-at-host off" -Level WARN
            return $false
        }
        $cap = $match.capabilities | Where-Object { $_.name -eq 'EncryptionAtHostSupported' }
        return ($cap -and $cap.value -eq 'True')
    } catch {
        Write-ZsLog "Encryption-at-host capability check failed, leaving it off" -Level WARN
        return $false
    }
}

function Resolve-ZsZones {
    <#
    .SYNOPSIS Resolves the zones a deployment will actually use, from a requested set and the live
        subscription/region/VM-size availability, under an explicit policy.
    .DESCRIPTION Single decision point for zone selection so behaviour is identical no matter who runs
        it or where. Takes the requested zones (which may be the sentinel 'auto') and reconciles them
        against what Test-ZsZoneSupport reports for the current session's region and the given VM size.

        Policy governs what happens when the request and reality diverge:
          Strict  (default) — any requested zone that is not usable is an error. The deployment does not
                              proceed with a silently reduced set. This preserves the operator's stated
                              resilience intent: if they asked for two zones and only one is available,
                              they must decide, not have it decided for them.
          Adapt            — intersect the request with what's usable and proceed with the result,
                              recording that a change was made so the caller can log it loudly. Never
                              silent, but does not block.
          Auto  (sentinel) — when Requested is 'auto', use every usable zone in the region. Portable
                              across subscriptions and regions; the result is whatever the subscription
                              can actually do.

        Returns the resolved set plus enough context for the caller to message or fail precisely.
    .PARAMETER Requested The requested zones: a string array, or a single-element array containing 'auto'.
    .PARAMETER VmSize The VM size the zones must support.
    .PARAMETER Policy How to reconcile a request that exceeds availability: 'Strict' or 'Adapt'. Ignored
        for the 'auto' sentinel, which always uses the full usable set.
    .OUTPUTS PSCustomObject: Zones (string[] resolved), Requested (string[]), Usable (string[]),
        Offered (string[]), Dropped (string[]), Mode (string), Changed (bool), Ok (bool), Reason (string).
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][string[]]$Requested,
        [Parameter(Mandatory)][string]$VmSize,
        [ValidateSet('Strict','Adapt')][string]$Policy = 'Strict'
    )

    $info = Test-ZsZoneSupport -VmSize $VmSize
    $usable  = @($info.SupportedZones | Sort-Object)
    $offered = @($info.SupportedZones)  # SupportedZones already excludes restrictions; offered kept for context
    $isAuto  = ($Requested.Count -eq 1 -and $Requested[0] -ieq 'auto')

    # Region offers no usable zones at all for this size.
    if ($usable.Count -eq 0) {
        $reason = if (-not $info.SizeFound) {
            "VM size $VmSize is not offered in $($script:ZsSession.Location)."
        } elseif (-not $info.RegionHasZones) {
            "Region $($script:ZsSession.Location) does not offer availability zones for $VmSize."
        } else {
            "No usable zones for $VmSize in $($script:ZsSession.Location) (all restricted for this subscription)."
        }
        return [PSCustomObject]@{
            Zones=@(); Requested=$Requested; Usable=@(); Offered=$offered; Dropped=@()
            Mode=$(if($isAuto){'Auto'}else{$Policy}); Changed=$false; Ok=$false; Reason=$reason
        }
    }

    if ($isAuto) {
        return [PSCustomObject]@{
            Zones=$usable; Requested=$Requested; Usable=$usable; Offered=$offered; Dropped=@()
            Mode='Auto'; Changed=$true; Ok=$true
            Reason="Auto-selected all usable zones in $($script:ZsSession.Location): $($usable -join ', ')."
        }
    }

    $req     = @($Requested | Sort-Object)
    $keep    = @($req | Where-Object { $_ -in $usable })
    $dropped = @($req | Where-Object { $_ -notin $usable })

    if ($dropped.Count -eq 0) {
        return [PSCustomObject]@{
            Zones=$req; Requested=$req; Usable=$usable; Offered=$offered; Dropped=@()
            Mode=$Policy; Changed=$false; Ok=$true
            Reason="All requested zones ($($req -join ', ')) are usable in $($script:ZsSession.Location)."
        }
    }

    # Request exceeds availability.
    if ($Policy -eq 'Adapt') {
        return [PSCustomObject]@{
            Zones=$keep; Requested=$req; Usable=$usable; Offered=$offered; Dropped=$dropped
            Mode='Adapt'; Changed=$true; Ok=($keep.Count -gt 0)
            Reason="Adapted to subscription limits in $($script:ZsSession.Location): dropped zone(s) $($dropped -join ', '), using $($keep -join ', '). Resilience is reduced from the requested spread."
        }
    }

    # Strict: fail with the specific gap.
    return [PSCustomObject]@{
        Zones=@(); Requested=$req; Usable=$usable; Offered=$offered; Dropped=$dropped
        Mode='Strict'; Changed=$false; Ok=$false
        Reason="Zone(s) $($dropped -join ', ') not usable for $VmSize in $($script:ZsSession.Location). Usable zones: $($usable -join ', '). Set Zones to a usable subset, use 'auto', or pass -AdaptZones to deploy across only the usable zones."
    }
}

function Get-ZsUsableZones {
    <#
    .SYNOPSIS Reports the availability zones the current subscription can use for a VM size in the connected region.
    .DESCRIPTION Operator-facing discovery. After Connect-ZscalerAzure, this answers "which zones can I
        actually deploy into here?" by reading Microsoft.Compute/skus live — the region's zone offering
        minus this subscription's restrictions. Use it to choose Zones for a config, or to scan regions
        before committing. Works for any subscription, region, and size.
    .PARAMETER VmSize The VM size to check. Defaults to the module's connector default.
    .PARAMETER Location Region to check. Defaults to the connected session's region. Supplying this
        checks a different region without reconnecting.
    .EXAMPLE
    Get-ZsUsableZones -VmSize Standard_D2s_v3
    Shows usable zones for that size in the connected region.
    .EXAMPLE
    'westus2','westus3','centralus' | ForEach-Object { Get-ZsUsableZones -Location $_ }
    Scans several regions for usable zones.
    .OUTPUTS PSCustomObject: Location, VmSize, Offered (string[]), Usable (string[]), Restricted (bool).
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [string]$VmSize = $script:CcImage.DefaultVmSize,
        [string]$Location = ''
    )
    Assert-ZsConnected -Cmdlet $PSCmdlet
    if (-not $VmSize) { $VmSize = 'Standard_D2s_v3' }

    $restore = $script:ZsSession.Location
    if ($Location) { $script:ZsSession.Location = $Location }
    try {
        $info = Test-ZsZoneSupport -VmSize $VmSize
        [PSCustomObject]@{
            Location   = $script:ZsSession.Location
            VmSize     = $VmSize
            Offered    = @($info.OfferedZones | Sort-Object)
            Usable     = @($info.SupportedZones | Sort-Object)
            Restricted = [bool]$info.Restricted
            SizeFound  = [bool]$info.SizeFound
        }
    } finally {
        $script:ZsSession.Location = $restore
    }
}


function Test-ZsRegion {
    <#
    .SYNOPSIS Validates a region name against the subscription's available locations and reports whether it supports availability zones.
    .DESCRIPTION Calls Microsoft's per-subscription locations list, which is authoritative for both
        whether a region name is valid and whether the subscription is entitled to it. The physical
        region entries carry availabilityZoneMappings when the region is zone-enabled. Returns a
        structured result the caller uses to fail fast with a friendly, specific message: unknown
        region name, versus a valid region that simply has no zones.
    .PARAMETER Region The region name to validate (for example 'westus2').
    .OUTPUTS PSCustomObject: Exists (bool), HasZones (bool), DisplayName (string),
        Suggestions (string[]) — up to a handful of near-name matches when Exists is false.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param([Parameter(Mandatory)][string]$Region)

    $norm = ($Region -replace '\s','').ToLower()
    $uri  = "$(Get-ZsSubscriptionPath)/locations?api-version=$($script:ApiVersions.Subscription)"
    try {
        $locs = Invoke-ArmGet -Uri $uri
        $all  = @($locs.value)
        # Match on the canonical name (e.g. 'westus2'); regionalDisplayName is human text.
        $match = $all | Where-Object { $_.name -eq $norm } | Select-Object -First 1
        if (-not $match) {
            # Offer near matches so a typo gets a helpful nudge rather than a bare failure.
            $suggest = @($all |
                Where-Object { $_.metadata.regionType -eq 'Physical' } |
                Where-Object { $_.name -like "*$norm*" -or $norm -like "*$($_.name)*" -or ($_.displayName -and $_.displayName.ToLower().Replace(' ','') -like "*$norm*") } |
                ForEach-Object { $_.name } | Select-Object -First 6)
            return [PSCustomObject]@{ Exists=$false; HasZones=$false; DisplayName=''; Suggestions=$suggest; Inconclusive=$false }
        }

        # Zone capability: physical, zone-enabled regions expose availabilityZoneMappings.
        $hasZones = $false
        if ($match.availabilityZoneMappings -and @($match.availabilityZoneMappings).Count -gt 0) { $hasZones = $true }

        return [PSCustomObject]@{
            Exists      = $true
            HasZones    = $hasZones
            DisplayName = if ($match.displayName) { $match.displayName } else { $match.regionalDisplayName }
            Suggestions = @(); Inconclusive=$false }
    } catch {
        # Inconclusive (transient ARM error or an API that omits the field): don't block, but log.
        Write-ZsLog "Region validation for '$Region' was inconclusive: $($_.Exception.Message)" -Level WARN
        return [PSCustomObject]@{ Exists=$true; HasZones=$true; DisplayName=$Region; Suggestions=@(); Inconclusive=$true }
    }
}

function Test-ZsZoneSupport {
    <#
    .SYNOPSIS Returns the availability zones a VM size actually supports in the session's region.
    .DESCRIPTION Queries Microsoft.Compute/skus, which reports per-region zone availability in
        locationInfo[].zones, and cross-references restrictions (a size can be listed for a region
        yet be restricted from zonal allocation on a given subscription). Returns an object with the
        set of usable zones plus enough context for the caller to produce an actionable message.
        Regions without zone support return an empty Zones set; the caller decides whether that is
        fatal (zones requested) or acceptable (no zones requested).
    .OUTPUTS PSCustomObject: RegionHasZones (bool), SupportedZones (string[]), SizeFound (bool),
        Restricted (bool).
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param([Parameter(Mandatory)][string]$VmSize)

    $loc = $script:ZsSession.Location
    $uri = "$(Get-ZsSubscriptionPath)/providers/Microsoft.Compute/skus?api-version=$($script:ApiVersions.Compute)&`$filter=location eq '$loc'"
    try {
        $skus  = Invoke-ArmGet -Uri $uri
        $match = $skus.value | Where-Object { $_.resourceType -eq 'virtualMachines' -and $_.name -eq $VmSize } | Select-Object -First 1
        if (-not $match) {
            return [PSCustomObject]@{ RegionHasZones=$false; SupportedZones=@(); SizeFound=$false; Restricted=$false; OfferedZones=@() }
        }

        # locationInfo carries the zones this size is offered in for the region.
        $li = $match.locationInfo | Where-Object { $_.location -eq $loc } | Select-Object -First 1
        $offeredZones = @()
        if ($li -and $li.zones) { $offeredZones = @($li.zones | Sort-Object) }

        # A NotAvailableForSubscription restriction with a zone reasonCode removes specific zones
        # even when the region offers them. Subtract any zone-scoped restrictions.
        $restrictedZones = [System.Collections.Generic.List[string]]::new()
        $restricted = $false
        foreach ($r in @($match.restrictions)) {
            if ($r.type -eq 'Zone' -and $r.restrictionInfo -and $r.restrictionInfo.zones) {
                $restricted = $true
                foreach ($rz in $r.restrictionInfo.zones) { $restrictedZones.Add([string]$rz) }
            }
            elseif ($r.type -eq 'Location') {
                # Whole size restricted in the region.
                $restricted = $true
                $offeredZones = @()
            }
        }
        $usable = @($offeredZones | Where-Object { $_ -notin $restrictedZones })

        return [PSCustomObject]@{
            RegionHasZones = ($offeredZones.Count -gt 0)
            OfferedZones   = $offeredZones
            SupportedZones = $usable
            SizeFound      = $true
            Restricted     = $restricted
        }
    } catch {
        Write-ZsLog "Zone support check failed for $VmSize in ${loc}: $($_.Exception.Message)" -Level WARN
        return [PSCustomObject]@{ RegionHasZones=$false; OfferedZones=@(); SupportedZones=@(); SizeFound=$false; Restricted=$false }
    }
}
