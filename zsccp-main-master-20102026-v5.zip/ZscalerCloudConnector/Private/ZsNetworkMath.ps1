<#
.SYNOPSIS
    Network address helpers: IPv4/CIDR validation, containment and overlap checks, and the
    explicit per-subnet CIDR resolver used by the deployment.

.DESCRIPTION
    Provides the address-math primitives and the subnet-resolution contract for the module.
    Subnet CIDRs are never derived or defaulted. Every subnet required by the selected topology
    must be supplied explicitly, either as a runtime parameter or in the JSON configuration. If a
    required subnet CIDR is absent from both sources, resolution throws and names every missing
    subnet at once so the operator can correct them in a single pass.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function ConvertTo-ZsIpUInt {
    <#
    .SYNOPSIS Converts a dotted-quad IPv4 address to its 32-bit unsigned integer value.
    .PARAMETER IpAddress Dotted-quad IPv4 address.
    .OUTPUTS [uint32]
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([uint32])]
    param([Parameter(Mandatory)][string]$IpAddress)

    $octets = $IpAddress.Split('.')
    if ($octets.Count -ne 4) { throw [System.ArgumentException]::new("Invalid IPv4 address: $IpAddress") }
    # Accumulated in 64-bit and narrowed once at the end. Shifting a uint32 left by 8 on the final
    # octet crosses Int32.MaxValue for any address above 127.x — which includes every 192.168.0.0/16
    # deployment — and leaves the result dependent on how the shift operator promotes its operand.
    # Doing the arithmetic in a type that cannot overflow removes the question.
    [uint64]$value = 0
    foreach ($o in $octets) {
        if ($o -notmatch '^\d{1,3}$') { throw [System.ArgumentException]::new("Invalid octet in $IpAddress") }
        $n = [int]$o
        if ($n -gt 255) { throw [System.ArgumentException]::new("Octet out of range in $IpAddress") }
        $value = ($value * 256) + $n
    }
    return [uint32]$value
}

function ConvertFrom-ZsIpUInt {
    <#
    .SYNOPSIS Converts a 32-bit unsigned integer to a dotted-quad IPv4 address.
    .PARAMETER Value 32-bit unsigned integer.
    .OUTPUTS [string]
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param([Parameter(Mandatory)][uint32]$Value)

    return "$(($Value -shr 24) -band 0xFF).$(($Value -shr 16) -band 0xFF).$(($Value -shr 8) -band 0xFF).$($Value -band 0xFF)"
}

function Test-ZsCidr {
    <#
    .SYNOPSIS Validates that a string is a well-formed IPv4 CIDR in canonical network form.
    .DESCRIPTION Returns $true only for a syntactically valid IPv4 CIDR with a prefix length of 0
        to 32 whose host bits are clear. Azure rejects a prefix carrying host bits (10.0.1.5/24)
        with InvalidAddressPrefixFormat, so accepting it here only defers the failure into the
        middle of a deployment, which is what this validation exists to prevent.
        Does not test containment or overlap; those are separate checks.
    .PARAMETER Cidr Candidate CIDR string.
    .OUTPUTS [bool]
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([bool])]
    param([Parameter(Mandatory)][AllowEmptyString()][string]$Cidr)

    if ([string]::IsNullOrWhiteSpace($Cidr)) { return $false }
    if ($Cidr -notmatch '^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/\d{1,2}$') { return $false }
    $parts  = $Cidr.Split('/')
    $prefix = [int]$parts[1]
    if ($prefix -gt 32) { return $false }
    foreach ($o in $parts[0].Split('.')) { if ([int]$o -gt 255) { return $false } }

    # Host bits must be clear, so the address given is the network address.
    $base = ConvertTo-ZsIpUInt -IpAddress $parts[0]
    $mask = if ($prefix -eq 0) { [uint32]0 } else { [uint32]((0xFFFFFFFFL -shl (32 - $prefix)) -band 0xFFFFFFFFL) }
    if (($base -band $mask) -ne $base) { return $false }
    return $true
}

function Get-ZsCidrBounds {
    <#
    .SYNOPSIS Returns the network and broadcast bounds of a CIDR as unsigned integers.
    .PARAMETER Cidr A validated IPv4 CIDR.
    .OUTPUTS PSCustomObject with Start, End, and Prefix.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param([Parameter(Mandatory)][string]$Cidr)

    $parts  = $Cidr.Split('/')
    $prefix = [int]$parts[1]
    $base   = ConvertTo-ZsIpUInt -IpAddress $parts[0]
    $mask   = if ($prefix -eq 0) { [uint32]0 } else { [uint32]((0xFFFFFFFFL -shl (32 - $prefix)) -band 0xFFFFFFFFL) }
    $start  = $base -band $mask
    # Sized in 64-bit: a /0 spans 2^32 addresses, which does not fit a uint32, and computing the
    # size in the narrower type threw a cast error instead of returning bounds.
    [uint64]$size = [uint64]1 -shl (32 - $prefix)
    return [PSCustomObject]@{ Start = [uint64]$start; End = ([uint64]$start + $size - 1); Prefix = $prefix }
}

function Test-ZsCidrContains {
    <#
    .SYNOPSIS Tests whether an outer CIDR fully contains an inner CIDR.
    .PARAMETER Outer The containing CIDR (for example, the VNet range).
    .PARAMETER Inner The candidate subnet CIDR.
    .OUTPUTS [bool]
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([bool])]
    param([Parameter(Mandatory)][string]$Outer, [Parameter(Mandatory)][string]$Inner)

    $o = Get-ZsCidrBounds -Cidr $Outer
    $i = Get-ZsCidrBounds -Cidr $Inner
    return ($i.Start -ge $o.Start -and $i.End -le $o.End)
}

function Test-ZsCidrOverlap {
    <#
    .SYNOPSIS Tests whether two CIDRs overlap.
    .PARAMETER CidrA First CIDR.
    .PARAMETER CidrB Second CIDR.
    .OUTPUTS [bool]
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([bool])]
    param([Parameter(Mandatory)][string]$CidrA, [Parameter(Mandatory)][string]$CidrB)

    $a = Get-ZsCidrBounds -Cidr $CidrA
    $b = Get-ZsCidrBounds -Cidr $CidrB
    return ($a.Start -le $b.End -and $a.End -ge $b.Start)
}

function Resolve-ZsSubnetPlan {
    <#
    .SYNOPSIS Resolves and validates the explicit per-subnet CIDR plan for a deployment.
    .DESCRIPTION Builds the set of subnets required by the selected topology and options, then resolves
        each one's CIDR from the supplied map (runtime parameters take precedence over JSON, the caller
        having already merged them). Every required subnet must have a CIDR. If any are missing, the
        function throws once and names all of them. All supplied CIDRs are validated for syntax,
        containment within the VNet address space, and mutual non-overlap.

        No CIDR is ever derived or defaulted. This is the single enforcement point for the
        explicit-or-exit subnet contract.
    .PARAMETER VnetCidr The VNet address space. Required and validated.
    .PARAMETER SubnetCidrs Hashtable mapping subnet name to CIDR, merged from runtime and JSON by the caller.
    .PARAMETER EnableBastion Require an AzureBastionSubnet entry.
    .PARAMETER EnableZpa Require the two ZPA DNS resolver subnet entries.
    .OUTPUTS PSCustomObject mapping each required subnet name to its validated CIDR.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][string]$VnetCidr,
        [Parameter(Mandatory)][hashtable]$SubnetCidrs,
        [string[]]$Zones = @('1','2'),
        [switch]$EnableBastion,
        [switch]$EnableZpa
    )

    if (-not (Test-ZsCidr -Cidr $VnetCidr)) {
        Write-ZsError -Message "VNet address space '$VnetCidr' is not a valid IPv4 CIDR (expected something like 10.10.0.0/16)." -ErrorId 'ZsInvalidVnetCidr'
    }

    $required = [System.Collections.Generic.List[string]]::new()
    if ($EnableBastion) { $required.Add('AzureBastionSubnet') }
    # Per-zone connector subnets: each zone has its own management and service subnet, so a zone
    # failure is isolated and each zone's NAT gateway and NSGs are independent.
    # StandardV2 NAT is zone-redundant, so nothing forces per-zone connector subnets any more:
    # one management and one service subnet serve every zone's compute. Zonal resilience lives
    # where it belongs - in the per-zone scale sets and the zone-redundant NAT and load
    # balancer - not in subnet bookkeeping.
    $required.Add('snet-zscc-mgmt')
    $required.Add('snet-zscc-service')
    $required.Add('snet-zscc-lb')
    $required.Add('snet-zscc-workload')
    $required.Add('snet-zscc-funcapp')
    if ($EnableZpa) {
        $required.Add('snet-zscc-dns-inbound')
        $required.Add('snet-zscc-dns-outbound')
    }

    # 1. Presence: collect every missing subnet, then fail once naming all of them.
    $missing = [System.Collections.Generic.List[string]]::new()
    foreach ($name in $required) {
        if (-not $SubnetCidrs.ContainsKey($name) -or [string]::IsNullOrWhiteSpace([string]$SubnetCidrs[$name])) {
            $missing.Add($name)
        }
    }
    if ($missing.Count -gt 0) {
        Write-ZsError -Message ("Missing required subnet CIDR(s): " + ($missing -join ', ') + ". Supply each as a runtime parameter or in the JSON config. Subnet CIDRs are never auto-derived.") -ErrorId 'ZsMissingSubnetCidr'
    }

    # 2. Syntax of each supplied CIDR.
    $bad = [System.Collections.Generic.List[string]]::new()
    foreach ($name in $required) {
        if (-not (Test-ZsCidr -Cidr ([string]$SubnetCidrs[$name]))) { $bad.Add("$name='$($SubnetCidrs[$name])'") }
    }
    if ($bad.Count -gt 0) {
        Write-ZsError -Message ("Invalid subnet CIDR(s): " + ($bad -join ', ') + ". Each must be valid IPv4 CIDR notation.") -ErrorId 'ZsInvalidSubnetCidr'
    }

    # 3. Containment within the VNet.
    $outOfRange = [System.Collections.Generic.List[string]]::new()
    foreach ($name in $required) {
        if (-not (Test-ZsCidrContains -Outer $VnetCidr -Inner ([string]$SubnetCidrs[$name]))) {
            $outOfRange.Add("$name=$($SubnetCidrs[$name])")
        }
    }
    if ($outOfRange.Count -gt 0) {
        Write-ZsError -Message ("Subnet(s) fall outside the VNet $VnetCidr`: " + ($outOfRange -join ', ') + ". Adjust them to sit within the VNet range.") -ErrorId 'ZsSubnetOutsideVnet'
    }

    # 4. Minimum sizes Azure enforces, checked here so they fail in preflight naming every
    #    offender rather than one at a time partway through the deployment.
    #    /29 is the platform floor for any subnet; Bastion Standard requires /26; an App Service
    #    delegated subnet cannot be smaller than /28 and Microsoft recommends /26 for scale-out.
    $minPrefix = @{}
    # Shared subnets must hold every zone's connectors at once; /29's five usable addresses
    # cannot. /27 (27 usable) covers the portal ceiling of 16 connectors per scale set only
    # for a single zone - capacity against the configured fleet is checked at deployment,
    # where the zone count and instance ceilings are known.
    $minPrefix['snet-zscc-mgmt']    = 28
    $minPrefix['snet-zscc-service'] = 28
    $minPrefix['snet-zscc-lb']       = 29
    $minPrefix['snet-zscc-workload'] = 29
    $minPrefix['snet-zscc-funcapp']  = 28
    if ($EnableBastion) { $minPrefix['AzureBastionSubnet'] = 26 }
    if ($EnableZpa) {
        $minPrefix['snet-zscc-dns-inbound']  = 28
        $minPrefix['snet-zscc-dns-outbound'] = 28
    }

    $tooSmall = [System.Collections.Generic.List[string]]::new()
    foreach ($name in $required) {
        if (-not $minPrefix.ContainsKey($name)) { continue }
        $b = Get-ZsCidrBounds -Cidr ([string]$SubnetCidrs[$name])
        if ($b.Prefix -gt $minPrefix[$name]) {
            $tooSmall.Add("$name=$($SubnetCidrs[$name]) (needs /$($minPrefix[$name]) or larger)")
        }
    }
    if ($tooSmall.Count -gt 0) {
        $hint = if ($EnableBastion -and $tooSmall -match 'AzureBastionSubnet') { ' Widen it or pass -NoBastion.' } else { '' }
        Write-ZsError -Message ("Subnet(s) too small: " + ($tooSmall -join ', ') + ".$hint") -ErrorId 'ZsSubnetTooSmall'
    }

    # 5. Mutual non-overlap.
    $names = @($required)
    $conflicts = [System.Collections.Generic.List[string]]::new()
    for ($i = 0; $i -lt $names.Count; $i++) {
        for ($j = $i + 1; $j -lt $names.Count; $j++) {
            if (Test-ZsCidrOverlap -CidrA ([string]$SubnetCidrs[$names[$i]]) -CidrB ([string]$SubnetCidrs[$names[$j]])) {
                $conflicts.Add("$($names[$i]) overlaps $($names[$j])")
            }
        }
    }
    if ($conflicts.Count -gt 0) {
        Write-ZsError -Message ("Overlapping subnet CIDR(s): " + ($conflicts -join '; ') + ". Each subnet must occupy a distinct range.") -ErrorId 'ZsOverlappingSubnets'
    }

    $plan = [ordered]@{}
    foreach ($name in $required) { $plan[$name] = [string]$SubnetCidrs[$name] }
    return [PSCustomObject]$plan
}
