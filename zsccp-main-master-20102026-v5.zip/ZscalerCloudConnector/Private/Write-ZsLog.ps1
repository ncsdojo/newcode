<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Write-ZsLog).

.DESCRIPTION
    One writer for every message the module emits, with a deliberate split between the two audiences.

    The log file is the record: it takes everything, with a millisecond timestamp on every line, and
    is what gets attached to a support case. Diagnostic detail is recorded there at INFO, because a
    file that mixes severities the reader must mentally filter is harder to read than one that
    reports facts uniformly and reserves WARN and ERROR for things that genuinely need attention.

    The console is the summary. It carries milestones, warnings and errors and nothing else.
    Diagnostic detail never reaches it, so an operator watching a deployment sees its progress rather
    than its internals.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Write-ZsLog {
    <#
    .SYNOPSIS Writes one line to the session log file and, when it warrants the operator's attention,
        to the console.
    .PARAMETER Message The text to record.
    .PARAMETER Level INFO, WARN, ERROR, FATAL, or DEBUG. DEBUG is diagnostic detail: it is recorded
        in the file as INFO and never printed to the console.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory, Position = 0)]
        [AllowEmptyString()]
        [string]$Message,

        [Parameter()]
        [ValidateSet('INFO','WARN','ERROR','DEBUG','FATAL')]
        [string]$Level = 'INFO'
    )

    # DEBUG is a routing decision, not a severity: it selects file-only, and the file records it as
    # the plain fact it is.
    $fileOnly  = ($Level -eq 'DEBUG')
    $fileLevel = if ($fileOnly) { 'INFO' } else { $Level }

    $line = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff')] [$fileLevel] $Message"

    if ($script:ZsSession) {
        $logFile = $null
        try { $logFile = $script:ZsSession.LogFile } catch { }
        if ($logFile) {
            try {
                [System.IO.File]::AppendAllText($logFile, "$line`n")
            } catch {
                # The log file is the record attached to a support case. Silently swallowing a
                # write failure produces an empty one and nobody finds out until it is needed.
                # Warn once per session rather than on every line.
                $warned = $false
                try { $warned = [bool]$script:ZsSession.LogWriteFailed } catch { }
                if (-not $warned) {
                    try { $script:ZsSession.LogWriteFailed = $true } catch { }
                    Write-Warning "Could not write to the session log at $logFile`: $($_.Exception.Message). The run continues, but no log file will be produced."
                }
            }
        }
        $buffer = $null
        try { $buffer = $script:ZsSession.LogBuffer } catch { }
        # Tested against $null, not for truthiness: an empty collection is falsy in PowerShell, so
        # a truthiness test would skip the first line and leave the buffer empty for the whole run —
        # which is exactly the state Disconnect-ZscalerAzure -ExportLog checks before writing.
        if ($null -ne $buffer) { $buffer.Add($line) | Out-Null }
    }

    if ($fileOnly) { return }

    # Console: the message alone. The timestamp is in the file, where it is needed for correlation;
    # on screen it sits between the operator and what is happening.
    #
    # ERROR and FATAL go to the error stream, not the warning stream. Routing every severity to
    # Write-Warning made a fatal indistinguishable from a caution on screen, and left nothing on
    # stderr at all, so a pipeline capturing stderr saw a clean run whatever happened. These are
    # non-terminating writes: the caller still decides whether to throw.
    switch ($Level) {
        'WARN'  { Write-Warning $Message }
        # Write-Error renders the ConciseView block - source path, line number, a squiggle
        # underlining the logger's own call site - which makes every handled failure look like
        # a module crash and leaks internal paths. These are log lines, not error records:
        # one clean line on stderr, same shape as every other level.
        'ERROR' { $Host.UI.WriteErrorLine("ERROR: $Message") }
        'FATAL' { $Host.UI.WriteErrorLine("FATAL: $Message") }
        default { Write-Information $Message -InformationAction Continue }
    }
}

function Initialize-ZsLogging {
    <#
    .SYNOPSIS Initializes the dated log file under the artifact root.
    .DESCRIPTION If no explicit path is supplied, the log name is <n><dd><mm><yyyy>.log under the
        artifact root (the runtime directory by default). The file is appended to, not overwritten, so
        multiple runs on the same day accumulate in one log. Returns the resolved log path.
    .PARAMETER LogFile Optional explicit log path. When omitted, a dated name is generated.
    .PARAMETER Name Base name for the dated log. Defaults to the module name.
    .OUTPUTS [string] The resolved log file path.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [string]$LogFile = '',
        [string]$Name = 'ZscalerCloudConnector'
    )

    if (-not $LogFile) {
        $stamp   = Get-Date -Format 'ddMMyyyy'
        $LogFile = Get-ZsArtifactPath -FileName "$Name$stamp.log"
    } else {
        $dir = [System.IO.Path]::GetDirectoryName($LogFile)
        if ($dir -and -not (Test-Path $dir)) { [System.IO.Directory]::CreateDirectory($dir) | Out-Null }
    }

    $banner = "# ZscalerCloudConnector session $(Get-Date -Format 'o')`n"
    [System.IO.File]::AppendAllText($LogFile, $banner)
    return $LogFile
}
