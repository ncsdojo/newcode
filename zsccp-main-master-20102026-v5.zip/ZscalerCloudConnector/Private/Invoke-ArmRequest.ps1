<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Invoke-ArmRequest).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Invoke-ArmRequest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Uri,
        [ValidateSet('Get','Put','Post','Delete','Patch')][string]$Method = 'Get',
        [object]$Body,
        [int]$MaxRetries = 3,
        [switch]$AllowNotFound,
        # Ceiling for the inline Azure-AsyncOperation poll on a 202. Ten minutes suits most
        # resources; Bastion routinely takes ten to twenty-five, and a ceiling below the
        # resource's honest build time reports a timeout for a create that was going fine —
        # while the caller's Wait-ArmProvision, sized for the slow resource, never runs.
        [int]$AsyncTimeoutSeconds = 600
    )

    # Dry-run invariant: no mutating call leaves this function under -WhatIf, regardless of
    # what a caller forgot to guard. Reads pass through so plans stay accurate.
    if ($WhatIfPreference -and $Method -ne 'Get') {
        Write-ZsLog "What if: ARM $Method $Uri" -Level DEBUG
        return $null
    }

    $fullUri = "$($script:Endpoints.Arm)$Uri"
    $json    = if ($Body) { $Body | ConvertTo-Json -Depth 50 -Compress } else { $null }

    for ($attempt = 1; $attempt -le $MaxRetries; $attempt++) {
        $token   = Get-ArmToken
        $headers = @{ Authorization = "Bearer $token"; 'Content-Type' = 'application/json' }
        try {
            $splat = @{ Uri = $fullUri; Method = $Method; Headers = $headers }
            if ($json -and $Method -ne 'Get') { $splat.Body = $json; $splat.ContentType = 'application/json' }

            if ($Method -eq 'Get') {
                return (Invoke-RestMethod @splat -TimeoutSec 60 -ErrorAction Stop)
            }

            # PUT/POST/DELETE: -SkipHttpErrorCheck so HTTP errors don't throw. Status checked directly.
            $webResp = Invoke-WebRequest @splat -SkipHttpErrorCheck -TimeoutSec 120
            $statusCode = [int]$webResp.StatusCode
            $respBody   = $webResp.Content

            # Retryable errors: 0 = connection dropped, 408 = timeout, 429 = throttled, 5xx = server error.
            if ($statusCode -in @(408, 429, 500, 502, 503, 504) -and $attempt -lt $MaxRetries) {
                $wait = [math]::Pow(2, $attempt) * 2
                # Headers is a generic dictionary: indexing a key that is not present throws
                # KeyNotFoundException rather than yielding $null, and a 429 or 503 without a
                # Retry-After header is entirely normal.
                $ra = $null
                if ($webResp.Headers -and $webResp.Headers.ContainsKey('Retry-After')) { $ra = @($webResp.Headers['Retry-After'])[0] }
                if (-not $ra -and $respBody) {
                    try { $p = $respBody | ConvertFrom-Json -ErrorAction SilentlyContinue; if ($p.'Retry-After') { $ra = $p.'Retry-After' } } catch { }
                }
                if ($ra) { try { $wait = [math]::Max([int]$ra, $wait) } catch { } }
                Write-ZsLog "ARM $Method $statusCode, retry $attempt/$MaxRetries in ${wait}s" -Level WARN
                Start-Sleep -Seconds $wait
                continue
            }

            # Non-retryable errors.
            if ($statusCode -ge 400) {
                # A 404 under -AllowNotFound is the documented success case: absence is the answer
                # the caller asked for. Return it as $null rather than throwing, so a delete of an
                # already-gone resource and a probe for one that was never created both read as
                # what they are instead of as failures a caller has to catch and re-classify.
                if ($AllowNotFound -and $statusCode -eq 404) {
                    Write-ZsLog "ARM $Method $Uri returned 404 (absent; allowed)" -Level DEBUG
                    return $null
                }

                $armCode = ''; $armMsg = $respBody
                try {
                    $parsed = $respBody | ConvertFrom-Json -ErrorAction SilentlyContinue
                    if ($parsed -and $parsed.PSObject.Properties.Name -contains 'error') {
                        if ($parsed.error.PSObject.Properties.Name -contains 'code')    { $armCode = [string]$parsed.error.code }
                        if ($parsed.error.PSObject.Properties.Name -contains 'message') { $armMsg  = [string]$parsed.error.message }
                    }
                } catch { }

                # A 409 whose body says the name is finishing a previous delete is transient by
                # Azure's own words ("This may be due to a pending delete operation, try again
                # later") - seen in the field re-creating a scale set minutes after its teardown.
                # Deletes finalize in minutes, so the wait is longer and flatter than the general
                # backoff, and bounded: a name that never frees is a real conflict and still fails.
                if ($statusCode -eq 409 -and $armMsg -match 'pending delete operation|is new, but resource already exists') {
                    if (-not $script:ZsPendingDeleteWaits) { $script:ZsPendingDeleteWaits = @{} }
                    $pdKey = ($Uri -split '\?')[0]
                    $pdSoFar = if ($script:ZsPendingDeleteWaits.ContainsKey($pdKey)) { [int]$script:ZsPendingDeleteWaits[$pdKey] } else { 0 }
                    if ($pdSoFar -lt 10) {
                        $script:ZsPendingDeleteWaits[$pdKey] = $pdSoFar + 1
                        Write-ZsLog "$(($pdKey -split '/')[-1]): the name is still finishing a previous delete; waiting 30s before retrying ($($pdSoFar + 1)/10)" -Level WARN
                        Start-Sleep -Seconds 30
                        $attempt--   # this wait does not consume a general retry
                        continue
                    }
                    Write-ZsLog "$(($pdKey -split '/')[-1]): still pending delete after $($pdSoFar * 30)s; giving up - if a teardown just ran, wait for it to finalize and re-run" -Level ERROR
                }

                $errorId = if ($armCode) { "Arm.$armCode" } else { "Arm.Http$statusCode" }
                $logMsg = $armMsg
                if ($armCode -match 'DisallowedByPolicy' -and $logMsg -match 'Policy identifiers:') {
                    # The identifiers blob is a JSON wall repeated verbatim by every caller that logs the
                    # exception. The classifier parses it into names; the raw log keeps the sentence and
                    # drops the blob.
                    $logMsg = ($logMsg -split 'Policy identifiers:')[0].TrimEnd() + ' (policy identifiers parsed into the classified summary)'
                }
                # A policy denial is routinely survivable - the custom-role paths classify it,
                # name the policy, and fall back - so the raw line is detail (DEBUG), and the
                # classified WARN is the one thing the operator reads. If nothing handles it,
                # the failure still surfaces: the deployment's FATAL now carries the unwrapped
                # ARM message, not this log line.
                $rawLevel = if ($armCode -match 'DisallowedByPolicy') { 'DEBUG' } else { 'ERROR' }
                Write-ZsLog "ARM $Method $Uri failed: $statusCode $armCode $logMsg" -Level $rawLevel
                $record = [System.Management.Automation.ErrorRecord]::new(
                    [System.Net.Http.HttpRequestException]::new("$armCode $armMsg"),
                    $errorId, [System.Management.Automation.ErrorCategory]::ConnectionError, $Uri
                )
                throw $record
            }

            # 202 Accepted — async long-running operation. Poll until terminal state.
            if ($statusCode -eq 202) {
                # Headers is a generic dictionary: an absent key throws rather than yielding $null,
                # and some providers send only Location.
                $asyncUrl = $null
                if ($webResp.Headers.ContainsKey('Azure-AsyncOperation')) { $asyncUrl = @($webResp.Headers['Azure-AsyncOperation'])[0] }
                if (-not $asyncUrl -and $webResp.Headers.ContainsKey('Location')) { $asyncUrl = @($webResp.Headers['Location'])[0] }
                if ($asyncUrl) {
                    Write-ZsLog "Async operation started, polling..." -Level DEBUG
                    # Initialised before the loop: every poll can fail and `continue`, and the
                    # post-loop terminal-state test must still have a value to read under
                    # Set-StrictMode rather than throwing on an unassigned variable.
                    $asyncStatus = ''
                    $asyncPolls = [math]::Max(1, [int][math]::Ceiling($AsyncTimeoutSeconds / 5))
                    $asyncNote  = 120
                    for ($poll = 1; $poll -le $asyncPolls; $poll++) {
                        Start-Sleep -Seconds 5
                        # A long create should be visibly in progress, not silent until it ends.
                        if (($poll * 5) -ge $asyncNote) {
                            Write-ZsLog "Async operation on $Uri still running ($($poll * 5)s elapsed, ceiling ${AsyncTimeoutSeconds}s)"
                            $asyncNote += 120
                        }
                        try {
                            $pollResult = Invoke-RestMethod -Uri $asyncUrl -Headers @{ Authorization = "Bearer $(Get-ArmToken)" } -TimeoutSec 30 -ErrorAction Stop
                        } catch {
                            Write-ZsLog "Async poll attempt $poll failed: $($_.Exception.Message)" -Level WARN
                            continue
                        }
                        # Azure async responses vary by provider. Status may be in .status,
                        # .properties.provisioningState, or the response may be the resource itself.
                        $asyncStatus = ''
                        if ($pollResult.PSObject.Properties.Name -contains 'status') {
                            $asyncStatus = [string]$pollResult.status
                        } elseif ($pollResult.PSObject.Properties.Name -contains 'properties' -and
                                  $pollResult.properties.PSObject.Properties.Name -contains 'provisioningState') {
                            $asyncStatus = [string]$pollResult.properties.provisioningState
                        }
                        if ($asyncStatus -in @('Succeeded','Canceled','Failed')) {
                            if ($asyncStatus -ne 'Succeeded') {
                                # A terminal Failed or Canceled is ARM's considered answer, not a
                                # transport problem, and repeating the call cannot change it. The
                                # error id must therefore carry the provider's own error code: a
                                # bare exception has no status code, the outer handler reads that
                                # absence as 0 (a dropped connection) and retries a refusal. The
                                # Arm.* id both stops the retry, via the re-throw below, and lets
                                # the failure be classified.
                                $asyncCode = ''; $asyncMsg = $asyncStatus
                                try {
                                    if ($pollResult.PSObject.Properties.Name -contains 'error') {
                                        if ($pollResult.error.PSObject.Properties.Name -contains 'code')    { $asyncCode = [string]$pollResult.error.code }
                                        if ($pollResult.error.PSObject.Properties.Name -contains 'message') { $asyncMsg  = [string]$pollResult.error.message }
                                    }
                                } catch { }
                                $errDetail = if ($asyncCode) { "$asyncCode`: $asyncMsg" } else { $asyncMsg }
                                Write-ZsLog "Async operation $errDetail" -Level ERROR

                                $asyncRecord = [System.Management.Automation.ErrorRecord]::new(
                                    [System.InvalidOperationException]::new("Async operation $errDetail"),
                                    $(if ($asyncCode) { "Arm.$asyncCode" } else { 'Arm.AsyncOperationFailed' }),
                                    [System.Management.Automation.ErrorCategory]::InvalidResult, $Uri
                                )
                                # The classifier reads the ARM error envelope, so it is preserved
                                # rather than flattened into prose.
                                if ($asyncCode) {
                                    $asyncRecord.ErrorDetails = [System.Management.Automation.ErrorDetails]::new(
                                        (@{ error = @{ code = $asyncCode; message = $asyncMsg } } | ConvertTo-Json -Depth 5 -Compress))
                                }
                                throw $asyncRecord
                            }
                            Write-ZsLog "Async operation completed" -Level DEBUG
                            break
                        }
                    }
                    # If the loop exhausted without reaching a terminal state, fail explicitly.
                    if ($asyncStatus -notin @('Succeeded','Canceled','Failed')) {
                        Write-ZsLog "Async operation timed out after ${AsyncTimeoutSeconds}s (no terminal status received)" -Level ERROR
                        throw [System.TimeoutException]::new("Async operation on $Uri timed out after ${AsyncTimeoutSeconds}s without reaching a terminal state.")
                    }
                }
            }

            # Success — parse response body.
            if ($respBody) {
                try { return ($respBody | ConvertFrom-Json) } catch { return $null }
            }
            return $null
        } catch {
            # Re-throw already-structured ARM errors without reprocessing.
            if ($_.FullyQualifiedErrorId -match '^Arm\.' -or ($_.TargetObject -and $_.TargetObject -eq $Uri)) {
                throw $_
            }

            # GET failures (Invoke-RestMethod) or unexpected errors land here.
            $status = 0; $detail = ''
            try { $status = [int]$_.Exception.Response.StatusCode } catch { }
            try { $detail = $_.ErrorDetails.Message } catch { }
            if (-not $detail) { try { $detail = [string]$_.Exception.Message } catch { $detail = "$_" } }

            if ($status -in @(0, 408, 429, 500, 502, 503, 504) -and $attempt -lt $MaxRetries) {
                $wait = [math]::Pow(2, $attempt) * 2
                try {
                    $respHeaders = $_.Exception.Response.Headers
                    if ($respHeaders -and $respHeaders.Contains('Retry-After')) {
                        $ra = @($respHeaders.GetValues('Retry-After'))[0]
                        if ($ra) { $wait = [math]::Max([int]$ra, $wait) }
                    }
                } catch { }
                Write-ZsLog "ARM $Method $status, retry $attempt/$MaxRetries in ${wait}s" -Level WARN
                Start-Sleep -Seconds $wait
                continue
            }

            $armCode = ''; $armMsg = $detail
            try {
                $p = $detail | ConvertFrom-Json -ErrorAction SilentlyContinue
                if ($p -and $p.PSObject.Properties.Name -contains 'error') {
                    if ($p.error.PSObject.Properties.Name -contains 'code')    { $armCode = "$($p.error.code)" }
                    if ($p.error.PSObject.Properties.Name -contains 'message') { $armMsg  = "$($p.error.message)" }
                }
            } catch { }

            # Same contract as the status-code path above: absence is an answer, not a failure.
            # Invoke-RestMethod raises on a 404, so a GET reaches the caller through here.
            if ($AllowNotFound -and $status -eq 404) {
                Write-ZsLog "ARM $Method $Uri returned 404 (absent; allowed)" -Level DEBUG
                return $null
            }

            $errorId = if ($armCode) { "Arm.$armCode" } else { "Arm.Http$status" }
            $logMsg = $armMsg
            if ($armCode -match 'DisallowedByPolicy' -and $logMsg -match 'Policy identifiers:') {
                # The identifiers blob is a JSON wall repeated verbatim by every caller that logs the
                # exception. The classifier parses it into names; the raw log keeps the sentence and
                # drops the blob.
                $logMsg = ($logMsg -split 'Policy identifiers:')[0].TrimEnd() + ' (policy identifiers parsed into the classified summary)'
            }
            Write-ZsLog "ARM $Method $Uri failed: $status $armCode $logMsg" -Level ERROR
            $record = [System.Management.Automation.ErrorRecord]::new(
                [System.Net.Http.HttpRequestException]::new("$armCode $armMsg"),
                $errorId, [System.Management.Automation.ErrorCategory]::ConnectionError, $Uri
            )
            throw $record
        }
    }
}

function Invoke-ArmPut {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Uri,
        [Parameter(Mandatory)][object]$Body,
        [int]$AsyncTimeoutSeconds = 600
    )
    Write-ZsLog "PUT $Uri" -Level DEBUG
    return Invoke-ArmRequest -Uri $Uri -Method Put -Body $Body -AsyncTimeoutSeconds $AsyncTimeoutSeconds
}

function Invoke-ArmGet {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Uri, [switch]$AllowNotFound)
    return Invoke-ArmRequest -Uri $Uri -Method Get -AllowNotFound:$AllowNotFound
}

function Invoke-ArmPost {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Uri, [object]$Body)
    Write-ZsLog "POST $Uri" -Level DEBUG
    return Invoke-ArmRequest -Uri $Uri -Method Post -Body $Body
}

function Invoke-ArmDelete {
    <#
    .SYNOPSIS Issues an ARM DELETE.
    .DESCRIPTION Mirrors Invoke-ArmGet's handling of absence: with -AllowNotFound, a 404 is a
        successful outcome rather than an error, which is what a delete usually wants — a resource
        that is already gone is the state being asked for, and teardown re-runs depend on it.
    .PARAMETER Uri ARM resource path, without the endpoint prefix.
    .PARAMETER AllowNotFound Treat a 404 as success instead of throwing.
    .PARAMETER AsyncTimeoutSeconds Ceiling for the inline async poll on a 202. Deletes of a scale
        set full of instances, of Bastion, or of a resource group take well past the default ten
        minutes, and a ceiling below the honest deletion time reports a timeout for a delete that
        is progressing — and lets the next delete in the dependency order fire while this one is
        still running, which is the ordering the rank table exists to prevent.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Uri,
        [switch]$AllowNotFound,
        [int]$AsyncTimeoutSeconds = 600
    )
    Write-ZsLog "DELETE $Uri" -Level DEBUG
    return Invoke-ArmRequest -Uri $Uri -Method Delete -AllowNotFound:$AllowNotFound -AsyncTimeoutSeconds $AsyncTimeoutSeconds
}

function Test-ArmResource {
    [CmdletBinding()]
    [OutputType([hashtable])]
    param([Parameter(Mandatory)][string]$Uri)
    try {
        $r = Invoke-ArmGet -Uri $Uri -AllowNotFound
        # -AllowNotFound returns $null for a confirmed 404. Absence must be reported as absence:
        # returning Exists=$true here would tell every caller its resource already existed and
        # skip the creation of the entire deployment.
        if ($null -eq $r) { return @{ Exists = $false; Resource = $null; State = $null } }
        $state = $null
        if ($r.properties -and ($r.properties.PSObject.Properties.Name -contains 'provisioningState')) {
            $state = $r.properties.provisioningState
        }
        return @{ Exists = $true; Resource = $r; State = $state }
    } catch {
        # Anything that is not a confirmed 404 rethrows. Auth failures, throttling and server
        # errors must not be read as "not found", which would turn an outage into a creation attempt.
        throw
    }
}

function Wait-ArmProvision {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Uri,
        [string]$Label = '',
        [int]$TimeoutSeconds = 600,
        [int]$PollSeconds    = 10
    )
    if (-not $Label) { $Label = ($Uri -split '/')[-1] }
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $state = $null
    $nextNote = 120
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
        # A GET straight after the PUT can 404 briefly while ARM's read path catches up with its
        # write path. Inside a short grace window that is "still materialising", not "absent";
        # past it, a 404 means the create genuinely did not happen and is rethrown.
        try {
            $r = Invoke-ArmGet -Uri $Uri
        } catch {
            if ($_.FullyQualifiedErrorId -match 'NotFound|Http404' -and $sw.Elapsed.TotalSeconds -lt 120) {
                Write-ZsLog "$Label not yet visible to reads ($([int]$sw.Elapsed.TotalSeconds)s); waiting" -Level DEBUG
                Start-Sleep -Seconds $PollSeconds
                continue
            }
            throw
        }
        $state = $null
        if ($r.properties -and ($r.properties.PSObject.Properties.Name -contains 'provisioningState')) {
            $state = $r.properties.provisioningState
        }
        # Function Apps and App Services use properties.state (Running/Stopped) instead of provisioningState.
        if (-not $state -and $r.properties -and ($r.properties.PSObject.Properties.Name -contains 'state')) {
            $appState = $r.properties.state
            if ($appState -eq 'Running') { $state = 'Succeeded' }
            elseif ($appState -eq 'Stopped') { $state = 'Succeeded' }
        }
        # If neither property exists, the resource exists — treat as succeeded.
        if (-not $state -and $r.id) { $state = 'Succeeded' }
        if ($state -eq 'Succeeded') {
            Write-ZsLog "$Label provisioned ($([int]$sw.Elapsed.TotalSeconds)s)"
            return $r
        }
        # Failed and Canceled are terminal: waiting out the clock on them reports a timeout
        # for what is actually a provisioning error. Surface any error object the resource carries.
        if ($state -in @('Failed','Canceled')) {
            $detail = ''
            try {
                if ($r.properties.PSObject.Properties.Name -contains 'error' -and $r.properties.error) {
                    $detail = ' ' + ($r.properties.error | ConvertTo-Json -Compress -Depth 5)
                }
            } catch { }
            throw [System.InvalidOperationException]::new("Provisioning ${state}: $Label ($Uri)$detail")
        }
        # Long creates (Bastion is minutes on a good day) get a periodic heartbeat so a stall
        # is visible while it is happening, not only in the post-mortem.
        if ($sw.Elapsed.TotalSeconds -ge $nextNote) {
            Write-ZsLog "$Label still provisioning (state=$(if ($state) { $state } else { 'Unknown' }), $([int]$sw.Elapsed.TotalSeconds)s elapsed)"
            $nextNote += 120
        }
        Start-Sleep -Seconds $PollSeconds
    }
    throw [System.TimeoutException]::new("Timeout ${TimeoutSeconds}s waiting for $Label (last state: $(if ($state) { $state } else { 'Unknown' }))")
}

function Get-ZsRoleAssignmentName {
    # The name Set-ZsRoleAssignment gives an assignment: a GUID from the scope, the role definition
    # ID exactly as the caller passes it, and the principal, as 5.4.1.0 named them.
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)][string]$Scope,
        [Parameter(Mandatory)][string]$RoleDefinitionId,
        [Parameter(Mandatory)][string]$PrincipalId
    )
    $seed = "$($Scope.ToLower())|$($RoleDefinitionId.ToLower())|$($PrincipalId.ToLower())"
    $md5  = [System.Security.Cryptography.MD5]::Create()
    try { return [System.Guid]::new($md5.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($seed))).ToString() }
    finally { $md5.Dispose() }
}

function Set-ZsRoleAssignment {
    <#
    .SYNOPSIS Assigns a role to a principal at a scope, idempotently, and records the assignment.
    .DESCRIPTION Checks for an existing assignment first, so a re-run is quiet rather than logging a
        409 per role. The lookup pages: a scope with many assignments returns the matching one on a
        later page, and stopping at the first page would create a duplicate assignment on every run.

        The assignment name is a deterministic GUID derived from scope, role and principal rather
        than a random one. A PUT at a fixed name is an upsert, so a run interrupted between the
        create and its acknowledgement reconciles on the next run instead of accumulating duplicate
        assignments that differ only by name.

        Every assignment is recorded in the manifest, because teardown removes the role assignments
        and custom roles this module created and cannot remove what it did not record. One found
        under that deterministic name is this module's; one found under another name is not. The
        name is seeded with the role definition ID exactly as the caller passes it, as 5.4.1.0 did,
        so the assignments it made are still recognised as the module's.

        Azure lists a role under the subscription of the scope it is assigned at, so the definition
        is sent with the scope's subscription and matched on its GUID. A subnet in the platform's
        subscription is granted, and found, under that subscription's path.
    .PARAMETER Scope ARM scope for the assignment.
    .PARAMETER RoleDefinitionId Fully qualified role definition resource ID.
    .PARAMETER PrincipalId Object ID of the principal receiving the role.
    .PARAMETER PrincipalType Principal type; ServicePrincipal for managed identities.
    #>
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][string]$Scope,
        [Parameter(Mandatory)][string]$RoleDefinitionId,
        [Parameter(Mandatory)][string]$PrincipalId,
        [string]$PrincipalType = 'ServicePrincipal'
    )

    # Deterministic name: same scope + role + principal always yields the same assignment.
    $assignId = Get-ZsRoleAssignmentName -Scope $Scope -RoleDefinitionId $RoleDefinitionId -PrincipalId $PrincipalId

    $roleName = ($RoleDefinitionId -split '/')[-1]
    if ($Scope -match '^/subscriptions/([^/]+)') {
        $RoleDefinitionId = "/subscriptions/$($Matches[1])/providers/Microsoft.Authorization/roleDefinitions/$roleName"
    }

    $filter   = [uri]::EscapeDataString("principalId eq '$PrincipalId'")
    $uri      = "$Scope/providers/Microsoft.Authorization/roleAssignments?api-version=$($script:ApiVersions.Authorization)&`$filter=$filter"

    $page = 0
    while ($uri -and $page -lt 20) {
        $page++
        $existing = if ($uri -like 'http*') {
            Invoke-RestMethod -Uri $uri -Headers @{ Authorization = "Bearer $(Get-ArmToken)" } -TimeoutSec 60 -ErrorAction Stop
        } else {
            Invoke-ArmGet -Uri $uri
        }
        # The list covers assignments at, above and below the scope. Only one at the scope or
        # above it grants the role here: the same role on one scale set does not cover the group.
        # An assignment's id is its scope followed by the assignment segment.
        $match = @($existing.value) | Where-Object {
            $aScope = [string]$_.id -replace '/providers/Microsoft\.Authorization/roleAssignments/[^/]+$', ''
            ((([string]$_.properties.roleDefinitionId) -split '/')[-1] -eq $roleName) -and
            (-not $aScope -or $Scope -eq $aScope -or $Scope.StartsWith("$aScope/", [System.StringComparison]::OrdinalIgnoreCase))
        } | Select-Object -First 1
        if ($match) {
            Write-ZsLog "Role assignment exists for principal $PrincipalId ($roleName)" -Level DEBUG
            Add-ZsManifestResource -Type 'RoleAssignment' -Name $match.name -ResourceId $match.id -Properties @{
                Scope = $Scope; RoleDefinitionId = $RoleDefinitionId; PrincipalId = $PrincipalId; PreExisting = ($match.name -ne $assignId)
            }
            return
        }
        $uri = ''
        if ($existing.PSObject.Properties['nextLink'] -and $existing.nextLink) { $uri = [string]$existing.nextLink }
    }

    $assignUri = "$Scope/providers/Microsoft.Authorization/roleAssignments/$assignId`?api-version=$($script:ApiVersions.Authorization)"
    $roleLabel = $script:Roles.GetEnumerator() | Where-Object { $_.Value -eq $roleName } | Select-Object -First 1 -ExpandProperty Key
    if (-not $PSCmdlet.ShouldProcess(($Scope -split '/')[-1], "Assign role $(if ($roleLabel) { $roleLabel } else { $roleName }) to principal $PrincipalId")) { return }
    Invoke-ArmPut -Uri $assignUri -Body @{
        properties = @{ roleDefinitionId = $RoleDefinitionId; principalId = $PrincipalId; principalType = $PrincipalType }
    } | Out-Null

    Add-ZsManifestResource -Type 'RoleAssignment' -Name $assignId -ResourceId "$Scope/providers/Microsoft.Authorization/roleAssignments/$assignId" -Properties @{
        Scope = $Scope; RoleDefinitionId = $RoleDefinitionId; PrincipalId = $PrincipalId; PreExisting = $false
    }
    Write-ZsLog "Assigned role $roleName to principal $PrincipalId at $Scope" -Level DEBUG
}
