<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Invoke-ZscalerRequest).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Invoke-ZscalerRequest {
    <#
    .SYNOPSIS Calls the Cloud & Branch Connector API with automatic session renewal.
    .DESCRIPTION The JSESSIONID cookie expires after approximately 5 minutes of inactivity.
    On a 401, this function silently re-authenticates using the stored SecureString credentials,
    updates the session cookie, and retries the original request exactly once.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Uri,
        [ValidateSet('Get','Post','Put','Delete')][string]$Method = 'Get',
        [object]$Body
    )

    $json = if ($Body) { $Body | ConvertTo-Json -Depth 20 -Compress } else { $null }

    # Two kinds of retry share this loop: one re-authentication on a 401, and bounded backoff for
    # transient failures. Previously only the 401 was handled, so a single 429 or 503 from the
    # portal ended a deployment that was otherwise fine.
    $maxAttempts = 4
    $reauthed = $false
    for ($try = 1; $try -le $maxAttempts; $try++) {
        $splat = @{
            Uri         = $Uri
            Method      = $Method
            Headers     = @{ 'Content-Type' = 'application/json' }
            ContentType = 'application/json'
            WebSession  = $script:ZsSession.ZscalerSession
        }
        if ($json -and $Method -ne 'Get') { $splat.Body = $json }

        try {
            return (Invoke-RestMethod @splat -ErrorAction Stop)
        } catch {
            $status = 0; try { $status = [int]$_.Exception.Response.StatusCode } catch { }

            if ($status -eq 401 -and -not $reauthed) {
                # Session expired; re-authenticate with stored credentials. Once only: a second
                # 401 after a successful re-auth is a credential problem, not an expiry.
                Write-ZsLog 'Zscaler session expired, re-authenticating' -Level WARN
                $reauthed = $true
                $plainKey  = ConvertFrom-ZsSecureString -Secure $script:ZsSession.ZscalerApiKeySS
                $plainPass = ConvertFrom-ZsSecureString -Secure $script:ZsSession.ZscalerPasswordSS
                try {
                    $sess = Connect-ZscalerLegacy -BaseUrl $script:ZsSession.ZscalerApiUrl `
                                                  -ApiKey $plainKey `
                                                  -Username $script:ZsSession.ZscalerUsername `
                                                  -Password $plainPass
                    $script:ZsSession.ZscalerSession = $sess
                    Write-ZsLog 'Zscaler session renewed'
                } finally {
                    $plainKey = $null; $plainPass = $null
                }
                continue
            }

            if ($status -in @(0, 408, 429, 500, 502, 503, 504) -and $try -lt $maxAttempts) {
                $wait = [math]::Pow(2, $try) * 2
                Write-ZsLog "Zscaler API $status, retry $try/$($maxAttempts - 1) in ${wait}s" -Level WARN
                Start-Sleep -Seconds $wait
                continue
            }
            throw
        }
    }
}
