<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Get-ZscalerObfuscatedKey).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Get-ZscalerObfuscatedKey {
    [CmdletBinding()]
    [OutputType([hashtable])]
    param([Parameter(Mandatory)][ValidateScript({ if ($_.Length -ge 12) { $true } else { throw 'API key must be at least 12 characters.' } })][string]$ApiKey)

    $now = [long]([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
    $n   = $now.ToString().Substring($now.ToString().Length - 6)
    $r   = ([int][math]::Floor([int]$n / 2)).ToString('D6')
    $len = $ApiKey.Length
    $sb  = [System.Text.StringBuilder]::new(12)

    for ($i = 0; $i -lt 6; $i++) {
        $idx = [int][char]::GetNumericValue($n[$i]) % $len
        $sb.Append($ApiKey[$idx]) | Out-Null
    }
    for ($i = 0; $i -lt 6; $i++) {
        $idx = ([int][char]::GetNumericValue($r[$i]) + 2) % $len
        $sb.Append($ApiKey[$idx]) | Out-Null
    }
    return @{ Timestamp = $now; ObfuscatedKey = $sb.ToString() }
}

function Connect-ZscalerLegacy {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$BaseUrl,
        [Parameter(Mandatory)][string]$ApiKey,
        [Parameter(Mandatory)][string]$Username,
        [Parameter(Mandatory)][string]$Password
    )
    $obf  = Get-ZscalerObfuscatedKey -ApiKey $ApiKey
    # Clock-skew and key-length sanity check. Logs no secret values, and goes to the file only:
    # it is diagnostic detail for a failed authentication, not something an operator watching a
    # deployment needs on screen every time a session is established.
    $utc = [DateTimeOffset]::FromUnixTimeMilliseconds($obf.Timestamp).UtcDateTime.ToString('yyyy-MM-dd HH:mm:ss')
    Write-ZsLog "Auth diagnostic: timestamp=$($obf.Timestamp) (UTC $utc), inputKeyLen=$($ApiKey.Length), obfuscatedKeyLen=$($obf.ObfuscatedKey.Length)" -Level DEBUG
    $body = @{ apiKey = $obf.ObfuscatedKey; username = $Username; password = $Password; timestamp = $obf.Timestamp } | ConvertTo-Json -Compress
    # The caller (Connect-ZscalerCloud) wraps this in a try/catch that parses the Zscaler
    # error body and surfaces a friendly message, so here we let the exception propagate.
    $null = Invoke-WebRequest -Uri "$BaseUrl/api/v1/auth" -Method Post -Body $body -ContentType 'application/json' -SessionVariable sess -ErrorAction Stop
    return $sess
}
