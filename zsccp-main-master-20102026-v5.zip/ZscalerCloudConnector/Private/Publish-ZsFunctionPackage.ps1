<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (function package build and delivery).

.DESCRIPTION
    Builds the function zip when it is delivered from a local copy - this module's own function
    (-FunctionPackage Module), or Zscaler's zip placed in FunctionApp/vendor when the published URL
    is not used - and zip-deploys it onto the plan's own disk through the SCM endpoint
    (WEBSITE_RUN_FROM_PACKAGE=1). The host mounts it from there at every start, with no network
    fetch. It never goes into the function's storage account: the platform fetches a package URL
    outside the app's VNet integration, and an account with public network access disabled
    refuses that fetch, so every cold start would fail with VolumeMountFailure.

    The app has public network access disabled, so its SCM endpoint answers only on the app's
    private endpoint. The push therefore runs from a host inside the network that resolves
    privatelink.azurewebsites.net, authenticated with the deployer's Entra token; basic publishing
    credentials are off.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Test-ZsVendorPackage {
    <#
    .SYNOPSIS Validates Zscaler's official function package in the module's FunctionApp folder.
    .DESCRIPTION The vendor artifact is the supported lifecycle package, so a missing or broken
        copy must fail a deployment at its start rather than at publish time deep in the run.
        Checks presence, that the archive carries function_app.py and host.json at its root, and
        that it is self-contained (a vendored .python_packages tree), and reads its version.
    .OUTPUTS [PSCustomObject] Valid, Path, SizeKB, Version, Reason.
    .EXAMPLE
    Test-ZsVendorPackage
    Returns Valid=$true with the package version when the artifact is usable.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param()
    # The vendor artifact lives in FunctionApp/vendor/ so it cannot be confused with this
    # module's own function sources, which share its file names. The legacy location directly
    # in FunctionApp/ is still accepted for deployments set up before that separation.
    $moduleRoot = Split-Path $PSScriptRoot -Parent
    $faDir = Join-Path $moduleRoot 'FunctionApp'
    $path = @(
        (Join-Path (Join-Path $faDir 'vendor') 'zscaler_cc_function_app.zip')
        (Join-Path $faDir 'zscaler_cc_function_app.zip')
    ) | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $path) { $path = Join-Path (Join-Path $faDir 'vendor') 'zscaler_cc_function_app.zip' }
    $result = [PSCustomObject]@{ Valid=$false; Path=$path; SizeKB=0; Version=''; Reason='' }
    if (-not (Test-Path $path)) { $result.Reason = 'file not found (looked in FunctionApp/vendor/ and FunctionApp/)'; return $result }
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zip = [System.IO.Compression.ZipFile]::OpenRead($path)
        try {
            $names = @($zip.Entries | ForEach-Object { $_.FullName })
            if ($names -notcontains 'function_app.py') { $result.Reason = 'function_app.py is missing from the archive root'; return $result }
            if ($names -notcontains 'host.json')       { $result.Reason = 'host.json is missing from the archive root'; return $result }
            if (-not ($names | Where-Object { $_ -like '.python_packages/lib/site-packages/*' })) {
                $result.Reason = 'no vendored .python_packages tree; the package is not self-contained'; return $result
            }
            $verEntry = $zip.Entries | Where-Object { $_.FullName -eq 'version.py' } | Select-Object -First 1
            if ($verEntry) {
                $reader = [System.IO.StreamReader]::new($verEntry.Open())
                try { if ($reader.ReadToEnd() -match 'VERSION\s*=\s*"([^"]+)"') { $result.Version = $Matches[1] } } finally { $reader.Dispose() }
            }
        } finally { $zip.Dispose() }
        $result.SizeKB = [math]::Round((Get-Item $path).Length / 1KB)
        $result.Valid = $true
        return $result
    } catch { $result.Reason = "unreadable archive: $($_.Exception.Message)"; return $result }
}

function Build-ZsFunctionPackage {
    <#
    .SYNOPSIS Builds this module's function zip, or picks up Zscaler's, and names it by its content.
    .DESCRIPTION The hash is what the Function App's package tag records once the zip is deployed, so a
        run that brings the same package deploys nothing. A Module build is hashed over the staged tree
        rather than the zip, whose entry timestamps change on every build; Zscaler's zip is hashed as
        it is. A built zip is a temporary file the caller removes after deploying it.
    .PARAMETER FunctionPackage Vendor (Zscaler's zip from FunctionApp/vendor) or Module (this module's function).
    .OUTPUTS [PSCustomObject] Path, Hash, SizeKB, Temporary.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [ValidateSet('Vendor','Module')][string]$FunctionPackage = 'Vendor'
    )

    $moduleRoot = Split-Path $PSScriptRoot -Parent
    $srcDir = Join-Path $moduleRoot 'FunctionApp'
    $vendorPkg = ''
    if ($FunctionPackage -eq 'Vendor') {
        # Zscaler's package is proprietary and is not redistributed with this module. The
        # operator copies their own downloaded artifact (terraform module path
        # modules/terraform-zscc-function-app-azure/zscaler_cc_function_app.zip) into the
        # FunctionApp/vendor folder, and it is deployed exactly as supplied.
        $vp = Test-ZsVendorPackage
        $vendorPkg = $vp.Path
        if (-not $vp.Valid) {
            throw [System.IO.FileNotFoundException]::new("FunctionPackage=Vendor but the package check failed: $($vp.Reason) ($($vp.Path)). Copy zscaler_cc_function_app.zip from Zscaler's terraform module into the FunctionApp/vendor folder.")
        }
    } elseif (-not (Test-Path (Join-Path $srcDir 'function_app.py'))) {
        throw [System.IO.FileNotFoundException]::new("Function source not found at $srcDir")
    }

    # Build the package in a temp staging directory.
    $staging = Join-Path ([System.IO.Path]::GetTempPath()) "zscc-func-$([guid]::NewGuid().ToString('N').Substring(0,8))"
    New-Item -ItemType Directory -Path $staging -Force | Out-Null

    # The vendored dependency tree is thousands of small files. Per-file progress rendering
    # dominates the copy's runtime, and the provider does not always emit a completion record,
    # which strands a progress bar on the console for the rest of the session.
    $priorProgress = $ProgressPreference
    $ProgressPreference = 'SilentlyContinue'
    $builtZip = $false; $keepZip = $false; $zipPath = ''
    try {
        if ($FunctionPackage -eq 'Vendor') {
            $zipPath = $vendorPkg
            Write-ZsLog "Publishing Zscaler's official function package$(if ($vp.Version) { " v$($vp.Version)" }) verbatim from $(Split-Path $vp.Path -Leaf) in $(Split-Path (Split-Path $vp.Path -Parent) -Leaf)/ ($($vp.SizeKB) KB, self-contained dependencies; no module source is staged or merged)"
            if (Test-Path (Join-Path $srcDir 'python_packages.zip')) {
                Write-ZsLog "Operator wheel set python_packages.zip is not used in Vendor mode; keep it for -FunctionPackage Module"
            }
        } else {
        Copy-Item -Path (Join-Path $srcDir '*') -Destination $staging -Recurse -Force
        # The vendor artifact must never ride inside the Module package, from either location.
        Remove-Item -Path (Join-Path $staging 'vendor') -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -Path (Join-Path $staging 'zscaler_cc_function_app.zip') -Force -ErrorAction SilentlyContinue

        # Dependencies. A pre-vendored .python_packages tree shipped in the FunctionApp folder
        # is used as-is — for operator machines without Python, or builds done elsewhere such as
        # Cloud Shell or CI. A folder or a zip of it is accepted (Explorer cannot create
        # leading-dot names, so the underscore and bare spellings work too), and a zip may root
        # at lib/site-packages or wrap it in one folder. Without either, pip vendors the wheels
        # for the host's platform (manylinux/cp311), not the operator's.
        $vendorFolderNames = @('.python_packages','_python_packages','python_packages')
        $vendorZipNames    = @('.python_packages.zip','_python_packages.zip','python_packages.zip')

        # The archive itself must never ship inside the function package.
        foreach ($zipName in $vendorZipNames) {
            Remove-Item -Path (Join-Path $staging $zipName) -Force -ErrorAction SilentlyContinue
        }

        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $preVendorSrc = ''; $preVendorLabel = ''; $vendorExtract = ''
        foreach ($vendorName in $vendorFolderNames) {
            $cand = Join-Path $srcDir $vendorName
            if (Test-Path (Join-Path $cand 'lib/site-packages')) { $preVendorSrc = $cand; $preVendorLabel = $vendorName; break }
        }
        if (-not $preVendorSrc) {
            foreach ($zipName in $vendorZipNames) {
                $zipCand = Join-Path $srcDir $zipName
                if (-not (Test-Path $zipCand)) { continue }
                $vendorExtract = Join-Path ([System.IO.Path]::GetTempPath()) "zscc-vendor-$([guid]::NewGuid().ToString('N').Substring(0,8))"
                [System.IO.Compression.ZipFile]::ExtractToDirectory($zipCand, $vendorExtract)
                if (Test-Path (Join-Path $vendorExtract 'lib/site-packages')) {
                    $preVendorSrc = $vendorExtract
                } else {
                    foreach ($vendorName in $vendorFolderNames) {
                        if (Test-Path (Join-Path $vendorExtract "$vendorName/lib/site-packages")) {
                            $preVendorSrc = Join-Path $vendorExtract $vendorName; break
                        }
                    }
                }
                if ($preVendorSrc) { $preVendorLabel = $zipName; break }
                Write-ZsLog "$zipName does not contain lib/site-packages at its root or under a python_packages folder; ignoring it." -Level WARN
                Remove-Item -Path $vendorExtract -Recurse -Force -ErrorAction SilentlyContinue
                $vendorExtract = ''
            }
        }

        if ($preVendorSrc) {
            foreach ($vendorName in $vendorFolderNames) {
                Remove-Item -Path (Join-Path $staging $vendorName) -Recurse -Force -ErrorAction SilentlyContinue
            }
            Copy-Item -Path $preVendorSrc -Destination (Join-Path $staging '.python_packages') -Recurse -Force
            if ($vendorExtract) { Remove-Item -Path $vendorExtract -Recurse -Force -ErrorAction SilentlyContinue }
            $pydFile = Get-ChildItem -Path (Join-Path $staging '.python_packages') -Recurse -Filter '*.pyd' -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($pydFile) {
                Write-ZsLog "Pre-vendored packages contain Windows binaries (*.pyd); they will not import on the Linux Functions host. Rebuild with: pip install -r requirements.txt --target .python_packages/lib/site-packages --platform manylinux2014_x86_64 --implementation cp --python-version 311 --only-binary=:all:" -Level WARN
            } else {
                Write-ZsLog "Bundling this module's function code with the operator-supplied Python wheel set from $preVendorLabel"
            }
        } else {
        $pipTarget = Join-Path $staging '.python_packages/lib/site-packages'
        New-Item -ItemType Directory -Path $pipTarget -Force | Out-Null
        $reqFile = Join-Path $staging 'requirements.txt'
        $pipOk = $false
        foreach ($pipCmd in @('pip3','pip','python3 -m pip','python -m pip')) {
            try {
                $parts = $pipCmd -split ' '
                $exe = $parts[0]; $preArgs = @($parts | Select-Object -Skip 1)
                $pipArgs = $preArgs + @('install','-r',$reqFile,'--target',$pipTarget,
                    '--platform','manylinux2014_x86_64','--implementation','cp','--python-version','311',
                    '--only-binary=:all:','--quiet')
                & $exe @pipArgs 2>&1 | Out-Null
                if ($LASTEXITCODE -eq 0) { $pipOk = $true; break }
            } catch { continue }
        }
        if (-not $pipOk) {
            Remove-Item -Path (Join-Path $staging '.python_packages') -Recurse -Force -ErrorAction SilentlyContinue
            # A config is honoured in full or the run refuses it, and that applies to the
            # package too: run-from-package performs no host-side build, so a source-only
            # archive is a guaranteed-dead function shipped on purpose.
            throw [System.InvalidOperationException]::new(
                "Python dependencies could not be vendored (pip unavailable or failed), and a source-only archive cannot run: run-from-package mounts the zip exactly as deployed and the host performs no build. Refusing to deploy it. " +
                "Install Python 3.11+ with pip and re-run, or place a pre-built .python_packages folder (manylinux2014/cp311 wheels) or python_packages.zip in the module's FunctionApp directory.")
        }
        }

        $zipPath = Join-Path ([System.IO.Path]::GetTempPath()) "zscc-func-$(Get-Date -Format 'yyyyMMddHHmmss')-$([guid]::NewGuid().ToString('N').Substring(0,6)).zip"
        if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        [System.IO.Compression.ZipFile]::CreateFromDirectory($staging, $zipPath)
        $zipName = Split-Path $zipPath -Leaf
        $builtZip = $true
        Write-ZsLog "Function package built: $zipName ($([math]::Round((Get-Item $zipPath).Length / 1KB)) KB)"
        }

        # Name the package by its content. A Module build is hashed over the staged tree rather than
        # the zip, whose entry timestamps change on every build.
        $sha = [System.Security.Cryptography.SHA256]::Create()
        try {
            if ($FunctionPackage -eq 'Vendor') {
                $stream = [System.IO.File]::OpenRead($zipPath)
                try { $digest = $sha.ComputeHash($stream) } finally { $stream.Dispose() }
            } else {
                $ms = [System.IO.MemoryStream]::new()
                $stagingFull = (Get-Item -LiteralPath $staging).FullName
                try {
                    foreach ($f in @(Get-ChildItem -LiteralPath $stagingFull -Recurse -File -Force | Sort-Object { $_.FullName.Substring($stagingFull.Length).Replace('\','/') } -CaseSensitive)) {
                        $rel = [System.Text.Encoding]::UTF8.GetBytes($f.FullName.Substring($stagingFull.Length).Replace('\','/'))
                        $ms.Write($rel, 0, $rel.Length)
                        $bytes = [System.IO.File]::ReadAllBytes($f.FullName)
                        $ms.Write($bytes, 0, $bytes.Length)
                    }
                    $ms.Position = 0
                    $digest = $sha.ComputeHash($ms)
                } finally { $ms.Dispose() }
            }
        } finally { $sha.Dispose() }
        $hash = (-join ($digest | ForEach-Object { $_.ToString('x2') })).Substring(0, 16)
        $keepZip = $true
        return [PSCustomObject]@{ Path=$zipPath; Hash=$hash; SizeKB=[math]::Round((Get-Item $zipPath).Length / 1KB); Temporary=$builtZip }
    } finally {
        $ProgressPreference = $priorProgress
        # Clear any progress record the file system provider left behind mid-copy.
        Write-Progress -Activity 'Copying' -Completed -ErrorAction SilentlyContinue
        Remove-Item -Path $staging -Recurse -Force -ErrorAction SilentlyContinue
        # A built zip outlives this call only when it is handed back; on a failure it goes too.
        if ($builtZip -and -not $keepZip -and $zipPath -and (Test-Path $zipPath)) { Remove-Item $zipPath -Force -ErrorAction SilentlyContinue }
    }
}

function Publish-ZsPackageToScm {
    <#
    .SYNOPSIS Zip-deploys a package onto the plan's disk through the Function App's private endpoint.
    .DESCRIPTION With WEBSITE_RUN_FROM_PACKAGE=1 on the app, Kudu keeps the zip in /home/data/SitePackages
        and the host mounts it locally at every start. Public network access is off for the app and its
        SCM endpoint, so this host must resolve <app>.scm.azurewebsites.net to the app's private
        endpoint; access restrictions do not apply to private endpoint traffic. It authenticates with
        the deployer's Entra token, since basic publishing credentials are disabled.
    .PARAMETER FunctionAppName Function App name; the SCM host is derived from it.
    .PARAMETER ZipPath Local path of the package, deployed byte for byte.
    .OUTPUTS None. Throws ZsPackagePushNeedsNetwork when this host cannot reach the private endpoint.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$FunctionAppName,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$ZipPath
    )

    # Checked before sending anything: from a host that resolves the public address the request
    # would only be refused, after a long wait.
    $scmHost = "$FunctionAppName.scm.azurewebsites.net"
    $resolved = @(Resolve-ZsHostAddress -HostName $scmHost)
    if ($resolved.Count -eq 0 -or @($resolved | Where-Object { -not (Test-ZsPrivateAddress -Address $_) }).Count -gt 0) {
        $seen = if ($resolved.Count -gt 0) { "resolves it to $($resolved -join ', ')" } else { 'cannot resolve it' }
        throw [System.InvalidOperationException]::new(
            "ZsPackagePushNeedsNetwork: the function package is zip-deployed to $FunctionAppName through its private endpoint, because the app " +
            "has public network access disabled, and this machine $seen. Re-run the deployment from a host inside the network that resolves " +
            "privatelink.azurewebsites.net to that endpoint: the VNet itself, a network the zone is linked to, or on-premises through the hub's DNS.")
    }

    $sizeKB = [math]::Round((Get-Item -LiteralPath $ZipPath).Length / 1KB)
    $uri = "https://$scmHost/api/zipdeploy?isAsync=true"
    Write-ZsLog "Zip-deploying the function package to $FunctionAppName through its private endpoint ($sizeKB KB)"
    # The SCM site can take a minute to answer after the endpoint is created or the app restarts.
    $resp = $null
    for ($attempt = 1; $attempt -le 4; $attempt++) {
        try {
            $resp = Invoke-WebRequest -Uri $uri -Method Post -InFile $ZipPath -ContentType 'application/zip' `
                -Headers @{ Authorization = "Bearer $(Get-ArmToken)" } -TimeoutSec 600 -SkipHttpErrorCheck
        } catch {
            if ($attempt -eq 4) { throw }
            Write-ZsLog "SCM endpoint not answering yet (attempt $attempt of 4): $($_.Exception.Message)" -Level DEBUG
            Start-Sleep -Seconds 20; continue
        }
        if ([int]$resp.StatusCode -in @(502, 503) -and $attempt -lt 4) { Start-Sleep -Seconds 20; continue }
        break
    }
    $code = [int]$resp.StatusCode
    if ($code -in @(401, 403)) {
        throw [System.UnauthorizedAccessException]::new(
            "The zip deploy to $FunctionAppName was refused ($code). The deploying principal needs Microsoft.Web/sites/publish/Action on the app " +
            "(Website Contributor or Contributor), and the request has to arrive through the app's private endpoint.")
    }
    if ($code -ge 300 -and $code -ne 202) { throw [System.InvalidOperationException]::new("The zip deploy to $FunctionAppName failed: HTTP $code") }

    $pollUrl = "$($resp.Headers['Location'] | Select-Object -First 1)"
    if ($code -eq 202 -and $pollUrl) {
        $sw = [System.Diagnostics.Stopwatch]::StartNew()
        $done = $false
        while ($sw.Elapsed.TotalSeconds -lt 600) {
            Start-Sleep -Seconds 5
            $st = $null
            try { $st = Invoke-RestMethod -Uri $pollUrl -Headers @{ Authorization = "Bearer $(Get-ArmToken)" } -TimeoutSec 30 }
            catch { Write-ZsLog "Deployment status not readable yet: $($_.Exception.Message)" -Level DEBUG; continue }
            if ($st.status -eq 4) { $done = $true; break }
            if ($st.status -eq 3) {
                throw [System.InvalidOperationException]::new("Kudu reports the deployment to $FunctionAppName failed: $($st.status_text) (log: $($st.log_url))")
            }
        }
        if (-not $done) { throw [System.TimeoutException]::new("The deployment to $FunctionAppName did not complete within 600 seconds.") }
    }
    Write-ZsLog "Function package deployed to $FunctionAppName (/home/data/SitePackages); the host mounts it locally at every start"
}
