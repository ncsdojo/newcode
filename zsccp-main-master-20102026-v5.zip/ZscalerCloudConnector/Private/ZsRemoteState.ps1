<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module — remote deployment state with locking.

.DESCRIPTION
    Stores the deployment manifest as a blob in Azure Storage and holds a lease on it for
    the duration of a deployment. The blob gives the manifest a home that outlives the
    operator's machine; the lease prevents two concurrent runs from reconciling the same
    resource group at once, which matters because re-runs rewrite Function App settings
    and toggle network ACLs — interleaving two of those is a corruption path, not noise.

    The lease is infinite for the run and released in the caller's finally block. Renewal
    from a single-threaded script that spends minutes inside ARM provisioning waits is not
    dependable, so a short self-expiring lease would drop the lock mid-deployment; an
    infinite lease held for the run is the reliable shape. The cost is that a crashed run
    leaves the lease held — New-ZsDeployment -BreakStateLock breaks it, the same recovery
    model as terraform force-unlock.

    The state key is <subscription>-<resourceGroup>, scoping the lock to exactly the unit
    two concurrent runs would collide over. All access is Entra ID via ZsStorageData.ps1;
    no account key or SAS is involved.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

$script:ZsStateConfig = $null
$script:ZsStateLeaseId = $null

function Initialize-ZsRemoteState {
    <#
    .SYNOPSIS Configures the remote state backend and acquires the deployment lock.
    .DESCRIPTION Ensures the state container and blob exist, then acquires the lease. Pair with
        Close-ZsRemoteState in a finally block. The seed write never overwrites existing state.
    .PARAMETER AccountName Storage account holding the state container.
    .PARAMETER ContainerName Container name.
    .PARAMETER StateKey Blob name. Defaults to '<subscription>-<resourceGroup>.json'.
    .PARAMETER BreakLease Break a leftover lease from a crashed run before acquiring.
    .OUTPUTS [PSCustomObject] with AccountName, ContainerName, StateKey.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$AccountName,
        [string]$ContainerName = 'zscc-state',
        [string]$StateKey = '',
        [switch]$BreakLease
    )

    if (-not $StateKey) {
        $StateKey = "$($script:ZsSession.SubscriptionId)-$($script:ZsSession.ResourceGroupName).json".ToLower()
    }

    New-ZsBlobContainer -AccountName $AccountName -ContainerName $ContainerName

    # The blob must exist before it can be leased. Seeded with If-None-Match:* so the create is
    # conditional: two first-ever runs starting together both see it absent, and the loser's write
    # is refused with 412 rather than overwriting the winner's. Only the lease decides who runs.
    $existing = Get-ZsBlob -AccountName $AccountName -ContainerName $ContainerName -BlobName $StateKey
    if ($null -eq $existing) {
        $seed = @{ SchemaVersion='3.0'; Status='Uninitialized'; CreatedAt=(Get-Date).ToString('o') } | ConvertTo-Json
        Set-ZsBlob -AccountName $AccountName -ContainerName $ContainerName -BlobName $StateKey `
            -Content $seed -ContentType 'application/json' -OnlyIfAbsent | Out-Null
    }

    $script:ZsStateConfig = [PSCustomObject]@{
        AccountName=$AccountName; ContainerName=$ContainerName; StateKey=$StateKey
    }

    Lock-ZsRemoteState -BreakExisting:$BreakLease

    Write-ZsLog "Remote state: https://$AccountName.blob.core.windows.net/$ContainerName/$StateKey"
    return $script:ZsStateConfig
}

function Lock-ZsRemoteState {
    <#
    .SYNOPSIS Acquires the deployment lease, failing fast when another run holds it.
    .PARAMETER BreakExisting Break the current lease first. Only for recovering from a crashed
        run — breaking the lease under a live deployment defeats the lock.
    .PARAMETER StaleAfterMinutes How long the state blob must have been untouched before a break
        is considered safe. A live run rewrites the blob as it records resources, so a recent
        write is evidence the holder is still working.
    #>
    [CmdletBinding()]
    param([switch]$BreakExisting, [int]$StaleAfterMinutes = 30)
    $c = $script:ZsStateConfig
    if (-not $c) { throw 'Remote state is not initialized. Call Initialize-ZsRemoteState first.' }

    $leaseUri = "https://$($c.AccountName).blob.core.windows.net/$($c.ContainerName)/$($c.StateKey)?comp=lease"
    $acquire  = @{
        'x-ms-lease-action'      = 'acquire'
        'x-ms-lease-duration'    = '-1'
        'x-ms-proposed-lease-id' = [guid]::NewGuid().ToString()
    }

    $resp = Invoke-ZsBlobRequest -Uri $leaseUri -Method Put -Headers $acquire -AllowStatus @(409)
    if ([int]$resp.StatusCode -eq 409 -and $BreakExisting) {
        # -BreakStateLock is documented as crash recovery, but nothing enforced that, so a
        # mistaken invocation took the lock out from under a running deployment and put two runs
        # into the same resource group — the exact outcome the lease exists to prevent. A live run
        # rewrites the state blob as it records resources, so its age is the available evidence.
        $ageMinutes = $null
        try {
            $blobUri = "https://$($c.AccountName).blob.core.windows.net/$($c.ContainerName)/$($c.StateKey)"
            $head = Invoke-ZsBlobRequest -Uri $blobUri -Method Head -AllowStatus @(404)
            if ($head.Headers -and $head.Headers.ContainsKey('Last-Modified')) {
                $lastModified = [datetime]::Parse(@($head.Headers['Last-Modified'])[0]).ToUniversalTime()
                $ageMinutes = [int]([DateTime]::UtcNow - $lastModified).TotalMinutes
            }
        } catch {
            Write-ZsLog "Could not read the state blob's age: $($_.Exception.Message)" -Level WARN
        }

        if ($null -ne $ageMinutes -and $ageMinutes -lt $StaleAfterMinutes) {
            throw [System.InvalidOperationException]::new(
                "Refusing to break the state lock on $($c.StateKey): it was written $ageMinutes minute(s) ago, " +
                "which means the run holding it is very likely still alive. Breaking it would leave two " +
                "deployments reconciling $($script:ZsSession.ResourceGroupName) at once. Wait for it to finish, " +
                "or if you are certain it is dead, wait until the state is $StaleAfterMinutes minutes old.")
        }

        $ageNote = if ($null -ne $ageMinutes) { "last written $ageMinutes minute(s) ago" } else { 'age unknown' }
        Write-ZsLog "Breaking leftover state lease on $($c.StateKey) ($ageNote)" -Level WARN
        Invoke-ZsBlobRequest -Uri $leaseUri -Method Put -Headers @{
            'x-ms-lease-action'='break'; 'x-ms-lease-break-period'='0'
        } -AllowStatus @(409) | Out-Null
        $resp = Invoke-ZsBlobRequest -Uri $leaseUri -Method Put -Headers $acquire -AllowStatus @(409)
    }

    if ([int]$resp.StatusCode -eq 409) {
        throw [System.InvalidOperationException]::new(
            "Another deployment holds the state lock on $($c.StateKey). Wait for it to finish; " +
            "if it crashed, re-run with -BreakStateLock to take over.")
    }

    $leaseId = $null
    if ($resp.Headers -and $resp.Headers.ContainsKey('x-ms-lease-id')) { $leaseId = @($resp.Headers['x-ms-lease-id'])[0] }
    if (-not $leaseId) {
        throw [System.InvalidOperationException]::new(
            "The state blob lease was acquired but Azure returned no lease id, so the lock cannot be " +
            "released or written under. Re-run to retry.")
    }
    $script:ZsStateLeaseId = $leaseId
    Write-ZsLog "Acquired deployment state lock" -Level DEBUG
}

function Save-ZsRemoteState {
    <#
    .SYNOPSIS Writes the current in-memory manifest to the state blob under the held lease.
    #>
    [CmdletBinding()]
    param()
    $c = $script:ZsStateConfig
    if (-not $c) { return }

    $payload = Get-ZsManifest
    if (-not $payload) { return }

    Set-ZsBlob -AccountName $c.AccountName -ContainerName $c.ContainerName -BlobName $c.StateKey `
        -Content ($payload | ConvertTo-Json -Depth 20) -ContentType 'application/json' `
        -LeaseId $(if ($script:ZsStateLeaseId) { $script:ZsStateLeaseId } else { '' }) | Out-Null
}

function Get-ZsRemoteState {
    <#
    .SYNOPSIS Reads the remote state blob and returns it as a hashtable, or $null when absent.
    #>
    [CmdletBinding()]
    [OutputType([hashtable])]
    param(
        [string]$AccountName = '',
        [string]$ContainerName = 'zscc-state',
        [string]$StateKey = ''
    )
    if (-not $AccountName -and $script:ZsStateConfig) {
        $AccountName   = $script:ZsStateConfig.AccountName
        $ContainerName = $script:ZsStateConfig.ContainerName
        $StateKey      = $script:ZsStateConfig.StateKey
    }
    if (-not $AccountName) { throw 'No state storage account supplied and none configured for this session.' }
    if (-not $StateKey) {
        $StateKey = "$($script:ZsSession.SubscriptionId)-$($script:ZsSession.ResourceGroupName).json".ToLower()
    }
    $json = Get-ZsBlob -AccountName $AccountName -ContainerName $ContainerName -BlobName $StateKey
    if (-not $json) { return $null }
    return ($json | ConvertFrom-Json -AsHashtable)
}

function Close-ZsRemoteState {
    <#
    .SYNOPSIS Flushes final state and releases the lease. Safe to call when never initialized.
    .DESCRIPTION Intended for a finally block. Release failures are logged rather than thrown:
        masking a deployment's real error with a cleanup error helps nobody, and a stuck lease
        is recoverable with -BreakStateLock.
    #>
    [CmdletBinding()]
    param()
    $c = $script:ZsStateConfig
    if (-not $c) { return }

    try { Save-ZsRemoteState } catch { Write-ZsLog "Could not write final remote state: $($_.Exception.Message)" -Level WARN }

    if ($script:ZsStateLeaseId) {
        try {
            $leaseUri = "https://$($c.AccountName).blob.core.windows.net/$($c.ContainerName)/$($c.StateKey)?comp=lease"
            Invoke-ZsBlobRequest -Uri $leaseUri -Method Put -Headers @{
                'x-ms-lease-action'='release'; 'x-ms-lease-id'=$script:ZsStateLeaseId
            } | Out-Null
            Write-ZsLog "Released deployment state lock" -Level DEBUG
        } catch {
            Write-ZsLog "Could not release the state lock; recover with -BreakStateLock on the next run. $($_.Exception.Message)" -Level WARN
        }
        $script:ZsStateLeaseId = $null
    }
    $script:ZsStateConfig = $null
}
