<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module — resource paths, naming, tags, and artifact I/O.

.DESCRIPTION
    Small deterministic helpers shared across cmdlets: subscription/resource-group path builders,
    resource naming, tag assembly, local artifact path resolution, and manifest step lookup. Environment
    validation and capability checks live in ZsValidation.ps1; ARM/vault transport in Invoke-ArmRequest.ps1.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Get-ZsSubscriptionPath { return "/subscriptions/$($script:ZsSession.SubscriptionId)" }
function Get-ZsRgPath { return "$(Get-ZsSubscriptionPath)/resourceGroups/$($script:ZsSession.ResourceGroupName)" }

function Get-ZsArtifactRoot {
    <#
    .SYNOPSIS Returns the single directory under which all local artifacts are written.
    .DESCRIPTION Every file the module produces locally (logs, manifests, saved configs, SSH keys)
        is written under this root. Defaults to the runtime working directory. If the session carries
        an explicit ArtifactRoot it is used instead. The directory is created if it does not exist.
    .OUTPUTS [string] Absolute path to the artifact root.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param()

    # Read defensively: under Set-StrictMode -Version Latest, reading a key that is not present on
    # the session throws rather than yielding $null, so a session assembled without this key would
    # fail here instead of falling back to the working directory as intended.
    $configured = $null
    try { $configured = $script:ZsSession.ArtifactRoot } catch { }
    $root = if ($configured) { $configured } else { (Get-Location).Path }
    if (-not (Test-Path $root)) { [System.IO.Directory]::CreateDirectory($root) | Out-Null }
    return $root
}

function Get-ZsArtifactPath {
    <#
    .SYNOPSIS Resolves a file name to a full path under the artifact root.
    .PARAMETER FileName The bare file name to place under the artifact root.
    .OUTPUTS [string] Absolute path.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param([Parameter(Mandatory)][string]$FileName)
    return Join-Path (Get-ZsArtifactRoot) $FileName
}

function Resolve-ZsOutputFile {
    <#
    .SYNOPSIS Resolves a user-supplied path to a writable file path, appending a default name for directories.
    .DESCRIPTION Accepts an empty value (artifact root), an existing directory, a path ending in a separator,
        '.', a bare relative name (artifact root), or a full file path. Always returns a path that includes a
        file name, creating the target directory if needed. This prevents writing file contents to a directory.
    .PARAMETER Path The user-supplied path. May be empty, a directory, or a file path.
    .PARAMETER DefaultFileName File name to use when Path resolves to a directory.
    .OUTPUTS [string] A full file path suitable for writing.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param([string]$Path = '', [Parameter(Mandatory)][string]$DefaultFileName)

    if (-not $Path) { return Get-ZsArtifactPath -FileName $DefaultFileName }
    if (Test-Path $Path -PathType Container) { return Join-Path (Resolve-Path $Path).Path $DefaultFileName }
    if ($Path -in @('.', '.\', './') -or $Path.EndsWith('\') -or $Path.EndsWith('/')) {
        $dir = if ($Path -in @('.', '.\', './')) { (Get-Location).Path } else { $Path.TrimEnd('\','/') }
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        return Join-Path (Resolve-Path $dir).Path $DefaultFileName
    }
    if (-not [System.IO.Path]::IsPathRooted($Path)) { return Get-ZsArtifactPath -FileName $Path }
    return $Path
}

function New-ZsResourceName {
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)][string]$Prefix,
        [string]$Environment = '', [string]$Location = '', [string]$Suffix = ''
    )
    $parts = @($Prefix)
    if ($Environment) { $parts += $Environment }
    if ($Location)    { $parts += $Location }
    if ($Suffix)      { $parts += $Suffix }
    return ($parts -join '-').ToLower()
}

function Get-ZsTags {
    [CmdletBinding()]
    [OutputType([hashtable])]
    param([hashtable]$Extra = @{})
    $tags = @{
        'zscaler-deployment-id' = $script:ZsSession.DeploymentId
        'environment'           = $script:ZsSession.Environment
        'managed-by'            = $script:ZsOwnedByTag
        'deployed-at'           = $script:ZsSession.DeployedAt
    }
    foreach ($k in $Extra.Keys) { $tags[$k] = $Extra[$k] }
    return $tags
}

function Get-ZsPropertyValue {
    # Reads a dotted path such as properties.networkAcls.defaultAction, returning $null where a step
    # is missing. ARM leaves properties out freely (a subnet without an NSG has no
    # networkSecurityGroup at all), and under StrictMode a plain dereference of one throws.
    [CmdletBinding()]
    param([AllowNull()]$InputObject, [Parameter(Mandatory)][string]$Path)
    $cur = $InputObject
    foreach ($seg in ($Path -split '\.')) {
        if ($null -eq $cur) { return $null }
        if ($cur -is [System.Collections.IDictionary]) {
            $cur = if ($cur.Contains($seg)) { $cur[$seg] } else { $null }
            continue
        }
        $p = $cur.PSObject.Properties[$seg]
        $cur = if ($p) { $p.Value } else { $null }
    }
    return $cur
}

function ConvertTo-ZsCcUrl {
    # CC_URL is passed without a scheme, as Zscaler's own module passes it to the function and to the
    # connectors' cloud-init. Zscaler's package prefixes https:// itself (azure_utils.extract_base_url);
    # handed a URL that already has one, it takes "https" for the host and every sync fails.
    [CmdletBinding()]
    [OutputType([string])]
    param([AllowEmptyString()][string]$Url = '')
    return ($Url.Trim() -replace '^(?i)https?://', '')
}

function Get-ZsConnectorUserData {
    # The base64 [ZSCALER] block the connector image reads at first boot: the keys, and their order,
    # that the Terraform compute module sends. FIPS_ENABLED is written out because FIPS mode is fixed
    # when a connector is provisioned and cannot be changed afterwards.
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)][string]$ProvisioningUrl,
        [Parameter(Mandatory)][string]$KeyVaultUri,
        [Parameter(Mandatory)][int]$HttpProbePort,
        [string]$IdentityClientId = ''
    )
    $lines = @('[ZSCALER]', "CC_URL=$(ConvertTo-ZsCcUrl -Url $ProvisioningUrl)", "AZURE_VAULT_URL=$KeyVaultUri", "HTTP_PROBE_PORT=$HttpProbePort")
    if ($IdentityClientId) { $lines += "AZURE_MANAGED_IDENTITY_CLIENT_ID=$IdentityClientId" }
    $lines += 'FIPS_ENABLED=False'
    return [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes(($lines -join "`n")))
}

function Resolve-ZsHostAddress {
    # The IPv4 addresses this machine's own resolver gives for a name; none when it cannot resolve it.
    [CmdletBinding()]
    [OutputType([string[]])]
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$HostName)
    try {
        return @([System.Net.Dns]::GetHostAddresses($HostName) | Where-Object { $_.AddressFamily -eq 'InterNetwork' } | ForEach-Object { $_.IPAddressToString })
    } catch {
        Write-ZsLog "DNS lookup of $HostName failed: $($_.Exception.Message)" -Level DEBUG
        return @()
    }
}

function Test-ZsPrivateAddress {
    # RFC 1918 or the 100.64.0.0/10 shared space: where a private endpoint's address comes from.
    [CmdletBinding()]
    [OutputType([bool])]
    param([Parameter(Mandatory)][string]$Address)
    if ($Address -notmatch '^\d{1,3}(\.\d{1,3}){3}$') { return $false }
    $o = @($Address -split '\.' | ForEach-Object { [int]$_ })
    if ($o[0] -eq 10) { return $true }
    if ($o[0] -eq 172 -and $o[1] -ge 16 -and $o[1] -le 31) { return $true }
    if ($o[0] -eq 192 -and $o[1] -eq 168) { return $true }
    if ($o[0] -eq 100 -and $o[1] -ge 64 -and $o[1] -le 127) { return $true }
    return $false
}

function Resolve-ZsRoleDefinitionScope {
    <#
    .SYNOPSIS Returns the scope and deterministic GUID for one of this module's custom role
        definitions, following the deployment's scoping mode.
    .DESCRIPTION A greenfield deployment owns its subscription's namespace for these roles and
        writes them at subscription scope, so one definition serves every deployment in the
        subscription. A BringYourOwn deployment is the opposite case: the deployer commonly holds
        rights on its resource group and nothing above it, and Microsoft.Authorization/roleDefinitions/write
        at subscription scope is exactly the permission it does not have. Writing the definition at
        the group keeps the whole deployment inside group-scoped rights.

        The GUID is derived from the seed rather than randomly, so a PUT at that name is an upsert
        and re-runs reconcile the permission set instead of accumulating definitions. The seed
        carries the resource group under BringYourOwn, so a group-scoped definition has an id of
        its own. Greenfield seeds and scopes are those of earlier releases, so existing
        deployments continue to reconcile the definition they already have.
    .PARAMETER RoleName The display name of the custom role.
    .PARAMETER AtResourceGroup Write the definition at the resource group whatever the mode, as the
        connector replacement role is: it is assignable only within this deployment.
    .OUTPUTS PSCustomObject with Scope, Guid and ResourceId.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param([Parameter(Mandatory)][string]$RoleName, [switch]$AtResourceGroup)

    $subId = $script:ZsSession.SubscriptionId
    $byo   = $false
    try { $byo = [bool]$script:ZsSession.BringYourOwnResourceGroup } catch { }

    if ($byo -or $AtResourceGroup) {
        $scope = Get-ZsRgPath
        $seed  = "$subId|$($script:ZsSession.ResourceGroupName)|$RoleName"
    } else {
        $scope = Get-ZsSubscriptionPath
        $seed  = "$subId|$RoleName"
    }

    $md5 = [System.Security.Cryptography.MD5]::Create()
    try { $guid = [System.Guid]::new($md5.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($seed))).ToString() }
    finally { $md5.Dispose() }

    return [PSCustomObject]@{
        Scope      = $scope
        Guid       = $guid
        ResourceId = "$scope/providers/Microsoft.Authorization/roleDefinitions/$guid"
    }
}

function Test-ZsRoleDefinitionCurrent {
    # True when a custom role definition as Resource Manager returned it grants exactly these actions
    # and data actions, excludes nothing, and is assignable at exactly these scopes. A definition PUT
    # at a fixed GUID is an upsert, so this decides whether a run has anything to write, and what a
    # dry run reports.
    [CmdletBinding()]
    [OutputType([bool])]
    param(
        [AllowNull()]$Definition,
        [string[]]$Actions = @(),
        [string[]]$DataActions = @(),
        [Parameter(Mandatory)][string[]]$AssignableScopes
    )
    $setOf = { param($v) (@($v | Where-Object { $_ } | ForEach-Object { "$_".ToLowerInvariant() } | Sort-Object -Unique)) -join '|' }
    $perms = @(Get-ZsPropertyValue $Definition 'properties.permissions' | Where-Object { $_ })
    if ($perms.Count -ne 1) { return $false }
    return ((& $setOf (Get-ZsPropertyValue $perms[0] 'actions')) -eq (& $setOf $Actions)) -and
        ((& $setOf (Get-ZsPropertyValue $perms[0] 'dataActions')) -eq (& $setOf $DataActions)) -and
        -not (& $setOf (Get-ZsPropertyValue $perms[0] 'notActions')) -and
        -not (& $setOf (Get-ZsPropertyValue $perms[0] 'notDataActions')) -and
        ((& $setOf (Get-ZsPropertyValue $Definition 'properties.assignableScopes')) -eq (& $setOf $AssignableScopes))
}

function Test-ZsModuleOwned {
    <#
    .SYNOPSIS Reports whether a resource was created by this deployment stack, from the tag it
        stamps on creation.
    .DESCRIPTION The read side of the managed-by tag Get-ZsTags writes. It answers the question that
        decides whether teardown may delete a resource, and "did this run create it" is the wrong
        question to ask: a run that stops partway on a missing permission leaves resources behind,
        and the re-run that resumes verifies them instead of creating them. Those are the module's
        own resources either way, and a teardown that spared them because a later run did not happen
        to create them would leave a deployment that can never be removed.

        Two tag values count as owned. This module writes ZscalerCloudConnector-PSModule; the
        Terraform configuration that builds the same deployment writes terraform-zscc. They produce
        the same resources under the same names, and either can be asked to remove the other's work,
        so recognising only its own tag would let this module adopt a Terraform-built deployment on
        a re-run, mark every resource in it as somebody else's, and then refuse to tear down what it
        had just reconciled.

        Absence of the tag is taken as not owned. A resource the customer brought — their virtual
        network, their key vault — carries no such tag, and treating an unreadable answer as
        ownership would put someone else's infrastructure on the delete list.
    .PARAMETER Resource The ARM resource as returned by a GET.
    .OUTPUTS [bool]
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([bool])]
    param($Resource)

    # Read defensively: Set-StrictMode -Version Latest turns an absent member into a terminating
    # error, and an untagged resource genuinely has no tags member at all.
    try {
        if (-not $Resource -or -not $Resource.PSObject.Properties['tags'] -or -not $Resource.tags) { return $false }
        foreach ($t in $Resource.tags.PSObject.Properties) {
            if ($t.Name -eq 'managed-by' -and [string]$t.Value -in $script:ZsOwnedByTags) { return $true }
        }
    } catch { }
    return $false
}

