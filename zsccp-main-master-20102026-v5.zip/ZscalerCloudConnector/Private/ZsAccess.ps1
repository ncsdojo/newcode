<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module — deployment scope resolution, effective-permission
    evaluation, Azure Policy restriction discovery, and ARM failure classification.

.DESCRIPTION
    Everything a run needs in order to answer one question before it builds anything: at the scope
    this deployment will actually write to, does the calling identity hold the control-plane actions
    the deployment requires, and is any enforcing Azure Policy going to refuse the result?

    Scope is decided once, here, and bound to the session before any other check runs:

      Greenfield  — no BringYourOwn.ResourceGroupName in the config. The module creates its own
                    resource group, so the subscription is the scope that must hold the permissions.
      Brownfield  — BringYourOwn.ResourceGroupName is present AND the resource group exists. The
                    resource group is the scope. A named group that does not exist, or exists but
                    cannot be read, is a clean stop rather than a silent fall back to greenfield.

    Permissions come from the documented Permissions - List API, which returns the aggregated
    actions/notActions of the *calling* identity at the queried scope, inheritance from management
    group and subscription included. Deny assignments are read separately and subtracted, because
    the permissions API does not account for them. Azure Policy blockers are discovered ahead of
    time through Policy Insights checkPolicyRestrictions, which names the offending assignment and
    definition so the operator is told which policy stopped them rather than being handed an opaque
    refusal twenty minutes into a run.

    Everything here is read-only. Nothing in this file mutates Azure state.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

Set-StrictMode -Version Latest

# API versions for the access-preflight surface. Kept beside the code that uses them so a version
# bump is a one-line change reviewed against the operations it affects.
$script:AccessApiVersions = [ordered]@{
    Permissions        = '2022-04-01'   # Permissions - List / List For Resource Group
    DenyAssignments    = '2022-04-01'   # Deny Assignments - List For Scope
    RoleAssignments    = '2022-04-01'
    RoleDefinitions    = '2022-04-01'
    ResourceGroup      = '2021-04-01'   # Resource Groups - Check Existence (HEAD)
    PolicyRestrictions = '2023-03-01'   # Microsoft.PolicyInsights checkPolicyRestrictions
    PolicyAssignments  = '2022-06-01'
    PolicyDefinitions  = '2023-04-01'
}

# Token claims

function Get-ZsTokenClaims {
    <#
    .SYNOPSIS Decodes the current ARM access token's payload claims locally.
    .DESCRIPTION Role assignments and permission lookups key off the service principal's *object*
        id — the 'oid' claim — not the application/client id. Reading it from the token avoids a
        Microsoft Graph round trip and the directory-read permission that call would otherwise
        require. Decoding is local and performs no signature validation: the token was just issued
        to this process by Entra ID and is used here only to identify the caller to itself.
    .OUTPUTS PSCustomObject: ObjectId, AppId, TenantId, DisplayName, IdentityType.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param([string]$Token = '')

    $empty = [PSCustomObject]@{ ObjectId=''; AppId=''; TenantId=''; DisplayName=''; IdentityType='Unknown' }
    if (-not $Token) {
        try { $Token = Get-ArmToken } catch { return $empty }
    }
    if (-not $Token) { return $empty }

    $parts = $Token -split '\.'
    if ($parts.Count -lt 2) { return $empty }

    try {
        # Base64url -> base64, restoring the padding the JWT encoding strips.
        $b64 = $parts[1].Replace('-', '+').Replace('_', '/')
        switch ($b64.Length % 4) { 2 { $b64 += '==' } 3 { $b64 += '=' } 1 { return $empty } }
        $json   = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b64))
        $claims = $json | ConvertFrom-Json

        $has = { param($n) $null -ne $claims.PSObject.Properties[$n] }
        $oid = if (& $has 'oid') { [string]$claims.oid } else { '' }
        $app = if (& $has 'appid') { [string]$claims.appid } elseif (& $has 'azp') { [string]$claims.azp } else { '' }
        $tid = if (& $has 'tid') { [string]$claims.tid } else { '' }
        $nam = if (& $has 'app_displayname') { [string]$claims.app_displayname }
               elseif (& $has 'name') { [string]$claims.name }
               elseif (& $has 'upn') { [string]$claims.upn }
               else { '' }
        # idtyp is present on app-only tokens; its absence with a upn/name claim indicates a user.
        $typ = if ((& $has 'idtyp') -and [string]$claims.idtyp -eq 'app') { 'ServicePrincipal' }
               elseif ((& $has 'upn') -or (& $has 'unique_name')) { 'User' }
               elseif ($app -and -not (& $has 'upn')) { 'ServicePrincipal' }
               else { 'Unknown' }

        return [PSCustomObject]@{ ObjectId=$oid; AppId=$app; TenantId=$tid; DisplayName=$nam; IdentityType=$typ }
    } catch {
        Write-ZsLog "Could not decode ARM token claims: $($_.Exception.Message)" -Level DEBUG
        return $empty
    }
}

# Scope resolution

function Test-ZsResourceGroupExists {
    <#
    .SYNOPSIS Determines whether a resource group exists, distinguishing absence from inaccessibility.
    .DESCRIPTION Uses the Resource Groups - Check Existence operation (HEAD), whose three outcomes
        are three genuinely different situations that must not be collapsed into one:

          204  the group exists and is readable
          404  the group does not exist
          403  the group exists but this identity cannot read it

        Treating 403 as "not found" would send a brownfield run down the greenfield path and have it
        attempt to create a resource group that is already there. Each outcome gets its own verdict.
    .PARAMETER Name The resource group name.
    .OUTPUTS PSCustomObject: Exists (bool), Readable (bool), StatusCode (int), Verdict (string).
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Name)

    $uri = "$($script:Endpoints.Arm)/subscriptions/$($script:ZsSession.SubscriptionId)/resourcegroups/$([uri]::EscapeDataString($Name))?api-version=$($script:AccessApiVersions.ResourceGroup)"
    try {
        $resp   = Invoke-WebRequest -Uri $uri -Method Head -Headers @{ Authorization = "Bearer $(Get-ArmToken)" } -SkipHttpErrorCheck -TimeoutSec 60
        $status = [int]$resp.StatusCode
    } catch {
        Write-ZsLog "Resource group existence check for '$Name' was inconclusive: $($_.Exception.Message)" -Level DEBUG
        return [PSCustomObject]@{ Exists=$false; Readable=$false; StatusCode=0; Verdict='Inconclusive' }
    }

    switch ($status) {
        204     { return [PSCustomObject]@{ Exists=$true;  Readable=$true;  StatusCode=204; Verdict='Exists' } }
        200     { return [PSCustomObject]@{ Exists=$true;  Readable=$true;  StatusCode=200; Verdict='Exists' } }
        404     { return [PSCustomObject]@{ Exists=$false; Readable=$true;  StatusCode=404; Verdict='NotFound' } }
        403     { return [PSCustomObject]@{ Exists=$true;  Readable=$false; StatusCode=403; Verdict='Forbidden' } }
        401     { return [PSCustomObject]@{ Exists=$false; Readable=$false; StatusCode=401; Verdict='Unauthenticated' } }
        default { return [PSCustomObject]@{ Exists=$false; Readable=$false; StatusCode=$status; Verdict='Inconclusive' } }
    }
}

function Resolve-ZsDeploymentScope {
    <#
    .SYNOPSIS Decides, once, which ARM scope this deployment writes to, and binds it to the session.
    .DESCRIPTION The scope determines which permissions matter, which policies apply, and which
        preflight checks are even meaningful, so it is settled before any other check runs rather
        than being discovered partway through the build.

        A BringYourOwn resource group name in the config declares brownfield intent. That intent is
        honoured only when the group actually exists; the alternatives are reported plainly instead
        of being worked around:

          exists            brownfield. Scope is the resource group. The session's resource group
                            name is rebound now, so every subsequent path and check targets it.
          does not exist    stop. The config names a group that is not there. Silently creating it
                            would turn a brownfield deployment into a greenfield one against a name
                            the operator expected to already hold their network.
          not readable      stop. The group is there but this identity cannot see it, which is a
                            permission problem to fix, not a deployment to attempt.

        With no BringYourOwn group the module creates its own, so the subscription is the scope.
    .PARAMETER ResourceGroupName The BringYourOwn resource group name from the config, if any.
    .PARAMETER Cmdlet The calling $PSCmdlet, so a stop surfaces from the operator's cmdlet.
    .OUTPUTS PSCustomObject: Kind, Scope, SubscriptionId, ResourceGroupName, Mode, IsExisting.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [string]$ResourceGroupName = '',
        [System.Management.Automation.PSCmdlet]$Cmdlet = $null
    )

    $subId   = $script:ZsSession.SubscriptionId
    $subPath = "/subscriptions/$subId"
    $rgName  = $ResourceGroupName.Trim()

    if (-not $rgName) {
        $planned = $script:ZsSession.ResourceGroupName
        # A greenfield run whose target group already exists is still greenfield — the module owns
        # the group either way — but the operator should know they are adding to something.
        $pre = Test-ZsResourceGroupExists -Name $planned
        if ($pre.Exists -and $pre.Readable) {
            Write-ZsLog "Resource group $planned already exists; the deployment will add to it" -Level DEBUG
        }
        $script:ZsSession.BringYourOwnResourceGroup = $false
        return [PSCustomObject]@{
            Kind='Subscription'; Scope=$subPath; SubscriptionId=$subId
            ResourceGroupName=$planned; Mode='Greenfield'; IsExisting=[bool]$pre.Exists
        }
    }

    $check = Test-ZsResourceGroupExists -Name $rgName
    switch ($check.Verdict) {
        'Exists' {
            # Bind now. Everything downstream — Get-ZsRgPath, manifest, teardown — reads this.
            $script:ZsSession.ResourceGroupName = $rgName
            # Custom role definitions follow the scoping mode: a brownfield deployer usually holds
            # roleDefinitions/write on its group and not on the subscription, so the definitions are
            # written at the group. Resolve-ZsRoleDefinitionScope reads this.
            $script:ZsSession.BringYourOwnResourceGroup = $true
            if ($script:ZsManifest) { $script:ZsManifest.ResourceGroup = $rgName }
            return [PSCustomObject]@{
                Kind='ResourceGroup'; Scope="$subPath/resourceGroups/$rgName"; SubscriptionId=$subId
                ResourceGroupName=$rgName; Mode='Brownfield'; IsExisting=$true
            }
        }
        'NotFound' {
            Write-ZsError -Cmdlet $Cmdlet -ErrorId 'ZsByoResourceGroupNotFound' -Category ObjectNotFound -Message (
                "The config names an existing resource group to deploy into, but '$rgName' does not exist in subscription $subId.`n" +
                "  Brownfield deployments only ever deploy into a resource group that is already there.`n" +
                "  Either create '$rgName' first, correct BringYourOwn.ResourceGroupName in the config, or clear that field to let the module create and own its own resource group.`n" +
                "  Nothing has been deployed.")
        }
        'Forbidden' {
            $who = (Get-ZsTokenClaims).DisplayName
            $sp  = if ($who) { "'$who'" } else { 'this identity' }
            Write-ZsError -Cmdlet $Cmdlet -ErrorId 'ZsByoResourceGroupForbidden' -Category PermissionDenied -Message (
                "Resource group '$rgName' exists, but $sp cannot read it.`n" +
                "  Missing permission: Microsoft.Resources/subscriptions/resourceGroups/read at /subscriptions/$subId/resourceGroups/$rgName`n" +
                "  Grant at least Reader on that resource group, then re-run.`n" +
                "  Nothing has been deployed.")
        }
        'Unauthenticated' {
            Write-ZsError -Cmdlet $Cmdlet -ErrorId 'ZsTokenRejected' -Category AuthenticationError -Message (
                "Azure rejected the access token while checking resource group '$rgName'. Re-run Connect-ZscalerAzure and try again. Nothing has been deployed.")
        }
        default {
            Write-ZsError -Cmdlet $Cmdlet -ErrorId 'ZsScopeInconclusive' -Category ConnectionError -Message (
                "Could not determine whether resource group '$rgName' exists (HTTP $($check.StatusCode)).`n" +
                "  The deployment scope cannot be established, so nothing has been attempted. Verify network access to management.azure.com and re-run.")
        }
    }
}

# Effective permissions

function Get-ZsEffectivePermissions {
    <#
    .SYNOPSIS Returns the calling identity's aggregated permissions at a scope.
    .DESCRIPTION Reads the Permissions - List API, which returns the effective actions/notActions
        and dataActions/notDataActions of the caller at the scope, already aggregated across every
        role assigned to it directly or inherited from a group, subscription, or management group.
        Results page; every page is followed.
    .PARAMETER Scope ARM scope, e.g. /subscriptions/{id} or /subscriptions/{id}/resourceGroups/{rg}.
    .OUTPUTS PSCustomObject: Available (bool), Sets (object[]), Reason (string).
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param([Parameter(Mandatory)][string]$Scope)

    $sets = [System.Collections.Generic.List[object]]::new()
    $uri  = "$Scope/providers/Microsoft.Authorization/permissions?api-version=$($script:AccessApiVersions.Permissions)"
    $page = 0

    try {
        while ($uri -and $page -lt 20) {
            $page++
            $resp = if ($uri -like 'http*') {
                Invoke-RestMethod -Uri $uri -Headers @{ Authorization = "Bearer $(Get-ArmToken)" } -TimeoutSec 60 -ErrorAction Stop
            } else {
                Invoke-ArmGet -Uri $uri
            }
            foreach ($v in @($resp.value)) { $sets.Add($v) }

            $uri = ''
            if ($resp.PSObject.Properties['nextLink'] -and $resp.nextLink) { $uri = [string]$resp.nextLink }
        }
        Write-ZsLog "Effective permissions read at $Scope ($($sets.Count) permission set(s))" -Level DEBUG
        return [PSCustomObject]@{ Available=$true; Sets=$sets.ToArray(); Reason='' }
    } catch {
        $status = 0; try { $status = [int]$_.Exception.Response.StatusCode } catch { }
        $reason = if ($status -eq 403) {
            'The identity lacks Microsoft.Authorization/permissions/read at this scope, so its effective permissions cannot be enumerated.'
        } else {
            "The permissions API could not be read: $($_.Exception.Message)"
        }
        Write-ZsLog "Effective permission enumeration unavailable at ${Scope}: $reason" -Level DEBUG
        return [PSCustomObject]@{ Available=$false; Sets=@(); Reason=$reason }
    }
}

function Get-ZsDenyAssignments {
    <#
    .SYNOPSIS Returns deny assignments applying at a scope.
    .DESCRIPTION The permissions API reports what roles grant; it does not subtract deny assignments,
        which override every grant. They are read separately so a preflight does not report an action
        as available when a deny assignment will refuse it at write time. Unreadable deny assignments
        are not fatal — most identities cannot read them — but the gap is recorded so the verdict can
        be honest about what it did and did not verify.
    .OUTPUTS PSCustomObject: Available (bool), Assignments (object[]).
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param([Parameter(Mandatory)][string]$Scope)

    try {
        $resp = Invoke-ArmGet -Uri "$Scope/providers/Microsoft.Authorization/denyAssignments?api-version=$($script:AccessApiVersions.DenyAssignments)"
        return [PSCustomObject]@{ Available=$true; Assignments=@($resp.value) }
    } catch {
        Write-ZsLog "Deny assignments not readable at $Scope; the permission verdict does not account for them" -Level DEBUG
        return [PSCustomObject]@{ Available=$false; Assignments=@() }
    }
}

function ConvertTo-ZsActionRegex {
    <#
    .SYNOPSIS Translates an RBAC action pattern into an anchored regex.
    .DESCRIPTION RBAC action strings are case-insensitive and use '*' as their only wildcard, which
        spans path separators: 'Microsoft.Network/*' matches 'Microsoft.Network/virtualNetworks/write'.
        Every other regex metacharacter in the pattern — the '.' in a provider namespace above all —
        must be escaped so it matches literally rather than matching any character.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param([Parameter(Mandatory)][AllowEmptyString()][string]$Pattern)
    if (-not $Pattern) { return '^$' }
    $escaped = [regex]::Escape($Pattern).Replace('\*', '.*')
    return "^$escaped$"
}

function Test-ZsActionGranted {
    <#
    .SYNOPSIS Evaluates whether a required action is granted by a set of permission objects.
    .DESCRIPTION Applies Azure RBAC's evaluation rules:

          * a permission set grants an action when one of its actions matches and none of its
            notActions matches — notActions subtract from that set, they are not a global deny;
          * sets are additive, so the action is granted when *any* set grants it. A notAction in one
            role never removes what another role grants;
          * deny assignments override everything, and are applied last.

        Data-plane requirements are evaluated against dataActions/notDataActions by the same rules.
    .PARAMETER Action The required action string.
    .PARAMETER Sets Permission objects from Get-ZsEffectivePermissions.
    .PARAMETER DenyAssignments Deny assignments from Get-ZsDenyAssignments.
    .PARAMETER PrincipalId The caller's object id, used to test deny-assignment applicability.
    .PARAMETER DataAction Evaluate against dataActions instead of actions.
    .OUTPUTS PSCustomObject: Granted (bool), Denied (bool), DeniedBy (string).
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][string]$Action,
        [object[]]$Sets = @(),
        [object[]]$DenyAssignments = @(),
        [string]$PrincipalId = '',
        [switch]$DataAction
    )

    $needle  = $Action.ToLowerInvariant()
    $granted = $false

    foreach ($s in $Sets) {
        if (-not $s) { continue }
        $allow = @(); $subtract = @()
        try {
            if ($DataAction) {
                if ($s.PSObject.Properties['dataActions'])    { $allow    = @($s.dataActions) }
                if ($s.PSObject.Properties['notDataActions']) { $subtract = @($s.notDataActions) }
            } else {
                if ($s.PSObject.Properties['actions'])    { $allow    = @($s.actions) }
                if ($s.PSObject.Properties['notActions']) { $subtract = @($s.notActions) }
            }
        } catch { continue }

        $matched = $false
        foreach ($a in $allow) {
            if ($a -and $needle -match (ConvertTo-ZsActionRegex -Pattern ([string]$a).ToLowerInvariant())) { $matched = $true; break }
        }
        if (-not $matched) { continue }

        $removed = $false
        foreach ($n in $subtract) {
            if ($n -and $needle -match (ConvertTo-ZsActionRegex -Pattern ([string]$n).ToLowerInvariant())) { $removed = $true; break }
        }
        # This set grants it; another set's notActions cannot take it away.
        if (-not $removed) { $granted = $true; break }
    }

    # Deny assignments outrank every grant.
    $denied = $false; $deniedBy = ''
    foreach ($d in $DenyAssignments) {
        if (-not $d -or -not $d.PSObject.Properties['properties']) { continue }
        $p = $d.properties
        try {
            $applies = $false
            foreach ($pr in @($p.principals)) {
                $pid = [string]$pr.id
                if ($pid -eq $PrincipalId -or $pid -eq '00000000-0000-0000-0000-000000000000') { $applies = $true; break }
            }
            if (-not $applies) { continue }
            foreach ($ex in @($p.excludePrincipals)) {
                if ([string]$ex.id -eq $PrincipalId) { $applies = $false; break }
            }
            if (-not $applies) { continue }

            foreach ($perm in @($p.permissions)) {
                $dAllow = if ($DataAction) { @($perm.dataActions) } else { @($perm.actions) }
                $dNot   = if ($DataAction) { @($perm.notDataActions) } else { @($perm.notActions) }
                $hit = $false
                foreach ($a in $dAllow) { if ($a -and $needle -match (ConvertTo-ZsActionRegex -Pattern ([string]$a).ToLowerInvariant())) { $hit = $true; break } }
                if (-not $hit) { continue }
                $exempt = $false
                foreach ($n in $dNot) { if ($n -and $needle -match (ConvertTo-ZsActionRegex -Pattern ([string]$n).ToLowerInvariant())) { $exempt = $true; break } }
                if (-not $exempt) {
                    $denied = $true
                    $deniedBy = if ($p.PSObject.Properties['denyAssignmentName'] -and $p.denyAssignmentName) { [string]$p.denyAssignmentName } else { [string]$d.name }
                    break
                }
            }
        } catch { continue }
        if ($denied) { break }
    }

    return [PSCustomObject]@{ Granted=($granted -and -not $denied); Denied=$denied; DeniedBy=$deniedBy }
}

# Required action matrix

function Get-ZsRequiredActions {
    <#
    .SYNOPSIS Returns the control-plane actions this deployment needs, tagged with the scope each
        one must be held at and the feature that requires it.
    .DESCRIPTION The matrix is shaped by the run, not fixed: a deployment that assigns no roles does
        not need roleAssignments/write, and one that never touches Defender does not need
        Microsoft.Security. Each entry records the scope at which the action must be held, which is
        what makes a brownfield verdict meaningful — several operations are subscription-level by
        nature and cannot be satisfied by any amount of permission on a resource group.
    .OUTPUTS PSCustomObject[]: Action, Purpose, RequiredScope ('Subscription'|'Deployment'), DataAction.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject[]])]
    param(
        [ValidateSet('Greenfield','Brownfield')][string]$Mode = 'Greenfield',
        [ValidateSet('VM','VMSS')][string]$Topology = 'VM',
        [string]$IdentityRoleMode = 'LeastPrivilege',
        [string]$FunctionRoleMode = 'Reader',
        [switch]$Bastion,
        [switch]$Defender,
        [switch]$MonitorPrivateLink,
        [ValidateSet('Premium','Standard','Basic')][string]$BastionSku = 'Premium',
        [ValidateSet('ip','prefix')][string]$NatPublicIpMode = 'ip',
        [switch]$NatExistingPublicIp,
        [switch]$NoNatGateway,
        [switch]$RemediationRole,
        [switch]$LocalFunctionPackage
    )

    $m = [System.Collections.Generic.List[PSCustomObject]]::new()
    $add = {
        param([string]$Action, [string]$Purpose, [string]$RequiredScope = 'Deployment', [bool]$IsData = $false)
        $m.Add([PSCustomObject]@{ Action=$Action; Purpose=$Purpose; RequiredScope=$RequiredScope; DataAction=$IsData })
    }

    # Resource group. Greenfield creates it; brownfield only needs to read the one it was given.
    if ($Mode -eq 'Greenfield') {
        & $add 'Microsoft.Resources/subscriptions/resourceGroups/write' 'Create the deployment resource group' 'Subscription'
    }
    & $add 'Microsoft.Resources/subscriptions/resourceGroups/read' 'Read the deployment resource group' 'Deployment'
    & $add 'Microsoft.Resources/deployments/read' 'Read deployment state' 'Deployment'

    # Networking.
    & $add 'Microsoft.Network/virtualNetworks/write'          'Create the connector virtual network'
    & $add 'Microsoft.Network/virtualNetworks/subnets/write'  'Create management, service, workload and function subnets'
    & $add 'Microsoft.Network/virtualNetworks/subnets/join/action' 'Attach interfaces and delegated services to subnets'
    & $add 'Microsoft.Network/networkSecurityGroups/write'    'Create per-zone network security groups'
    & $add 'Microsoft.Network/networkSecurityGroups/join/action' 'Associate NSGs with subnets and interfaces'
    & $add 'Microsoft.Network/networkInterfaces/write'        'Create connector management and service interfaces'
    & $add 'Microsoft.Network/routeTables/write'              'Create the workload route table'
    & $add 'Microsoft.Network/routeTables/join/action'        'Associate the route table with the workload subnet'
    # Public addresses: a Bastion public IP only for the SKUs that have one (a private-only Premium
    # Bastion has none), and the NAT gateway's egress address unless one is supplied. Where the
    # platform's own egress serves the subnets (NoNatGateway) there is no NAT gateway at all.
    if ($Bastion -and $BastionSku -ne 'Premium') { & $add 'Microsoft.Network/publicIPAddresses/write' 'Create the Bastion public address' }
    if (-not $NoNatGateway) {
        if (-not $NatExistingPublicIp) {
            if ($NatPublicIpMode -eq 'prefix') { & $add 'Microsoft.Network/publicIPPrefixes/write' 'Create the NAT gateway egress prefix' }
            else { & $add 'Microsoft.Network/publicIPAddresses/write' 'Create the NAT gateway egress address' }
        }
        if ($NatPublicIpMode -eq 'prefix') { & $add 'Microsoft.Network/publicIPPrefixes/join/action' 'Attach the egress prefix to the NAT gateway' }
        else { & $add 'Microsoft.Network/publicIPAddresses/join/action' 'Attach the egress address to the NAT gateway' }
        & $add 'Microsoft.Network/natGateways/write'              'Create the NAT gateway for connector egress'
        & $add 'Microsoft.Network/natGateways/join/action'        'Associate the NAT gateway with the connector and function subnets'
    }
    & $add 'Microsoft.Network/loadBalancers/write'            'Create the internal load balancer'
    & $add 'Microsoft.Network/privateEndpoints/write'         'Create private endpoints for storage and monitoring'
    & $add 'Microsoft.Network/privateDnsZones/write'          'Create private DNS zones for those endpoints'
    & $add 'Microsoft.Network/privateDnsZones/virtualNetworkLinks/write' 'Link private DNS zones to the virtual network'
    if ($Bastion) { & $add 'Microsoft.Network/bastionHosts/write' 'Create the Bastion host for connector administration' }

    # Compute.
    if ($Topology -eq 'VMSS') {
        & $add 'Microsoft.Compute/virtualMachineScaleSets/write' 'Create the connector scale set'
        # A Flexible scale set creates each connector as a VM with its own NICs and disk on the
        # caller's behalf; Microsoft lists Compute VM Write and Network beside the scale set write.
        & $add 'Microsoft.Compute/virtualMachines/write'         'Create the connector VMs the Flexible scale set places'
        & $add 'Microsoft.Compute/disks/write'                   'Create connector OS disks'
        & $add 'Microsoft.Network/loadBalancers/backendAddressPools/join/action' 'Join connector service NICs to the backend pool'
        & $add 'Microsoft.Insights/autoscaleSettings/write'      'Create scale set autoscale rules'
    } else {
        & $add 'Microsoft.Compute/virtualMachines/write' 'Create the connector virtual machines'
        & $add 'Microsoft.Compute/disks/write'           'Create connector OS disks'
    }

    # Identity and authorization.
    & $add 'Microsoft.ManagedIdentity/userAssignedIdentities/write'  'Create the connector and function managed identities'
    & $add 'Microsoft.ManagedIdentity/userAssignedIdentities/assign/action' 'Attach those identities to compute and the function app'
    # Whatever the role modes, the identities get their vault and storage data roles and the
    # function its health-remediation grants.
    & $add 'Microsoft.Authorization/roleAssignments/write' 'Assign roles to the managed identities'
    & $add 'Microsoft.Authorization/roleAssignments/read'  'Detect existing role assignments before assigning'
    if ($IdentityRoleMode -eq 'LeastPrivilege' -or $FunctionRoleMode -eq 'LeastPrivilege') {
        # Custom role definitions follow the scoping mode. Greenfield writes them at the
        # subscription, so one definition serves every deployment there. Brownfield writes them at
        # the resource group, because a group-scoped deployer does not hold roleDefinitions/write
        # any higher — demanding it at the subscription would fail a deployment that can in fact
        # complete, which is the failure this whole matrix exists to avoid.
        $roleDefScope = if ($Mode -eq 'Brownfield') { 'Deployment' } else { 'Subscription' }
        & $add 'Microsoft.Authorization/roleDefinitions/write' 'Create the least-privilege custom role definitions' $roleDefScope
        & $add 'Microsoft.Authorization/roleDefinitions/delete' 'Remove those definitions at teardown once nothing is assigned to them' $roleDefScope
    }
    if ($RemediationRole) {
        # The connector replacement role is defined at the deployment group, whatever the mode.
        & $add 'Microsoft.Authorization/roleDefinitions/write' 'Create the connector replacement role at the resource group'
        & $add 'Microsoft.Authorization/roleDefinitions/delete' 'Remove it at teardown once nothing is assigned to it'
    }
    # Locking is only half the transaction. An identity that can write a lock but not read or remove
    # one deploys successfully and then cannot tear down: every locked resource refuses its delete
    # with ScopeLocked, and the lock it cannot see is the reason. All three are required together,
    # which is what the custom role in the README grants.
    & $add 'Microsoft.Authorization/locks/write'  'Lock deployed resources against accidental deletion'
    & $add 'Microsoft.Authorization/locks/read'   'Find those locks again at teardown'
    & $add 'Microsoft.Authorization/locks/delete' 'Remove them at teardown, without which the resources they protect cannot be deleted'

    # Key Vault, storage, function app, monitoring.
    & $add 'Microsoft.KeyVault/vaults/write' 'Create the deployment key vault'
    # The connector credentials go in through Resource Manager, which the vault's firewall does
    # not cover: a control-plane write, not a data-plane role, and no line of sight to the vault.
    & $add 'Microsoft.KeyVault/vaults/secrets/write' 'Write connector credentials into the vault through Resource Manager'
    & $add 'Microsoft.Storage/storageAccounts/write'        'Create the function storage account'
    # A local function package is zip-deployed to the app through its private endpoint with the
    # deployer's Entra token, and the app is tagged with the package it received. Line of sight to
    # that endpoint is the other requirement, which no permission shows.
    if ($LocalFunctionPackage) {
        & $add 'Microsoft.Web/sites/publish/Action' 'Zip-deploy the function package through the app''s private endpoint'
        & $add 'Microsoft.Resources/tags/write'     'Record on the app which function package it runs'
        Write-ZsLog 'The function package is zip-deployed through the Function App''s private endpoint: run from a host inside the network.' -Level DEBUG
    }
    & $add 'Microsoft.Web/serverfarms/write'                'Create the lifecycle function app service plan'
    & $add 'Microsoft.Web/sites/write'                      'Create the lifecycle function app'
    & $add 'Microsoft.Web/sites/config/write'               'Configure function app settings and access restrictions'
    & $add 'Microsoft.Web/serverfarms/join/action'          'Place the function app on its plan'
    & $add 'Microsoft.OperationalInsights/workspaces/write' 'Create the Log Analytics workspace'
    & $add 'Microsoft.Insights/components/write'            'Create the Application Insights component'
    & $add 'Microsoft.Insights/actionGroups/write'          'Create the alert action group'
    & $add 'Microsoft.Insights/metricAlerts/write'          'Create connector health and capacity alerts'
    & $add 'Microsoft.Insights/scheduledQueryRules/write'   'Create log-based alert rules'
    & $add 'Microsoft.Insights/diagnosticSettings/write'    'Route resource diagnostics to the workspace'
    if ($MonitorPrivateLink) { & $add 'Microsoft.Insights/privateLinkScopes/write' 'Create the Azure Monitor private link scope' }

    # Subscription-level operations. These cannot be satisfied at resource group scope at all.
    & $add 'Microsoft.MarketplaceOrdering/offertypes/publishers/offers/plans/agreements/write' 'Accept the Cloud Connector marketplace image terms' 'Subscription'
    & $add 'Microsoft.Resources/subscriptions/providers/register/action' 'Register the resource providers the deployment uses' 'Subscription'
    & $add 'Microsoft.Features/providers/features/register/action' 'Register the EncryptionAtHost compute feature' 'Subscription'
    if ($Defender) { & $add 'Microsoft.Security/pricings/write' 'Enable the requested Defender for Cloud plans' 'Subscription' }

    return $m.ToArray()
}

# Azure Policy

function Test-ZsPolicyRestrictions {
    <#
    .SYNOPSIS Discovers enforcing Azure Policy assignments that would refuse this deployment, by name.
    .DESCRIPTION Calls Policy Insights checkPolicyRestrictions with a representative shape of each
        resource type the deployment creates that policy commonly restricts, and reports any Deny
        result together with the assignment and definition display names behind it.

        This is the difference between "the deployment failed" and "the deployment was refused by
        'Deny public IP addresses', assigned at the subscription" — the second is actionable without
        anyone reading a portal blade.

        The API reports Deny effects only. Audit, Modify and DeployIfNotExists are invisible to it
        and are not blockers, so their absence here is correct rather than a gap.
    .PARAMETER Scope Subscription or resource group scope to evaluate against.
    .PARAMETER Location The region the deployment targets.
    .PARAMETER BastionPublicIpExists The Bastion's public IP exists already and is not created again.
    .PARAMETER NatExistingPublicIp No NAT egress address is created: one was supplied, or this
        deployment's own exists already.
    .PARAMETER NoNatGateway No NAT gateway is created: the platform's egress serves the subnets.
    .OUTPUTS PSCustomObject: Available (bool), Blockers (object[]), Checked (int), Reason (string).
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][string]$Scope,
        [Parameter(Mandatory)][string]$Location,
        [ValidateSet('VM','VMSS')][string]$Topology = 'VM',
        [string]$VmSize = 'Standard_D2s_v3',
        [switch]$Bastion,
        [ValidateSet('Premium','Standard','Basic')][string]$BastionSku = 'Premium',
        [switch]$BastionPublicIpExists,
        [ValidateSet('ip','prefix')][string]$NatPublicIpMode = 'ip',
        [switch]$NatExistingPublicIp,
        [switch]$NoNatGateway
    )

    # One probe per resource the deployment creates that policy commonly restricts, in the shape
    # the deployment actually creates it. A probe stricter than the real request reports a refusal
    # the deployment would never meet; a looser one misses one it will.
    $probes = [System.Collections.Generic.List[object]]::new()
    if (-not $NoNatGateway) {
        if (-not $NatExistingPublicIp) {
            if ($NatPublicIpMode -eq 'prefix') {
                $probes.Add(@{ Label='NAT egress prefix'; Type='Microsoft.Network/publicIPPrefixes'; Api='2025-03-01'
                               Content=@{ sku=@{ name='StandardV2' }; properties=@{ prefixLength=31; publicIPAddressVersion='IPv4' } } })
            } else {
                $probes.Add(@{ Label='NAT egress public IP'; Type='Microsoft.Network/publicIPAddresses'; Api='2025-03-01'
                               Content=@{ sku=@{ name='StandardV2' }; properties=@{ publicIPAllocationMethod='Static'; publicIPAddressVersion='IPv4' } } })
            }
        }
        $probes.Add(@{ Label='NAT gateway'; Type='Microsoft.Network/natGateways'; Api='2025-03-01'
                       Content=@{ sku=@{ name='StandardV2' }; properties=@{ idleTimeoutInMinutes=10 } } })
    }
    $probes.Add(@{ Label='Network security group'; Type='Microsoft.Network/networkSecurityGroups'; Api='2024-01-01'
                   Content=@{ properties=@{} } })
    $probes.Add(@{ Label='Virtual network'; Type='Microsoft.Network/virtualNetworks'; Api='2024-01-01'
                   Content=@{ properties=@{} } })
    # The connectors' service NICs forward traffic. Microsoft's landing-zone baseline denies that
    # ("Network interfaces should disable IP forwarding", 88c0b9da-ce96-4b03-9635-f29a937e2900);
    # where it is assigned, no connector can be created without an exemption.
    $probes.Add(@{ Label='Connector service NIC (IP forwarding)'; Type='Microsoft.Network/networkInterfaces'; Api='2024-01-01'
                   Content=@{ properties=@{ enableIPForwarding=$true } } })
    if ($Topology -eq 'VMSS') {
        $probes.Add(@{ Label="Scale set ($VmSize)"; Type='Microsoft.Compute/virtualMachineScaleSets'; Api='2024-07-01'
                       Content=@{ sku=@{ name=$VmSize }; properties=@{ orchestrationMode='Flexible' } } })
    } else {
        $probes.Add(@{ Label="Virtual machine ($VmSize)"; Type='Microsoft.Compute/virtualMachines'; Api='2024-07-01'
                       Content=@{ properties=@{ hardwareProfile=@{ vmSize=$VmSize } } } })
    }
    if ($Bastion) {
        $basContent = if ($BastionSku -eq 'Premium') { @{ sku=@{ name='Premium' }; properties=@{ enablePrivateOnlyBastion=$true } } }
                      else { @{ sku=@{ name=$BastionSku }; properties=@{} } }
        $probes.Add(@{ Label="Bastion ($BastionSku)"; Type='Microsoft.Network/bastionHosts'; Api='2025-03-01'; Content=$basContent })
        if ($BastionSku -ne 'Premium' -and -not $BastionPublicIpExists) {
            $probes.Add(@{ Label='Bastion public IP'; Type='Microsoft.Network/publicIPAddresses'; Api='2024-01-01'
                           Content=@{ sku=@{ name='Standard' }; properties=@{ publicIPAllocationMethod='Static' } } })
        }
    }
    $probes.Add(@{ Label='Storage account'; Type='Microsoft.Storage/storageAccounts'; Api='2023-05-01'
                   Content=@{ sku=@{ name='Standard_ZRS' }; kind='StorageV2'
                              properties=@{ allowBlobPublicAccess=$false; minimumTlsVersion='TLS1_2'; supportsHttpsTrafficOnly=$true
                                            allowSharedKeyAccess=$false; publicNetworkAccess='Disabled'
                                            networkAcls=@{ defaultAction='Deny'; bypass='AzureServices' } } } })
    $probes.Add(@{ Label='Key vault'; Type='Microsoft.KeyVault/vaults'; Api='2023-07-01'
                   Content=@{ properties=@{ enableSoftDelete=$true; enablePurgeProtection=$true; enableRbacAuthorization=$true
                                            publicNetworkAccess='Disabled'; networkAcls=@{ defaultAction='Deny'; bypass='AzureServices' } } } })
    $probes.Add(@{ Label='Function app'; Type='Microsoft.Web/sites'; Api='2023-12-01'
                   Content=@{ kind='functionapp,linux'; properties=@{ httpsOnly=$true; publicNetworkAccess='Disabled'
                              siteConfig=@{ minTlsVersion='1.2'; ftpsState='Disabled'; http20Enabled=$true; vnetRouteAllEnabled=$true } } } })

    $uri      = "$Scope/providers/Microsoft.PolicyInsights/checkPolicyRestrictions?api-version=$($script:AccessApiVersions.PolicyRestrictions)"
    $blockers = [System.Collections.Generic.List[object]]::new()
    $checked  = 0
    $seen     = [System.Collections.Generic.HashSet[string]]::new()

    foreach ($probe in $probes) {
        $body = @{
            resourceDetails = @{
                resourceContent = ($probe.Content + @{ type = $probe.Type })
                apiVersion      = $probe.Api
                scope           = $Scope
            }
            pendingFields = @(
                @{ field = 'name';     values = @("zscc-preflight") }
                @{ field = 'location'; values = @($Location) }
                @{ field = 'tags' }
            )
        }

        try {
            $resp = Invoke-ArmPost -Uri $uri -Body $body
            $checked++
        } catch {
            $status = 0; try { $status = [int]$_.Exception.Response.StatusCode } catch { }
            if ($status -eq 403) {
                return [PSCustomObject]@{ Available=$false; Blockers=@(); Checked=$checked
                    Reason='The identity cannot read Azure Policy restrictions at this scope, so policy blockers could not be checked in advance.' }
            }
            # A single probe failing (an api-version a provider no longer honours, a transient 5xx)
            # must not suppress the other probes' findings.
            Write-ZsLog "Policy restriction probe for $($probe.Label) was inconclusive: $($_.Exception.Message)" -Level DEBUG
            continue
        }

        foreach ($b in (Get-ZsPolicyDenials -Response $resp -Label $probe.Label)) {
            $key = "$($b.PolicyAssignmentId)|$($b.PolicyDefinitionId)|$($b.Resource)"
            if ($seen.Add($key)) { $blockers.Add($b) }
        }
    }

    return [PSCustomObject]@{ Available=$true; Blockers=$blockers.ToArray(); Checked=$checked; Reason='' }
}

function Get-ZsPolicyDenials {
    <#
    .SYNOPSIS Extracts Deny results from a checkPolicyRestrictions response.
    .DESCRIPTION Denials surface in two places in the response — per-field restrictions and the
        content evaluation result — and the policy identity is carried in a policyInfo object in
        both. Each is read defensively: providers populate different subsets of the display-name
        fields, and a preflight that throws on a missing optional field is worse than no preflight.
    .OUTPUTS PSCustomObject[] describing each denial.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject[]])]
    param([Parameter(Mandatory)][AllowNull()][object]$Response, [string]$Label = '')

    $out = [System.Collections.Generic.List[PSCustomObject]]::new()
    if (-not $Response) { return $out.ToArray() }

    $shape = {
        param($info, $reason)
        $get = { param($o, $n) if ($o -and $o.PSObject.Properties[$n]) { [string]$o.$n } else { '' } }
        $defId  = & $get $info 'policyDefinitionId'
        $asgId  = & $get $info 'policyAssignmentId'
        $defNm  = & $get $info 'policyDefinitionDisplayName'
        $asgNm  = & $get $info 'policyAssignmentDisplayName'
        if (-not $defNm) { $defNm = & $get $info 'policyDefinitionName' }
        if (-not $defNm -and $defId) { $defNm = ($defId -split '/')[-1] }
        if (-not $asgNm) { $asgNm = & $get $info 'policyAssignmentName' }
        if (-not $asgNm -and $asgId) { $asgNm = ($asgId -split '/')[-1] }
        [PSCustomObject]@{
            Resource                  = $Label
            PolicyDefinitionDisplayName = $defNm
            PolicyAssignmentDisplayName = $asgNm
            PolicyDefinitionId          = $defId
            PolicyAssignmentId          = $asgId
            PolicyAssignmentScope       = (& $get $info 'policyAssignmentScope')
            PolicySetDefinitionId       = (& $get $info 'policySetDefinitionId')
            Reason                      = $reason
        }
    }

    try {
        if ($Response.PSObject.Properties['fieldRestrictions']) {
            foreach ($fr in @($Response.fieldRestrictions)) {
                $field = if ($fr.PSObject.Properties['field']) { [string]$fr.field } else { '' }
                foreach ($r in @($fr.restrictions)) {
                    $result = if ($r.PSObject.Properties['result']) { [string]$r.result } else { '' }
                    if ($result -ne 'Deny') { continue }
                    $info = if ($r.PSObject.Properties['policy']) { $r.policy } else { $null }
                    $out.Add((& $shape $info "restricts the '$field' field"))
                }
            }
        }
        if ($Response.PSObject.Properties['contentEvaluationResult'] -and $Response.contentEvaluationResult) {
            foreach ($pe in @($Response.contentEvaluationResult.policyEvaluations)) {
                $eval = if ($pe.PSObject.Properties['evaluationResult']) { [string]$pe.evaluationResult } else { '' }
                $effect = ''
                try { if ($pe.policyInfo.PSObject.Properties['policyDefinitionEffect']) { $effect = [string]$pe.policyInfo.policyDefinitionEffect } } catch { }
                if ($eval -ne 'NonCompliant' -and $effect -notin @('deny','Deny','denyAction','DenyAction')) { continue }
                $info = if ($pe.PSObject.Properties['policyInfo']) { $pe.policyInfo } else { $null }
                $out.Add((& $shape $info 'would deny the resource as configured'))
            }
        }
    } catch {
        Write-ZsLog "Could not fully parse a policy restriction response: $($_.Exception.Message)" -Level DEBUG
    }
    return $out.ToArray()
}

# ARM failure classification

function Resolve-ZsArmFailure {
    <#
    .SYNOPSIS Classifies an ARM error and renders it as an operator-facing explanation.
    .DESCRIPTION Preflight reduces surprises; it does not replace the authoritative answer, which is
        what ARM says when the write is attempted. This turns that answer into something readable,
        and above all names the cause:

          Policy       the policy assignment and definition that refused the request, taken from the
                       structured PolicyViolation entry in additionalInfo when present, and from the
                       policy identifiers embedded in the message when it is not
          Permission   the exact action and scope the identity was missing
          Quota        the limit that was reached, which is a capacity problem and not a rights one
          Registration the resource provider that is not registered on the subscription
          ApiVersion   the api-version the caller sent that the resource type does not serve, which
                       ARM reports under the same code as a missing registration
          Locked       the scope whose lock refused the operation, which is often not the resource
                       the operation named
          Policy       Azure Policy or a deny assignment, which no role assignment overrides
          LinkedPermission a missing action on a resource the request touches indirectly, rather than
                       on the resource it named
          Dependency   another resource still references this one, so the order is wrong
          Transient    the resource was mid-operation and the call can simply be repeated

        Anything unrecognised is returned unchanged rather than being forced into a category.
    .PARAMETER ErrorRecord The caught ErrorRecord.
    .OUTPUTS PSCustomObject: Kind, Code, Summary, Detail, PolicyName, PolicyAssignment, Action, Scope.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param([Parameter(Mandatory)][System.Management.Automation.ErrorRecord]$ErrorRecord)

    $raw = ''
    try { $raw = [string]$ErrorRecord.ErrorDetails.Message } catch { }
    if (-not $raw) { try { $raw = [string]$ErrorRecord.Exception.Message } catch { } }

    $code = ''; $message = $raw; $addl = @()
    try {
        $parsed = $raw | ConvertFrom-Json -ErrorAction Stop
        if ($parsed.PSObject.Properties['error']) {
            $e = $parsed.error
            if ($e.PSObject.Properties['code'])    { $code    = [string]$e.code }
            if ($e.PSObject.Properties['message']) { $message = [string]$e.message }
            if ($e.PSObject.Properties['additionalInfo']) { $addl = @($e.additionalInfo) }
        }
    } catch { }
    # Invoke-ArmRequest folds the ARM code into the exception message as "<code> <message>".
    if (-not $code -and $raw -match '^\s*([A-Za-z][A-Za-z0-9._]+)\s') { $code = $Matches[1] }

    $result = [PSCustomObject]@{
        Kind='Unclassified'; Code=$code; Summary=''; Detail=$message
        PolicyName=''; PolicyAssignment=''; PolicyScope=''; Action=''; Scope=''
    }

    # Azure Policy and deny assignments
    # Both refuse an identity that holds the role, and neither is fixed by granting another one.
    # Reported as a permission failure they send an operator to re-grant a role that was never
    # missing, so they are separated here and the remedy is stated with the cause.
    if ($code -match 'DisallowedByPolicy|RequestDisallowedByAzureRM|DisallowedByAssignment' -or
        $message -match 'disallowed by policy|deny assignment') {
        $defName = ''; $asgName = ''; $asgScope = ''; $reason = ''
        foreach ($a in $addl) {
            $t = ''; try { $t = [string]$a.type } catch { }
            if ($t -ne 'PolicyViolation') { continue }
            try {
                $i = $a.info
                $g = { param($n) if ($i -and $i.PSObject.Properties[$n]) { [string]$i.$n } else { '' } }
                $defName  = (& $g 'policyDefinitionDisplayName'); if (-not $defName) { $defName = & $g 'policyDefinitionName' }
                $asgName  = (& $g 'policyAssignmentDisplayName'); if (-not $asgName) { $asgName = & $g 'policyAssignmentName' }
                $asgScope = & $g 'policyAssignmentScope'
                try { if ($i.evaluationDetails.PSObject.Properties['reason']) { $reason = [string]$i.evaluationDetails.reason } } catch { }
            } catch { }
            if ($defName -or $asgName) { break }
        }
        # Some providers put the identifiers only in the message text.
        if (-not $defName -and $message -match "Policy identifiers:\s*'(\[.*\])'") {
            try {
                $ids = ($Matches[1] -replace '\\"','"') | ConvertFrom-Json
                foreach ($entry in @($ids)) {
                    if ($entry.PSObject.Properties['policyDefinition'] -and $entry.policyDefinition.PSObject.Properties['id']) {
                        $defName = ($entry.policyDefinition.id -split '/')[-1]
                    }
                    if ($entry.PSObject.Properties['policyAssignment'] -and $entry.policyAssignment.PSObject.Properties['name']) {
                        $asgName = [string]$entry.policyAssignment.name
                    }
                    if ($defName -or $asgName) { break }
                }
            } catch { }
        }

        $named = @()
        if ($asgName) { $named += "policy assignment '$asgName'" }
        if ($defName) { $named += "policy definition '$defName'" }
        $who = if ($named.Count) { $named -join ' / ' } else { 'an Azure Policy assignment' }

        $result.Kind             = 'Policy'
        $result.PolicyName       = $defName
        $result.PolicyAssignment = $asgName
        $result.PolicyScope      = $asgScope
        $result.Summary          = "Azure Policy refused this resource: $who"
        if ($reason) { $result.Detail = $reason }
        return $result
    }

    # RBAC on a linked resource
    # The identity has the action it was asked about and is missing one on a resource the request
    # touches indirectly — joining a subnet, assigning an identity. Reported as a plain permission
    # failure it sends an operator to re-grant a role they already hold at a scope that was never
    # the problem, so the linked scope is named separately.
    if ($code -match 'LinkedAuthorizationFailed|AuthorizationFailedForLinkedResource' -or
        $message -match 'linked scope') {
        if ($message -match "perform action '([^']+)' on the linked scope") { $result.Action = $Matches[1] }
        elseif ($message -match "does not have permission to perform action '([^']+)'") { $result.Action = $Matches[1] }
        if ($message -match "linked scope\(s\) '([^']+)'") { $result.Scope = $Matches[1] }
        elseif ($message -match "linked scope '([^']+)'")    { $result.Scope = $Matches[1] }
        $result.Kind    = 'LinkedPermission'
        $result.Summary = if ($result.Action) {
            "The identity is missing $($result.Action) on a linked resource" + $(if ($result.Scope) { ", $($result.Scope)" } else { '' })
        } else { 'The identity is missing an action on a resource this operation links to' }
        $result.Detail  = 'The action named in the request succeeded; grant the linked action at the linked scope, not at the scope of the request.'
        return $result
    }

    # Still referenced
    # Azure names the resource still pointing at this one. That is an ordering fact, not a fault:
    # the reference goes first and this succeeds. Retrying it unchanged never helps.
    if ($code -match 'InUse|ResourceInUse|CannotDeleteResource|SubnetsHaveServiceAssociationLink|InUseSubnetCannotBeDeleted|InUseNetworkSecurityGroupCannotBeDeleted|PublicIPAddressCannotBeDeleted' -or
        $message -match 'in use by|still allocated to|cannot be deleted because it.s linked|Please delete the following resources|serviceAssociationLink') {
        # Resource IDs are drawn from a known character set, so they are matched by what they may
        # contain rather than by guessing every delimiter ARM might wrap them in.
        $blockers = @()
        foreach ($m in [regex]::Matches($message, '/subscriptions/[A-Za-z0-9._\-/]+')) { $blockers += $m.Value.TrimEnd('.', '/') }
        $blockers = @($blockers | Select-Object -Unique)
        $result.Kind    = 'Dependency'
        $result.Scope   = ($blockers | Select-Object -First 3) -join ', '
        $result.Summary = if ($blockers.Count -gt 0) {
            "another resource still references it: $((($blockers | Select-Object -First 3) | ForEach-Object { ($_ -split '/')[-1] }) -join ', ')"
        } else { 'another resource still references it' }
        return $result
    }

    # Not yet settled
    # A provisioning state that has not come to rest is the one failure here worth simply waiting on.
    if ($message -match 'while in provisioning state|Try again in a few minutes|another operation is in progress|is in a transitional state') {
        $result.Kind    = 'Transient'
        $result.Summary = 'the resource was mid-operation and the call can be repeated'
        return $result
    }

    # RBAC
    if ($code -eq 'AuthorizationFailed' -or $message -match 'does not have authorization to perform action') {
        if ($message -match "perform action '([^']+)'") { $result.Action = $Matches[1] }
        if ($message -match "over scope '([^']+)'")      { $result.Scope  = $Matches[1] }
        $result.Kind    = 'Permission'
        $result.Summary = if ($result.Action) {
            "The deploying identity is missing the action $($result.Action)" + $(if ($result.Scope) { " at $($result.Scope)" } else { '' })
        } else { 'The deploying identity is not authorized for this operation' }
        return $result
    }

    # Quota / capacity
    if ($code -match 'QuotaExceeded|OperationNotAllowed|ResourceQuotaExceeded|LimitReached' -or
        $message -match 'exceeding quota|quota limits|Current Limit|Cannot create more than') {
        $result.Kind    = 'Quota'
        $result.Summary = 'A subscription quota or capacity limit was reached — this is a capacity request, not a permission problem'
        return $result
    }

    # Locked scope
    # ARM names the locked scope, which is rarely the resource being deleted: a private endpoint is
    # refused because of a lock on the resource it terminates on. Naming the blocking scope is the
    # whole content of this error, so it is pulled out rather than left inside the message.
    if ($code -match 'ScopeLocked' -or $message -match 'scope\(s\) are locked') {
        $blocked = ''; $locked = ''
        if ($message -match "The scope '([^']+)' cannot perform")  { $blocked = $Matches[1] }
        if ($message -match "are locked: '([^']+)'")               { $locked  = $Matches[1] }
        $result.Kind    = 'Locked'
        $result.Action  = $blocked
        $result.Scope   = $locked
        $result.Summary = if ($locked) {
            "a resource lock on $locked refused it"
        } else { 'a resource lock refused it' }
        return $result
    }

    # Unsupported api-version
    # ARM returns NoRegisteredProviderFound for two unrelated causes: the provider genuinely is not
    # registered, and the provider is registered but does not serve this type at the api-version
    # that was sent. Only the second one enumerates the versions it does serve, so that list is what
    # tells the two apart. Calling this one a registration problem sends the operator to register a
    # provider that is already registered, and the real fault — a wrong version in the caller — stays
    # hidden.
    if ($code -match 'NoRegisteredProviderFound' -and $message -match 'supported api-versions are') {
        $sent = ''; $type = ''; $supported = ''
        if ($message -match "API version '([^']+)'")           { $sent      = $Matches[1] }
        if ($message -match "for type '([^']+)'")              { $type      = $Matches[1] }
        if ($message -match "supported api-versions are '([^']+)'") { $supported = $Matches[1] }

        $result.Kind    = 'ApiVersion'
        $result.Action  = $sent
        $result.Scope   = $type
        $result.Summary = if ($type -and $sent) {
            "api-version $sent is not supported for type $type"
        } else { 'The api-version sent is not supported for this resource type' }
        if ($supported) {
            $first = (($supported -split ',') | ForEach-Object { $_.Trim() } | Select-Object -First 6) -join ', '
            $result.Detail = "Supported: $first"
        }
        return $result
    }

    # Provider registration
    if ($code -match 'MissingSubscriptionRegistration|MissingRegistration|NoRegisteredProviderFound') {
        $ns = ''
        if ($message -match "namespace\s+'?([A-Za-z0-9.]+)'?") { $ns = $Matches[1] }
        elseif ($message -match "([A-Za-z]+\.[A-Za-z]+)\s+is not registered") { $ns = $Matches[1] }
        $result.Kind    = 'Registration'
        $result.Action  = $ns
        $result.Summary = if ($ns) {
            "Resource provider $ns is not registered on this subscription; registration is a subscription-level action"
        } else { 'A required resource provider is not registered on this subscription' }
        return $result
    }

    return $result
}

function Write-ZsArmFailure {
    <#
    .SYNOPSIS Logs a classified ARM failure as one clear operator-facing line, with its remedy.
    .PARAMETER ErrorRecord The caught ErrorRecord.
    .PARAMETER Context What was being attempted, for the leading clause.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][System.Management.Automation.ErrorRecord]$ErrorRecord,
        [string]$Context = 'The operation'
    )
    $f = Resolve-ZsArmFailure -ErrorRecord $ErrorRecord
    switch ($f.Kind) {
        'Policy' {
            Write-ZsLog "$Context was blocked. $($f.Summary)." -Level ERROR
            if ($f.Detail)      { Write-ZsLog "  Policy reason: $($f.Detail)" -Level ERROR }
            if ($f.PolicyScope) { Write-ZsLog "  Assigned at: $($f.PolicyScope)" -Level ERROR }
            Write-ZsLog "  No role assignment overrides this. Ask the policy owner for an exemption at this scope, or adjust the deployment to satisfy the policy." -Level ERROR
        }
        'Permission' {
            Write-ZsLog "$Context was blocked. $($f.Summary)." -Level ERROR
            if ($f.Action) { Write-ZsLog "  Grant a role containing $($f.Action)$(if ($f.Scope) { " at $($f.Scope)" })." -Level ERROR }
        }
        'Quota' {
            Write-ZsLog "$Context was blocked. $($f.Summary)." -Level ERROR
            Write-ZsLog "  $($f.Detail)" -Level ERROR
        }
        'Registration' {
            Write-ZsLog "$Context was blocked. $($f.Summary)." -Level ERROR
            Write-ZsLog "  A subscription Contributor or Owner must register it; a resource-group-scoped identity cannot." -Level ERROR
        }
        'LinkedPermission' {
            Write-ZsLog "$Context failed. $($f.Summary)." -Level ERROR
            Write-ZsLog "  $($f.Detail)" -Level ERROR
        }
        'Dependency' {
            Write-ZsLog "$Context was refused: $($f.Summary)." -Level ERROR
            Write-ZsLog "  This is a deletion-order problem, not a permissions one. The referencing resource has to go first." -Level ERROR
        }
        'Transient' {
            Write-ZsLog "$Context did not complete: $($f.Summary)." -Level WARN
        }
        'Locked' {
            # No remedy is offered here. Whether the lock was left in place deliberately, could not
            # be removed, or was never seen is not knowable from the ARM error, and guessing at it is
            # what sends an operator after a permission they already hold. The caller holds that
            # answer and says so.
            Write-ZsLog "$Context was blocked: $($f.Summary)." -Level ERROR
        }
        'ApiVersion' {
            Write-ZsLog "$Context failed. $($f.Summary)." -Level ERROR
            if ($f.Detail) { Write-ZsLog "  $($f.Detail)" -Level ERROR }
            Write-ZsLog "  This is a module defect, not a permission or registration problem — the provider is registered." -Level ERROR
        }
        default {
            Write-ZsLog "$Context failed: $($f.Detail)" -Level ERROR
        }
    }
    return $f
}
