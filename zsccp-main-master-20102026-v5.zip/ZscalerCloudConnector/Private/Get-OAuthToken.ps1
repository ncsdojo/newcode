<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Get-OAuthToken).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Get-OAuthToken {
    [CmdletBinding()]
    [OutputType([string])]
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Resource)

    $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    if ($script:ZsSession.Tokens.ContainsKey($Resource)) {
        $cached = $script:ZsSession.Tokens[$Resource]
        if ($cached.ExpiresOn -gt ($now + 300)) { return $cached.AccessToken }
    }

    $authMethod = $script:ZsSession.AuthMethod

    # Service principal: client_credentials grant
    if ($authMethod -eq 'client_secret') {
        $secret = ConvertFrom-ZsSecureString -Secure $script:ZsSession.ClientSecretSS
        $body = @{
            grant_type    = 'client_credentials'
            client_id     = $script:ZsSession.ClientId
            client_secret = $secret
            scope         = "$Resource/.default"
        }
        $uri  = "$($script:Endpoints.Login)/$($script:ZsSession.TenantId)/oauth2/v2.0/token"

        # Every ARM, vault and blob call funnels through here, and a deployment runs for the best
        # part of an hour. A transient failure at the identity endpoint is not a credential
        # problem and must not end the run: retry the transport-level and throttling cases, and
        # let a real rejection (bad secret, wrong tenant) through on the first response.
        $resp = $null
        for ($tokenAttempt = 1; $tokenAttempt -le 4; $tokenAttempt++) {
            try {
                $resp = Invoke-RestMethod -Uri $uri -Method Post -Body $body -ContentType 'application/x-www-form-urlencoded' -TimeoutSec 30 -ErrorAction Stop
                break
            } catch {
                $tokenStatus = 0
                try { $tokenStatus = [int]$_.Exception.Response.StatusCode } catch { }
                if ($tokenStatus -in @(0, 408, 429, 500, 502, 503, 504) -and $tokenAttempt -lt 4) {
                    $tokenWait = [math]::Pow(2, $tokenAttempt) * 2
                    Write-ZsLog "Token endpoint $tokenStatus, retry $tokenAttempt/3 in ${tokenWait}s" -Level WARN
                    Start-Sleep -Seconds $tokenWait
                    continue
                }

                $msg = $_.ErrorDetails.Message
                if ($msg -match '"error_description"\s*:\s*"([^"]+)"') { $desc = $Matches[1] -replace '\\u0027',"'" } else { $desc = $msg }
                if (-not $desc) { $desc = $_.Exception.Message }
                $hint = switch -Regex ("$msg") {
                    '7000215'       { 'You pasted the Secret ID (a GUID), not the Secret Value. In Entra ID > App Registrations > Certificates & Secrets, copy the Value column. If it is hidden, create a new secret.' }
                    '7000222'       { 'The client secret has expired. Create a new one in Entra ID > App Registrations > Certificates & Secrets.' }
                    '700016'        { 'The application is not found or not configured for client_credentials. Verify the ClientId and that the app registration has an API permission for the target resource.' }
                    '90002|InvalidTenant' { 'The tenant ID is not valid. Verify -TenantId matches your Azure AD directory.' }
                    default         { '' }
                }
                $full = "Azure AD authentication failed: $desc"
                if ($hint) { $full += "`n`nFix: $hint" }
                throw $full
            }
        }

        # The secret is a managed string and cannot be zeroed; drop the last references to it as
        # soon as the request is done so its lifetime is the call rather than the session.
        $body['client_secret'] = $null
        $secret = $null

        $script:ZsSession.Tokens[$Resource] = @{
            AccessToken = $resp.access_token
            ExpiresOn   = $now + $resp.expires_in
        }
        return $resp.access_token
    }

    # MSAL flows (PKCE, certificate, silent): refresh via MSAL cache
    if ($authMethod -in @('interactive','certificate','devicecode')) {
        # Check the loaded modules before scanning the disk: this runs on every cache miss, and
        # Get-Module -ListAvailable walks every path in PSModulePath each time.
        $msalPresent = [bool](Get-Module -Name $script:MsalModule)
        if (-not $msalPresent) { $msalPresent = [bool](Get-Module -ListAvailable -Name $script:MsalModule) }
        if (-not $msalPresent) {
            throw "Authentication method '$authMethod' needs $($script:MsalModule) $($script:MsalModuleVersion), which is not installed. Install it, or reconnect with a client secret."
        }

        Import-Module $script:MsalModule -RequiredVersion $script:MsalModuleVersion -ErrorAction Stop

        # A silent refresh reads a local cache but still calls the token endpoint, so it fails
        # transiently for the same reasons the client_credentials grant does.
        for ($tokenAttempt = 1; $tokenAttempt -le 3; $tokenAttempt++) {
            try {
                $token = Get-MsalToken `
                    -ClientId    $script:ZsSession.ClientId `
                    -TenantId    $script:ZsSession.TenantId `
                    -Scopes      @("$Resource/.default") `
                    -RedirectUri $script:LocalRedirectUri `
                    -Silent

                $script:ZsSession.Tokens[$Resource] = @{
                    AccessToken = $token.AccessToken
                    ExpiresOn   = $token.ExpiresOn.ToUnixTimeSeconds()
                }
                return $token.AccessToken
            } catch {
                if ($tokenAttempt -lt 3) {
                    Write-ZsLog "Silent token refresh attempt $tokenAttempt failed for $Resource, retrying: $($_.Exception.Message)" -Level WARN
                    Start-Sleep -Seconds ($tokenAttempt * 3)
                    continue
                }
                Write-ZsLog "Silent token refresh failed for $Resource : $($_.Exception.Message)" -Level WARN
                throw "Token expired and silent refresh failed. Re-run Connect-ZscalerAzure to re-authenticate."
            }
        }
    }

    throw "No valid authentication method available to acquire a token for $Resource. Run Connect-ZscalerAzure first."
}

function Get-ArmToken   { return Get-OAuthToken -Resource $script:Endpoints.Arm }
