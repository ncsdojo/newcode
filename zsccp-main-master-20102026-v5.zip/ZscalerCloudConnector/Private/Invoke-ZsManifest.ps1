<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (Initialize-ZsManifest).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Initialize-ZsManifest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$SubscriptionId,
        [Parameter(Mandatory)][string]$ResourceGroupName,
        [Parameter(Mandatory)][string]$Location
    )
    $script:ZsManifest = [ordered]@{
        SchemaVersion  = '3.0'
        DeploymentId   = $script:ZsSession.DeploymentId
        StartedAt      = (Get-Date).ToString('o')
        CompletedAt    = $null
        Status         = 'InProgress'
        SubscriptionId = $SubscriptionId
        ResourceGroup  = $ResourceGroupName
        Location       = $Location
        Resources      = [ordered]@{}
        Outputs        = [ordered]@{}
        Errors         = [System.Collections.Generic.List[string]]::new()
    }
}

function Add-ZsManifestResource {
    <#
    .SYNOPSIS Records a resource this deployment created, or adopted from an earlier one.
    .DESCRIPTION -PreExisting marks a resource that belongs to somebody else. It belongs on the
        manifest for the same reason a created one does: the deployment acts on it — it locks it, at
        least — and teardown has to know that. It is not the deployment's to delete, and the flag is
        what keeps those two facts apart.

        The flag turns on ownership, not on which run happened to get there first. Callers decide it
        from the managed-by tag, via Test-ZsModuleOwned. That distinction is what keeps an idempotent
        re-run idempotent: a first run stopped partway by a missing permission leaves resources
        behind, and the re-run verifies them rather than creating them. They are still this module's
        resources, still deleted at teardown, and a flag set from "this run did not create it" would
        strand them — deployable, lockable, and permanently undeletable.
    .PARAMETER PreExisting The resource was not created by this module and is not its to delete.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Type,
        [Parameter(Mandatory)][string]$Name,
        [string]$ResourceId = '',
        [hashtable]$Properties = @{},
        [switch]$PreExisting
    )
    if (-not $script:ZsManifest.Resources.Contains($Type)) {
        $script:ZsManifest.Resources[$Type] = [System.Collections.Generic.List[object]]::new()
    }
    $entry = [ordered]@{ Name = $Name; ResourceId = $ResourceId; CreatedAt = (Get-Date).ToString('o') }
    if ($PreExisting) { $entry['PreExisting'] = $true }
    foreach ($k in $Properties.Keys) { $entry[$k] = $Properties[$k] }
    $script:ZsManifest.Resources[$Type].Add($entry)
}

function Add-ZsManifestOutput {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Key, [Parameter(Mandatory)]$Value)
    $script:ZsManifest.Outputs[$Key] = $Value
}

function Add-ZsManifestError {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Message)
    # This function runs inside catch blocks, so it must never throw, whatever shape the
    # manifest is in: the initialized ordered hashtable, a PSCustomObject re-loaded from an
    # older blob, or null because the failure happened before Connect initialized anything.
    # A failure to record a failure masks the original error - the worst possible trade - so
    # every shape degrades to the log rather than to an exception.
    $stamped = "$(Get-Date -Format 'o') $Message"
    $m = $script:ZsManifest
    if ($null -eq $m) {
        Write-ZsLog "Manifest not initialized; error recorded to log only: $Message" -Level ERROR
        return
    }
    if ($m -is [System.Collections.IDictionary]) {
        if (-not $m.Contains('Errors') -or $null -eq $m['Errors']) {
            $m['Errors'] = [System.Collections.Generic.List[string]]::new()
        }
        $m['Errors'].Add($stamped)
        return
    }
    $prop = $m.PSObject.Properties['Errors']
    if (-not $prop -or $null -eq $prop.Value) {
        $m | Add-Member -NotePropertyName 'Errors' -NotePropertyValue ([System.Collections.Generic.List[string]]::new()) -Force
    } elseif ($prop.Value -isnot [System.Collections.Generic.List[string]]) {
        # A JSON round-trip turns the list into a fixed array; rebuild it appendable.
        $rebuilt = [System.Collections.Generic.List[string]]::new()
        foreach ($e in @($prop.Value)) { $rebuilt.Add([string]$e) }
        $m | Add-Member -NotePropertyName 'Errors' -NotePropertyValue $rebuilt -Force
    }
    $m.Errors.Add($stamped)
}

function Complete-ZsManifest {
    [CmdletBinding()]
    param([ValidateSet('Succeeded','Failed','PartialSuccess')][string]$Status = 'Succeeded')
    $script:ZsManifest.CompletedAt = (Get-Date).ToString('o')
    $script:ZsManifest.Status      = $Status
}

function Export-ZsManifest {
    [CmdletBinding()]
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Path)
    $json = $script:ZsManifest | ConvertTo-Json -Depth 20
    # Atomic write: temp file + rename prevents a partial write from corrupting the manifest
    # if the process is interrupted mid-deployment.
    $tmpPath = "${Path}.tmp"
    [System.IO.File]::WriteAllText($tmpPath, $json, [System.Text.Encoding]::UTF8)
    if ([System.IO.File]::Exists($Path)) { [System.IO.File]::Delete($Path) }
    [System.IO.File]::Move($tmpPath, $Path)
    Write-ZsLog "Manifest: $Path"

    # Mirror to the remote state blob when a backend is configured; the local file remains the
    # working artifact. Mirror failure is logged rather than thrown — it must never fail a
    # completed deployment.
    try { Save-ZsRemoteState } catch { Write-ZsLog "Could not mirror manifest to remote state: $($_.Exception.Message)" -Level WARN }

    return $Path
}

function Get-ZsManifest { return $script:ZsManifest }
