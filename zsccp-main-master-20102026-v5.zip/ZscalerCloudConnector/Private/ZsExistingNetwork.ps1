<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module — existing-network resolution for brownfield deployments.

.DESCRIPTION
    The PowerShell equivalent of the Terraform data sources: given the names (or resource IDs) of an
    existing VNet and its subnets, read them from ARM once and hand back a normalized description the
    orchestrator can build on. Nothing in this file creates network resources; it looks things up,
    validates what it finds, and associates module-created NSGs / service endpoints onto subnets that
    already exist — the same attach-don't-create contract the Terraform prod environment follows.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Get-ZsConfigValue {
    <#
    .SYNOPSIS Reads one field off a config fragment that may be a hashtable or a PSCustomObject.
    .DESCRIPTION Config arrives two ways: ConvertFrom-Json -AsHashtable (the module's own loader)
        yields dictionaries, while a config assembled by hand or deserialized elsewhere yields
        PSCustomObjects. Under Set-StrictMode -Version Latest, reading a property that is not there
        throws on the latter, so every optional BringYourOwn field goes through this reader: absent
        or blank returns '', present returns the trimmed string.
    .PARAMETER Map The config fragment (hashtable, ordered dictionary, or PSCustomObject).
    .PARAMETER Key The field name.
    .OUTPUTS [string] The trimmed value, or '' when absent, null, or whitespace.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param($Map, [Parameter(Mandatory)][string]$Key)

    if ($null -eq $Map) { return '' }
    $val = $null
    if ($Map -is [System.Collections.IDictionary]) {
        if ($Map.Contains($Key)) { $val = $Map[$Key] }
    } else {
        $prop = $Map.PSObject.Properties[$Key]
        if ($prop) { $val = $prop.Value }
    }
    if ($null -eq $val) { return '' }
    return ([string]$val).Trim()
}

function Get-ZsConfigFlag {
    # A true/false config field; $Default when it is absent or blank.
    [CmdletBinding()]
    [OutputType([bool])]
    param($Map, [Parameter(Mandatory)][string]$Key, [bool]$Default = $false)
    $raw = Get-ZsConfigValue $Map $Key
    if (-not $raw) { return $Default }
    if ($raw -match '^(?i)(true|1|yes|y)$')  { return $true }
    if ($raw -match '^(?i)(false|0|no|n)$') { return $false }
    throw [System.ArgumentException]::new("Config field $Key must be true or false, not '$raw'.")
}

function Get-ZsSubnetPrefix {
    <#
    .SYNOPSIS Returns a subnet's CIDR whether ARM reports addressPrefix or addressPrefixes.
    .DESCRIPTION Subnets created recently, or with multiple prefixes, carry addressPrefixes (a list)
        instead of the singular addressPrefix. Terraform reads address_prefixes[0]; this does the same,
        preferring the singular field when both are present.
    .PARAMETER Subnet The live subnet object from ARM.
    .OUTPUTS [string] The first CIDR, or '' when neither field is present.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param([Parameter(Mandatory)]$Subnet)

    $props = $null
    if ($Subnet.PSObject.Properties['properties']) { $props = $Subnet.properties }
    if (-not $props) { return '' }
    if ($props.PSObject.Properties['addressPrefix'] -and $props.addressPrefix) { return [string]$props.addressPrefix }
    if ($props.PSObject.Properties['addressPrefixes'] -and @($props.addressPrefixes).Count -gt 0) {
        return [string]@($props.addressPrefixes)[0]
    }
    return ''
}

function Resolve-ZsExistingNetwork {
    <#
    .SYNOPSIS Resolves an existing VNet and its subnets from names or resource IDs, like Terraform data sources.
    .DESCRIPTION Reads the BringYourOwn block and settles, in one ARM read, everything a brownfield
        deployment attaches to:

          VNet     by VnetId, or by VnetName + VnetResourceGroupName (+ VnetSubscriptionId when the
                   hub network lives in another subscription). Name-based lookup mirrors the Terraform
                   variables vnet_name / vnet_resource_group_name / network_subscription_id, so the
                   same values move between the two tools unchanged.
          Subnets  by <Role>SubnetName within that VNet (mgmt_subnet_name and friends in Terraform),
                   or by <Role>SubnetId. When both are supplied for a role they must agree. Subnet
                   names are the platform team's own — nothing here expects the snet-zscc-* names the
                   greenfield path creates.
          Bastion  the subnet named AzureBastionSubnet (the name Azure mandates), when -WantBastion.
                   Its absence is reported, not fatal: the orchestrator decides whether that skips
                   Bastion or stops the run.

        Every failure is collected and reported together — a missing VNet names the exact name/group/
        subscription that was looked up; missing subnets are listed alongside the names that do exist
        in the VNet — so one run surfaces the whole gap, the way one terraform plan does.

        Returns $null when the config names no VNet at all, which is what greenfield looks like.
    .PARAMETER BringYourOwn The BringYourOwn config fragment (hashtable or PSCustomObject).
    .PARAMETER WantBastion Probe for AzureBastionSubnet and return it when present.
    .PARAMETER Cmdlet The calling $PSCmdlet, so a stop surfaces from the operator's cmdlet.
    .OUTPUTS PSCustomObject: VnetName, VnetId, VnetPath, VnetResourceGroupName, VnetSubscriptionId,
        Location, AddressSpace, Subnets (role-keyed map of Name/Id/Prefix/HasNsg/NsgId/Object),
        SubnetPlan (role-keyed CIDRs), BastionSubnet (Name/Id/Prefix or $null), CrossSubscription.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)]$BringYourOwn,
        [switch]$WantBastion,
        [System.Management.Automation.PSCmdlet]$Cmdlet = $null
    )

    $api = $script:ApiVersions.Network
    $byo = $BringYourOwn

    # VNet reference: an ID wins when both are present, but only if the name agrees with it —
    # a config that says one thing in VnetId and another in VnetName is a config to fix, not
    # a tie to break silently.
    $vnetId   = Get-ZsConfigValue $byo 'VnetId'
    $vnetName = Get-ZsConfigValue $byo 'VnetName'
    if (-not $vnetId -and -not $vnetName) { return $null }

    $idPattern = '(?i)^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\.Network/virtualNetworks/[^/]+$'
    if ($vnetId) {
        if ($vnetId -notmatch $idPattern) {
            Write-ZsError -Cmdlet $Cmdlet -ErrorId 'ZsByoVnetIdMalformed' -Category InvalidArgument -Message (
                "BringYourOwn.VnetId is not a virtual network resource ID: '$vnetId'.`n" +
                "  Expected /subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Network/virtualNetworks/<name>.`n" +
                "  Or name the network instead: VnetName + VnetResourceGroupName (+ VnetSubscriptionId when it lives in another subscription).")
        }
        $idLeaf = ($vnetId -split '/')[-1]
        if ($vnetName -and $idLeaf -notlike $vnetName) {
            Write-ZsError -Cmdlet $Cmdlet -ErrorId 'ZsByoVnetMismatch' -Category InvalidArgument -Message (
                "BringYourOwn.VnetId names '$idLeaf' but BringYourOwn.VnetName says '$vnetName'. They must agree; fix or clear one of them.")
        }
        $vnetName = $idLeaf
        $vnetSub  = ($vnetId -split '/')[2]
        $vnetRg   = ($vnetId -split '/')[4]
    } else {
        # Name-based, the Terraform way. The group defaults to the deployment's own group and the
        # subscription to the session's, which is the common single-subscription layout; both are
        # overridable because the hub network is often the platform team's, not the deployment's.
        $vnetRg  = Get-ZsConfigValue $byo 'VnetResourceGroupName'
        if (-not $vnetRg) { $vnetRg = $script:ZsSession.ResourceGroupName }
        $vnetSub = Get-ZsConfigValue $byo 'VnetSubscriptionId'
        if (-not $vnetSub) { $vnetSub = $script:ZsSession.SubscriptionId }
        $vnetId  = "/subscriptions/$vnetSub/resourceGroups/$vnetRg/providers/Microsoft.Network/virtualNetworks/$vnetName"
    }

    # One read serves every lookup below: ARM returns the subnets inline on the VNet, so this is
    # the whole of the "data source" traffic. GETs pass through under -WhatIf, so a dry run
    # resolves and validates the existing network exactly as terraform plan does.
    $vnet = $null
    try { $vnet = Invoke-ArmGet -Uri "$vnetId`?api-version=$api" } catch {
        $where = "subscription $vnetSub, resource group $vnetRg"
        Write-ZsError -Cmdlet $Cmdlet -ErrorId 'ZsByoVnetNotFound' -Category ObjectNotFound -Message (
            "The existing virtual network could not be read: '$vnetName' ($where).`n" +
            "  Brownfield attaches to a network that is already there; nothing is created on its behalf.`n" +
            "  Check the name, group and subscription in BringYourOwn (VnetName / VnetResourceGroupName / VnetSubscriptionId or VnetId),`n" +
            "  and that this identity holds at least Reader on it. ARM said: $($_.Exception.Message)`n" +
            "  Nothing has been deployed.")
    }

    # A VNet in another region cannot carry this deployment's NICs — Azure requires the interface,
    # its VNet and its VM to share a region — so a mismatch here is a guaranteed mid-deployment
    # failure named now instead.
    $vnetLoc = ''
    if ($vnet.PSObject.Properties['location']) { $vnetLoc = ([string]$vnet.location) -replace '\s','' }
    $sessLoc = ([string]$script:ZsSession.Location) -replace '\s',''
    if ($vnetLoc -and $sessLoc -and ($vnetLoc -notlike $sessLoc)) {
        Write-ZsError -Cmdlet $Cmdlet -ErrorId 'ZsByoVnetWrongRegion' -Category InvalidOperation -Message (
            "VNet '$vnetName' is in region '$($vnet.location)' but this session deploys to '$($script:ZsSession.Location)'.`n" +
            "  Connector NICs must live in the VNet's region. Reconnect with -Location $($vnet.location), or point at a VNet in $($script:ZsSession.Location).`n" +
            "  Nothing has been deployed.")
    }

    $addressSpace = @()
    if ($vnet.PSObject.Properties['properties'] -and $vnet.properties.PSObject.Properties['addressSpace'] -and
        $vnet.properties.addressSpace.PSObject.Properties['addressPrefixes']) {
        $addressSpace = @($vnet.properties.addressSpace.addressPrefixes)
    }

    $liveSubnets = @{}
    if ($vnet.PSObject.Properties['properties'] -and $vnet.properties.PSObject.Properties['subnets']) {
        foreach ($s in @($vnet.properties.subnets)) { $liveSubnets[([string]$s.name).ToLowerInvariant()] = $s }
    }
    $liveNames = @($liveSubnets.Values | ForEach-Object { [string]$_.name } | Sort-Object)

    # Role table. PlanKey is the role name the rest of the module keys on; the live subnet keeps
    # whatever name its owners gave it. FuncApp is optional here — an unnamed Function App subnet
    # means the orchestrator creates snet-zscc-funcapp from FuncAppSubnetCidr, as before.
    $roles = @(
        @{ PlanKey='snet-zscc-mgmt';     Label='Management';    NameField='MgmtSubnetName';     IdField='MgmtSubnetId';     Required=$true  }
        @{ PlanKey='snet-zscc-service';  Label='Service';       NameField='ServiceSubnetName';  IdField='ServiceSubnetId';  Required=$true  }
        @{ PlanKey='snet-zscc-workload'; Label='Workload';      NameField='WorkloadSubnetName'; IdField='WorkloadSubnetId'; Required=$true  }
        @{ PlanKey='snet-zscc-lb';       Label='Load balancer'; NameField='LbSubnetName';       IdField='LbSubnetId';       Required=$true  }
        @{ PlanKey='snet-zscc-funcapp';  Label='Function App';  NameField='FuncAppSubnetName';  IdField='FuncAppSubnetId';  Required=$false }
    )

    $errors  = [System.Collections.Generic.List[string]]::new()
    $subnets = @{}
    $plan    = [ordered]@{}
    $subnetIdPattern = '(?i)^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\.Network/virtualNetworks/[^/]+/subnets/[^/]+$'

    foreach ($r in $roles) {
        $name = Get-ZsConfigValue $byo $r.NameField
        $id   = Get-ZsConfigValue $byo $r.IdField

        if ($id) {
            if ($id -notmatch $subnetIdPattern) {
                $errors.Add("$($r.Label) subnet: BringYourOwn.$($r.IdField) is not a subnet resource ID ('$id').")
                continue
            }
            $idVnet = ($id -replace '(?i)/subnets/[^/]+$','')
            if ($idVnet -notlike $vnetId) {
                $errors.Add("$($r.Label) subnet: $($r.IdField) belongs to VNet '$idVnet', not the resolved VNet '$vnetId'. Every subnet must live in the one VNet.")
                continue
            }
            $idLeaf = ($id -split '/')[-1]
            if ($name -and $idLeaf -notlike $name) {
                $errors.Add("$($r.Label) subnet: $($r.IdField) names '$idLeaf' but $($r.NameField) says '$name'. They must agree; fix or clear one of them.")
                continue
            }
            $name = $idLeaf
        }
        if (-not $name) {
            if ($r.Required) {
                $errors.Add("$($r.Label) subnet: not named. Set BringYourOwn.$($r.NameField) (or $($r.IdField)). The existing network is all-or-nothing: mgmt, service, workload and lb must all be named together.")
            }
            continue
        }

        $live = $liveSubnets[$name.ToLowerInvariant()]
        if (-not $live) {
            $errors.Add("$($r.Label) subnet '$name': not found in VNet '$vnetName'. Subnets present: $(if ($liveNames) { $liveNames -join ', ' } else { '(none)' }).")
            continue
        }
        $prefix = Get-ZsSubnetPrefix -Subnet $live
        if (-not $prefix) { $errors.Add("$($r.Label) subnet '$name': no addressPrefix on the live subnet.") ; continue }

        $nsgId = ''
        if ($live.properties.PSObject.Properties['networkSecurityGroup'] -and $live.properties.networkSecurityGroup -and
            $live.properties.networkSecurityGroup.PSObject.Properties['id']) {
            $nsgId = [string]$live.properties.networkSecurityGroup.id
        }
        $subnets[$r.PlanKey] = [PSCustomObject]@{
            Name   = [string]$live.name
            Id     = [string]$live.id
            Prefix = $prefix
            HasNsg = [bool]$nsgId
            NsgId  = $nsgId
            Object = $live
        }
        $plan[$r.PlanKey] = $prefix
    }

    # Bastion follows the fixed name Azure mandates, so there is no name field to read. Missing is
    # a fact for the caller, not an error: the Terraform prod environment fails its data source in
    # that case, but here the orchestrator downgrades to a logged skip unless told otherwise.
    $bastion = $null
    if ($WantBastion) {
        $live = $liveSubnets['azurebastionsubnet']
        if ($live) {
            $bastion = [PSCustomObject]@{ Name=[string]$live.name; Id=[string]$live.id; Prefix=(Get-ZsSubnetPrefix -Subnet $live) }
            if ($bastion.Prefix) { $plan['AzureBastionSubnet'] = $bastion.Prefix }
        }
    }

    if ($errors.Count -gt 0) {
        Write-ZsError -Cmdlet $Cmdlet -ErrorId 'ZsByoSubnetResolution' -Category ObjectNotFound -Message (
            "Existing-network resolution failed for VNet '$vnetName':`n  " + ($errors -join "`n  ") +
            "`n  Nothing has been deployed.")
    }

    Write-ZsLog ("Resolved existing network: VNet $vnetName ($vnetRg) with " +
        "$(@($subnets.Keys).Count) subnet(s)$(if ($bastion) { ' + AzureBastionSubnet' })")

    # Custom DNS servers decide where privatelink names resolve: a zone linked to this VNet is
    # consulted only when the VNet uses Azure-provided DNS, or its DNS forwards to it.
    $dnsServers = @(Get-ZsPropertyValue $vnet 'properties.dhcpOptions.dnsServers' | Where-Object { $_ } | ForEach-Object { [string]$_ })

    return [PSCustomObject]@{
        VnetName              = $vnetName
        VnetId                = [string]$vnet.id
        VnetPath              = [string]$vnet.id
        VnetResourceGroupName = $vnetRg
        VnetSubscriptionId    = $vnetSub
        Location              = [string]$vnet.location
        AddressSpace          = $addressSpace
        Subnets               = $subnets
        SubnetPlan            = [PSCustomObject]$plan
        BastionSubnet         = $bastion
        CrossSubscription     = ($vnetSub -notlike $script:ZsSession.SubscriptionId)
        DnsServers            = $dnsServers
    }
}

function Set-ZsSubnetNsgAssociation {
    <#
    .SYNOPSIS Associates an NSG with an existing subnet, replacing any different one already there.
    .DESCRIPTION The PowerShell twin of azurerm_subnet_network_security_group_association: a
        GET-merge-PUT that sets networkSecurityGroup and preserves everything else on the subnet
        (NAT gateway, route table, delegations, service endpoints). Idempotent — a subnet already
        carrying this NSG is verified and left alone. Attaching replaces whatever the subnet had
        before; on a subnet somebody else owns that replacement is logged as a warning naming the
        NSG it displaced, so the change is visible to whoever reviews the run.
    .PARAMETER SubnetId Bare resource ID of the subnet.
    .PARAMETER NsgId Resource ID of the NSG to bind.
    .PARAMETER Label Short name for logging and ShouldProcess.
    .PARAMETER KeepForeignNsg Leave an NSG this module did not create in place instead of replacing it,
        for subnets whose NSG belongs to the network's owner (AzureBastionSubnet, a brought Function
        App subnet). Returns false then.
    .OUTPUTS [bool] True when the subnet ends the call carrying the NSG (already or newly).
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding(SupportsShouldProcess)]
    [OutputType([bool])]
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$SubnetId,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$NsgId,
        [string]$Label = '',
        [switch]$KeepForeignNsg
    )

    if (-not $Label) { $Label = ($SubnetId -split '/')[-1] }
    $api  = $script:ApiVersions.Network
    $sUri = "$SubnetId`?api-version=$api"

    # A dry run reads the subnet as the real run does, so it names only an association that would
    # change. A subnet the run would create is not there yet to read.
    $live = Invoke-ArmGet -Uri $sUri -AllowNotFound:$WhatIfPreference
    if (-not $live) { return $true }
    $currentNsg = ''
    if ($live.PSObject.Properties['properties'] -and $live.properties.PSObject.Properties['networkSecurityGroup'] -and
        $live.properties.networkSecurityGroup -and $live.properties.networkSecurityGroup.PSObject.Properties['id']) {
        $currentNsg = [string]$live.properties.networkSecurityGroup.id
    }
    if ($currentNsg -and ($currentNsg -like $NsgId)) {
        Write-ZsLog "Subnet $Label already carries the NSG; association verified"
        return $true
    }
    if ($currentNsg -and $KeepForeignNsg -and (Test-ZsForeignNsg -NsgId $currentNsg)) {
        Write-ZsLog "Subnet $Label carries NSG $(($currentNsg -split '/')[-1]), which this deployment did not create; it is left in place and governs the subnet" -Level WARN
        return $false
    }
    if (-not $PSCmdlet.ShouldProcess($Label, "Associate NSG $(($NsgId -split '/')[-1])")) { return [bool]$WhatIfPreference }

    if ($currentNsg) {
        Write-ZsLog "Subnet $Label carried a different NSG ($currentNsg); it is being replaced. Confirm with the subnet's owner if that NSG was theirs." -Level WARN
    }
    $live.properties | Add-Member -NotePropertyName 'networkSecurityGroup' -NotePropertyValue @{ id = $NsgId } -Force
    Invoke-ArmPut -Uri $sUri -Body @{ properties = $live.properties } | Out-Null
    Wait-ArmProvision -Uri $sUri -Label "NSG-assoc-$Label" | Out-Null
    Write-ZsLog "Associated NSG with subnet $Label"
    return $true
}

function Test-ZsForeignNsg {
    # True for an NSG this deployment stack did not create. One the deployer cannot read is somebody
    # else's too: it is in a resource group the deployment has no rights in.
    [CmdletBinding()]
    [OutputType([bool])]
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$NsgId)
    $nsg = $null
    try { $nsg = Invoke-ArmGet -Uri "$NsgId`?api-version=$($script:ApiVersions.Network)" -AllowNotFound }
    catch { Write-ZsLog "Could not read NSG $NsgId`: $($_.Exception.Message)" -Level DEBUG }
    return (-not ($nsg -and (Test-ZsModuleOwned -Resource $nsg)))
}

function Assert-ZsSubnetAttachment {
    <#
    .SYNOPSIS Stops a brought-network deployment, before anything is attached, when a subnet already
        carries an NSG or NAT gateway the configuration does not name.
    .DESCRIPTION A subnet takes one NSG and one NAT gateway, so attaching this deployment's would replace
        the network owner's. Terraform's associations refuse a subnet that already has one, and its
        attach_nsgs and attach_nat_gateway leave the owner's in place; this applies the same contract to
        the subnets as Resolve-ZsExistingNetwork read them. An NSG or NAT gateway this module created
        is its own, so a re-run passes.
    .PARAMETER Network The result of Resolve-ZsExistingNetwork.
    .PARAMETER MgmtNsgId The NSG BringYourOwn.MgmtNsgId names for the management subnet, if any.
    .PARAMETER ServiceNsgId The NSG BringYourOwn.ServiceNsgId names for the service subnet, if any.
    .PARAMETER AttachNatGateway Whether the deployment attaches its NAT gateway (BringYourOwn.AttachNatGateway).
    .PARAMETER Cmdlet The calling $PSCmdlet, so a stop surfaces from the operator's cmdlet.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]$Network,
        [string]$MgmtNsgId = '',
        [string]$ServiceNsgId = '',
        [bool]$AttachNatGateway = $true,
        [System.Management.Automation.PSCmdlet]$Cmdlet = $null
    )

    $problems = [System.Collections.Generic.List[string]]::new()
    if ([bool]$MgmtNsgId -ne [bool]$ServiceNsgId) {
        $problems.Add("BringYourOwn.MgmtNsgId and ServiceNsgId are supplied together or not at all, as Terraform's attach_nsgs covers both subnets. Name the other subnet's NSG too, or clear this one.")
    }
    foreach ($role in @(
            @{ Key='snet-zscc-mgmt';    Label='Management'; Named=$MgmtNsgId }
            @{ Key='snet-zscc-service'; Label='Service';    Named=$ServiceNsgId })) {
        $s = $Network.Subnets[$role.Key]
        if (-not $s.NsgId -or ($role.Named -and $s.NsgId -eq $role.Named)) { continue }
        if (Test-ZsForeignNsg -NsgId $s.NsgId) {
            $problems.Add("$($role.Label) subnet $($s.Name) carries NSG $(($s.NsgId -split '/')[-1]), which this deployment did not create. " +
                "Name it, with the other subnet's, in BringYourOwn.MgmtNsgId and ServiceNsgId to keep it (it must then allow what this module's NSG allows), or have the subnet's owner detach it.")
        }
    }

    $ownNat = "$(Get-ZsRgPath)/providers/Microsoft.Network/natGateways/natgw-zscc-$($script:ZsSession.Environment)-$($script:ZsSession.Location)"
    foreach ($key in @('snet-zscc-mgmt','snet-zscc-service','snet-zscc-funcapp')) {
        if (-not $Network.Subnets.ContainsKey($key)) { continue }
        $s = $Network.Subnets[$key]
        $nat = [string](Get-ZsPropertyValue $s.Object 'properties.natGateway.id')
        if (-not $nat) { continue }
        $own = $nat -eq $ownNat
        if ($AttachNatGateway -and -not $own) {
            $problems.Add("Subnet $($s.Name) carries NAT gateway $(($nat -split '/')[-1]), which this deployment did not create. " +
                "Set BringYourOwn.AttachNatGateway to false to keep it as the subnets' way out, or have the subnet's owner detach it.")
        } elseif (-not $AttachNatGateway -and $own) {
            Write-ZsLog ("Subnet $($s.Name) still carries this deployment's NAT gateway. AttachNatGateway false creates none, but does not detach or delete " +
                "this one, where Terraform's attach_nat_gateway = false destroys it: to hand the subnets to the platform's egress, detach it from them and " +
                "delete it, and its public address once the zscc-protect lock on that is lifted.") -Level WARN
        }
    }

    if ($problems.Count -gt 0) {
        Write-ZsError -Cmdlet $Cmdlet -ErrorId 'ZsByoSubnetAttached' -Category ResourceExists -Message (
            "The brought network's subnets already carry what this deployment would attach, and a subnet takes one of each:`n  " +
            ($problems -join "`n  ") + "`n  Nothing has been deployed.")
    }
}

function Add-ZsSubnetServiceEndpoint {
    <#
    .SYNOPSIS Ensures a subnet carries the named service endpoints, adding any that are missing.
    .DESCRIPTION GET-merge-PUT that unions the requested services into the subnet's serviceEndpoints
        while preserving every other property. Used for the service endpoints asked of
        New-ZsNetworkFoundation on an existing Function App subnet. Idempotent: a subnet already
        carrying every requested service is verified and left untouched.
    .PARAMETER SubnetId Bare resource ID of the subnet.
    .PARAMETER Services Service names to ensure, for example Microsoft.Storage.
    .PARAMETER Label Short name for logging and ShouldProcess.
    .OUTPUTS [bool] True when the subnet ends the call carrying every requested service.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding(SupportsShouldProcess)]
    [OutputType([bool])]
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$SubnetId,
        [Parameter(Mandatory)][string[]]$Services,
        [string]$Label = ''
    )

    if (-not $Label) { $Label = ($SubnetId -split '/')[-1] }
    $api  = $script:ApiVersions.Network
    $sUri = "$SubnetId`?api-version=$api"

    if ($WhatIfPreference) {
        Write-ZsLog "What if: ensure service endpoints ($($Services -join ', ')) on subnet $Label" -Level DEBUG
        return $true
    }

    $live = Invoke-ArmGet -Uri $sUri
    $existing = @()
    if ($live.PSObject.Properties['properties'] -and $live.properties.PSObject.Properties['serviceEndpoints']) {
        $existing = @($live.properties.serviceEndpoints | Where-Object { $_ } | ForEach-Object { [string]$_.service })
    }
    $missing = @($Services | Where-Object { $_ -notin $existing })
    if ($missing.Count -eq 0) {
        Write-ZsLog "Subnet $Label already carries service endpoint(s): $($Services -join ', ')"
        return $true
    }
    if (-not $PSCmdlet.ShouldProcess($Label, "Add service endpoints: $($missing -join ', ')")) { return $false }

    $merged = [System.Collections.Generic.List[object]]::new()
    foreach ($svc in $existing) { $merged.Add(@{ service = $svc }) }
    foreach ($m in $missing)    { $merged.Add(@{ service = $m }) }
    $live.properties | Add-Member -NotePropertyName 'serviceEndpoints' -NotePropertyValue $merged -Force
    Invoke-ArmPut -Uri $sUri -Body @{ properties = $live.properties } | Out-Null
    Wait-ArmProvision -Uri $sUri -Label "$Label (service endpoints)" | Out-Null
    Write-ZsLog "Added service endpoint(s) to ${Label}: $($missing -join ', ')"
    return $true
}

function Remove-ZsSubnetServiceEndpoint {
    # GET-merge-PUT removing the named service endpoints; the others keep their locations as returned.
    # True when the subnet was written.
    [CmdletBinding(SupportsShouldProcess)]
    [OutputType([bool])]
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$SubnetId,
        [Parameter(Mandatory)][string[]]$Services,
        [string]$Label = ''
    )

    if (-not $Label) { $Label = ($SubnetId -split '/')[-1] }
    $sUri = "$SubnetId`?api-version=$($script:ApiVersions.Network)"
    $live = Invoke-ArmGet -Uri $sUri
    $have = @(Get-ZsPropertyValue $live 'properties.serviceEndpoints' | Where-Object { $_ })
    $drop = @($have | ForEach-Object { [string]$_.service } | Where-Object { $_ -in $Services })
    if ($drop.Count -eq 0) { return $false }
    if (-not $PSCmdlet.ShouldProcess($Label, "Remove service endpoints: $($drop -join ', ')")) { return $false }

    $keep = @($have | Where-Object { [string]$_.service -notin $Services })
    $live.properties | Add-Member -NotePropertyName 'serviceEndpoints' -NotePropertyValue $keep -Force
    Invoke-ArmPut -Uri $sUri -Body @{ properties = $live.properties } | Out-Null
    Wait-ArmProvision -Uri $sUri -Label "$Label (service endpoints)" | Out-Null
    Write-ZsLog "Removed service endpoint(s) from ${Label}: $($drop -join ', ')"
    return $true
}
