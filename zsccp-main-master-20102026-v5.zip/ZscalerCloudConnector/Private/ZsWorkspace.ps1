<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module — shared Log Analytics workspace provisioning.

.DESCRIPTION
    Both New-ZsDiagnostics and the lifecycle Function App's Application Insights component
    need a workspace, and the Function App is created first in the deployment order. Both
    call through here and converge on one workspace with the deterministic module name,
    so a deployment never ends up paying for two.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Get-ZsWorkspaceName {
    [CmdletBinding()]
    [OutputType([string])]
    param()
    return New-ZsResourceName -Prefix 'log-zscc' -Environment $script:ZsSession.Environment -Location $script:ZsSession.Location
}

function New-ZsWorkspace {
    <#
    .SYNOPSIS Ensures the Log Analytics workspace exists and returns it.
    .PARAMETER WorkspaceName Explicit name; the deterministic module name is used if omitted.
    .PARAMETER RetentionDays Workspace retention in days.
    .OUTPUTS The workspace ARM resource object.
    #>
    [CmdletBinding()]
    param(
        [string]$WorkspaceName = '',
        [ValidateRange(30,730)][int]$RetentionDays = 90
    )
    $loc = $script:ZsSession.Location; $tags = Get-ZsTags; $rgPath = Get-ZsRgPath
    if (-not $WorkspaceName) { $WorkspaceName = Get-ZsWorkspaceName }

    $waPath = "$rgPath/providers/Microsoft.OperationalInsights/workspaces/$WorkspaceName"
    $waUri  = "$waPath`?api-version=$($script:ApiVersions.LogAnalytics)"
    $check  = Test-ArmResource -Uri $waUri
    if ($check.Exists) { return $check.Resource }

    $waBody = @{
        location=$loc; tags=$tags
        properties=@{ sku=@{name='PerGB2018'}; retentionInDays=$RetentionDays
            features=@{ enableLogAccessUsingOnlyResourcePermissions=$true } }
    }
    try {
        Invoke-ArmPut -Uri $waUri -Body $waBody | Out-Null
    } catch {
        # Self-register the provider at point of use. The workspace is created even when
        # pre-flight was skipped, and losing every trace and alert to an unregistered
        # provider is a silent failure worth one registration attempt here.
        if ("$_" -notmatch 'MissingSubscriptionRegistration') { throw }
        $subPath = Get-ZsSubscriptionPath
        Write-ZsLog "Registering Microsoft.OperationalInsights (required for the Log Analytics workspace)"
        Invoke-ArmPost -Uri "$subPath/providers/Microsoft.OperationalInsights/register?api-version=$($script:ApiVersions.Providers)" | Out-Null
        for ($rpPoll = 1; $rpPoll -le 12; $rpPoll++) {
            Start-Sleep -Seconds 10
            $prov = Invoke-ArmGet -Uri "$subPath/providers/Microsoft.OperationalInsights`?api-version=$($script:ApiVersions.Providers)"
            if ($prov.registrationState -eq 'Registered') { break }
        }
        Invoke-ArmPut -Uri $waUri -Body $waBody | Out-Null
    }
    $wa = Wait-ArmProvision -Uri $waUri -Label $WorkspaceName
    Add-ZsManifestResource -Type 'LogAnalyticsWorkspace' -Name $WorkspaceName -ResourceId $wa.id
    return $wa
}

function New-ZsAppInsights {
    <#
    .SYNOPSIS Ensures a workspace-based Application Insights component exists and returns it.
    .DESCRIPTION Always workspace-based (classic components are retired), so the telemetry lands
        in the same workspace as the diagnostic settings and one KQL query spans both.
    .PARAMETER Name Component name.
    .PARAMETER WorkspaceId Resource ID of the backing Log Analytics workspace.
    .OUTPUTS The Application Insights ARM resource object.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$WorkspaceId
    )
    $loc = $script:ZsSession.Location; $tags = Get-ZsTags; $rgPath = Get-ZsRgPath
    $aiUri = "$rgPath/providers/Microsoft.Insights/components/$Name`?api-version=$($script:ApiVersions.AppInsights)"

    Invoke-ArmPut -Uri $aiUri -Body @{
        location=$loc; tags=$tags; kind='web'
        properties=@{
            Application_Type    = 'web'
            WorkspaceResourceId = $WorkspaceId
            IngestionMode       = 'LogAnalytics'
        }
    } | Out-Null
    $ai = Wait-ArmProvision -Uri $aiUri -Label $Name
    Add-ZsManifestResource -Type 'ApplicationInsights' -Name $Name -ResourceId $ai.id
    return $ai
}
