<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (network security group helpers).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function ConvertTo-ZsRuleKey {
    # One comparable line per security rule. A rule as written here (a hashtable) and the same rule
    # read back from Resource Manager (singular and plural fields both present, one of them empty,
    # plus etag and provisioning state) reduce to the same line: the fields that decide what it does.
    [CmdletBinding()]
    [OutputType([string])]
    param([Parameter(Mandatory)][object]$Rule)

    $p = Get-ZsPropertyValue $Rule 'properties'
    $pick = {
        param($single, $plural)
        $many = @(Get-ZsPropertyValue $p $plural | Where-Object { $_ } | ForEach-Object { "$_" } | Sort-Object)
        if ($many.Count -gt 0) { $many -join ',' } else { "$(Get-ZsPropertyValue $p $single)" }
    }
    $parts = @(
        "$(Get-ZsPropertyValue $Rule 'name')"
        "$(Get-ZsPropertyValue $p 'priority')"
        "$(Get-ZsPropertyValue $p 'direction')"
        "$(Get-ZsPropertyValue $p 'access')"
        "$(Get-ZsPropertyValue $p 'protocol')"
        (& $pick 'sourcePortRange' 'sourcePortRanges')
        (& $pick 'destinationPortRange' 'destinationPortRanges')
        (& $pick 'sourceAddressPrefix' 'sourceAddressPrefixes')
        (& $pick 'destinationAddressPrefix' 'destinationAddressPrefixes')
    )
    return ($parts -join '|').ToLowerInvariant()
}

function Set-ZsNsg {
    # Like an azurerm_network_security_group with inline rules: the group ends with exactly these
    # rules. A group this module created that has drifted is rewritten in one PUT; one of the same
    # name without this deployment's managed-by tag is somebody else's, and is reported, not touched.
    # Returns the NSG's resource ID, or a placeholder under -WhatIf.
    [CmdletBinding(SupportsShouldProcess)]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Name,
        [Parameter(Mandatory)][object[]]$Rules,
        [Parameter(Mandatory)][string]$Role
    )

    $loc = $script:ZsSession.Location; $tags = Get-ZsTags; $api = $script:ApiVersions.Network
    $nsgPath = "$(Get-ZsRgPath)/providers/Microsoft.Network/networkSecurityGroups/$Name"
    $nsgUri  = "$nsgPath`?api-version=$api"

    $existing = Test-ArmResource -Uri $nsgUri
    if ($existing.Exists) {
        $live  = $existing.Resource
        $owned = Test-ZsModuleOwned -Resource $live
        Add-ZsManifestResource -Type 'NSG' -Name $Name -ResourceId $live.id -Properties @{ Role=$Role; RuleCount=@($Rules).Count } -PreExisting:(-not $owned)

        $liveRules = @(Get-ZsPropertyValue $live 'properties.securityRules' | Where-Object { $_ })
        $liveKeys = @($liveRules | ForEach-Object { ConvertTo-ZsRuleKey -Rule $_ } | Sort-Object)
        $wantKeys = @($Rules     | ForEach-Object { ConvertTo-ZsRuleKey -Rule $_ } | Sort-Object)
        if (($liveKeys -join "`n") -eq ($wantKeys -join "`n")) {
            Write-ZsLog "$Role NSG $Name verified"
            return [string]$live.id
        }

        $added   = @($wantKeys | Where-Object { $_ -notin $liveKeys }).Count
        $dropped = @($liveKeys | Where-Object { $_ -notin $wantKeys }).Count
        if (-not $owned) {
            Write-ZsLog ("$Role NSG $Name differs from this module's rule set ($added rule(s) to add or change, $dropped to remove), " +
                "but it carries no managed-by tag of this deployment, so it is somebody else's and is left as it is. " +
                "Bring its rules in line, or remove it so the module creates its own.") -Level WARN
            return [string]$live.id
        }
        if ($PSCmdlet.ShouldProcess($Name, "Reconcile $Role NSG rules")) {
            # Tags the group already carries are kept; this module's own are laid over them.
            $merged = @{}
            if ($live.PSObject.Properties['tags'] -and $live.tags) {
                foreach ($p in $live.tags.PSObject.Properties) { $merged[$p.Name] = $p.Value }
            }
            foreach ($k in $tags.Keys) { $merged[$k] = $tags[$k] }
            Invoke-ArmPut -Uri $nsgUri -Body @{ location=$live.location; tags=$merged; properties=@{ securityRules=@($Rules) } } | Out-Null
            Wait-ArmProvision -Uri $nsgUri -Label $Name | Out-Null
            Write-ZsLog "$Role NSG $Name reconciled: $added rule(s) added or changed, $dropped removed"
        }
        return [string]$live.id
    }

    if ($PSCmdlet.ShouldProcess($Name, "Create $Role NSG")) {
        Invoke-ArmPut -Uri $nsgUri -Body @{ location=$loc; tags=$tags; properties=@{ securityRules=@($Rules) } } | Out-Null
        $nsg = Wait-ArmProvision -Uri $nsgUri -Label $Name
        Add-ZsManifestResource -Type 'NSG' -Name $Name -ResourceId $nsg.id -Properties @{ Role=$Role; RuleCount=@($Rules).Count }
        return [string]$nsg.id
    }
    return "($($Role.ToLowerInvariant()) NSG created at deploy time)"
}

function Get-ZsFuncAppNsgRuleSet {
    # With route-all every connection the app makes leaves through its integration subnet, so this is
    # what it can reach: HTTPS to its private endpoints and to the internet (the Zscaler portal API,
    # Resource Manager, Entra ID), HTTP for certificate revocation, and DNS. Nothing arrives inbound
    # on an integration subnet; the deny says so.
    [CmdletBinding()]
    [OutputType([hashtable[]])]
    param()
    return @(
        @{ name = 'DenyAllIn';                properties = @{ priority=4096; direction='Inbound';  access='Deny';  protocol='*';   sourcePortRange='*'; destinationPortRange='*';   sourceAddressPrefix='*'; destinationAddressPrefix='*' } }
        @{ name = 'AllowPrivateEndpointsOut'; properties = @{ priority=100;  direction='Outbound'; access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='443'; sourceAddressPrefix='*'; destinationAddressPrefix='VirtualNetwork' } }
        @{ name = 'AllowHTTPSOut';            properties = @{ priority=110;  direction='Outbound'; access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='443'; sourceAddressPrefix='*'; destinationAddressPrefix='Internet' } }
        @{ name = 'AllowHTTPOut';             properties = @{ priority=120;  direction='Outbound'; access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='80';  sourceAddressPrefix='*'; destinationAddressPrefix='Internet' } }
        @{ name = 'AllowDNSUdpOut';           properties = @{ priority=130;  direction='Outbound'; access='Allow'; protocol='Udp'; sourcePortRange='*'; destinationPortRange='53';  sourceAddressPrefix='*'; destinationAddressPrefix='*' } }
        @{ name = 'AllowDNSTcpOut';           properties = @{ priority=131;  direction='Outbound'; access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='53';  sourceAddressPrefix='*'; destinationAddressPrefix='*' } }
        @{ name = 'DenyAllOut';               properties = @{ priority=4096; direction='Outbound'; access='Deny';  protocol='*';   sourcePortRange='*'; destinationPortRange='*';   sourceAddressPrefix='*'; destinationAddressPrefix='*' } }
    )
}

function Get-ZsBastionNsgRuleSet {
    # Microsoft's rule set for AzureBastionSubnet (https://learn.microsoft.com/azure/bastion/bastion-nsg).
    # ClientSource is where sessions come from: VirtualNetwork for a private-only Bastion, Internet
    # for one with a public IP, or an admin range.
    [CmdletBinding()]
    [OutputType([hashtable[]])]
    param([Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$ClientSource)

    return @(
        @{ name='AllowHttpsInbound';                     properties=@{ priority=100;  direction='Inbound';  access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='443';              sourceAddressPrefix=$ClientSource;      destinationAddressPrefix='*' } }
        @{ name='AllowGatewayManagerInbound';            properties=@{ priority=110;  direction='Inbound';  access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='443';              sourceAddressPrefix='GatewayManager';   destinationAddressPrefix='*' } }
        @{ name='AllowAzureLoadBalancerInbound';         properties=@{ priority=120;  direction='Inbound';  access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='443';              sourceAddressPrefix='AzureLoadBalancer'; destinationAddressPrefix='*' } }
        @{ name='AllowBastionHostCommunicationInbound';  properties=@{ priority=130;  direction='Inbound';  access='Allow'; protocol='*';   sourcePortRange='*'; destinationPortRanges=@('8080','5701'); sourceAddressPrefix='VirtualNetwork';   destinationAddressPrefix='VirtualNetwork' } }
        @{ name='DenyAllInbound';                        properties=@{ priority=4096; direction='Inbound';  access='Deny';  protocol='*';   sourcePortRange='*'; destinationPortRange='*';                sourceAddressPrefix='*';                destinationAddressPrefix='*' } }
        @{ name='AllowSshRdpOutbound';                   properties=@{ priority=100;  direction='Outbound'; access='Allow'; protocol='*';   sourcePortRange='*'; destinationPortRanges=@('22','3389');   sourceAddressPrefix='*';                destinationAddressPrefix='VirtualNetwork' } }
        @{ name='AllowAzureCloudOutbound';               properties=@{ priority=110;  direction='Outbound'; access='Allow'; protocol='Tcp'; sourcePortRange='*'; destinationPortRange='443';              sourceAddressPrefix='*';                destinationAddressPrefix='AzureCloud' } }
        @{ name='AllowBastionHostCommunicationOutbound'; properties=@{ priority=120;  direction='Outbound'; access='Allow'; protocol='*';   sourcePortRange='*'; destinationPortRanges=@('8080','5701'); sourceAddressPrefix='VirtualNetwork';   destinationAddressPrefix='VirtualNetwork' } }
        @{ name='AllowHttpOutbound';                     properties=@{ priority=130;  direction='Outbound'; access='Allow'; protocol='*';   sourcePortRange='*'; destinationPortRange='80';               sourceAddressPrefix='*';                destinationAddressPrefix='Internet' } }
        @{ name='DenyAllOutbound';                       properties=@{ priority=4096; direction='Outbound'; access='Deny';  protocol='*';   sourcePortRange='*'; destinationPortRange='*';                sourceAddressPrefix='*';                destinationAddressPrefix='*' } }
    )
}
