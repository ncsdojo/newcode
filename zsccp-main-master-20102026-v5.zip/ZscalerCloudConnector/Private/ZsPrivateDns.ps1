<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (private endpoint and private DNS helpers).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

function Test-ZsManifestHas {
    # Several private endpoints share one zone and one link, and the manifest names each once.
    [CmdletBinding()]
    [OutputType([bool])]
    param([Parameter(Mandatory)][string]$Type, [Parameter(Mandatory)][string]$ResourceId)
    $entries = Get-ZsPropertyValue (Get-ZsPropertyValue $script:ZsManifest 'Resources') $Type
    foreach ($e in @($entries | Where-Object { $_ })) {
        if ([string](Get-ZsPropertyValue $e 'ResourceId') -eq $ResourceId) { return $true }
    }
    return $false
}

function Resolve-ZsPrivateDnsZone {
    # Returns the ID of the zone a private endpoint registers in, in one of the two arrangements the
    # Terraform environments have:
    #   - the platform's zone (HubResourceGroupName set). In a hub-and-spoke network the privatelink
    #     zones live in the hub, already linked where the hub's resolver sees them, and Azure will not
    #     link a second zone of the same name to the VNet. It is used as it is; nothing is created.
    #   - this deployment's own zone, linked to the VNet. An existing zone, or a link already joining
    #     the VNet to it, is used rather than another made.
    [CmdletBinding(SupportsShouldProcess)]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$ZoneName,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$VnetId,
        [string]$HubResourceGroupName = '',
        [string]$HubSubscriptionId = ''
    )

    $dnsApi = $script:ApiVersions.PrivateDns
    if ($HubResourceGroupName) {
        $sub = if ($HubSubscriptionId) { $HubSubscriptionId } else { $script:ZsSession.SubscriptionId }
        $zoneId = "/subscriptions/$sub/resourceGroups/$HubResourceGroupName/providers/Microsoft.Network/privateDnsZones/$ZoneName"
        $zone = Invoke-ArmGet -Uri "$zoneId`?api-version=$dnsApi" -AllowNotFound
        if (-not $zone) {
            throw [System.InvalidOperationException]::new(
                "The platform's private DNS zone $ZoneName was not found in resource group $HubResourceGroupName " +
                "(subscription $sub), or this identity cannot read it. The private endpoints register their records there. " +
                "Have the platform team create it and link it where their DNS resolves privatelink names, or clear " +
                "PrivateDnsZoneResourceGroupName so the deployment creates its own zone linked to the VNet.")
        }
        if (-not (Test-ZsManifestHas -Type 'PrivateDnsZone' -ResourceId ([string]$zone.id))) {
            Add-ZsManifestResource -Type 'PrivateDnsZone' -Name $ZoneName -ResourceId ([string]$zone.id) -PreExisting
        }
        return [string]$zone.id
    }

    $tags = Get-ZsTags
    $zonePath = "$(Get-ZsRgPath)/providers/Microsoft.Network/privateDnsZones/$ZoneName"
    $zoneUri  = "$zonePath`?api-version=$dnsApi"
    $zoneLive = Invoke-ArmGet -Uri $zoneUri -AllowNotFound
    if (-not $zoneLive) {
        if (-not $PSCmdlet.ShouldProcess($ZoneName, 'Create private DNS zone')) { return $zonePath }
        Invoke-ArmPut -Uri $zoneUri -Body @{ location='global'; tags=$tags } | Out-Null
        Add-ZsManifestResource -Type 'PrivateDnsZone' -Name $ZoneName -ResourceId $zonePath
        Write-ZsLog "$ZoneName ready"
    } elseif (-not (Test-ZsManifestHas -Type 'PrivateDnsZone' -ResourceId $zonePath)) {
        Add-ZsManifestResource -Type 'PrivateDnsZone' -Name $ZoneName -ResourceId $zonePath -PreExisting:(-not (Test-ZsModuleOwned -Resource $zoneLive))
    }

    # A VNet links to a zone once. Any link already joining the two is the link.
    $links = Invoke-ArmGet -Uri "$zonePath/virtualNetworkLinks?api-version=$dnsApi" -AllowNotFound
    $existingLink = @(Get-ZsPropertyValue $links 'value' | Where-Object {
        $_ -and ([string](Get-ZsPropertyValue $_ 'properties.virtualNetwork.id') -eq $VnetId)
    }) | Select-Object -First 1
    if ($existingLink) {
        if (-not (Test-ZsManifestHas -Type 'PrivateDnsZoneLink' -ResourceId ([string]$existingLink.id))) {
            Add-ZsManifestResource -Type 'PrivateDnsZoneLink' -Name ([string]$existingLink.name) -ResourceId ([string]$existingLink.id) `
                -PreExisting:(-not (Test-ZsModuleOwned -Resource $existingLink))
        }
        return $zonePath
    }

    $linkName = "link-zscc-$($script:ZsSession.ShortId)"
    $linkPath = "$zonePath/virtualNetworkLinks/$linkName"
    if ($PSCmdlet.ShouldProcess("$ZoneName -> $(($VnetId -split '/')[-1])", 'Link private DNS zone to the VNet')) {
        try {
            Invoke-ArmPut -Uri "$linkPath`?api-version=$dnsApi" -Body @{
                location='global'; tags=$tags
                properties=@{ virtualNetwork=@{ id=$VnetId }; registrationEnabled=$false }
            } | Out-Null
        } catch {
            if ("$($_.Exception.Message) $($_.ErrorDetails)" -match '(?i)overlapping namespace|already linked') {
                throw [System.InvalidOperationException]::new(
                    "The VNet is already linked to another $ZoneName zone - in a hub-and-spoke network, the platform's. " +
                    "Azure links a VNet to one zone of a name. Set BringYourOwn.PrivateDnsZoneResourceGroupName (and " +
                    "PrivateDnsZoneSubscriptionId when it is in another subscription) to that zone's resource group, so the " +
                    "private endpoints register their records there.")
            }
            throw
        }
        Add-ZsManifestResource -Type 'PrivateDnsZoneLink' -Name $linkName -ResourceId $linkPath
        Write-ZsLog "DNS VNet link $linkName ready on $ZoneName"
    }
    return $zonePath
}

function Set-ZsPrivateEndpoint {
    # Creates a private endpoint (GroupId: vault, blob, queue, table, sites, azuremonitor) and registers
    # it in the given zones. An existing endpoint is verified and its zone group brought to those zones.
    # Returns the endpoint's Id and PrivateIp.
    [CmdletBinding(SupportsShouldProcess)]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Name,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$TargetId,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$GroupId,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$SubnetId,
        [Parameter(Mandatory)][string[]]$ZoneIds,
        [hashtable]$Properties = @{}
    )

    $nApi = $script:ApiVersions.Network
    $pePath = "$(Get-ZsRgPath)/providers/Microsoft.Network/privateEndpoints/$Name"
    $peUri  = "$pePath`?api-version=$nApi"

    $check = Test-ArmResource -Uri $peUri
    if ($check.Exists) {
        Write-ZsLog "Private Endpoint $Name verified" -Level DEBUG
    } elseif ($PSCmdlet.ShouldProcess($Name, "Create $GroupId private endpoint")) {
        Invoke-ArmPut -Uri $peUri -Body @{
            location=$script:ZsSession.Location; tags=(Get-ZsTags)
            properties=@{
                subnet=@{ id=$SubnetId }
                privateLinkServiceConnections=@(@{
                    name=$Name
                    properties=@{ privateLinkServiceId=$TargetId; groupIds=@($GroupId) }
                })
            }
        } | Out-Null
        Wait-ArmProvision -Uri $peUri -Label $Name | Out-Null
        Write-ZsLog "$Name provisioned"
    } else {
        return [PSCustomObject]@{ Id="(private endpoint $Name created at deploy time)"; PrivateIp='' }
    }

    $pe = Invoke-ArmGet -Uri $peUri
    $conn0 = @(Get-ZsPropertyValue $pe 'properties.privateLinkServiceConnections')[0]
    $connState = [string](Get-ZsPropertyValue $conn0 'properties.privateLinkServiceConnectionState.status')
    if (-not $connState) { $connState = 'Unknown' }
    if ($connState -ne 'Approved') {
        Write-ZsLog "Private Endpoint $Name connection state is '$connState' (expected 'Approved'). The resource owner may need to approve it." -Level WARN
    }

    # Zone group: one config per zone. A single-zone endpoint keeps the "<group>-config" name its
    # zone group has always had, so an existing endpoint's record is not dropped and re-added.
    $zg = Invoke-ArmGet -Uri "$pePath/privateDnsZoneGroups/default?api-version=$nApi" -AllowNotFound
    $liveZones = @(Get-ZsPropertyValue $zg 'properties.privateDnsZoneConfigs' | Where-Object { $_ } | ForEach-Object { [string](Get-ZsPropertyValue $_ 'properties.privateDnsZoneId') })
    $wantZones = @($ZoneIds | Where-Object { $_ -and $_ -notmatch '^\(' })
    $sameZones = (@($liveZones | ForEach-Object { $_.ToLowerInvariant() } | Sort-Object) -join ',') -eq (@($wantZones | ForEach-Object { $_.ToLowerInvariant() } | Sort-Object) -join ',')
    if ($wantZones.Count -gt 0 -and -not $sameZones -and $PSCmdlet.ShouldProcess($Name, 'Register in private DNS')) {
        $configs = @()
        foreach ($z in $wantZones) {
            $cfgName = if ($wantZones.Count -eq 1) { "$GroupId-config" } else { (($z -split '/')[-1]) -replace '\.', '-' }
            $configs += @{ name=$cfgName; properties=@{ privateDnsZoneId=$z } }
        }
        Invoke-ArmPut -Uri "$pePath/privateDnsZoneGroups/default?api-version=$nApi" -Body @{ properties=@{ privateDnsZoneConfigs=$configs } } | Out-Null
        Write-ZsLog "DNS zone group attached to $Name ($((@($wantZones | ForEach-Object { ($_ -split '/')[-1] })) -join ', '))"
    }

    $peNic = Invoke-ArmGet -Uri "$($pe.properties.networkInterfaces[0].id)?api-version=$nApi"
    $peIp = [string]$peNic.properties.ipConfigurations[0].properties.privateIPAddress

    if (-not (Test-ZsManifestHas -Type 'PrivateEndpoint' -ResourceId ([string]$pe.id))) {
        $props = @{ Target=($TargetId -split '/')[-1]; GroupId=$GroupId; PrivateIp=$peIp }
        foreach ($k in $Properties.Keys) { $props[$k] = $Properties[$k] }
        Add-ZsManifestResource -Type 'PrivateEndpoint' -Name $Name -ResourceId ([string]$pe.id) -Properties $props -PreExisting:(-not (Test-ZsModuleOwned -Resource $pe))
    }
    return [PSCustomObject]@{ Id=[string]$pe.id; PrivateIp=$peIp }
}
