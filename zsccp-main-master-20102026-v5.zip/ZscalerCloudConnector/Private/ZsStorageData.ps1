<#
.SYNOPSIS
    Blob data-plane access using Entra ID bearer tokens instead of account keys.

.DESCRIPTION
    Every blob operation the module performs — remote state read/write and lease
    acquisition — goes through here, authenticating with an Entra ID bearer token
    from the caller's own session. No account key is read and no SAS is constructed, so
    storage accounts are created with allowSharedKeyAccess disabled, access is granted
    and revoked through Storage Blob Data role assignments, and every operation lands in
    the audit trail attributed to a real principal rather than an anonymous key holder.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

$script:ZsBlobApiVersion = '2023-11-03'

function Get-ZsStorageToken {
    <#
    .SYNOPSIS Acquires an Entra ID token for the storage data plane.
    .OUTPUTS [string] Bearer token for https://storage.azure.com.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param()
    return Get-OAuthToken -Resource $script:Endpoints.Storage
}

function Invoke-ZsBlobRequest {
    <#
    .SYNOPSIS Issues an authenticated blob data-plane request.
    .DESCRIPTION Adds the bearer token, x-ms-date and x-ms-version headers every blob request
        requires, merges caller-supplied x-ms-* headers, and returns the raw web response so
        callers can read response headers (lease IDs, ETags) as well as the body.
    .PARAMETER Uri Absolute blob endpoint URI.
    .PARAMETER Method HTTP method.
    .PARAMETER Headers Additional headers, typically x-ms-* directives.
    .PARAMETER Body Request body: byte[] or string.
    .PARAMETER ContentType Content type for the body.
    .PARAMETER AllowStatus Status codes to treat as success in addition to 2xx.
    .OUTPUTS The Invoke-WebRequest response object.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Uri,
        [ValidateSet('Get','Put','Head','Delete')][string]$Method = 'Get',
        [hashtable]$Headers = @{},
        [object]$Body = $null,
        [string]$ContentType = '',
        [int[]]$AllowStatus = @(),
        [int]$MaxRetries = 3
    )
    if ($WhatIfPreference -and $Method -ne 'Get') {
        Write-ZsLog "What if: blob $Method $Uri" -Level DEBUG
        return $null
    }

    for ($attempt = 1; $attempt -le $MaxRetries; $attempt++) {
        $h = @{
            'Authorization' = "Bearer $(Get-ZsStorageToken)"
            'x-ms-date'     = [DateTime]::UtcNow.ToString('R')
            'x-ms-version'  = $script:ZsBlobApiVersion
        }
        foreach ($k in $Headers.Keys) { $h[$k] = $Headers[$k] }

        $splat = @{ Uri = $Uri; Method = $Method; Headers = $h; SkipHttpErrorCheck = $true; TimeoutSec = 180 }
        if ($null -ne $Body)  { $splat.Body = $Body }
        if ($ContentType)     { $splat.ContentType = $ContentType }

        # -SkipHttpErrorCheck suppresses HTTP status errors, not transport ones: a dropped
        # connection, a DNS failure or a TLS reset still throws. Those are the failures most worth
        # retrying, and without this catch they escape the loop entirely and no retry ever happens.
        $resp = $null
        try {
            $resp = Invoke-WebRequest @splat
        } catch {
            if ($attempt -lt $MaxRetries) {
                $wait = [math]::Pow(2, $attempt) * 2
                Write-ZsLog "Blob $Method transport error, retry $attempt/$MaxRetries in ${wait}s: $($_.Exception.Message)" -Level WARN
                Start-Sleep -Seconds $wait
                continue
            }
            Write-ZsLog "Blob $Method failed after $MaxRetries attempts: $($_.Exception.Message)" -Level ERROR
            throw
        }

        $status = [int]$resp.StatusCode

        if ($status -lt 400 -or $status -in $AllowStatus) { return $resp }

        if ($status -in @(408, 429, 500, 502, 503, 504) -and $attempt -lt $MaxRetries) {
            $wait = [math]::Pow(2, $attempt) * 2
            $ra = $null
            if ($resp.Headers -and $resp.Headers.ContainsKey('Retry-After')) { $ra = @($resp.Headers['Retry-After'])[0] }
            if ($ra) { try { $wait = [math]::Max([int]$ra, $wait) } catch { } }
            Write-ZsLog "Blob $Method $status, retry $attempt/$MaxRetries in ${wait}s" -Level WARN
            Start-Sleep -Seconds $wait
            continue
        }

        $detail = ''
        try { $detail = [string]$resp.Content } catch { }
        throw [System.Net.Http.HttpRequestException]::new("Blob $Method failed ($status): $detail")
    }
}

function New-ZsBlobContainer {
    <#
    .SYNOPSIS Creates a private blob container, tolerating the already-exists case.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$AccountName,
        [Parameter(Mandatory)][string]$ContainerName
    )
    $uri = "https://$AccountName.blob.core.windows.net/$ContainerName`?restype=container"
    # 409 ContainerAlreadyExists is the idempotent path, not an error.
    Invoke-ZsBlobRequest -Uri $uri -Method Put -AllowStatus @(409) | Out-Null
}

function Set-ZsBlob {
    <#
    .SYNOPSIS Writes a block blob.
    .PARAMETER LeaseId Required when the blob is currently leased.
    .PARAMETER OnlyIfAbsent Send If-None-Match:* so the write is refused with 412 if the blob
        already exists. Used for seeding, where an unconditional write would let a concurrent
        run overwrite state that is already there.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$AccountName,
        [Parameter(Mandatory)][string]$ContainerName,
        [Parameter(Mandatory)][string]$BlobName,
        [Parameter(Mandatory)][object]$Content,
        [string]$ContentType = 'application/octet-stream',
        [string]$LeaseId = '',
        [switch]$OnlyIfAbsent
    )
    $bytes = if ($Content -is [byte[]]) { $Content } else { [System.Text.Encoding]::UTF8.GetBytes([string]$Content) }
    $h = @{ 'x-ms-blob-type' = 'BlockBlob' }
    if ($LeaseId)      { $h['x-ms-lease-id'] = $LeaseId }
    if ($OnlyIfAbsent) { $h['If-None-Match']  = '*' }
    $uri = "https://$AccountName.blob.core.windows.net/$ContainerName/$BlobName"
    $allow = if ($OnlyIfAbsent) { @(412) } else { @() }
    Invoke-ZsBlobRequest -Uri $uri -Method Put -Headers $h -Body $bytes -ContentType $ContentType -AllowStatus $allow | Out-Null
    return $uri
}

function Get-ZsBlob {
    <#
    .SYNOPSIS Reads a blob as text. Returns $null when the blob does not exist.
    .DESCRIPTION Text only. Invoke-WebRequest returns Content as a byte[] for a non-text content
        type, and casting that to string yields the literal 'System.Byte[]' rather than failing,
        so a binary blob read through here would silently produce nonsense.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)][string]$AccountName,
        [Parameter(Mandatory)][string]$ContainerName,
        [Parameter(Mandatory)][string]$BlobName
    )
    $uri  = "https://$AccountName.blob.core.windows.net/$ContainerName/$BlobName"
    $resp = Invoke-ZsBlobRequest -Uri $uri -Method Get -AllowStatus @(404)
    if ([int]$resp.StatusCode -eq 404) { return $null }
    if ($resp.Content -is [byte[]]) {
        return [System.Text.Encoding]::UTF8.GetString($resp.Content)
    }
    return [string]$resp.Content
}
