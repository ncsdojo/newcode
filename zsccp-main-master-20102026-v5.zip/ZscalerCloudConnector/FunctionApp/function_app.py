"""
Cloud Connector lifecycle functions.

Two timers, matching the Zscaler reference function app:

  healthMonitor              every 60s. Evaluates the cloud_connector_aggr_health metric per
                             connector instance, terminates instances that fail the health
                             criteria, and restores scale set capacity so they are replaced.
  synchronizeCloudResources  every SYNC_CRON (default 30 min). Removes EC group entries in the
                             Zscaler portal that no longer have a backing Azure instance.

Health evaluation, thresholds, grace period, termination ratio and portal reconciliation follow
the Zscaler reference implementation. The plumbing does not: all Azure access is raw ARM REST
under the Function App's user-assigned managed identity, so the package needs no management SDK,
no storage account key, and no outbound path beyond the endpoints the VNet already permits.

Environment variables are read under both the Zscaler reference names and this module's names,
so either publisher can drive the same code.
"""

import datetime
import json
import logging
import os
import time
import urllib.parse

import azure.functions as func
import requests
from azure.identity import ManagedIdentityCredential

app = func.FunctionApp()

ARM_ENDPOINT = "https://management.azure.com"
ARM_SCOPE = "https://management.azure.com/.default"
VAULT_SCOPE = "https://vault.azure.net/.default"
COMPUTE_API = "2024-07-01"
METRICS_API = "2018-01-01"

# Health contract published by the connectors. Values and thresholds match the Zscaler
# reference: a sample of 100 is healthy, 0 is unhealthy, and an absent sample counts as
# unhealthy once the instance is past its grace period.
CC_HEALTH_METRIC = "cloud_connector_aggr_health"
CC_METRIC_NAMESPACE = "Zscaler/CloudConnectors"
HEALTHY_METRIC_VALUE = 100
UNHEALTHY_METRIC_VALUE = 0

DEFAULT_HC_DATA_POINTS = 10
DEFAULT_HC_UNHEALTHY_THRESHOLD = 7
DEFAULT_HC_CONSECUTIVE_UNHEALTHY_THRESHOLD = 5
DEFAULT_MAX_TERMINATION_PERCENT = 0.2
DEFAULT_GRACE_PERIOD_TIME_MIN = 30
TERMINATION_POLICY_OLDEST = "oldest"
TERMINATION_POLICY_NEWEST = "newest"

# Fleet-wide fail-safe. Connectors fail independently; a verdict against most of the fleet at
# once is far more likely to be a fault in the path the verdict came through — the metric
# namespace, the identity that reads it, sustained throttling — than simultaneous failure of
# unrelated instances. Above this ratio the monitor reports and terminates nothing, because
# terminating on a bad signal destroys a fleet that was serving traffic.
DEFAULT_FLEET_SUSPICION_RATIO = 0.5

# Capacity restore after a termination is a poll, not a fixed wait: the scale set's desired count
# is decremented asynchronously, and a restore that ran before the decrement landed would read
# "unchanged", skip, and leave the set permanently short.
VMSS_CAPACITY_POLL_INTERVAL_SEC = 5
VMSS_CAPACITY_POLL_TIMEOUT_SEC = 60

API_KEY_SECRET_NAME = "api-key"
USERNAME_SECRET_NAME = "username"
PASSWORD_SECRET_NAME = "password"


# --------------------------------------------------------------------------------------
# Settings
# --------------------------------------------------------------------------------------

def _setting(*names, default=""):
    """First non-empty value among the given app setting names."""
    for n in names:
        v = os.environ.get(n)
        if v is not None and str(v).strip() != "":
            return str(v).strip()
    return default


def _int_setting(*names, default=0):
    """App settings arrive as strings. The reference implementation compares them against
    ints without casting, which raises as soon as a tunable is actually set; cast here."""
    raw = _setting(*names, default="")
    if raw == "":
        return default
    try:
        return int(float(raw))
    except (TypeError, ValueError):
        logging.warning("Setting %s is not numeric (%r); using default %s", names[0], raw, default)
        return default


def _float_setting(*names, default=0.0):
    raw = _setting(*names, default="")
    if raw == "":
        return default
    try:
        return float(raw)
    except (TypeError, ValueError):
        logging.warning("Setting %s is not numeric (%r); using default %s", names[0], raw, default)
        return default


def _bool_setting(*names, default=False):
    raw = _setting(*names, default="").lower()
    if raw == "":
        return default
    return raw not in ("false", "0", "no", "off")


def subscription_id():
    """The reference passes SUBSCRIPTION_ID as a full '/subscriptions/<guid>' path; this
    module passes a bare GUID. Accept either."""
    raw = _setting("SUBSCRIPTION_ID", "AZURE_SUBSCRIPTION_ID")
    if raw.startswith("/"):
        parts = [p for p in raw.split("/") if p]
        return parts[1] if len(parts) > 1 else ""
    return raw


def resource_group():
    return _setting("RESOURCE_GROUP", "AZURE_RESOURCE_GROUP", "CC_RESOURCE_GROUP")


def identity_client_id():
    return _setting("MANAGED_IDENTITY", "AZURE_CLIENT_ID") or None


def vmss_names():
    """VMSS_NAME is a JSON list in the reference. Accept a JSON list, a comma separated
    list, or a single name."""
    raw = _setting("VMSS_NAME")
    if not raw:
        return []
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, list):
            return [str(n).strip() for n in parsed if str(n).strip()]
        return [str(parsed).strip()]
    except (ValueError, TypeError):
        return [n.strip() for n in raw.split(",") if n.strip()]


def certificate_verify():
    return _bool_setting("CERTIFICATE_VERIFY", default=True)


# --------------------------------------------------------------------------------------
# Azure REST
# --------------------------------------------------------------------------------------

def _credential():
    return ManagedIdentityCredential(client_id=identity_client_id())


def _arm_headers(cred):
    return {"Authorization": f"Bearer {cred.get_token(ARM_SCOPE).token}"}


ARM_RETRY_STATUSES = (408, 429, 500, 502, 503, 504)
ARM_MAX_ATTEMPTS = 4


def _arm_request(method, cred, url, **kwargs):
    """One retrying entry point for every ARM call.

    The health monitor issues a metrics query per instance per minute, and Azure Monitor throttles
    that harder than the ARM control plane does. Without a retry a single 429 fails the whole
    invocation, which on the health path means a pass that sees nothing and on the sync path means
    a pass that reconciles nothing.
    """
    last_exc = None
    for attempt in range(1, ARM_MAX_ATTEMPTS + 1):
        try:
            resp = requests.request(method, url, timeout=60, **kwargs)
        except requests.RequestException as exc:
            last_exc = exc
            if attempt == ARM_MAX_ATTEMPTS:
                raise
            wait = 2 ** attempt
            logging.warning("ARM %s transport error (%s); retry %d/%d in %ds",
                            method, exc, attempt, ARM_MAX_ATTEMPTS - 1, wait)
            time.sleep(wait)
            continue

        if resp.status_code in ARM_RETRY_STATUSES and attempt < ARM_MAX_ATTEMPTS:
            wait = 2 ** attempt
            retry_after = resp.headers.get("Retry-After")
            if retry_after:
                try:
                    wait = max(int(retry_after), wait)
                except (TypeError, ValueError):
                    pass
            logging.warning("ARM %s returned %d; retry %d/%d in %ds",
                            method, resp.status_code, attempt, ARM_MAX_ATTEMPTS - 1, wait)
            time.sleep(wait)
            continue

        return resp

    if last_exc:
        raise last_exc
    raise RuntimeError(f"ARM {method} {url} exhausted retries")


def arm_get(cred, path, api_version, params=None, allow_not_found=False):
    url = f"{ARM_ENDPOINT}{path}"
    q = {"api-version": api_version}
    if params:
        q.update(params)
    resp = _arm_request("GET", cred, url, headers=_arm_headers(cred), params=q)
    if allow_not_found and resp.status_code == 404:
        return None
    resp.raise_for_status()
    return resp.json()


def arm_get_all(cred, path, api_version, params=None):
    """A paged GET, following nextLink. ARM pages a resource listing at a provider-chosen size,
    and reading only the first page silently narrows the fleet the caller reasons about — on the
    health path that means instances never evaluated, on the sync path connectors wrongly seen as
    stale and deregistered."""
    body = arm_get(cred, path, api_version, params=params) or {}
    values = list(body.get("value", []))
    next_link = body.get("nextLink")
    pages = 1
    while next_link and pages < 50:
        resp = _arm_request("GET", cred, next_link, headers=_arm_headers(cred))
        resp.raise_for_status()
        body = resp.json()
        values.extend(body.get("value", []))
        next_link = body.get("nextLink")
        pages += 1
    return values


def arm_post(cred, path, api_version, body=None):
    url = f"{ARM_ENDPOINT}{path}"
    headers = _arm_headers(cred)
    headers["Content-Type"] = "application/json"
    resp = _arm_request("POST", cred, url, headers=headers,
                        params={"api-version": api_version}, json=body)
    resp.raise_for_status()
    return resp


def arm_patch(cred, path, api_version, body):
    url = f"{ARM_ENDPOINT}{path}"
    headers = _arm_headers(cred)
    headers["Content-Type"] = "application/json"
    resp = _arm_request("PATCH", cred, url, headers=headers,
                        params={"api-version": api_version}, json=body)
    resp.raise_for_status()
    return resp


def vmss_path(sub_id, rg, vmss_name):
    return (f"/subscriptions/{sub_id}/resourceGroups/{rg}"
            f"/providers/Microsoft.Compute/virtualMachineScaleSets/{vmss_name}")


def vm_path(sub_id, rg, vm_name):
    return (f"/subscriptions/{sub_id}/resourceGroups/{rg}"
            f"/providers/Microsoft.Compute/virtualMachines/{vm_name}")


def discover_instances(cred, sub_id, rg, names, standalone_prefix=""):
    """One resource group VM listing serves both timers.

    Returns a list of dicts: name, vm_id (the immutable Azure VM UUID), computer_name,
    vmss_name, provisioning_state, time_created. Scale sets here are Flexible orchestration,
    so members are first class VM resources and the VM name is also the scale set instance ID.
    """
    listing = arm_get_all(
        cred,
        f"/subscriptions/{sub_id}/resourceGroups/{rg}/providers/Microsoft.Compute/virtualMachines",
        COMPUTE_API,
    )
    wanted = {n.lower() for n in names}
    out = []
    for vm in listing:
        props = vm.get("properties", {}) or {}
        ref = (props.get("virtualMachineScaleSet") or {}).get("id", "")
        member_of = ref.split("/")[-1].lower() if ref else ""

        if wanted:
            if member_of not in wanted:
                continue
        else:
            # Standalone topology: no scale set membership, matched by name prefix.
            if ref:
                continue
            if standalone_prefix and not vm.get("name", "").lower().startswith(standalone_prefix.lower()):
                continue

        out.append({
            "name": vm.get("name", ""),
            "vm_id": (props.get("vmId") or "").lower(),
            "computer_name": ((props.get("osProfile") or {}).get("computerName") or "").lower(),
            "vmss_name": ref.split("/")[-1] if ref else "",
            "provisioning_state": props.get("provisioningState", ""),
            "time_created": _parse_time(props.get("timeCreated")),
        })
    return out


def _parse_time(value):
    if not value:
        return None
    text = str(value).replace("Z", "+00:00")
    try:
        parsed = datetime.datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=datetime.timezone.utc)
    return parsed


def get_secret(cred, vault_url, name):
    token = cred.get_token(VAULT_SCOPE).token
    url = f"{vault_url.rstrip('/')}/secrets/{name}?api-version=7.4"
    resp = requests.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=30)
    resp.raise_for_status()
    return resp.json()["value"]


# --------------------------------------------------------------------------------------
# Health monitoring
# --------------------------------------------------------------------------------------

def query_health_metrics(cred, sub_id, rg, vm_name, lookback_minutes=30):
    """Maximum of cloud_connector_aggr_health per minute over the lookback window, oldest
    first. A minute with no sample yields None, which the evaluator counts as unhealthy."""
    end = datetime.datetime.now(datetime.timezone.utc)
    start = end - datetime.timedelta(minutes=lookback_minutes)
    params = {
        "metricnames": CC_HEALTH_METRIC,
        "metricnamespace": CC_METRIC_NAMESPACE,
        "timespan": f"{start.strftime('%Y-%m-%dT%H:%M:%SZ')}/{end.strftime('%Y-%m-%dT%H:%M:%SZ')}",
        "interval": "PT1M",
        "aggregation": "Maximum",
    }
    body = arm_get(cred, f"{vm_path(sub_id, rg, vm_name)}/providers/microsoft.insights/metrics",
                   METRICS_API, params=params)

    samples = []
    for metric in body.get("value", []):
        for series in metric.get("timeseries", []):
            for point in series.get("data", []):
                samples.append((point.get("timeStamp") or "", point.get("maximum")))
    samples.sort(key=lambda item: item[0])
    return [value for _, value in samples]


def check_grace_period(instance, metric_values, data_points, grace_minutes):
    """A connector is exempt from health evaluation until it has either been alive for the
    grace period or published at least one healthy sample. Returns (evaluate, values)."""
    healthy_index = -1
    for index, value in enumerate(metric_values):
        if value is not None and value != UNHEALTHY_METRIC_VALUE:
            healthy_index = index
            break

    created = instance.get("time_created")
    if created is None:
        # No creation timestamp available, so no defensible grace window can be computed.
        # Evaluate on the samples actually present rather than assuming either state.
        long_lived = True
    else:
        long_lived = (datetime.datetime.now(datetime.timezone.utc) - created) >= datetime.timedelta(minutes=grace_minutes)

    if not metric_values and long_lived:
        return True, [None] * data_points
    if healthy_index == -1 and long_lived:
        return True, metric_values[-data_points:]
    if healthy_index == -1 and not long_lived:
        return False, []
    if len(metric_values) - healthy_index <= data_points:
        return True, metric_values[healthy_index:]
    return True, metric_values[-data_points:]


def determine_health(name, metric_values, data_points, unhealthy_threshold, consecutive_threshold):
    unhealthy = 0
    consecutive = 0
    max_consecutive = 0
    for value in metric_values:
        if value is None or value == UNHEALTHY_METRIC_VALUE:
            unhealthy += 1
            consecutive += 1
        else:
            consecutive = 0
        max_consecutive = max(max_consecutive, consecutive)

    logging.info("%s: %d unhealthy samples, %d consecutive", name, unhealthy, max_consecutive)

    if unhealthy >= unhealthy_threshold and len(metric_values) >= data_points:
        return False
    if max_consecutive >= consecutive_threshold:
        return False
    return True


def terminate_instances(cred, sub_id, rg, doomed, total_instances, terminate_enabled,
                        max_percent, policy):
    """Terminate at most max_percent of the fleet (minimum one) and restore each scale set's
    capacity afterwards, because deleting an instance decrements the desired count."""
    if not doomed:
        logging.info("No instances to terminate on this iteration")
        return []

    epoch = datetime.datetime.min.replace(tzinfo=datetime.timezone.utc)
    reverse = policy == TERMINATION_POLICY_NEWEST
    doomed = sorted(doomed, key=lambda i: i.get("time_created") or epoch, reverse=reverse)

    allowed = max(int(total_instances * max_percent), 1)
    logging.info("Unhealthy instances: %d; permitted terminations this iteration: %d",
                 len(doomed), allowed)

    if not terminate_enabled:
        logging.warning(
            "Health remediation is disabled (TERMINATE_UNHEALTHY_INSTANCES=false). "
            "%d unhealthy connector(s) detected and NOT terminated: %s",
            len(doomed), [i["name"] for i in doomed])
        return []

    capacity_before = {}
    terminated = []
    for instance in doomed[:allowed]:
        vmss = instance.get("vmss_name")
        if not vmss:
            logging.warning("%s has no scale set membership; skipping termination", instance["name"])
            continue
        if vmss not in capacity_before:
            try:
                cfg = arm_get(cred, vmss_path(sub_id, rg, vmss), COMPUTE_API)
                capacity_before[vmss] = (cfg.get("sku") or {}).get("capacity")
            except Exception as exc:
                logging.error("Could not read capacity for %s: %s", vmss, exc)
                capacity_before[vmss] = None
        try:
            logging.warning("Terminating unhealthy instance %s in %s", instance["name"], vmss)
            arm_post(cred, f"{vmss_path(sub_id, rg, vmss)}/delete", COMPUTE_API,
                     body={"instanceIds": [instance["name"]]})
            terminated.append(instance)
        except Exception as exc:
            logging.error("Failed to terminate %s: %s", instance["name"], exc)

    if terminated:
        for vmss, previous in capacity_before.items():
            if previous is None:
                continue
            # Wait for the decrement to actually land. Deleting an instance lowers the scale set's
            # desired count asynchronously; a fixed sleep that expires first reads the capacity as
            # unchanged, skips the restore, and lets the decrement land afterwards, leaving the
            # set permanently one instance short for every termination.
            deadline = time.monotonic() + VMSS_CAPACITY_POLL_TIMEOUT_SEC
            current = None
            observed_drop = False
            while time.monotonic() < deadline:
                time.sleep(VMSS_CAPACITY_POLL_INTERVAL_SEC)
                try:
                    cfg = arm_get(cred, vmss_path(sub_id, rg, vmss), COMPUTE_API)
                    current = (cfg.get("sku") or {}).get("capacity")
                except Exception as exc:
                    logging.error("Could not read capacity for %s: %s", vmss, exc)
                    continue
                if current is not None and current < previous:
                    observed_drop = True
                    break

            if not observed_drop:
                logging.warning(
                    "%s capacity still %s after %ds; the delete may not have decremented it yet. "
                    "Not restoring, because writing %s now could overwrite a concurrent autoscale "
                    "decision. The next pass re-evaluates.",
                    vmss, current, VMSS_CAPACITY_POLL_TIMEOUT_SEC, previous)
                continue

            try:
                logging.info("Restoring %s capacity %s -> %s after termination",
                             vmss, current, previous)
                arm_patch(cred, vmss_path(sub_id, rg, vmss), COMPUTE_API,
                          {"sku": {"capacity": previous}})
            except Exception as exc:
                logging.error("Could not restore capacity for %s: %s", vmss, exc)

    return terminated


def fleet_verdict_is_credible(doomed, no_data, instances, suspicion_ratio):
    """Fail-safe on the destructive path, mirroring the one run_resource_sync applies before it
    prunes the portal.

    Connectors fail independently. A verdict against most of the fleet in a single 60-second pass
    is far more likely to mean the health signal stopped arriving than that every connector broke
    at once, and the per-iteration termination cap does not protect against it: the cap has a
    floor of one instance and the timer runs every minute, so a persistent bad signal drains the
    fleet an instance at a time while replacements sit inside their grace period.

    Returns True when the verdict should be acted on, False when it should be reported and
    nothing terminated. FLEET_SUSPICION_RATIO=1 disables the ratio guard; the no-data guard
    stays on regardless, because terminating on an absence of evidence is never intended.
    """
    total = len(instances)
    if not doomed or total == 0:
        return True

    ratio = len(doomed) / total

    # Every condemned instance reached that verdict with no metric samples whatsoever. That is a
    # statement about the metric pipeline, not about the connectors.
    if no_data and len(no_data) == len(doomed):
        logging.error(
            "Refusing to terminate: all %d condemned instance(s) were judged on an absence of "
            "metric data rather than on unhealthy samples. Check that the connector identity "
            "still holds Monitoring Metrics Publisher and that the %s namespace is receiving "
            "%s. No instance was terminated.",
            len(doomed), CC_METRIC_NAMESPACE, CC_HEALTH_METRIC)
        return False

    if total > 1 and suspicion_ratio < 1 and ratio >= suspicion_ratio:
        logging.error(
            "Refusing to terminate: %d of %d instances (%.0f%%) evaluated unhealthy in one pass, "
            "at or above the %.0f%% fail-safe threshold. A fleet-wide verdict is more often a "
            "fault in the health signal than simultaneous connector failure. Investigate the %s "
            "namespace and the function's Reader access, then lower FLEET_SUSPICION_RATIO, or set "
            "it to 1 to disable this guard entirely. No instance was terminated.",
            len(doomed), total, ratio * 100, suspicion_ratio * 100, CC_METRIC_NAMESPACE)
        return False

    return True


def run_health_monitor():
    sub_id = subscription_id()
    rg = resource_group()
    names = vmss_names()
    prefix = _setting("CC_COMPUTER_PREFIX", default="")

    if not sub_id or not rg:
        logging.error("Missing required settings: subscription and resource group")
        return

    data_points = _int_setting("HC_DATA_POINTS", default=DEFAULT_HC_DATA_POINTS)
    unhealthy_threshold = _int_setting("HC_UNHEALTHY_THRESHOLD",
                                       default=DEFAULT_HC_UNHEALTHY_THRESHOLD)
    consecutive_threshold = _int_setting("HC_CONSECUTIVE_UNHEALTHY_THRESHOLD",
                                         default=DEFAULT_HC_CONSECUTIVE_UNHEALTHY_THRESHOLD)
    grace_minutes = _int_setting("GRACE_PERIOD_TIME_MIN", default=DEFAULT_GRACE_PERIOD_TIME_MIN)
    max_percent = _float_setting("MAX_TERMINATION_PERCENT",
                                 default=DEFAULT_MAX_TERMINATION_PERCENT)
    terminate_enabled = _bool_setting("TERMINATE_UNHEALTHY_INSTANCES", default=True)
    suspicion_ratio = _float_setting("FLEET_SUSPICION_RATIO",
                                     default=DEFAULT_FLEET_SUSPICION_RATIO)
    if not 0 < suspicion_ratio <= 1:
        logging.warning("FLEET_SUSPICION_RATIO %s is out of range (0 < r <= 1); using %s",
                        suspicion_ratio, DEFAULT_FLEET_SUSPICION_RATIO)
        suspicion_ratio = DEFAULT_FLEET_SUSPICION_RATIO
    policy = _setting("TERMINATION_POLICY", default=TERMINATION_POLICY_OLDEST).lower()
    if policy != TERMINATION_POLICY_NEWEST:
        policy = TERMINATION_POLICY_OLDEST

    cred = _credential()
    try:
        instances = discover_instances(cred, sub_id, rg, names, standalone_prefix=prefix)
    except Exception as exc:
        logging.error("Failed to enumerate connector instances: %s", exc)
        return

    if not instances:
        logging.info("No connector instances found; nothing to evaluate")
        return

    doomed = []
    no_data = []
    for instance in instances:
        name = instance["name"]
        try:
            if instance.get("provisioning_state") == "Failed":
                logging.warning("%s is in a Failed provisioning state; marking for termination",
                                name)
                doomed.append(instance)
                continue

            metric_values = query_health_metrics(cred, sub_id, rg, name)
            # A query that succeeds and returns nothing is evidence about the metric pipeline,
            # not about the connector. It is still evaluated below, but it is counted so the
            # fail-safe can tell "the fleet is sick" from "we cannot see the fleet".
            had_samples = any(value is not None for value in metric_values)

            evaluate, values = check_grace_period(instance, metric_values, data_points,
                                                  grace_minutes)
            if not evaluate:
                logging.info("%s is inside its %d minute grace period; skipping",
                             name, grace_minutes)
                continue

            if not determine_health(name, values, data_points, unhealthy_threshold,
                                    consecutive_threshold):
                if had_samples:
                    logging.warning("%s evaluated unhealthy", name)
                else:
                    logging.warning("%s evaluated unhealthy with no metric samples at all", name)
                    no_data.append(instance)
                doomed.append(instance)
            else:
                logging.info("%s healthy", name)
        except Exception as exc:
            logging.error("Failed to evaluate health of %s: %s", name, exc)
            continue

    if not fleet_verdict_is_credible(doomed, no_data, instances, suspicion_ratio):
        return

    terminate_instances(cred, sub_id, rg, doomed, len(instances), terminate_enabled,
                        max_percent, policy)


# --------------------------------------------------------------------------------------
# Zscaler portal API
# --------------------------------------------------------------------------------------

def obfuscate_api_key(seed):
    """Zscaler's legacy API key obfuscation, unchanged from the reference implementation.

    The indices below reach 11, so a seed shorter than 12 characters raises IndexError from
    inside the loop. Check up front instead, so a mis-stored secret names itself rather than
    surfacing as an opaque index error during portal authentication.
    """
    if seed is None or len(seed) < 12:
        raise ValueError(
            f"Cloud Connector API key must be at least 12 characters; got {len(seed or '')}. "
            "Check the 'api-key' secret in Key Vault.")
    now = int(time.time() * 1000)
    n = str(now)[-6:]
    r = str(int(n) >> 1).zfill(6)
    key = ""
    for i in range(len(n)):
        key += seed[int(n[i])]
    for j in range(len(r)):
        key += seed[int(r[j]) + 2]
    return now, key


class PortalClient:
    """Session-scoped client for the Cloud Connector portal API."""

    def __init__(self, base_url, api_key, username, password, verify=True):
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.verify = verify
        timestamp, obfuscated = obfuscate_api_key(api_key)
        resp = self.session.post(
            f"{self.base_url}/api/v1/auth",
            json={"apiKey": obfuscated, "username": username, "password": password,
                  "timestamp": timestamp},
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            timeout=30,
        )
        resp.raise_for_status()

    def get_group_by_name(self, group_name):
        resp = self.session.get(f"{self.base_url}/api/v1/ecgroup",
                                params={"name": group_name}, timeout=30)
        resp.raise_for_status()
        return resp.json()

    def list_groups(self):
        resp = self.session.get(f"{self.base_url}/api/v1/ecgroup", timeout=30)
        resp.raise_for_status()
        return resp.json()

    def remove_vm(self, group_id, vm_id):
        # Read before delete, mirroring the reference client's ordering.
        self.session.get(f"{self.base_url}/api/v1/ecgroup/{group_id}/vm/{vm_id}", timeout=30)
        resp = self.session.delete(f"{self.base_url}/api/v1/ecgroup/{group_id}/vm/{vm_id}",
                                   timeout=30)
        resp.raise_for_status()
        return True

    def activate(self):
        """Portal edits stay staged until activation. Without this call a removal is
        accepted and never takes effect."""
        self.session.get(f"{self.base_url}/api/v1/ecAdminActivateStatus", timeout=30)
        resp = self.session.put(f"{self.base_url}/api/v1/ecAdminActivateStatus/activate",
                                timeout=30)
        resp.raise_for_status()
        return True

    def logout(self):
        try:
            self.session.delete(f"{self.base_url}/api/v1/auth", timeout=30)
        except Exception as exc:
            logging.warning("Portal logout failed: %s", exc)


def ec_group_name(vnet_name, rg, sub_id, location, vmss_name):
    """Group naming contract used by the connector at registration time."""
    return f"{vnet_name}-{rg}-{sub_id}-{location}-{vmss_name}"


def vmss_vnet_and_location(cred, sub_id, rg, vmss_name):
    cfg = arm_get(cred, vmss_path(sub_id, rg, vmss_name), COMPUTE_API)
    props = cfg.get("properties") or {}
    nics = (((props.get("virtualMachineProfile") or {}).get("networkProfile") or {})
            .get("networkInterfaceConfigurations") or [])
    vnet = ""
    if nics:
        ip_configs = (nics[0].get("properties") or {}).get("ipConfigurations") or []
        if ip_configs:
            subnet_id = ((ip_configs[0].get("properties") or {}).get("subnet") or {}).get("id", "")
            if subnet_id:
                vnet = subnet_id.split("/")[-3]
    return vnet, cfg.get("location", "")


def extract_group_members(group):
    """Pull registered connectors out of an EC group payload.

    The portal returns them under ecVMs, each carrying the Azure VM UUID in
    metaConfig.uuid. Alternate key names are tolerated and logged, so an API change surfaces
    as a warning rather than as a sync that silently prunes nothing.
    """
    members = group.get("ecVMs")
    if members is None:
        for alt in ("ecVms", "ecInstances", "cloudConnectors"):
            if group.get(alt) is not None:
                logging.warning("EC group members found under '%s' rather than 'ecVMs'; "
                                "portal API shape may have changed", alt)
                members = group.get(alt)
                break
    if members is None:
        logging.warning("EC group %s exposes no recognised member collection. Keys present: %s",
                        group.get("id"), sorted(group.keys()))
        return []

    out = []
    group_id = group.get("id")
    for item in members:
        item_id = item.get("id")
        uuid = ((item.get("metaConfig") or {}).get("uuid") or "").strip()
        if not item_id:
            continue
        if not uuid:
            logging.warning("Connector %s has no uuid in metaConfig; cannot correlate to Azure",
                            item_id)
            continue
        if uuid == str(item_id):
            logging.warning("Connector %s reports its uuid as its own id; cannot correlate",
                            item_id)
            continue
        out.append({"vm_id": item_id, "uuid": uuid.lower(), "group_id": group_id,
                    "name": item.get("name") or item.get("hostName") or str(item_id)})
    return out


def portal_members_for_group(client, cred, sub_id, rg, vmss_name):
    vnet, location = vmss_vnet_and_location(cred, sub_id, rg, vmss_name)
    if not vnet or not location:
        logging.error("Could not derive VNet or location for %s; skipping group lookup",
                      vmss_name)
        return []

    name = ec_group_name(vnet, rg, sub_id, location, vmss_name)
    logging.info("EC group name: %s", name)

    groups = client.get_group_by_name(name)
    if isinstance(groups, dict):
        groups = [groups]
    if not groups:
        # Fall back to an unfiltered listing in case the portal ignores the name filter.
        logging.warning("Name-filtered EC group query returned nothing; listing all groups")
        all_groups = client.list_groups()
        if isinstance(all_groups, dict):
            all_groups = [all_groups]
        groups = [g for g in all_groups if g.get("name") == name]
        if not groups:
            logging.error("EC group %s does not exist in the portal", name)
            return []

    return extract_group_members(groups[0])


# --------------------------------------------------------------------------------------
# Resource synchronisation
# --------------------------------------------------------------------------------------

def run_resource_sync():
    sub_id = subscription_id()
    rg = resource_group()
    names = vmss_names()
    prefix = _setting("CC_COMPUTER_PREFIX", default="")
    vault_url = _setting("VAULT_URL", "AZURE_VAULT_URL")
    base_url = ""
    cc_url = _setting("CC_URL")
    if cc_url:
        parsed = urllib.parse.urlparse(cc_url if "://" in cc_url else f"https://{cc_url}")
        base_url = f"https://{parsed.netloc}"
    if not base_url:
        base_url = _setting("ZS_CC_BASE_URL")

    if not all([sub_id, rg, base_url, vault_url]):
        logging.error("Missing required app settings; aborting sync")
        return

    if not names:
        logging.info("No scale sets configured; portal reconciliation is scale set scoped "
                     "and has nothing to compare against")
        return

    cred = _credential()
    try:
        instances = discover_instances(cred, sub_id, rg, names, standalone_prefix=prefix)
    except Exception as exc:
        logging.error("Failed to enumerate connector instances: %s", exc)
        return

    logging.info("Live instances: %d", len(instances))

    # An empty discovery result is indistinguishable from a transient ARM or RBAC visibility
    # gap. Pruning on it would deregister every connector in the deployment while the
    # instances are still running, so refuse and retry on the next tick.
    if not instances:
        logging.error(
            "Zero live instances discovered; refusing to prune portal connectors (fail-safe). "
            "If the deployment was genuinely torn down, remove portal entries via "
            "Remove-ZsDeployment or the Zscaler console.")
        return

    live_uuids = {i["vm_id"] for i in instances if i["vm_id"]}
    if not live_uuids:
        logging.error("No Azure VM UUIDs resolved; refusing to prune portal connectors "
                      "(fail-safe)")
        return

    try:
        api_key = get_secret(cred, vault_url, API_KEY_SECRET_NAME)
        username = get_secret(cred, vault_url, USERNAME_SECRET_NAME)
        password = get_secret(cred, vault_url, PASSWORD_SECRET_NAME)
    except Exception as exc:
        logging.error("Failed to read credentials from Key Vault: %s", exc)
        return

    try:
        client = PortalClient(base_url, api_key, username, password, verify=certificate_verify())
    except Exception as exc:
        logging.error("Failed to authenticate to the Cloud Connector portal: %s", exc)
        return

    try:
        removed = 0
        for vmss_name in names:
            try:
                members = portal_members_for_group(client, cred, sub_id, rg, vmss_name)
            except Exception as exc:
                logging.error("Failed to read EC group for %s: %s", vmss_name, exc)
                continue

            logging.info("%s: %d connectors registered in portal", vmss_name, len(members))
            stale = [m for m in members if m["uuid"] not in live_uuids]
            if not stale:
                logging.info("%s: portal and scale set are in sync", vmss_name)
                continue

            logging.warning("%s: removing %d stale connectors: %s",
                            vmss_name, len(stale), [m["name"] for m in stale])
            for member in stale:
                try:
                    client.remove_vm(member["group_id"], member["vm_id"])
                    logging.info("Removed stale connector %s (uuid %s)",
                                 member["name"], member["uuid"])
                    removed += 1
                except Exception as exc:
                    logging.error("Failed to remove %s: %s", member["name"], exc)

        # Activation commits every staged removal in one pass.
        if removed:
            try:
                client.activate()
                logging.info("Activated portal configuration after %d removal(s)", removed)
            except Exception as exc:
                logging.error(
                    "STATE: %d connector(s) were deleted but activation failed: %s. The "
                    "removals remain staged until an admin activates them.", removed, exc)
    finally:
        client.logout()

    logging.info("CC sync complete")


# --------------------------------------------------------------------------------------
# Timers
# --------------------------------------------------------------------------------------

@app.timer_trigger(
    schedule=os.environ.get("HEALTH_CRON", "0 * * * * *"),
    arg_name="timer", run_on_startup=False, use_monitor=True
)
def healthMonitor(timer: func.TimerRequest) -> None:
    logging.info("Health monitoring triggered")
    try:
        run_health_monitor()
    except Exception as exc:
        logging.error("Failed to monitor health: %s", exc)


@app.timer_trigger(
    # Cadence is driven by the SYNC_CRON app setting, computed by the deployment module from
    # SyncIntervalMinutes in the JSON config.
    schedule=os.environ.get("SYNC_CRON", "0 */30 * * * *"),
    arg_name="timer", run_on_startup=False, use_monitor=True
)
def synchronizeCloudResources(timer: func.TimerRequest) -> None:
    logging.info("Resource synchronisation triggered")
    try:
        run_resource_sync()
    except Exception as exc:
        logging.error("Failed to synchronize resources: %s", exc)
