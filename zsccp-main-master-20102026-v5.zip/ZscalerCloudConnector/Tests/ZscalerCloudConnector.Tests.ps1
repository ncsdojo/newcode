#Requires -Modules Pester

BeforeAll {
    $ModulePath = Split-Path $PSScriptRoot -Parent
    Import-Module $ModulePath -Force

    function New-TestSecureString { param([string]$Plain) return (ConvertTo-SecureString $Plain -AsPlainText -Force) }
}

Describe 'Module Structure' {
    It 'Imports without error' {
        { Import-Module (Split-Path $PSScriptRoot -Parent) -Force } | Should -Not -Throw
    }

    It 'Exports expected function count' {
        $cmds = Get-Command -Module ZscalerCloudConnector
        $cmds.Count | Should -BeGreaterOrEqual 32
    }

    It 'Has matching PSD1 and PSM1 exports' {
        $root    = Split-Path $PSScriptRoot -Parent
        $psd     = Import-PowerShellDataFile "$root/ZscalerCloudConnector.psd1"
        $psdList = $psd.FunctionsToExport | Sort-Object
        $cmds    = (Get-Command -Module ZscalerCloudConnector).Name | Sort-Object
        $psdList | Should -Be $cmds
    }

    It 'Every exported function has OutputType' {
        $cmds = Get-Command -Module ZscalerCloudConnector
        foreach ($cmd in $cmds) {
            $cmd.OutputType | Should -Not -BeNullOrEmpty -Because "$($cmd.Name) needs OutputType"
        }
    }

    It 'Every Public .ps1 has comment-based help' {
        $root = Split-Path $PSScriptRoot -Parent
        $publicFiles = Get-ChildItem "$root/Public" -Filter '*.ps1'
        foreach ($f in $publicFiles) {
            $content = Get-Content $f.FullName -Raw
            $content | Should -Match '\.SYNOPSIS' -Because "$($f.Name) needs help"
        }
    }
}

Describe 'Parameter Validation' {
    Context 'Connect-ZscalerAzure' {
        It 'Rejects invalid TenantId format' {
            { Connect-ZscalerAzure -TenantId 'not-a-guid' -SubscriptionId '00000000-0000-0000-0000-000000000000' `
                -ClientId 'cid' -ClientSecret (New-TestSecureString 'x') -Location 'eastus2' } | Should -Throw
        }

        It 'Rejects invalid SubscriptionId format' {
            { Connect-ZscalerAzure -TenantId '00000000-0000-0000-0000-000000000000' -SubscriptionId 'bad' `
                -ClientId 'cid' -ClientSecret (New-TestSecureString 'x') -Location 'eastus2' } | Should -Throw
        }

        It 'Rejects invalid Environment value' {
            { Connect-ZscalerAzure -TenantId '00000000-0000-0000-0000-000000000000' -SubscriptionId '00000000-0000-0000-0000-000000000000' `
                -ClientId 'cid' -ClientSecret (New-TestSecureString 'x') -Location 'eastus2' -Environment 'invalid' } | Should -Throw
        }
    }

    Context 'Connect-ZscalerCloud' {
        It 'Rejects invalid Cloud value' {
            { Connect-ZscalerCloud -Cloud 'invalid' -ApiKey (New-TestSecureString 'x') -Username 'u' -Password (New-TestSecureString 'p') } | Should -Throw
        }

        It 'Accepts all valid cloud names' {
            foreach ($cloud in @('zscaler','zscalerone','zscalertwo','zscalerthree','zscloud','zscalergov')) {
                $paramSet = (Get-Command Connect-ZscalerCloud).Parameters['Cloud'].Attributes | Where-Object { $_ -is [System.Management.Automation.ValidateSetAttribute] }
                $paramSet.ValidValues | Should -Contain $cloud
            }
        }
    }

    Context 'New-ZsCloudConnector' {
        It 'Rejects CC count above 20' {
            $param = (Get-Command New-ZsCloudConnector).Parameters['Count']
            $range = $param.Attributes | Where-Object { $_ -is [System.Management.Automation.ValidateRangeAttribute] }
            $range.MaxRange | Should -Be 20
        }

        It 'Rejects probe port 0' {
            $param = (Get-Command New-ZsCloudConnector).Parameters['HttpProbePort']
            $range = $param.Attributes | Where-Object { $_ -is [System.Management.Automation.ValidateRangeAttribute] }
            $range.MinRange | Should -Be 1
        }
    }

    Context 'New-ZsLoadBalancer' {
        It 'Validates Distribution parameter values' {
            $param = (Get-Command New-ZsLoadBalancer).Parameters['Distribution']
            $set = $param.Attributes | Where-Object { $_ -is [System.Management.Automation.ValidateSetAttribute] }
            $set.ValidValues | Should -Contain 'Default'
            $set.ValidValues | Should -Contain 'SourceIP'
        }
    }

    Context 'New-ZsNetworkFoundation' {
        It 'Validates CIDR format on AddressSpace' {
            $call = { param($a) New-ZsNetworkFoundation -AddressSpace $a -SubnetPlan ([PSCustomObject]@{}) -MgmtNsgId 'x' -ServiceNsgId 'y' -WhatIf }
            foreach ($bad in '300.0.0.0/16', '10.0.0.0/40', '10.0.1.5/23', '10.0.0.0') {
                { & $call $bad } | Should -Throw -ExceptionType ([System.Management.Automation.ParameterBindingException]) -Because "$bad is not a network CIDR"
            }
            # A network CIDR binds; the cmdlet then stops on the missing Azure session instead.
            $err = $null
            try { & $call '10.157.108.0/23' } catch { $err = $_ }
            $err.Exception | Should -Not -BeOfType ([System.Management.Automation.ParameterBindingException])
        }
    }

    Context 'New-ZsPrivateNetwork' {
        It 'Validates IP format on NextHopIp' {
            $param = (Get-Command New-ZsPrivateNetwork).Parameters['NextHopIp']
            $pattern = $param.Attributes | Where-Object { $_ -is [System.Management.Automation.ValidatePatternAttribute] }
            $pattern | Should -Not -BeNullOrEmpty
        }
    }

    Context 'New-ZsCloudConnectorVmss' {
        It 'Has correct instance range limits' {
            # One EC group per scale set, and Zscaler takes at most 16 connectors in a group.
            $cmd = Get-Command New-ZsCloudConnectorVmss
            foreach ($n in 'MinInstances','MaxInstances','DesiredInstances','ScheduledMinInstances') {
                $range = $cmd.Parameters[$n].Attributes | Where-Object { $_ -is [System.Management.Automation.ValidateRangeAttribute] }
                $range.MinRange | Should -Be 1 -Because $n
                $range.MaxRange | Should -Be 16 -Because $n
            }
        }

        It 'Validates ASP SKU values' {
            $param = (Get-Command New-ZsCloudConnectorVmss).Parameters['AppServicePlanSku']
            $set = $param.Attributes | Where-Object { $_ -is [System.Management.Automation.ValidateSetAttribute] }
            $set.ValidValues | Should -Contain 'P0v3'
            $set.ValidValues | Should -Contain 'Y1' -Because 'it is accepted so that it can be refused by name (ZsPlanNeedsPublicStorage)'
            $set.ValidValues | Should -Contain 'EP1'
            $set.ValidValues | Should -Not -Contain 'FC1'
        }
    }

    Context 'New-ZsDeployment' {
        It 'Validates Topology parameter' {
            $param = (Get-Command New-ZsDeployment).Parameters['Topology']
            $set = $param.Attributes | Where-Object { $_ -is [System.Management.Automation.ValidateSetAttribute] }
            $set.ValidValues | Should -Contain 'VM'
            $set.ValidValues | Should -Contain 'VMSS'
        }
    }
}

Describe 'ShouldProcess Coverage' {
    It 'All mutation functions support ShouldProcess' {
        $mutations = @(
            'New-ZsResourceGroup','New-ZsNetworkSecurity','New-ZsNetworkFoundation'
            'New-ZsPublicNetwork','New-ZsPrivateNetwork','New-ZsVnetPeering'
            'New-ZsIdentity','New-ZsKeyVault','New-ZsLoadBalancer'
            'Approve-ZsMarketplaceTerms','New-ZsCloudConnector','New-ZsCloudConnectorVmss'
            'New-ZsDnsResolver','New-ZsProvisioningUrl','New-ZsDeployment'
            'Remove-ZsDeployment'
            'Set-ZsDefenderPlans','New-ZsDiagnostics'
            'New-ZsLifecycleFunctionApp','New-ZsMonitorAlerts','New-ZsMonitorPrivateLink'
        )
        foreach ($fn in $mutations) {
            $cmd = Get-Command $fn -Module ZscalerCloudConnector
            $cmd.Parameters.ContainsKey('WhatIf') | Should -BeTrue -Because "$fn must support -WhatIf"
            $cmd.Parameters.ContainsKey('Confirm') | Should -BeTrue -Because "$fn must support -Confirm"
        }
    }

    It 'Remove-ZsDeployment has High ConfirmImpact' {
        $cmd = Get-Command Remove-ZsDeployment
        $binding = $cmd.ScriptBlock.Attributes | Where-Object { $_ -is [System.Management.Automation.CmdletBindingAttribute] }
        $binding.ConfirmImpact | Should -Be 'High'
    }
}

Describe 'SecureString Handling' {
    It 'Connect-ZscalerAzure accepts string or SecureString for ClientSecret' {
        $param = (Get-Command Connect-ZscalerAzure).Parameters['ClientSecret']
        $param.ParameterType | Should -Be ([object])
    }

    It 'Connect-ZscalerCloud accepts string or SecureString for ApiKey and Password' {
        $apiParam  = (Get-Command Connect-ZscalerCloud).Parameters['ApiKey']
        $passParam = (Get-Command Connect-ZscalerCloud).Parameters['Password']
        $apiParam.ParameterType  | Should -Be ([object])
        $passParam.ParameterType | Should -Be ([object])
    }

    It 'New-ZsKeyVault requires SecureString for ApiKey and AdminPassword' {
        $apiParam  = (Get-Command New-ZsKeyVault).Parameters['ApiKey']
        $passParam = (Get-Command New-ZsKeyVault).Parameters['AdminPassword']
        $apiParam.ParameterType  | Should -Be ([SecureString])
        $passParam.ParameterType | Should -Be ([SecureString])
    }

    It 'ConvertFrom-ZsSecureString round-trips correctly' {
        InModuleScope ZscalerCloudConnector {
            $original = 'T3st!P@ssw0rd_Compl3x'
            $secure   = ConvertTo-SecureString $original -AsPlainText -Force
            $result   = ConvertFrom-ZsSecureString -Secure $secure
            $result | Should -BeExactly $original
        }
    }
}

Describe 'Configuration' {
    Context 'ZscalerDefaults' {
        It 'Has all required API versions' {
            $root = Split-Path $PSScriptRoot -Parent
            $used = @(Get-ChildItem (Join-Path $root 'Public'), (Join-Path $root 'Private') -Filter *.ps1 |
                Select-String -Pattern '\$script:ApiVersions\.(\w+)' -AllMatches | ForEach-Object { $_.Matches } |
                ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique)
            $used.Count | Should -BeGreaterThan 20
            InModuleScope ZscalerCloudConnector -Parameters @{ Used = $used } {
                param($Used)
                foreach ($key in $Used) { $script:ApiVersions.Contains($key) | Should -BeTrue -Because "the module reads ApiVersions.$key" }
            }
        }

        It 'Has correct marketplace image publisher' {
            InModuleScope ZscalerCloudConnector {
                $script:CcImage.Publisher | Should -Be 'zscaler1579058425289'
            }
        }

        It 'Has all 6 Zscaler cloud endpoints' {
            InModuleScope ZscalerCloudConnector {
                $script:ZscalerClouds.Count | Should -Be 6
                foreach ($cloud in @('zscaler','zscalerone','zscalertwo','zscalerthree','zscloud','zscalergov')) {
                    $script:ZscalerClouds.ContainsKey($cloud) | Should -BeTrue
                    $script:ZscalerClouds[$cloud].Connector | Should -Match '^https://'
                }
            }
        }

        It 'Has all 10 ZPA domains' {
            InModuleScope ZscalerCloudConnector {
                $script:ZpaDomains.Count | Should -Be 10
                $script:ZpaDomains | Should -Contain '*.zscaler.net'
                $script:ZpaDomains | Should -Contain '*.private.zscaler.com'
            }
        }
    }

    Context 'New-ZsDeploymentConfig' {
        It 'Returns valid greenfield config with defaults' {
            $cfg = New-ZsDeploymentConfig -Mode Greenfield
            $cfg.Mode              | Should -Be 'Greenfield'
            $cfg.VnetAddressSpace  | Should -Be '10.1.0.0/16'
            $cfg.CcCount           | Should -Be 2
            $cfg.HttpProbePort     | Should -Be 50000
            $cfg.BringYourOwn      | Should -Not -BeNullOrEmpty
        }

        It 'Throws on brownfield without Interactive or ConfigFile' {
            { New-ZsDeploymentConfig -Mode Brownfield } | Should -Throw
        }
    }
}

Describe 'Key Obfuscation' {
    It 'Produces a 12-character obfuscated key' {
        InModuleScope ZscalerCloudConnector {
            $result = Get-ZscalerObfuscatedKey -ApiKey 'AbCdEfGhIjKlMnOpQrStUv'
            $result.ObfuscatedKey.Length | Should -Be 12
            $result.Timestamp | Should -BeGreaterThan 0
        }
    }

    It 'Rejects keys shorter than 12 characters' {
        InModuleScope ZscalerCloudConnector {
            { Get-ZscalerObfuscatedKey -ApiKey 'short' } | Should -Throw
        }
    }

    It 'Handles keys where timestamp digits exceed key length via modulo' {
        InModuleScope ZscalerCloudConnector {
            $result = Get-ZscalerObfuscatedKey -ApiKey 'ABCDEFGHIJKL'
            $result.ObfuscatedKey.Length | Should -Be 12
        }
    }
}

Describe 'Session Management' {
    It 'Assert-ZsConnected throws when no session exists' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = $null
            { Assert-ZsConnected } | Should -Throw -ErrorId 'ZsNotConnected'
        }
    }

    It 'Assert-ZsConnected -Cloud throws when Zscaler not connected' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{ ZscalerConnected = $false }
            { Assert-ZsConnected -Cloud } | Should -Throw -ErrorId 'ZsCloudNotConnected'
        }
    }

    It 'Disconnect clears all sensitive fields' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{
                Connected = $true; DeploymentId = 'test'
                Tokens = @{ 'https://management.azure.com' = @{ AccessToken='secret' } }
                ClientSecretSS = (ConvertTo-SecureString 'x' -AsPlainText -Force)
                ZscalerApiKey = 'key'; ZscalerPassword = 'pass'
                ZscalerSession = 'sess'; LogBuffer = [System.Collections.Generic.List[string]]::new()
            }
        }
        Disconnect-ZscalerAzure
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession | Should -BeNullOrEmpty
        }
    }
}

Describe 'NSG Rules' {
    It 'Management NSG has deny-all inbound as lowest priority' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{ Connected=$true; Environment='test'; Location='eastus2'; DeploymentId='test'; DeployedAt='now'; ResourceGroupName='rg' }
        }
        $cmd = Get-Command New-ZsNetworkSecurity
        $cmd | Should -Not -BeNullOrEmpty
    }

    It 'Service NSG denies internet inbound explicitly' {
        $root = Split-Path $PSScriptRoot -Parent
        $content = Get-Content "$root/Public/New-ZsNetworkSecurity.ps1" -Raw
        $content | Should -Match 'DenyInternetIn'
        $content | Should -Not -Match "sourceAddressPrefix='\*'.*direction='Inbound'.*access='Allow'"
    }

    It 'SSH source is configurable' {
        $param = (Get-Command New-ZsNetworkSecurity).Parameters['SshSourceCidr']
        $param | Should -Not -BeNullOrEmpty
        $param.Attributes | Where-Object { $_ -is [System.Management.Automation.ValidateNotNullOrEmptyAttribute] } | Should -Not -BeNullOrEmpty
    }
}

Describe 'NIC Ordering' {
    It 'CC VM function creates management NIC as primary' {
        $root = Split-Path $PSScriptRoot -Parent
        $content = Get-Content "$root/Public/New-ZsCloudConnector.ps1" -Raw
        $nicProfile = [regex]::Match($content, 'networkProfile=@\{ networkInterfaces=@\(([\s\S]*?)\) \}').Groups[1].Value
        $entries = @([regex]::Matches($nicProfile, '@\{ id=\$(\w+)\.id; properties=@\{ primary=\$(\w+)') | ForEach-Object { "$($_.Groups[1].Value)=$($_.Groups[2].Value)" })
        $entries | Should -Be @('mObj=true','sObj=false')
    }

    It 'Service NIC has IP forwarding enabled' {
        $root = Split-Path $PSScriptRoot -Parent
        $vm = Get-Content "$root/Public/New-ZsCloudConnector.ps1" -Raw
        $vm | Should -Match 'name=''ipconfig-svc''[\s\S]{0,300}loadBalancerBackendAddressPools=@\(@\{id=\$LbBackendId\}\)[\s\S]{0,80}enableIPForwarding=\$true'
        $vm | Should -Match 'name=''ipconfig-mgmt''[\s\S]{0,200}enableIPForwarding=\$false'
        $vmss = Get-Content "$root/Public/New-ZsCloudConnectorVmss.ps1" -Raw
        $vmss | Should -Match 'name=''nic-svc''; properties=@\{\s+primary=\$false; enableIPForwarding=\$true'
        $vmss | Should -Match 'name=''nic-mgmt''; properties=@\{\s+primary=\$true; enableIPForwarding=\$false'
    }

    It 'VMSS preserves NIC ordering' {
        $root = Split-Path $PSScriptRoot -Parent
        $content = Get-Content "$root/Public/New-ZsCloudConnectorVmss.ps1" -Raw
        $mgmtNic = $content.IndexOf("name='nic-mgmt'")
        $svcNic  = $content.IndexOf("name='nic-svc'")
        $mgmtNic | Should -BeLessThan $svcNic -Because 'Management NIC must be defined first'
    }
}

Describe 'VMSS Topology' {
    It 'VMSS function uses Flexible orchestration' {
        $root = Split-Path $PSScriptRoot -Parent
        $content = Get-Content "$root/Public/New-ZsCloudConnectorVmss.ps1" -Raw
        $content | Should -Match "orchestrationMode='Flexible'"
    }

    It 'VMSS function creates autoscale policy' {
        $root = Split-Path $PSScriptRoot -Parent
        $content = Get-Content "$root/Public/New-ZsCloudConnectorVmss.ps1" -Raw
        $content | Should -Match 'autoscaleSettings'
        $content | Should -Match "metricName='smedge_metrics'"
        $content | Should -Match 'smedge_cpu_utilization'
    }

    It 'Function App uses Python runtime' {
        $root = Split-Path $PSScriptRoot -Parent
        $content = Get-Content "$root/Public/New-ZsLifecycleFunctionApp.ps1" -Raw
        $content | Should -Match "linuxFxVersion='Python"
        $content | Should -Match "FUNCTIONS_WORKER_RUNTIME.*python"
    }

    It 'Orchestrator supports Topology parameter for VMSS' {
        $param = (Get-Command New-ZsDeployment).Parameters['Topology']
        $set = $param.Attributes | Where-Object { $_ -is [System.Management.Automation.ValidateSetAttribute] }
        $set.ValidValues | Should -Contain 'VMSS'
    }
}

Describe 'Idempotency' {
    It 'All create functions use Test-ArmResource pattern' {
        $root = Split-Path $PSScriptRoot -Parent
        $idempotentFunctions = @(
            'New-ZsResourceGroup','New-ZsNetworkFoundation','New-ZsPublicNetwork'
            'New-ZsLoadBalancer','New-ZsIdentity','New-ZsKeyVault'
            'New-ZsCloudConnector','New-ZsCloudConnectorVmss','New-ZsVnetPeering'
            'Approve-ZsMarketplaceTerms'
        )
        foreach ($fn in $idempotentFunctions) {
            $content = Get-Content "$root/Public/$fn.ps1" -Raw
            $content | Should -Match 'Test-ArmResource' -Because "$fn must check existence before creation"
        }
    }
}

Describe 'Error Handling' {
    It 'New-ZsErrorRecord sets ErrorDetails to the message' {
        InModuleScope ZscalerCloudConnector {
            $r = New-ZsErrorRecord -Message 'clean line' -ErrorId 'ZsX'
            $r.ErrorDetails.Message | Should -Be 'clean line'
            $r.FullyQualifiedErrorId | Should -Match 'ZsX'
        }
    }

    It 'Write-ZsError produces a clean message via ErrorDetails' {
        InModuleScope ZscalerCloudConnector {
            $caught = $null
            try { Write-ZsError -Message 'friendly text' -ErrorId 'ZsTest' }
            catch { $caught = $_ }
            $caught | Should -Not -BeNullOrEmpty
            $caught.ErrorDetails.Message | Should -Be 'friendly text'
            $caught.FullyQualifiedErrorId | Should -Match 'ZsTest'
        }
    }

    It 'New-ZsDeployment gives a friendly error when not connected' {
        InModuleScope ZscalerCloudConnector { $script:ZsSession = $null }
        $caught = $null
        try { New-ZsDeployment -Topology VM } catch { $caught = $_ }
        $caught.ErrorDetails.Message | Should -Match 'Connect-ZscalerAzure'
    }

    It 'Write-ZsLog does not throw when no session exists' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = $null
            { Write-ZsLog 'test message' } | Should -Not -Throw
        }
    }

    It 'ARM request wrapper constructs proper ErrorRecord' {
        $root = Split-Path $PSScriptRoot -Parent
        $content = Get-Content "$root/Private/Invoke-ArmRequest.ps1" -Raw
        $content | Should -Match 'System\.Management\.Automation\.ErrorRecord'
        $content | Should -Match 'HttpRequestException'
    }

    It 'ARM retry only applies to transient status codes' {
        $root = Split-Path $PSScriptRoot -Parent
        $content = Get-Content "$root/Private/Invoke-ArmRequest.ps1" -Raw
        $content | Should -Match '429.*500.*502.*503.*504'
    }
}

Describe 'Function Package' {
    It 'Function source directory exists with required files' {
        $root = Split-Path $PSScriptRoot -Parent
        $faDir = Join-Path $root 'FunctionApp'
        Test-Path (Join-Path $faDir 'function_app.py') | Should -BeTrue
        Test-Path (Join-Path $faDir 'host.json')        | Should -BeTrue
        Test-Path (Join-Path $faDir 'requirements.txt') | Should -BeTrue
    }

    It 'Dependencies are pinned with minimum safe versions' {
        $root = Split-Path $PSScriptRoot -Parent
        $reqs = Get-Content (Join-Path $root 'FunctionApp/requirements.txt') -Raw
        $reqs | Should -Match 'requests>=2\.32\.4'    -Because 'requests <2.32.4 has CVE-2024-47081 (.netrc credential leak) and CVE-2024-35195 (SSL verify bypass)'
        $reqs | Should -Match 'azure-identity>=1\.25'  -Because 'azure-identity should be pinned to a stable release'
        $reqs | Should -Match 'azure-functions>=1\.24'  -Because 'azure-functions should be pinned to a stable release'
    }

    It 'Dependencies have major-version ceilings to prevent breaking changes' {
        $root = Split-Path $PSScriptRoot -Parent
        $reqs = Get-Content (Join-Path $root 'FunctionApp/requirements.txt') -Raw
        $reqs | Should -Match '<2\.0\.0'  -Because 'azure-identity 2.x would be a breaking change'
        $reqs | Should -Match '<3\.0\.0'  -Because 'requests 3.x would be a breaking change'
    }

    It 'Function code has a timer trigger on 30-minute schedule' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'FunctionApp/function_app.py') -Raw
        $code | Should -Match 'timer_trigger'
        $code | Should -Match '0 \*/30 \* \* \* \*'
    }

    It 'Function reconciles VMSS instances against portal connectors' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'FunctionApp/function_app.py') -Raw
        $code | Should -Match 'def discover_instances\('
        $code | Should -Match 'def portal_members_for_group\('
        $code | Should -Match 'stale = \[m for m in members if m\["uuid"\] not in live_uuids\]'
    }

    It 'host.json declares v4 extension bundle' {
        $root = Split-Path $PSScriptRoot -Parent
        $hostJson = Get-Content (Join-Path $root 'FunctionApp/host.json') -Raw | ConvertFrom-Json
        $hostJson.version | Should -Be '2.0'
        $hostJson.extensionBundle.version | Should -Match '4'
    }

    It 'Package delivery is keyless: an Entra-authenticated zip deploy, no account keys, no SAS, no storage' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Private/Publish-ZsFunctionPackage.ps1') -Raw
        $code | Should -Not -Match 'listKeys'
        $code | Should -Not -Match 'SharedKey'
        $code | Should -Not -Match 'Set-ZsBlob'
        $code | Should -Not -Match 'WEBSITE_RUN_FROM_PACKAGE_BLOB_MI_RESOURCE_ID'
        $code | Should -Match 'api/zipdeploy\?isAsync=true'
        $code | Should -Match 'Bearer \$\(Get-ArmToken\)'
    }

    It 'Publish helper honors a pre-vendored .python_packages tree' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Private/Publish-ZsFunctionPackage.ps1') -Raw
        $code | Should -Match '_python_packages'
        $code | Should -Match 'python_packages\.zip'
        $code | Should -Match 'pre-vendored'
    }

    It 'Package build and deploy functions exist' {
        & (Get-Module ZscalerCloudConnector) {
            foreach ($n in 'Build-ZsFunctionPackage','Publish-ZsPackageToScm','Test-ZsVendorPackage') {
                Get-Command $n -ErrorAction SilentlyContinue | Should -Not -BeNullOrEmpty -Because $n
            }
        }
    }
}

Describe 'Security Hardening' {
    It 'New-ZsKeyVault exposes purge protection switch' {
        $p = (Get-Command New-ZsKeyVault).Parameters['EnablePurgeProtection']
        $p.ParameterType | Should -Be ([switch])
    }

    It 'Purge protection defaults to enabled with an orchestrator opt-out' {
        $root = Split-Path $PSScriptRoot -Parent
        (Get-Content (Join-Path $root 'Public/New-ZsKeyVault.ps1') -Raw) | Should -Match '\[switch\]\$EnablePurgeProtection = \$true'
        (Get-Command New-ZsDeployment).Parameters.ContainsKey('DisablePurgeProtection') | Should -BeTrue
    }

    It 'New-ZsKeyVault soft-delete retention defaults to 90 and is bounded' {
        $p = (Get-Command New-ZsKeyVault).Parameters['SoftDeleteRetentionInDays']
        $r = $p.Attributes | Where-Object { $_ -is [System.Management.Automation.ValidateRangeAttribute] }
        $r.MinRange | Should -Be 7
        $r.MaxRange | Should -Be 90
    }

    It 'Key Vault is private from the create request and takes its secrets through Resource Manager' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsKeyVault.ps1') -Raw
        $code | Should -Match "publicNetworkAccess='Disabled'"
        $code | Should -Match "defaultAction='Deny'"
        $code | Should -Not -Match "publicNetworkAccess='Enabled'"
        $code | Should -Match '/secrets/\$name`\?api-version'
        $code | Should -Not -Match 'Invoke-VaultRequest'
    }

    It 'The deployer gets no Key Vault data-plane role or access policy' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsKeyVault.ps1') -Raw
        $code | Should -Not -Match 'DeployerSpObjectId'
        $code | Should -Not -Match 'KvSecretsOfficer'
        (Get-Command New-ZsKeyVault).Parameters.ContainsKey('DeployerIpCidr') | Should -BeFalse
    }

    It 'CC and VMSS functions expose EncryptAtHost switch' {
        (Get-Command New-ZsCloudConnector).Parameters['EncryptAtHost'].ParameterType | Should -Be ([switch])
        (Get-Command New-ZsCloudConnectorVmss).Parameters['EncryptAtHost'].ParameterType | Should -Be ([switch])
    }

    It 'Encryption-at-host capability probe exists' {
        InModuleScope ZscalerCloudConnector {
            Get-Command Test-EncryptionAtHostSupport | Should -Not -BeNullOrEmpty
        }
    }

    It 'Remove-ZsDeployment skips purge on protected vaults' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/Remove-ZsDeployment.ps1') -Raw
        $code | Should -Match 'purgeProtected'
        $code | Should -Match 'RetainedVaults'
    }

    It 'Set-ZsDefenderPlans defaults to the four relevant plans' {
        $p = (Get-Command Set-ZsDefenderPlans).Parameters['Plans']
        $s = $p.Attributes | Where-Object { $_ -is [System.Management.Automation.ValidateSetAttribute] }
        $s.ValidValues | Should -Contain 'KeyVaults'
        $s.ValidValues | Should -Contain 'StorageAccounts'
        $s.ValidValues | Should -Contain 'VirtualMachines'
        $s.ValidValues | Should -Contain 'Arm'
    }

    It 'New-ZsDiagnostics supports ShouldProcess and flow logs' {
        $cmd = Get-Command New-ZsDiagnostics
        $cmd.Parameters.ContainsKey('WhatIf') | Should -BeTrue
        $cmd.Parameters.ContainsKey('EnableVnetFlowLogs') | Should -BeTrue
    }

    It 'Orchestrator exposes the hardening switches' {
        $cmd = Get-Command New-ZsDeployment
        foreach ($sw in @('EnablePurgeProtection','EncryptAtHost','EnableDefender','EnableDiagnostics')) {
            $cmd.Parameters.ContainsKey($sw) | Should -BeTrue -Because "orchestrator needs -$sw"
        }
    }
}

Describe 'Capacity Planning' {
    It 'Derives peak from monthly volume and computes a connector count' {
        $plan = Get-ZsCapacityPlan -MonthlyTB 115 -PerConnectorMbps 500
        $plan.DerivedAvgGbps   | Should -BeGreaterThan 0.3
        $plan.DerivedAvgGbps   | Should -BeLessThan 0.4
        $plan.PlannedPeakGbps  | Should -BeGreaterThan 1.0
        $plan.RecommendedCount | Should -BeGreaterThan 2
        $plan.AutoscaleMax     | Should -Be ($plan.RecommendedCount * 2)
    }

    It 'Accepts a direct peak Gbps target' {
        $plan = Get-ZsCapacityPlan -PeakGbps 2.0 -PerConnectorMbps 500
        $plan.PlannedPeakGbps | Should -Be 2.0
    }

    It 'Connector count scales inversely with per-connector throughput' {
        $low  = Get-ZsCapacityPlan -MonthlyTB 115 -PerConnectorMbps 250
        $high = Get-ZsCapacityPlan -MonthlyTB 115 -PerConnectorMbps 500
        $low.ConnectorsForPeak | Should -BeGreaterThan $high.ConnectorsForPeak
    }

    It 'Throws when no target supplied' {
        { Get-ZsCapacityPlan } | Should -Throw
    }

    It 'Enforces a minimum of two connectors' {
        $plan = Get-ZsCapacityPlan -PeakGbps 0.05 -PerConnectorMbps 500
        $plan.RecommendedCount | Should -BeGreaterOrEqual 2
    }
}

Describe 'Explicit Subnet Resolution and Bastion' {
    It 'Resolves a complete explicit plan' {
        InModuleScope ZscalerCloudConnector {
            $supplied = @{
                'AzureBastionSubnet'='10.1.0.0/26';'snet-zscc-mgmt'='10.1.0.64/27';'snet-zscc-service'='10.1.0.96/27'
                'snet-zscc-lb'='10.1.0.192/27';'snet-zscc-workload'='10.1.1.0/24'
                'snet-zscc-funcapp'='10.1.2.0/26'
            }
            $plan = Resolve-ZsSubnetPlan -VnetCidr '10.1.0.0/16' -SubnetCidrs $supplied -Zones @('1','2') -EnableBastion
            $plan.'snet-zscc-mgmt' | Should -Be '10.1.0.64/27'
        }
    }

    It 'Throws naming every missing subnet at once' {
        InModuleScope ZscalerCloudConnector {
            $supplied = @{ 'snet-zscc-mgmt'='10.1.0.64/27' }
            $err = $null
            try { Resolve-ZsSubnetPlan -VnetCidr '10.1.0.0/16' -SubnetCidrs $supplied -Zones @('1','2') -EnableBastion } catch { $err = $_.Exception.Message }
            $err | Should -Match 'AzureBastionSubnet'
            $err | Should -Match 'snet-zscc-service'
            $err | Should -Not -Match 'snet-zscc-mgmt' -Because 'its CIDR was supplied'
            $err | Should -Match 'snet-zscc-lb'
            $err | Should -Match 'snet-zscc-workload'
            $err | Should -Match 'snet-zscc-funcapp'
        }
    }

    It 'Rejects a subnet outside the VNet' {
        InModuleScope ZscalerCloudConnector {
            $supplied = @{
                'snet-zscc-mgmt'='10.9.0.0/27';'snet-zscc-service'='10.1.0.96/27'
                'snet-zscc-lb'='10.1.0.192/27';'snet-zscc-workload'='10.1.1.0/24'
                'snet-zscc-funcapp'='10.1.2.0/26'
            }
            { Resolve-ZsSubnetPlan -VnetCidr '10.1.0.0/16' -SubnetCidrs $supplied -Zones @('1','2') } | Should -Throw
        }
    }

    It 'Rejects overlapping subnets' {
        InModuleScope ZscalerCloudConnector {
            $supplied = @{
                'snet-zscc-mgmt'='10.1.0.0/27';'snet-zscc-service'='10.1.0.0/27'
                'snet-zscc-lb'='10.1.0.192/27';'snet-zscc-workload'='10.1.1.0/24'
                'snet-zscc-funcapp'='10.1.2.0/26'
            }
            { Resolve-ZsSubnetPlan -VnetCidr '10.1.0.0/16' -SubnetCidrs $supplied -Zones @('1','2') } | Should -Throw
        }
    }

    It 'Rejects an invalid CIDR' {
        InModuleScope ZscalerCloudConnector {
            Test-ZsCidr -Cidr '10.1.0.0/33' | Should -BeFalse
            Test-ZsCidr -Cidr '999.1.0.0/24' | Should -BeFalse
            Test-ZsCidr -Cidr '10.1.0.0/24' | Should -BeTrue
            # Azure rejects a prefix carrying host bits, so preflight must too.
            Test-ZsCidr -Cidr '10.1.0.5/24' | Should -BeFalse
            Test-ZsCidr -Cidr '0.0.0.0/0'   | Should -BeTrue
        }
    }

    It 'Enforces Bastion /26 minimum' {
        InModuleScope ZscalerCloudConnector {
            $supplied = @{
                'AzureBastionSubnet'='10.1.0.0/27';'snet-zscc-mgmt'='10.1.0.64/27';'snet-zscc-service'='10.1.0.96/27'
                'snet-zscc-lb'='10.1.0.192/27';'snet-zscc-workload'='10.1.1.0/24'
                'snet-zscc-funcapp'='10.1.2.0/26'
            }
            { Resolve-ZsSubnetPlan -VnetCidr '10.1.0.0/16' -SubnetCidrs $supplied -Zones @('1','2') -EnableBastion } | Should -Throw
        }
    }

    It 'IP conversion round-trips' {
        InModuleScope ZscalerCloudConnector {
            ConvertFrom-ZsIpUInt -Value (ConvertTo-ZsIpUInt -IpAddress '10.1.0.64') | Should -Be '10.1.0.64'
            # Above Int32.MaxValue: the case where a 32-bit accumulator would have overflowed.
            ConvertTo-ZsIpUInt -IpAddress '192.168.1.1'   | Should -Be 3232235777
            ConvertTo-ZsIpUInt -IpAddress '255.255.255.255' | Should -Be 4294967295
            ConvertFrom-ZsIpUInt -Value (ConvertTo-ZsIpUInt -IpAddress '192.168.1.1') | Should -Be '192.168.1.1'
            # A /0 spans 2^32 addresses; bounds must not overflow computing it.
            (Get-ZsCidrBounds -Cidr '0.0.0.0/0').End | Should -Be 4294967295
        }
    }

    It 'New-ZsBastion defaults to Premium private-only and supports ShouldProcess' {
        $cmd = Get-Command New-ZsBastion
        $cmd.Parameters.ContainsKey('WhatIf') | Should -BeTrue
        ($cmd.ScriptBlock.Ast.Body.ParamBlock.Parameters | Where-Object { $_.Name.VariablePath.UserPath -eq 'Sku' }).DefaultValue.SafeGetValue() | Should -Be 'Premium'
        $root = Split-Path $PSScriptRoot -Parent
        (Get-Content (Join-Path $root 'Public/New-ZsBastion.ps1') -Raw) | Should -Match 'enablePrivateOnlyBastion=\(-not \$public\)'
    }

    It 'Orchestrator exposes NoBastion and explicit subnet CIDR params' {
        $cmd = Get-Command New-ZsDeployment
        $cmd.Parameters['NoBastion'].ParameterType | Should -Be ([switch])
        # Shared subnet CIDRs remain as runtime params; connector CIDRs come from config (MgmtSubnetCidr/ServiceSubnetCidr).
        foreach ($p in @('WorkloadSubnetCidr','LbSubnetCidr','BastionSubnetCidr')) {
            $cmd.Parameters.ContainsKey($p) | Should -BeTrue -Because "orchestrator needs -$p"
        }
        # The orchestrator takes no flat per-connector CIDR parameters; those are per-zone.
        $cmd.Parameters.ContainsKey('MgmtSubnetCidr') | Should -BeFalse
        $cmd.Parameters.ContainsKey('ServiceSubnetCidr') | Should -BeFalse
    }

    It 'Network foundation requires an explicit SubnetPlan' {
        $cmd = Get-Command New-ZsNetworkFoundation
        $cmd.Parameters['SubnetPlan'].Attributes.Mandatory | Should -Contain $true
        $cmd.Parameters.ContainsKey('MgmtSubnetCidr') | Should -BeFalse
    }
}

Describe 'Artifact Location and Log Naming' {
    It 'Dated log name uses <name><dd><mm><yyyy>.log format' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{ ArtifactRoot = $TestDrive }
            $path = Initialize-ZsLogging -Name 'ZscalerCloudConnector'
            $expected = "ZscalerCloudConnector$(Get-Date -Format 'ddMMyyyy').log"
            (Split-Path $path -Leaf) | Should -Be $expected
        }
    }

    It 'Same-day re-init appends rather than overwrites' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{ ArtifactRoot = $TestDrive }
            $p1 = Initialize-ZsLogging
            $p2 = Initialize-ZsLogging
            $p1 | Should -Be $p2
            (Get-Content $p1).Count | Should -BeGreaterThan 1
        }
    }

    It 'Artifact root defaults to the runtime directory' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{ ArtifactRoot = '' }
            (Get-ZsArtifactRoot) | Should -Be (Get-Location).Path
        }
    }

    It 'Artifact root honors an explicit session override' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{ ArtifactRoot = $TestDrive }
            (Get-ZsArtifactRoot) | Should -Be $TestDrive
        }
    }

    It 'Artifact path joins under the root' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{ ArtifactRoot = $TestDrive }
            (Get-ZsArtifactPath -FileName 'x.json') | Should -Be (Join-Path $TestDrive 'x.json')
        }
    }

    It 'Connect exposes an ArtifactRoot parameter' {
        (Get-Command Connect-ZscalerAzure).Parameters.ContainsKey('ArtifactRoot') | Should -BeTrue
    }
}

Describe 'Identity Least Privilege' {
    It 'New-ZsIdentity defaults to LeastPrivilege role mode' {
        (Get-Command New-ZsIdentity).Parameters['RoleMode'].Attributes.Where{$_ -is [System.Management.Automation.ValidateSetAttribute]}.ValidValues | Should -Contain 'LeastPrivilege'
        $def = (Get-Command New-ZsIdentity).Parameters['RoleMode']
        $def | Should -Not -BeNullOrEmpty
    }

    It 'New-ZsIdentity supports skipping role assignment' {
        (Get-Command New-ZsIdentity).Parameters.ContainsKey('SkipRoleAssignment') | Should -BeTrue
    }

    It 'RoleMode None is offered for out-of-band assignment' {
        $vals = (Get-Command New-ZsIdentity).Parameters['RoleMode'].Attributes.Where{$_ -is [System.Management.Automation.ValidateSetAttribute]}.ValidValues
        $vals | Should -Contain 'None'
        $vals | Should -Contain 'NetworkContributor'
    }

    It 'Least-privilege action set is read-only network actions' {
        InModuleScope ZscalerCloudConnector {
            $script:CcIdentityActions | Should -Contain 'Microsoft.Network/networkInterfaces/read'
            ($script:CcIdentityActions | Where-Object { $_ -match '/write|/delete|/action' }) | Should -BeNullOrEmpty
        }
    }

    It 'Orchestrator exposes IdentityRoleMode' {
        (Get-Command New-ZsDeployment).Parameters.ContainsKey('IdentityRoleMode') | Should -BeTrue
    }

    It 'Custom role resolver is internal, not exported' {
        $exported = (Get-Module ZscalerCloudConnector).ExportedFunctions.Keys
        $exported | Should -Not -Contain 'Resolve-ZsCcRoleDefinitionId'
    }
}

Describe 'Output Path Resolution' {
    It 'Appends a filename when given a directory' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{ ArtifactRoot = $TestDrive }
            $r = Resolve-ZsOutputFile -Path $TestDrive -DefaultFileName 'zscc-config.json'
            (Split-Path $r -Leaf) | Should -Be 'zscc-config.json'
            (Split-Path $r -Parent) | Should -Be $TestDrive
        }
    }

    It 'Uses the artifact root when path is empty' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{ ArtifactRoot = $TestDrive }
            $r = Resolve-ZsOutputFile -Path '' -DefaultFileName 'zscc-config.json'
            $r | Should -Be (Join-Path $TestDrive 'zscc-config.json')
        }
    }

    It 'Preserves an explicit full file path' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{ ArtifactRoot = $TestDrive }
            $full = Join-Path $TestDrive 'explicit.json'
            Resolve-ZsOutputFile -Path $full -DefaultFileName 'zscc-config.json' | Should -Be $full
        }
    }

    It 'Treats a trailing-separator path as a directory' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{ ArtifactRoot = $TestDrive }
            $r = Resolve-ZsOutputFile -Path "$TestDrive/" -DefaultFileName 'zscc-config.json'
            (Split-Path $r -Leaf) | Should -Be 'zscc-config.json'
        }
    }
}

Describe 'Manifest System' {
    BeforeEach {
        # The manifest carries the connected session's deployment id; earlier tests leave other
        # session shapes behind.
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{ DeploymentId='dep-manifest'; LogFile=''; LogBuffer=[System.Collections.Generic.List[string]]::new() }
        }
    }

    It 'Manifest initializes with correct schema' {
        InModuleScope ZscalerCloudConnector {
            Initialize-ZsManifest -SubscriptionId 'sub' -ResourceGroupName 'rg' -Location 'loc'
            $m = Get-ZsManifest
            $m.SchemaVersion | Should -Be '3.0'
            $m.DeploymentId | Should -Be 'dep-manifest'
            $m.Status | Should -Be 'InProgress'
            $m.Resources | Should -Not -BeNullOrEmpty
        }
    }

    It 'Resources accumulate correctly' {
        InModuleScope ZscalerCloudConnector {
            Initialize-ZsManifest -SubscriptionId 'sub' -ResourceGroupName 'rg' -Location 'loc'
            Add-ZsManifestResource -Type 'TestType' -Name 'test1' -ResourceId '/test/1'
            Add-ZsManifestResource -Type 'TestType' -Name 'test2' -ResourceId '/test/2'
            $m = Get-ZsManifest
            $m.Resources['TestType'].Count | Should -Be 2
        }
    }

    It 'Outputs accumulate correctly' {
        InModuleScope ZscalerCloudConnector {
            Initialize-ZsManifest -SubscriptionId 'sub' -ResourceGroupName 'rg' -Location 'loc'
            Add-ZsManifestOutput -Key 'ip' -Value '10.0.0.1'
            $m = Get-ZsManifest
            $m.Outputs['ip'] | Should -Be '10.0.0.1'
        }
    }

    It 'Complete sets final status and timestamp' {
        InModuleScope ZscalerCloudConnector {
            Initialize-ZsManifest -SubscriptionId 'sub' -ResourceGroupName 'rg' -Location 'loc'
            Complete-ZsManifest -Status 'Succeeded'
            $m = Get-ZsManifest
            $m.Status | Should -Be 'Succeeded'
            $m.CompletedAt | Should -Not -BeNullOrEmpty
        }
    }

    It 'Export writes valid JSON' {
        InModuleScope ZscalerCloudConnector {
            Initialize-ZsManifest -SubscriptionId 'sub' -ResourceGroupName 'rg' -Location 'loc'
            Add-ZsManifestResource -Type 'Test' -Name 'r1' -ResourceId '/r1'
            Complete-ZsManifest -Status 'Succeeded'
            $path = Join-Path $TestDrive 'manifest.json'
            Export-ZsManifest -Path $path
            $json = Get-Content $path -Raw
            { $json | ConvertFrom-Json } | Should -Not -Throw
        }
    }
}

Describe 'Zscaler Session Lifecycle' {
    It 'Disconnect-ZscalerCloud is exported' {
        Get-Command -Module ZscalerCloudConnector -Name Disconnect-ZscalerCloud | Should -Not -BeNullOrEmpty
    }

    It 'Disconnect-ZscalerCloud has OutputType' {
        (Get-Command Disconnect-ZscalerCloud).OutputType | Should -Not -BeNullOrEmpty
    }

    It 'Disconnect-ZscalerCloud warns when no session exists' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{ ZscalerConnected = $false }
        }
        $result = Disconnect-ZscalerCloud 3>&1
        $result.Disconnected | Should -BeFalse
    }

    It 'Disconnect-ZscalerCloud clears all credential fields' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{
                ZscalerConnected  = $true
                ZscalerApiUrl     = 'https://connector.zscalertwo.net'
                ZscalerSession    = 'mock-session'
                ZscalerApiKeySS   = (ConvertTo-SecureString 'testkey12345' -AsPlainText -Force)
                ZscalerPasswordSS = (ConvertTo-SecureString 'testpass' -AsPlainText -Force)
                ZscalerUsername   = 'admin@test.net'
                LogFile           = ''; LogBuffer = [System.Collections.Generic.List[string]]::new()
            }
        }
        $result = Disconnect-ZscalerCloud
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession.ZscalerSession    | Should -BeNullOrEmpty
            $script:ZsSession.ZscalerApiKeySS   | Should -BeNullOrEmpty
            $script:ZsSession.ZscalerPasswordSS | Should -BeNullOrEmpty
            $script:ZsSession.ZscalerConnected   | Should -BeFalse
        }
    }
}

Describe 'Zscaler Request Wrapper' {
    It 'Invoke-ZscalerRequest exists as an internal function' {
        InModuleScope ZscalerCloudConnector {
            Get-Command Invoke-ZscalerRequest | Should -Not -BeNullOrEmpty
        }
    }

    It 'Invoke-ZscalerRequest is not exported' {
        $exported = (Get-Module ZscalerCloudConnector).ExportedFunctions.Keys
        $exported | Should -Not -Contain 'Invoke-ZscalerRequest'
    }

    It 'Invoke-ZscalerRequest accepts Get, Post, Put, Delete methods' {
        InModuleScope ZscalerCloudConnector {
            $param = (Get-Command Invoke-ZscalerRequest).Parameters['Method']
            $set = $param.Attributes | Where-Object { $_ -is [System.Management.Automation.ValidateSetAttribute] }
            $set.ValidValues | Should -Contain 'Get'
            $set.ValidValues | Should -Contain 'Post'
            $set.ValidValues | Should -Contain 'Delete'
        }
    }

    It 'Provisioning URL uses the wrapper, not raw Invoke-RestMethod' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsProvisioningUrl.ps1') -Raw
        $code | Should -Match 'Invoke-ZscalerRequest'
        $code | Should -Not -Match 'Invoke-RestMethod'
    }

    It 'Test-ZsDeployment uses the wrapper for Zscaler API calls' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/Test-ZsDeployment.ps1') -Raw
        $code | Should -Match 'Invoke-ZscalerRequest'
        $code | Should -Not -Match 'Invoke-RestMethod.*WebSession'
    }

    It 'Re-authenticates on 401 via Connect-ZscalerLegacy' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Private/Invoke-ZscalerRequest.ps1') -Raw
        $code | Should -Match '401'
        $code | Should -Match 'Connect-ZscalerLegacy'
        $code | Should -Match 're-authenticating'
    }

    It 'Nulls plaintext credentials in a finally block' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Private/Invoke-ZscalerRequest.ps1') -Raw
        $code | Should -Match 'finally'
        $code | Should -Match '\$plainKey\s*=\s*\$null'
        $code | Should -Match '\$plainPass\s*=\s*\$null'
    }

    It 'Retries exactly once on 401, not infinitely' {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{ ZscalerSession=[Microsoft.PowerShell.Commands.WebRequestSession]::new(); ZscalerApiUrl='https://connector.zscaler.net'
                ZscalerUsername='admin@example.com'; ZscalerApiKeySS=(ConvertTo-SecureString 'k' -AsPlainText -Force)
                ZscalerPasswordSS=(ConvertTo-SecureString 'p' -AsPlainText -Force); LogFile=''; LogBuffer=[System.Collections.Generic.List[string]]::new() }
            Mock Invoke-RestMethod { throw [Microsoft.PowerShell.Commands.HttpResponseException]::new('Unauthorized', [System.Net.Http.HttpResponseMessage]::new([System.Net.HttpStatusCode]::Unauthorized)) }
            Mock Connect-ZscalerLegacy { [Microsoft.PowerShell.Commands.WebRequestSession]::new() }
            Mock Start-Sleep { }
            { Invoke-ZscalerRequest -Uri 'https://connector.zscaler.net/api/v1/ecgroup' } | Should -Throw
            Should -Invoke Connect-ZscalerLegacy -Times 1 -Exactly
            Should -Invoke Invoke-RestMethod -Times 2 -Exactly
            Should -Invoke Start-Sleep -Times 0 -Exactly
        }
    }
}

Describe 'Cloud Endpoint Configuration' {
    It 'Auth endpoint uses /api/v1/auth, not /authenticatedSession' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Private/Get-ZscalerToken.ps1') -Raw
        $code | Should -Match '/api/v1/auth'
        $code | Should -Not -Match '/api/v1/authenticatedSession'
    }

    It 'Connect-ZscalerCloud authenticates to the Connector endpoint' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/Connect-ZscalerCloud.ps1') -Raw
        $code | Should -Match '\$ep\.Connector'
        $code | Should -Not -Match 'Connect-ZscalerLegacy.*\$ep\.Api'
    }

    It 'ZscalerApiUrl is set to Connector, not Api' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/Connect-ZscalerCloud.ps1') -Raw
        $code | Should -Match 'ZscalerApiUrl\s*=\s*\$ep\.Connector'
    }

    It 'Logout sends DELETE to /api/v1/auth' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/Disconnect-ZscalerCloud.ps1') -Raw
        $code | Should -Match "api/v1/auth.*Method Delete"
    }
}

Describe 'VMSS UserData' {
    It 'Sets userData at the virtualMachineProfile level' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsCloudConnectorVmss.ps1') -Raw
        $code | Should -Match "virtualMachineProfile=@\{[^}]*userData="
    }

    It 'Retains customData in osProfile as fallback' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsCloudConnectorVmss.ps1') -Raw
        $code | Should -Match "osProfile=@\{[^}]*customData="
    }

    It 'Both userData and customData reference the same base64 variable' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsCloudConnectorVmss.ps1') -Raw
        ([regex]::Matches($code, 'userData=\$ud64')).Count   | Should -BeGreaterOrEqual 1
        ([regex]::Matches($code, 'customData=\$ud64')).Count | Should -BeGreaterOrEqual 1
    }

    It 'Cloud-init payload uses ZSCALER INI format with required keys' {
        InModuleScope ZscalerCloudConnector {
            $ud = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String(
                (Get-ZsConnectorUserData -ProvisioningUrl 'https://connector.zscaler.net/api/v1/provUrl?name=p' -KeyVaultUri 'https://kv.vault.azure.net' -HttpProbePort 50000 -IdentityClientId 'cid')))
            $lines = $ud -split "`n"
            $lines[0] | Should -Be '[ZSCALER]'
            $lines | Should -Contain 'CC_URL=connector.zscaler.net/api/v1/provUrl?name=p'
            $lines | Should -Contain 'AZURE_VAULT_URL=https://kv.vault.azure.net'
            $lines | Should -Contain 'HTTP_PROBE_PORT=50000'
            $lines | Should -Contain 'AZURE_MANAGED_IDENTITY_CLIENT_ID=cid'
            $lines[-1] | Should -Be 'FIPS_ENABLED=False'
        }
        $root = Split-Path $PSScriptRoot -Parent
        (Get-Content (Join-Path $root 'Public/New-ZsCloudConnectorVmss.ps1') -Raw) | Should -Match 'Get-ZsConnectorUserData'
        (Get-Content (Join-Path $root 'Public/New-ZsCloudConnector.ps1') -Raw) | Should -Match 'Get-ZsConnectorUserData'
    }
}

Describe 'ARM Retry-After' {
    It 'Invoke-ArmRequest reads the Retry-After response header' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Private/Invoke-ArmRequest.ps1') -Raw
        $code | Should -Match 'Retry-After'
    }

    It 'Uses whichever delay is larger: server or computed' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Private/Invoke-ArmRequest.ps1') -Raw
        $code | Should -Match 'Math.*Max'
    }

    It 'Falls back to exponential backoff when header is absent' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Private/Invoke-ArmRequest.ps1') -Raw
        $code | Should -Match 'Pow\(2'
        $code | Should -Match 'catch \{ \}'
    }

    It 'Still retries on the full set of transient status codes' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Private/Invoke-ArmRequest.ps1') -Raw
        $code | Should -Match '429.*500.*502.*503.*504'
    }
}

Describe 'VMSS Result Branching' {
    It 'New-ZsDeployment branches on VMSS vs VM result shape' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw
        $code | Should -Match "if \(\`$Topology -eq 'VMSS'\)"
    }

    It 'VMSS path logs VmssName per zone' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw
        $code | Should -Match '\$cc\.VmssName'
        $code | Should -Match '\$cc\.Zone'
    }

    It 'VM path logs VmName with ServiceIp' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw
        $code | Should -Match '\$cc\.VmName'
        $code | Should -Match '\$cc\.ServiceIp'
    }

    It 'New-ZsCloudConnectorVmss returns object with Zones and VmssNames' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsCloudConnectorVmss.ps1') -Raw
        $code | Should -Match 'Zones=.*VmssNames='
    }
}

Describe 'Brownfield Route Table' {

    It 'Route table is created with LB frontend as next hop' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw
        $code | Should -Match 'New-ZsPrivateNetwork.*NextHopIp.*lb\.FrontendIp'
    }
}

Describe 'Route Table Subnet Association' {
    It 'New-ZsPrivateNetwork accepts WorkloadSubnetPath parameter' {
        $param = (Get-Command New-ZsPrivateNetwork).Parameters['WorkloadSubnetPath']
        $param | Should -Not -BeNullOrEmpty
    }

    It 'Defaults to snet-zscc-workload when WorkloadSubnetPath is empty' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsPrivateNetwork.ps1') -Raw
        $code | Should -Match ([regex]::Escape('if (-not $WorkloadSubnetPath) { $WorkloadSubnetPath = "$VnetPath/subnets/snet-zscc-workload" }'))
    }

    It 'Uses GET-merge-PUT to preserve existing subnet properties' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsPrivateNetwork.ps1') -Raw
        $code | Should -Match 'Invoke-ArmGet -Uri \$subnetUri'
        $code | Should -Match '\$existing\.properties \| Add-Member -NotePropertyName ''routeTable'''
        $code | Should -Match 'Invoke-ArmPut -Uri \$subnetUri -Body @\{ properties=\$props \}'
    }

    It 'Does not hardcode subnet name in the PUT URI' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsPrivateNetwork.ps1') -Raw
        $code | Should -Not -Match 'Invoke-ArmPut.*subnets/snet-zscc-workload'
        $code | Should -Match 'Invoke-ArmPut.*subnetUri'
    }

    It 'Orchestrator passes the resolved BYO workload subnet ID, bare, never endpoint-prefixed' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw
        # BYO no longer reads the raw config field here: names or IDs alike resolve through
        # Resolve-ZsExistingNetwork into the role-keyed map, so any subnet name works.
        $code | Should -Match "Subnets\['snet-zscc-workload'\]"
        $code | Should -Match 'WorkloadSubnetPath'
        # The old BYO branch prefixed the ARM endpoint onto a path Invoke-ArmRequest prefixes
        # again, producing a doubled https:// URL. Pin its absence.
        $code | Should -Not -Match 'Endpoints\.Arm.*WorkloadSubnetId'
        $code | Should -Not -Match 'wlSubnetPath = .*Endpoints\.Arm'
    }
}

Describe 'Export Consistency' {
    It 'PSD1 and PSM1 export lists are identical' {
        $root = Split-Path $PSScriptRoot -Parent
        $psd  = (Import-PowerShellDataFile "$root/ZscalerCloudConnector.psd1").FunctionsToExport | Sort-Object
        $psm1 = Get-Content "$root/ZscalerCloudConnector.psm1" -Raw
        $psmExports = [regex]::Matches($psm1, "'([A-Z][a-z]+-Zs\w+)'") | ForEach-Object { $_.Groups[1].Value } | Sort-Object
        $psd | Should -Be $psmExports
    }
}

Describe 'Scheduled Scaling' {
    It 'VMSS function accepts ScheduledScaling switch' {
        (Get-Command New-ZsCloudConnectorVmss).Parameters.ContainsKey('ScheduledScaling') | Should -BeTrue
    }

    It 'VMSS function accepts all scheduled scaling parameters' {
        $cmd = Get-Command New-ZsCloudConnectorVmss
        foreach ($p in @('ScheduledMinInstances','ScheduledDays','ScheduledStartHour','ScheduledEndHour','ScheduledTimezone')) {
            $cmd.Parameters.ContainsKey($p) | Should -BeTrue -Because "VMSS needs -$p"
        }
    }

    It 'Orchestrator exposes ScheduledScaling and passes it through' {
        $cmd = Get-Command New-ZsDeployment
        $cmd.Parameters.ContainsKey('ScheduledScaling') | Should -BeTrue
        $cmd.Parameters.ContainsKey('ScheduledMinInstances') | Should -BeTrue
        $cmd.Parameters.ContainsKey('ScheduledTimezone') | Should -BeTrue
    }

    It 'Autoscale body includes scheduled profile when enabled' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsCloudConnectorVmss.ps1') -Raw
        $code | Should -Match 'scheduled-profile'
        $code | Should -Match 'ScheduledScaling'
        $code | Should -Match 'recurrence'
        $code | Should -Match 'frequency.*Week'
    }

    It 'Default profile gets recurrence when scheduled scaling is on' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsCloudConnectorVmss.ps1') -Raw
        $code | Should -Match '\$defaultProfile\.recurrence'
        $code | Should -Match 'ScheduledEndHour'
    }

    It 'Defaults match Terraform: weekdays, 9am start, 5pm end, PST' {
        # Parameter metadata carries no default values; the declaration does.
        $params = (Get-Command New-ZsCloudConnectorVmss).ScriptBlock.Ast.Body.ParamBlock.Parameters
        $default = { param($n) ($params | Where-Object { $_.Name.VariablePath.UserPath -eq $n }).DefaultValue.SafeGetValue() }
        & $default 'ScheduledStartHour'      | Should -Be 9
        & $default 'ScheduledStartMinute'    | Should -Be 0
        & $default 'ScheduledEndHour'        | Should -Be 17
        & $default 'ScheduledEndMinute'      | Should -Be 0
        & $default 'ScheduledTimezone'       | Should -Be 'Pacific Standard Time'
        & $default 'ScheduledDays'           | Should -Be @('Monday','Tuesday','Wednesday','Thursday','Friday')
        & $default 'ScheduledMinInstances'   | Should -Be 1
        & $default 'MinInstances'            | Should -Be 2
        & $default 'MaxInstances'            | Should -Be 4
        & $default 'DesiredInstances'        | Should -Be 2
        & $default 'ScaleOutThreshold'       | Should -Be 70
        & $default 'ScaleInThreshold'        | Should -Be 30
        & $default 'ScaleOutCooldownMinutes' | Should -Be 5
        & $default 'ScaleInCooldownMinutes'  | Should -Be 10
    }
}

Describe 'State-Aware Drift Detection' {
    It 'Compare-ZsDeployment is exported' {
        Get-Command -Module ZscalerCloudConnector -Name Compare-ZsDeployment | Should -Not -BeNullOrEmpty
    }

    It 'Compare-ZsDeployment has OutputType' {
        (Get-Command Compare-ZsDeployment).OutputType | Should -Not -BeNullOrEmpty
    }

    It 'Requires ManifestPath parameter' {
        $param = (Get-Command Compare-ZsDeployment).Parameters['ManifestPath']
        $param | Should -Not -BeNullOrEmpty
        $param.Attributes.Mandatory | Should -Contain $true
    }

    It 'Supports -Detailed switch for property-level diff' {
        (Get-Command Compare-ZsDeployment).Parameters['Detailed'].ParameterType | Should -Be ([switch])
    }

    It 'Checks provisioningState, NSG rules, LB rules, route table, autoscale, IP forwarding' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/Compare-ZsDeployment.ps1') -Raw
        $code | Should -Match 'provisioningState'
        $code | Should -Match 'securityRules'
        $code | Should -Match 'loadBalancingRules'
        $code | Should -Match 'addressPrefix.*0\.0\.0\.0/0'
        $code | Should -Match 'enableIPForwarding'
        $code | Should -Match 'autoscale.*disabled'
    }

    It 'Returns structured result with OK, Drift, Missing, Errors counts' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/Compare-ZsDeployment.ps1') -Raw
        $code | Should -Match 'OK\s*=\s*\$ok'
        $code | Should -Match 'Drift\s*=\s*\$drift'
        $code | Should -Match 'Missing\s*=\s*\$missing'
        $code | Should -Match 'Errors\s*=\s*\$errors'
    }

    It 'Handles 404 as Missing, not as a crash' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/Compare-ZsDeployment.ps1') -Raw
        $code | Should -Match '404.*NotFound'
        $code | Should -Match "Status='Missing'"
    }
}

Describe 'Resource Locks and Autoscale Compatibility' {
    It 'Locks are applied per resource, not on the resource group' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw
        $code | Should -Not -Match 'Get-ZsRgPath\)\/providers\/Microsoft\.Authorization\/locks'
        $code | Should -Match '\$target\.Id\)\/providers\/Microsoft\.Authorization\/locks'
    }

    It 'VNet, Key Vault, LB, Identity, and Route Table are lock targets' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw
        $code | Should -Match "Label='VNet'"
        $code | Should -Match "Label='KeyVault'"
        $code | Should -Match "Label='LoadBalancer'"
        $code | Should -Match "Label='Identity'"
        $code | Should -Match "Label='RouteTable'"
    }

    It 'VMSS is not a lock target (autoscale must delete instances)' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw
        $code | Should -Not -Match "Label='VMSS'"
    }

    It 'Remove-ZsDeployment cleans per-resource locks before teardown' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/Remove-ZsDeployment.ps1') -Raw
        # The group's locks are listed once and lifted before the first role assignment or resource
        # delete. Which locks qualify is exercised in Tests/Access/Test-TeardownSafety.ps1.
        $list    = $code.IndexOf('/providers/Microsoft.Authorization/locks?api-version')
        $unlock  = $code.IndexOf('Invoke-ArmDelete -Uri "$lockId')
        $deletes = @($code.IndexOf('Invoke-ArmDelete -Uri "$($a.ResourceId)'), $code.IndexOf('-Uri "$($r.ResourceId)?api-version=$apiVersion"'))
        $list | Should -BeGreaterThan 0
        $unlock | Should -BeGreaterThan $list
        foreach ($d in $deletes) { $d | Should -BeGreaterThan $unlock }
    }
}

Describe 'Service Endpoints and PaaS Lockdown' {
    It 'New-ZsNetworkFoundation accepts -ServiceEndpoints' {
        (Get-Command New-ZsNetworkFoundation).Parameters.ContainsKey('ServiceEndpoints') | Should -BeTrue
    }

    It 'No storage service endpoint is added: the storage account is reached through private endpoints' {
        $root = Split-Path $PSScriptRoot -Parent
        $dep = Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw
        $dep | Should -Not -Match "service='Microsoft.Storage'"
        $dep | Should -Not -Match 'Add-ZsSubnetServiceEndpoint'
        $fnd = Get-Content (Join-Path $root 'Public/New-ZsNetworkFoundation.ps1') -Raw
        $fnd | Should -Not -Match "service='Microsoft.Storage'"
        $fnd | Should -Match "privateEndpointNetworkPolicies='Disabled'"
    }

    It 'Function App subnet has App Service delegation' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsNetworkFoundation.ps1') -Raw
        $code | Should -Match 'Microsoft\.Web/serverFarms'
        $code | Should -Match 'snet-zscc-funcapp'
    }

    It 'New-ZsPublicNetwork accepts -FuncAppSubnetName' {
        (Get-Command New-ZsPublicNetwork).Parameters.ContainsKey('FuncAppSubnetName') | Should -BeTrue
    }

    It 'The one NAT gateway is associated with the connector and Function App subnets, not the load balancer subnet' {
        $root = Split-Path $PSScriptRoot -Parent
        $dep = Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw
        $dep | Should -Match "foreach \(\`$natKey in @\('snet-zscc-mgmt','snet-zscc-service','snet-zscc-funcapp'\)\)"
        $code = Get-Content (Join-Path $root 'Public/New-ZsPublicNetwork.ps1') -Raw
        $code | Should -Match 'FuncAppSubnetName'
    }

    It 'Key Vault is created private and reached through its private endpoint' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsKeyVault.ps1') -Raw
        $code | Should -Match "publicNetworkAccess='Disabled'"
        $code | Should -Match 'Set-ZsPrivateEndpoint -Name "pe-\$VaultName"'
        $code | Should -Match 'PrivateEndpointSubnetId'
    }

    It 'Function App is VNet-integrated with route-all from creation' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $code | Should -Match 'virtualNetworkSubnetId=\$FuncAppSubnetId'
        $code | Should -Match 'vnetRouteAllEnabled = \$true'
        $code | Should -Match 'subnetResourceId'
    }

    It 'Storage account is private from creation; nothing opens or re-locks it' {
        $root = Split-Path $PSScriptRoot -Parent
        $fa = Get-Content (Join-Path $root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $fa | Should -Match "publicNetworkAccess='Disabled'"
        $fa | Should -Match "defaultAction='Deny'; bypass='AzureServices'; ipRules=@\(\); virtualNetworkRules=@\(\)"
        $fa | Should -Not -Match "defaultAction = 'Allow'"
        $dep = Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw
        $dep | Should -Not -Match 'Open storage firewall'
        $dep | Should -Not -Match 'Protect-ZsFunctionStorage'
        & (Get-Module ZscalerCloudConnector) { Get-Command Protect-ZsFunctionStorage -ErrorAction SilentlyContinue } | Should -BeNullOrEmpty
    }

    It 'FuncAppSubnetCidr is in the config' {
        $cfg = New-ZsDeploymentConfig -Mode Greenfield
        $cfg.PSObject.Properties.Name -contains 'FuncAppSubnetCidr' -or
        $cfg.Contains('FuncAppSubnetCidr') | Should -BeTrue
    }

    It 'Funcapp subnet is in the subnet plan resolver' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Private/ZsNetworkMath.ps1') -Raw
        $code | Should -Match 'snet-zscc-funcapp'
    }
}

Describe 'Network-First Deployment Sequence' {
    It 'NSGs are created before Identity' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw
        $nsgPos = $code.IndexOf('New-ZsNetworkSecurity')
        $idPos  = $code.IndexOf('New-ZsIdentity')
        $nsgPos | Should -BeLessThan $idPos -Because 'network must exist before identity'
    }

    It 'VNet is created before Key Vault' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw
        $vnetPos = $code.IndexOf('New-ZsNetworkFoundation -AddressSpace')
        $kvPos   = $code.IndexOf('$kv = New-ZsKeyVault')
        $vnetPos | Should -BeGreaterThan 0
        $vnetPos | Should -BeLessThan $kvPos -Because 'subnets must exist for KV lockdown'
    }

    It 'Key Vault function accepts Private Endpoint parameters' {
        $cmd = Get-Command New-ZsKeyVault -Module ZscalerCloudConnector
        $cmd.Parameters.ContainsKey('PrivateEndpointSubnetId') | Should -BeTrue
        $cmd.Parameters.ContainsKey('VnetId') | Should -BeTrue
    }

    It 'Orchestrator passes FuncAppSubnetId to the VMSS function' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw
        $code | Should -Match 'FuncAppSubnetId'
    }
}

# Contract tests: assert against function signatures and capabilities, not source-code strings.
Describe 'Behavioral Contract Tests' {
    It 'New-ZsDeployment has all required parameters' {
        $cmd = Get-Command New-ZsDeployment -Module ZscalerCloudConnector
        $required = @('Topology','Mode','ConfigFile','ProvisioningUrl','ApiKey','AdminUser','AdminPassword')
        foreach ($p in $required) {
            $cmd.Parameters.ContainsKey($p) | Should -BeTrue -Because "$p is a required parameter"
        }
    }

    It 'New-ZsKeyVault accepts Private Endpoint parameters' {
        $cmd = Get-Command New-ZsKeyVault -Module ZscalerCloudConnector
        $cmd.Parameters.ContainsKey('PrivateEndpointSubnetId') | Should -BeTrue
        $cmd.Parameters.ContainsKey('VnetId') | Should -BeTrue
    }

    It 'New-ZsLifecycleFunctionApp is a separate function from VMSS' {
        $cmd = Get-Command New-ZsLifecycleFunctionApp -Module ZscalerCloudConnector -ErrorAction SilentlyContinue
        $cmd | Should -Not -BeNullOrEmpty
        $cmd.Parameters.ContainsKey('VmssNames') | Should -BeTrue
        $cmd.Parameters.ContainsKey('FuncAppSubnetId') | Should -BeTrue
    }

    It 'Remove-ZsDeployment supports ShouldProcess' {
        $cmd = Get-Command Remove-ZsDeployment -Module ZscalerCloudConnector
        $cmd.Parameters.ContainsKey('WhatIf') | Should -BeTrue
        $cmd.Parameters.ContainsKey('Confirm') | Should -BeTrue
    }

    It 'Reset-ZsConnectors exists and supports ShouldProcess' {
        $cmd = Get-Command Reset-ZsConnectors -Module ZscalerCloudConnector
        $cmd.Parameters.ContainsKey('WhatIf') | Should -BeTrue
        $cmd.Parameters.ContainsKey('Zones') | Should -BeTrue
    }

    It 'All exported functions have OutputType' {
        $mod = Get-Module ZscalerCloudConnector
        foreach ($fn in $mod.ExportedFunctions.Keys) {
            $cmd = Get-Command $fn -Module ZscalerCloudConnector
            $cmd.OutputType.Count | Should -BeGreaterThan 0 -Because "$fn should declare OutputType"
        }
    }

    It 'Config topology overrides parameter default' {
        $cmd = Get-Command New-ZsDeployment -Module ZscalerCloudConnector
        $cmd.Parameters['Topology'].Attributes | Where-Object { $_ -is [System.Management.Automation.ValidateSetAttribute] } |
            ForEach-Object { $_.ValidValues | Should -Contain 'VMSS' }
    }

    It 'Module exports exactly the functions its manifest declares' {
        $mod = Get-Module ZscalerCloudConnector
        $declared = (Import-PowerShellDataFile (Join-Path (Split-Path $PSScriptRoot -Parent) 'ZscalerCloudConnector.psd1')).FunctionsToExport
        @($mod.ExportedFunctions.Keys | Sort-Object) | Should -Be @($declared | Sort-Object)
    }
}

Describe 'Observability and Remote State' {
    It 'New-ZsMonitorAlerts is exported with ShouldProcess and alert parameters' {
        $cmd = Get-Command New-ZsMonitorAlerts -Module ZscalerCloudConnector
        $cmd | Should -Not -BeNullOrEmpty
        $cmd.Parameters.ContainsKey('WhatIf') | Should -BeTrue
        foreach ($p in @('AppInsightsId','LoadBalancerId','NotificationEmail','SyncIntervalMinutes','Severity')) {
            $cmd.Parameters.ContainsKey($p) | Should -BeTrue -Because "New-ZsMonitorAlerts needs -$p"
        }
    }

    It 'Alerts match the Terraform monitoring module' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsMonitorAlerts.ps1') -Raw
        $code | Should -Match "metricName='DipAvailability'"
        $code | Should -Match "operator='LessThan'; threshold=50; timeAggregation='Average'"
        $code | Should -Match 'where name == "synchronizeCloudResources"'
        # Each rule counts rows; a trailing summarize would always return one row.
        $code | Should -Not -Match '\|\s*summarize'
        $code | Should -Not -Match 'skipMetricValidation'
        $code | Should -Not -Match "metricName='FunctionExecutionCount'"
    }

    It 'Scheduled query rules use a stable API version' {
        InModuleScope ZscalerCloudConnector {
            $script:ApiVersions.ScheduledQuery | Should -Be '2023-12-01'
        }
    }

    It 'Function App storage connection is identity-based, not key-based' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $code | Should -Match 'allowSharedKeyAccess'
        $code | Should -Match 'AzureWebJobsStorage__credential'
        $code | Should -Not -Match "name='AzureWebJobsStorage';"
    }

    It 'Function role mode defaults to Reader plus the scoped custom role' {
        $p = (Get-Command New-ZsLifecycleFunctionApp).Parameters['FunctionRoleMode']
        $s = $p.Attributes | Where-Object { $_ -is [System.Management.Automation.ValidateSetAttribute] }
        $s.ValidValues | Should -Contain 'Reader'
        $s.ValidValues | Should -Contain 'LeastPrivilege'
        $root = Split-Path $PSScriptRoot -Parent
        (Get-Content (Join-Path $root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw) | Should -Match "FunctionRoleMode = 'Reader'"
    }

    It 'Remote state locking uses blob leases and stays internal' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Private/ZsRemoteState.ps1') -Raw
        foreach ($action in @('acquire','release','break')) {
            $code | Should -Match "x-ms-lease-action'\s*=\s*'$action" -Because "lease $action is part of the lock lifecycle"
        }
        (Get-Module ZscalerCloudConnector).ExportedFunctions.Keys | Should -Not -Contain 'Initialize-ZsRemoteState'
    }

    It 'Pre-flight registers every provider the deployment touches' {
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/Test-ZsPrerequisites.ps1') -Raw
        foreach ($rp in @('Microsoft.Compute','Microsoft.Network','Microsoft.ManagedIdentity','Microsoft.KeyVault','Microsoft.MarketplaceOrdering','Microsoft.Web','Microsoft.Storage','Microsoft.Insights','Microsoft.OperationalInsights','Microsoft.Authorization')) {
            $code | Should -Match ([regex]::Escape("'$rp'")) -Because "$rp resources are created by the deployment"
        }
    }

    It 'NotificationEmail is format-validated on both entry points' {
        foreach ($fn in 'New-ZsMonitorAlerts','New-ZsDeployment') {
            $attr = (Get-Command $fn).Parameters['NotificationEmail'].Attributes | Where-Object { $_ -is [System.Management.Automation.ValidatePatternAttribute] }
            $attr | Should -Not -BeNullOrEmpty -Because "$fn must reject malformed addresses at binding"
        }
        { New-ZsMonitorAlerts -NotificationEmail 'not-an-email' -WhatIf } | Should -Throw
        $root = Split-Path $PSScriptRoot -Parent
        # Config-sourced values bypass binding; the orchestrator must validate them itself.
        (Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw) | Should -Match 'ZsInvalidNotificationEmail'
        foreach ($cf in 'vmss','singlevm','twovms') {
            (Get-Content (Join-Path $root "Config/$cf.json") -Raw | ConvertFrom-Json).PSObject.Properties.Name | Should -Contain 'NotificationEmail'
        }
    }

    It 'Monitor Private Link scopes telemetry through the shared DNS helpers' {
        $cmd = Get-Command New-ZsMonitorPrivateLink -Module ZscalerCloudConnector
        $cmd.Parameters.ContainsKey('WhatIf') | Should -BeTrue
        $cmd.Parameters.ContainsKey('PrivateQueryAccess') | Should -BeTrue
        $root = Split-Path $PSScriptRoot -Parent
        $code = Get-Content (Join-Path $root 'Public/New-ZsMonitorPrivateLink.ps1') -Raw
        $code | Should -Match "ingestionAccessMode='PrivateOnly'"
        $code | Should -Match 'publicNetworkAccessForIngestion'
        foreach ($z in @('privatelink.monitor.azure.com','privatelink.oms.opinsights.azure.com','privatelink.ods.opinsights.azure.com','privatelink.agentsvc.azure-automation.net')) {
            $code | Should -Match ([regex]::Escape($z))
        }
        $code | Should -Match 'Resolve-ZsPrivateDnsZone'
        $code | Should -Match "Set-ZsPrivateEndpoint -Name \`$peName"
        # The storage account's endpoints come with the account, before anything resolves through the zone.
        $code | Should -Not -Match "groupIds=@\('blob'\)"
        (Get-Command New-ZsDeployment).Parameters.ContainsKey('EnableMonitorPrivateLink') | Should -BeTrue
        (Get-Command New-ZsDeployment).Parameters.ContainsKey('DisableMonitorPrivateLink') | Should -BeTrue -Because 'Monitor Private Link is default-on with an explicit opt-out'
        (Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw) | Should -Match 'elseif \(-not \$DisableMonitorPrivateLink\)'
    }

    It 'Orchestrator exposes remote state, alerting, and Function App hardening parameters' {
        $cmd = Get-Command New-ZsDeployment
        foreach ($p in @('StateStorageAccount','BreakStateLock','NotificationEmail','FunctionRoleMode','AllowedScmIpRanges','EnableFunctionPrivateEndpoint')) {
            $cmd.Parameters.ContainsKey($p) | Should -BeTrue -Because "orchestrator needs -$p"
        }
        (Get-Command Get-ZsDeploymentManifest).Parameters.ContainsKey('StateStorageAccount') | Should -BeTrue
    }
}

Describe 'Operational safety' {
    AfterAll { Import-Module (Join-Path (Split-Path $PSScriptRoot -Parent) 'ZscalerCloudConnector.psd1') -Force }

    It 'performs zero mutating ARM or blob calls under -WhatIf' {
        $r = & (Get-Module ZscalerCloudConnector) {
            function script:Invoke-WebRequest { throw 'network mutation attempted' }
            function script:Invoke-RestMethod { throw 'network mutation attempted' }
            function script:Get-ArmToken { 't' }; function script:Get-ZsStorageToken { 't' }
            $WhatIfPreference = $true
            $out = @()
            $out += ($null -eq (Invoke-ArmPut -Uri '/x' -Body @{a=1}))
            $out += ($null -eq (Invoke-ArmPost -Uri '/x'))
            $out += ($null -eq (Invoke-ArmDelete -Uri '/x'))
            $out += ($null -eq (Invoke-ArmRequest -Uri '/x' -Method Patch -Body @{a=1}))
            $blob = Get-Command Invoke-ZsBlobRequest
            $splat = @{}
            foreach ($p in $blob.Parameters.Values) {
                $isMand = $p.Attributes | Where-Object { $_ -is [System.Management.Automation.ParameterAttribute] -and $_.Mandatory }
                if ($isMand) {
                    $splat[$p.Name] = if ($p.Name -eq 'Uri') { 'https://a.blob.core.windows.net/c/b' }
                                      elseif ($p.ParameterType -eq [securestring]) { ConvertTo-SecureString 'x' -AsPlainText -Force }
                                      else { 'zsx' }
                }
            }
            if ($blob.Parameters.ContainsKey('Method')) { $splat['Method'] = 'Put' }
            $out += ($null -eq (Invoke-ZsBlobRequest @splat))
            function script:Invoke-RestMethod { 'GOT' }
            $out += ((Invoke-ArmGet -Uri '/x') -eq 'GOT')
            ,$out
        }
        $r | Should -Not -Contain $false
    }

    It 'treats only a confirmed 404 as absence in Test-ArmResource' {
        $r = & (Get-Module ZscalerCloudConnector) {
            function script:Invoke-ArmRequest {
                param([string]$Uri,[string]$Method='Get',[object]$Body,[int]$MaxRetries=3,[switch]$AllowNotFound)
                if ($Uri -match '404') {
                    if ($AllowNotFound) { return $null }
                    throw [System.Management.Automation.ErrorRecord]::new([Exception]::new('nf'),'Arm.ResourceNotFound',[System.Management.Automation.ErrorCategory]::ObjectNotFound,$Uri)
                }
                if ($Uri -match '403') { throw [System.Management.Automation.ErrorRecord]::new([Exception]::new('denied'),'Arm.AuthorizationFailed',[System.Management.Automation.ErrorCategory]::PermissionDenied,$Uri) }
                [PSCustomObject]@{ id='/x'; properties=[PSCustomObject]@{ provisioningState='Succeeded' } }
            }
            $forb = $false; try { Test-ArmResource -Uri '/r/403' | Out-Null } catch { $forb = ($_.FullyQualifiedErrorId -match 'AuthorizationFailed') }
            @{ Ok=(Test-ArmResource -Uri '/r/ok').Exists; Nf=(Test-ArmResource -Uri '/r/404').Exists; Forb=$forb }
        }
        $r.Ok   | Should -BeTrue
        $r.Nf   | Should -BeFalse
        $r.Forb | Should -BeTrue
    }

    It 'closes a Key Vault 5.4.1.0 left open or with deployment access, leaves a closed one alone, and writes the secrets through Resource Manager' {
        $r = & (Get-Module ZscalerCloudConnector) {
            $script:ZsSession = @{ Connected=$true; Environment='t'; Location='westus3'; ShortId='abc12345'
                SubscriptionId='s'; TenantId='tid'; ResourceGroupName='rg'; DeploymentId='d'; DeployedAt='now'; LogFile=''
                LogBuffer=[System.Collections.Generic.List[string]]::new() }
            function script:Assert-ZsConnected { param($Cmdlet) }
            function script:Get-ZsTags { @{} }
            function script:Get-ZsRgPath { '/subscriptions/s/resourceGroups/rg' }
            function script:Start-Sleep { param([int]$Seconds,[int]$Milliseconds) }
            # A 5.4.1.0 run that stopped between opening the vault and closing it, one that finished,
            # and a vault this release created.
            $states = [ordered]@{
                StoppedRun  = @{ Pna='Enabled';  Acl='Allow'; Deploy=$true }
                FinishedRun = @{ Pna='Disabled'; Acl='Deny';  Deploy=$true }
                Current     = @{ Pna='Disabled'; Acl='Deny';  Deploy=$false }
            }
            function script:NewVault { [PSCustomObject]@{ id='/subscriptions/s/resourceGroups/rg/providers/Microsoft.KeyVault/vaults/kv-zscc-1'; name='kv-zscc-1'
                properties=([PSCustomObject]@{ publicNetworkAccess=$script:VaultState.Pna; enablePurgeProtection=$true; vaultUri='https://kv-zscc-1.vault.azure.net/'
                    enabledForDeployment=$script:VaultState.Deploy; enabledForTemplateDeployment=$script:VaultState.Deploy
                    networkAcls=[PSCustomObject]@{ defaultAction=$script:VaultState.Acl; bypass='AzureServices' } }) } }
            function script:Test-ArmResource { param([string]$Uri) @{ Exists=$true; Resource=(NewVault); State='Succeeded' } }
            function script:Invoke-ArmGet { param([string]$Uri,[switch]$AllowNotFound)
                if ($Uri -match '/vaults\?') { return [PSCustomObject]@{ value=@([PSCustomObject]@{ name='kv-zscc-1' }) } }
                NewVault }
            function script:Invoke-ArmPut { param([string]$Uri,[object]$Body) $script:PutLog.Add(@{Uri=$Uri;Body=$Body}); $null }
            function script:Set-ZsRoleAssignment { param($Scope,$RoleDefinitionId,$PrincipalId,$PrincipalType) }
            function script:Resolve-ZsPrivateDnsZone { param($ZoneName,$VnetId,$HubResourceGroupName,$HubSubscriptionId) "/zones/$ZoneName" }
            function script:Set-ZsPrivateEndpoint { param($Name,$TargetId,$GroupId,$SubnetId,$ZoneIds,$Properties) $script:PeCall = @{ Name=$Name; GroupId=$GroupId; Zones=$ZoneIds }; [PSCustomObject]@{ Id='/pe'; PrivateIp='10.0.0.5' } }
            function script:Add-ZsManifestResource { param($Type,$Name,$ResourceId,$Properties,[switch]$PreExisting) }
            function script:Add-ZsManifestOutput { param($Key,$Value) }
            $out = @{}
            foreach ($s in $states.Keys) {
                $script:VaultState = $states[$s]
                $script:PutLog = [System.Collections.Generic.List[object]]::new()
                New-ZsKeyVault -IdentityPrincipalId 'p' -AdminUser 'a' -ApiKey (ConvertTo-SecureString 'k' -AsPlainText -Force) `
                    -AdminPassword (ConvertTo-SecureString 'pw' -AsPlainText -Force) -VnetId '/vnet' -PrivateEndpointSubnetId '/subnet' -Confirm:$false | Out-Null
                $out[$s] = @{ Puts=$script:PutLog.ToArray(); Pe=$script:PeCall }
            }
            $out
        }
        foreach ($s in 'StoppedRun','FinishedRun') {
            $vaultPuts = @($r[$s].Puts | Where-Object { $_.Uri -match '/vaults/kv-zscc-1\?' })
            $vaultPuts.Count | Should -Be 1 -Because $s
            $p = $vaultPuts[0].Body.properties
            $p.publicNetworkAccess | Should -Be 'Disabled'
            $p.networkAcls.defaultAction | Should -Be 'Deny'
            $p.enabledForDeployment | Should -BeFalse
            $p.enabledForTemplateDeployment | Should -BeFalse
            $p.enablePurgeProtection | Should -BeTrue
        }
        @($r.Current.Puts | Where-Object { $_.Uri -match '/vaults/kv-zscc-1\?' }).Count | Should -Be 0
        $secretPuts = @($r.StoppedRun.Puts | Where-Object { $_.Uri -match '/vaults/kv-zscc-1/secrets/' })
        @($secretPuts | ForEach-Object { ($_.Uri -split '/secrets/')[1] -replace '\?.*$','' }) | Should -Be @('api-key','username','password')
        $secretPuts[0].Body.properties.value | Should -Be 'k'
        $r.StoppedRun.Pe.GroupId | Should -Be 'vault'
        $r.StoppedRun.Pe.Zones | Should -Be @('/zones/privatelink.vaultcore.azure.net')
    }

    It 'closes a 5.4.1.0 storage account, open or IP-ruled, with a PATCH' {
        $r = & (Get-Module ZscalerCloudConnector) {
            $script:Calls = [System.Collections.Generic.List[object]]::new()
            function script:Invoke-ArmRequest { param([string]$Uri,[string]$Method='Get',[object]$Body,[int]$AsyncTimeoutSeconds) $script:Calls.Add(@{Uri=$Uri;Method=$Method;Body=$Body}); $null }
            $stor = [PSCustomObject]@{ id='/st'; properties=[PSCustomObject]@{ publicNetworkAccess='Enabled'; allowSharedKeyAccess=$false
                networkAcls=[PSCustomObject]@{ defaultAction='Deny'; ipRules=@([PSCustomObject]@{ value='1.2.3.4' }); virtualNetworkRules=@() } } }
            $pna        = [string](Get-ZsPropertyValue $stor 'properties.publicNetworkAccess')
            $aclRules   = @(Get-ZsPropertyValue $stor 'properties.networkAcls.ipRules' | Where-Object { $_ }).Count
            @{ Pna=$pna; Rules=$aclRules; Missing=(Get-ZsPropertyValue $stor 'properties.nothing.here') }
        }
        $r.Pna | Should -Be 'Enabled'
        $r.Rules | Should -Be 1
        $r.Missing | Should -BeNullOrEmpty
        $root = Split-Path $PSScriptRoot -Parent
        $fa = Get-Content (Join-Path $root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $fa | Should -Match "Invoke-ArmRequest -Uri \`$storUri -Method Patch -Body @\{ properties = \`$storPatch \}"
        $fa | Should -Match "\`$storPatch.publicNetworkAccess = 'Disabled'"
    }

    It 'wraps every inline orchestrator mutation in ShouldProcess' {
        $root = Split-Path $PSScriptRoot -Parent
        $src = Get-Content (Join-Path $root 'Public/New-ZsDeployment.ps1') -Raw
        $src -like "*Acquire deployment state lock*"                   | Should -BeTrue
        $src -like "*Create or update Function App subnet in BYO VNet*" | Should -BeTrue
        $src -like "*Apply CanNotDelete locks*"                        | Should -BeTrue
        # The open-then-lock storage steps are gone with the storage account's public access.
        $src -like "*Open storage firewall for package redeploy*"      | Should -BeFalse
        $src -like "*Protect-ZsFunctionStorage*"                       | Should -BeFalse
    }
}

Describe 'Connector health parity' {
    BeforeAll { $script:Root = Split-Path $PSScriptRoot -Parent }

    It 'registers both reference timers with the reference cadences' {
        $src = Get-Content (Join-Path $script:Root 'FunctionApp/function_app.py') -Raw
        $src | Should -Match 'def healthMonitor'
        $src | Should -Match 'def synchronizeCloudResources'
        $src | Should -Match '"HEALTH_CRON", "0 \* \* \* \* \*"'
    }

    It 'reads the health metric under the namespace the connectors publish to' {
        $src = Get-Content (Join-Path $script:Root 'FunctionApp/function_app.py') -Raw
        $src | Should -Match 'cloud_connector_aggr_health'
        $src | Should -Match 'Zscaler/CloudConnectors'
        $src | Should -Match 'HEALTHY_METRIC_VALUE = 100'
    }

    It 'correlates portal members by uuid and activates after removal' {
        $src = Get-Content (Join-Path $script:Root 'FunctionApp/function_app.py') -Raw
        $src | Should -Match 'ecVMs'
        $src | Should -Match 'metaConfig'
        $src | Should -Match 'ecAdminActivateStatus/activate'
        $src | Should -Match 'ecgroup/\{group_id\}/vm/\{vm_id\}'
    }

    It 'restores scale set capacity after terminating an instance' {
        $src = Get-Content (Join-Path $script:Root 'FunctionApp/function_app.py') -Raw
        $src | Should -Match 'Restoring %s capacity'
        $src | Should -Match '"sku": \{"capacity": previous\}'
    }

    It 'ships the health tunables as app settings under the reference names' {
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        foreach ($setting in @('HC_DATA_POINTS','HC_UNHEALTHY_THRESHOLD','HC_CONSECUTIVE_UNHEALTHY_THRESHOLD',
                               'GRACE_PERIOD_TIME_MIN','MAX_TERMINATION_PERCENT','TERMINATION_POLICY',
                               'TERMINATE_UNHEALTHY_INSTANCES','HEALTH_CRON')) {
            $src | Should -Match $setting
        }
    }

    It 'grants what replacing a connector takes, on the resource group, the subnets and the identity' {
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $src | Should -Match 'function Set-ZsHealthRemediationRole'
        $vmss = Get-Content (Join-Path $script:Root 'Public/New-ZsCloudConnectorVmss.ps1') -Raw
        $vmss | Should -Match 'Set-ZsHealthRemediationRole -PrincipalId'
        $vmss | Should -Match '-ConnectorIdentityId \$CcIdentityResourceId'
        & (Get-Module ZscalerCloudConnector) {
            $script:Roles.VirtualMachineContributor | Should -Be '9980e02c-c2be-4d73-94e8-173b1dc7cf3c'
            $script:Roles.ManagedIdentityOperator   | Should -Be 'f1a07417-d97a-45cb-824c-7a7467783830'
        }
    }

    It 'keeps the remediation actions out of the read-only role' {
        & (Get-Module ZscalerCloudConnector) {
            $script:FuncIdentityActions | Should -Not -Contain 'Microsoft.Compute/virtualMachineScaleSets/write'
            $script:FuncIdentityActions | Should -Not -Contain 'Microsoft.Compute/virtualMachineScaleSets/delete/action'
            $script:ZsLegacyRemediationRoleName | Should -Be 'ZSCC Lifecycle Function Health Remediation'
        }
    }

    It 'alerts on health verdicts from both packages and on the load balancer probe' {
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsMonitorAlerts.ps1') -Raw
        $src | Should -Match 'alert-zscc-health-verdict-'
        $src | Should -Match 'alert-zscc-lb-health-'
        $src | Should -Match 'Instance is unhealthy, adding it to the termination list'
        $src | Should -Match 'evaluated unhealthy'
        $src | Should -Not -Match 'alert-zscc-cc-unhealthy-\$'
    }
}

Describe 'Function host platform' {
    BeforeAll { $script:Root = Split-Path $PSScriptRoot -Parent }

    It 'creates the function storage account with shared key access disabled by default' {
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $src | Should -Match 'allowSharedKeyAccess=\[bool\]\$AllowSharedKeyStorageAccess'
        $src | Should -Not -Match 'allowSharedKeyAccess=\(-not \$AllowSharedKeyStorageAccess'
    }

    It 'defaults to a dedicated plan and drops the unimplemented flex tier' {
        $cmd = Get-Command New-ZsLifecycleFunctionApp
        $set = ($cmd.Parameters['AppServicePlanSku'].Attributes |
                Where-Object { $_ -is [System.Management.Automation.ValidateSetAttribute] }).ValidValues
        $set | Should -Not -Contain 'FC1'
        $set | Should -Contain 'P0v3'
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $src | Should -Match "\[string\]\`$AppServicePlanSku = 'P0v3'"
    }

    It 'refuses the tiers that need a content share on a storage account private from creation' {
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $src | Should -Match 'ZsPlanNeedsPublicStorage'
        $src | Should -Match "if \(\`$aspTier -in @\('Dynamic','ElasticPremium'\)\)"
    }

    It 'never configures an Azure Files content share' {
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $src | Should -Not -Match "\[.WEBSITE_CONTENTAZUREFILECONNECTIONSTRING.\]\s*="
        $src | Should -Not -Match 'listKeys'
    }

    It 'keeps timers alive on dedicated plans with Always On' {
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $src | Should -Match 'alwaysOn = \$true'
    }

    It 'reconciles a mismatched plan tier instead of reusing it' {
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $src | Should -Match 'a plan''s tier cannot be changed in place'
        $src | Should -Match 'asp-zscc-\$env-\$loc-\$\(\$AppServicePlanSku\.ToLower\(\)\)'
        $src | Should -Match 'serverFarmId = \$asp\.id'
    }

    It 'clears content share settings left behind by an elastic plan' {
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $src | Should -Match "'WEBSITE_CONTENTAZUREFILECONNECTIONSTRING','WEBSITE_CONTENTSHARE','WEBSITE_CONTENTOVERVNET'"
    }
}

Describe 'Console hygiene' {
    BeforeAll { $script:Root = Split-Path $PSScriptRoot -Parent }

    It 'suppresses per-file progress while staging the vendored dependency tree' {
        $src = Get-Content (Join-Path $script:Root 'Private/Publish-ZsFunctionPackage.ps1') -Raw
        $src | Should -Match "\`$ProgressPreference = 'SilentlyContinue'"
        $src | Should -Match "\`$ProgressPreference = \`$priorProgress"
        $src | Should -Match "Write-Progress -Activity 'Copying' -Completed"
    }

    It 'clears the deployment progress bar even when the run throws, and keeps the error' {
        # A trap that rethrows with a bare throw turns every failure into ScriptHalted; a finally
        # block clears the bar and lets the original error through.
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsCloudConnectorVmss.ps1') -Raw
        $src | Should -Match "\} finally \{\s+Write-Progress -Activity 'VMSS Deployment' -Completed"
        $src | Should -Not -Match 'trap\s*\{'
    }
}

Describe 'Function host prerequisites' {
    BeforeAll { $script:Root = Split-Path $PSScriptRoot -Parent }

    It 'grants Storage Account Contributor at the storage account, never the resource group' {
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $src | Should -Match 'Set-ZsRoleAssignment -Scope \$storPath[\s\S]{0,220}StorageAccountContributor'
        $src | Should -Not -Match 'Scope \$rgPath[\s\S]{0,140}StorageAccountContributor'
        & (Get-Module ZscalerCloudConnector) {
            $script:Roles.StorageAccountContributor | Should -Be '17d1049b-9a84-46fb-8f53-869881c3d3ab'
        }
    }

    It 'syncs triggers by restarting, never through the Resource Manager trigger sync' {
        $src = Get-Content (Join-Path $script:Root 'Private/Publish-ZsFunctionPackage.ps1') -Raw
        $src | Should -Not -Match 'syncfunctiontriggers'
        $src | Should -Not -Match 'Using pre-vendored Python dependencies'
        $fa = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $fa | Should -Not -Match 'syncfunctiontriggers'
        $fa | Should -Match 'restart\?api-version'
    }

    It 'creates the site with public network access off and both default actions deny' {
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $src | Should -Match "publicNetworkAccess='Disabled'"
        $src | Should -Match "ipSecurityRestrictionsDefaultAction = 'Deny'"
        $src | Should -Match "scmIpSecurityRestrictionsDefaultAction = 'Deny'"
        $src | Should -Match "publicNetworkAccess='Disabled' \} \}"
    }

    It 'exposes the inbound controls on the orchestrator' {
        $cmd = Get-Command New-ZsDeployment
        $cmd.Parameters.ContainsKey('AllowPublicSiteAccess') | Should -BeTrue
        $cmd.Parameters.ContainsKey('AllowedSiteIpRanges')   | Should -BeTrue
    }
}

Describe 'Startup verification' {
    BeforeAll { $script:Root = Split-Path $PSScriptRoot -Parent }

    It 'waits and restarts only where a private endpoint lets Resource Manager list the functions, and warns rather than fails' {
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $src | Should -Match '\$hasPe = \[bool\]\(\$EnablePrivateEndpoint -or \$localPackage\)'
        $src | Should -Match '\$budget    = if \(\$hostTouched -and \$hasPe\) \{ 420 \} else \{ 0 \}'
        $src | Should -Match '\$restartAt = if \(\$hostTouched -and \$hasPe\) \{ @\(120, 300\) \} else \{ @\(\) \}'
        $src | Should -Match 'Resource Manager does not list'
        $src | Should -Not -Match 'failed to index any functions'
    }

    It 'has no post-lockdown cold start: nothing locks storage at the end of the run' {
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsDeployment.ps1') -Raw
        $src | Should -Not -Match 'survives cold start under the locked firewall'
        $src | Should -Not -Match 'Lock storage to the function subnet'
    }
}

Describe 'Zscaler contract alignment' {
    BeforeAll { $script:Root = Split-Path $PSScriptRoot -Parent }

    It 'emits the reference app-setting names and none of the legacy ones' {
        $src = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        foreach ($name in @('SUBSCRIPTION_ID','MANAGED_IDENTITY','RESOURCE_GROUP','VAULT_URL','CC_URL','VMSS_NAME','WEBSITE_RUN_FROM_PACKAGE')) {
            $src | Should -Match ("(?m)^\s+$name\s+= ")
        }
        $src | Should -Match "'AZURE_SUBSCRIPTION_ID','AZURE_RESOURCE_GROUP'" -Because 'legacy names are removed on reconcile'
        $src | Should -Not -Match "name='ZS_CC_BASE_URL'"
        $src | Should -Match '/subscriptions/\$\(\$script:ZsSession\.SubscriptionId\)' -Because 'reference passes the full resource id'
        $src | Should -Match 'CC_URL\s+= \$ccUrl'
    }

    It 'ships requirements for exactly the packages the module''s function imports' {
        $req = @(Get-Content (Join-Path $script:Root 'FunctionApp/requirements.txt') | Where-Object { $_ -match '^\s*[A-Za-z]' } |
            ForEach-Object { ($_ -split '[<>=!~ ]')[0].ToLowerInvariant() } | Sort-Object)
        # Third-party imports: azure.functions, azure.identity, requests (the rest is the standard library).
        $code = Get-Content (Join-Path $script:Root 'FunctionApp/function_app.py') -Raw
        $imports = @([regex]::Matches($code, '(?m)^(?:import|from)\s+(azure\.\w+|requests)\b') | ForEach-Object { $_.Groups[1].Value -replace '\.', '-' } | Sort-Object -Unique)
        $req | Should -Be $imports
    }

    It 'resolves the lifecycle package: Auto orchestrator, Vendor downstream' {
        (Get-Content (Join-Path $script:Root 'Public/New-ZsDeployment.ps1') -Raw) |
            Should -Match "FunctionPackage = 'Auto'"
        foreach ($file in @('Public/New-ZsCloudConnectorVmss.ps1','Public/New-ZsLifecycleFunctionApp.ps1')) {
            (Get-Content (Join-Path $script:Root $file) -Raw) |
                Should -Match "\[ValidateSet\('Vendor','Module'\)\]\[string\]\`$FunctionPackage = 'Vendor'"
        }
        $dep = Get-Content (Join-Path $script:Root 'Public/New-ZsDeployment.ps1') -Raw
        $dep | Should -Match 'ZsVendorPackageMissing'
        $pre = Get-Content (Join-Path $script:Root 'Public/Test-ZsPrerequisites.ps1') -Raw
        $pre | Should -Match 'Test-ZsVendorPackage'
        & (Get-Module ZscalerCloudConnector) {
            (Get-Command Test-ZsVendorPackage -ErrorAction SilentlyContinue) | Should -Not -BeNullOrEmpty
            (Test-ZsVendorPackage).Valid | Should -BeFalse -Because 'the proprietary artifact is not redistributed with the module'
        }
    }

    It 'keeps HC tunables away from the vendor package' {
        $fa = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $fa | Should -Match "if \(\`$FunctionPackage -eq 'Module'\)"
    }
}

Describe 'Vendor behavioural fidelity' {
    BeforeAll { $script:Root = Split-Path $PSScriptRoot -Parent }

    It 'honours TerminateUnhealthyInstances under both packages' {
        $fa = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $fa | Should -Match "TERMINATE_UNHEALTHY_INSTANCES = \`$\(if \(\`$DisableHealthRemediation\)"
        $fa | Should -Not -Match "HEALTH_CRON[\s\S]{0,400}TERMINATE_UNHEALTHY_INSTANCES\s+= " -Because 'it is not one of the Module-only health settings'
    }

    It 'gates cadence overrides to the Module package and warns when ignored' {
        $fa = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $fa | Should -Match ([regex]::Escape('$FunctionPackage -eq ''Module'' -and $SyncIntervalMinutes -ne 30'))
        $fa | Should -Match 'ignored by the vendor package'
        $fa | Should -Match 'Tunables require -FunctionPackage Module'
    }

    It 'computes the heartbeat window from the cadence that actually runs' {
        $dep = Get-Content (Join-Path $script:Root 'Public/New-ZsDeployment.ps1') -Raw
        $dep | Should -Match ([regex]::Escape('if ($FunctionPackage -eq ''Vendor'') { 30 }'))
        $dep | Should -Match 'ZsConfigNotHonoured'
        $dep | Should -Match 'FunctionPackage resolved: Vendor'
        $dep | Should -Match 'FunctionPackage resolved: Module'
    }
}

Describe 'Lifecycle package resolution' {
    BeforeAll { $script:Root = Split-Path $PSScriptRoot -Parent }

    It 'ships every config on Auto so all three topologies get a working lifecycle' {
        foreach ($cfg in @('vmss','singlevm','twovms')) {
            (Get-Content (Join-Path $script:Root "Config/$cfg.json") -Raw | ConvertFrom-Json).FunctionPackage |
                Should -Be 'Auto'
        }
    }
}

Describe 'Package isolation' {
    BeforeAll { $script:Root = Split-Path $PSScriptRoot -Parent }

    It 'deploys the vendor artifact byte for byte, with no staging' {
        $pub = Get-Content (Join-Path $script:Root 'Private/Publish-ZsFunctionPackage.ps1') -Raw
        $pub | Should -Match '\$zipPath = \$vendorPkg'
        $pub | Should -Match '-InFile \$ZipPath'
    }

    It 'excludes the vendor folder and artifact from the module package' {
        $pub = Get-Content (Join-Path $script:Root 'Private/Publish-ZsFunctionPackage.ps1') -Raw
        $pub | Should -Match "Remove-Item -Path \(Join-Path \`$staging 'vendor'\) -Recurse"
        $pub | Should -Match "Remove-Item -Path \(Join-Path \`$staging 'zscaler_cc_function_app.zip'\)"
    }

    It 'resolves the vendor artifact from the vendor folder first' {
        $pub = Get-Content (Join-Path $script:Root 'Private/Publish-ZsFunctionPackage.ps1') -Raw
        $pub | Should -Match "Join-Path \(Join-Path \`$faDir 'vendor'\) 'zscaler_cc_function_app.zip'"
        Test-Path (Join-Path $script:Root 'FunctionApp/vendor') | Should -BeTrue
    }
}

Describe 'Local package delivery' {
    BeforeAll { $script:Root = Split-Path $PSScriptRoot -Parent }
    AfterAll { Import-Module (Join-Path (Split-Path $PSScriptRoot -Parent) 'ZscalerCloudConnector.psd1') -Force }

    It 'runs the vendor package from its URL, and zip-deploys a local one onto the plan disk through the app private endpoint' {
        $fa = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $fa | Should -Match '\$localPackage = \(\$FunctionPackage -eq .Module.\) -or \(-not \$FunctionPackageUrl\)'
        $fa | Should -Match "\`$packageUrl = if \(\`$localPackage\) \{ '1' \}"
        $fa | Should -Not -Match "WEBSITE_RUN_FROM_PACKAGE_BLOB_MI_RESOURCE_ID'\] ="
        $fa | Should -Match '\(\$EnablePrivateEndpoint -or \$localPackage\)'
        $fa | Should -Match 'basicPublishingCredentialsPolicies'
        $fa | Should -Not -Match 'Publish-ZsFunctionPackage|Remove-ZsStalePackages|Storage Blob Data Contributor'
        $dep = Get-Content (Join-Path $script:Root 'Public/New-ZsDeployment.ps1') -Raw
        $dep | Should -Match "\`$status = 'PartialSuccess'"
        $dep | Should -Match 'FunctionPackagePending=\$pkgPending'
        & (Get-Module ZscalerCloudConnector) {
            $script:ZsVendorPackageUrl | Should -Match '^https://raw\.githubusercontent\.com/zscaler/terraform-azurerm-cloud-connector-modules/6ca00169e6db4b983200d46c632b64fb29c427a7/'
            $script:ZsPackageTag | Should -Be 'zscc-function-package'
        }
    }

    It 'opens nothing to an address: the zip deploy goes through the private endpoint, with an Entra token' {
        $pub = Get-Content (Join-Path $script:Root 'Private/Publish-ZsFunctionPackage.ps1') -Raw
        $pub | Should -Not -Match 'zscc-deploy-temp'
        $pub | Should -Not -Match 'scmIpSecurityRestrictions'
        $pub | Should -Not -Match 'DeployerIpCidr'
        $r = & (Get-Module ZscalerCloudConnector) {
            $script:ZsSession = @{ ShortId='abc12345'; LogBuffer=[System.Collections.Generic.List[string]]::new(); LogFile='' }
            $script:Calls = [System.Collections.Generic.List[object]]::new()
            function script:Resolve-ZsHostAddress { param([string]$HostName) @('10.0.1.9') }
            function script:Get-ArmToken { 'tok' }
            function script:Start-Sleep { param([int]$Seconds) }
            function script:Invoke-WebRequest { param($Uri, $Method, $InFile, $ContentType, $Headers, $TimeoutSec, [switch]$SkipHttpErrorCheck)
                $script:Calls.Add(@{ Uri=$Uri; Method=$Method; InFile=$InFile; Auth=$Headers.Authorization })
                [PSCustomObject]@{ StatusCode=202; Headers=@{ Location=@('https://func-zscc-abc12345.scm.azurewebsites.net/api/deployments/latest') } } }
            function script:Invoke-RestMethod { param($Uri, $Headers, $TimeoutSec) [PSCustomObject]@{ status=4 } }
            $zip = Join-Path ([System.IO.Path]::GetTempPath()) "zscc-test-$([guid]::NewGuid().ToString('N')).zip"
            [System.IO.File]::WriteAllBytes($zip, [byte[]](1,2,3))
            try { Publish-ZsPackageToScm -FunctionAppName 'func-zscc-abc12345' -ZipPath $zip } finally { Remove-Item $zip -Force }
            $script:Calls[0]
        }
        $r.Uri    | Should -Be 'https://func-zscc-abc12345.scm.azurewebsites.net/api/zipdeploy?isAsync=true'
        $r.Method | Should -Be 'Post'
        $r.Auth   | Should -Be 'Bearer tok'
        $r.InFile | Should -Match 'zscc-test-.+\.zip$'
    }

    It 'says what is missing when the deploy is refused or Kudu reports a failure' {
        $r = & (Get-Module ZscalerCloudConnector) {
            $script:ZsSession = @{ ShortId='abc12345'; LogBuffer=[System.Collections.Generic.List[string]]::new(); LogFile='' }
            function script:Resolve-ZsHostAddress { param([string]$HostName) @('10.0.1.9') }
            function script:Get-ArmToken { 'tok' }
            function script:Start-Sleep { param([int]$Seconds) }
            $zip = Join-Path ([System.IO.Path]::GetTempPath()) "zscc-test-$([guid]::NewGuid().ToString('N')).zip"
            [System.IO.File]::WriteAllBytes($zip, [byte[]](1,2,3))
            $out = @{}
            try {
                function script:Invoke-WebRequest { param($Uri, $Method, $InFile, $ContentType, $Headers, $TimeoutSec, [switch]$SkipHttpErrorCheck) [PSCustomObject]@{ StatusCode=403; Headers=@{} } }
                try { Publish-ZsPackageToScm -FunctionAppName 'func-zscc-abc12345' -ZipPath $zip } catch { $out.refused = "$($_.Exception.Message)" }
                function script:Invoke-WebRequest { param($Uri, $Method, $InFile, $ContentType, $Headers, $TimeoutSec, [switch]$SkipHttpErrorCheck) [PSCustomObject]@{ StatusCode=202; Headers=@{ Location=@('https://x/api/deployments/latest') } } }
                function script:Invoke-RestMethod { param($Uri, $Headers, $TimeoutSec) [PSCustomObject]@{ status=3; status_text='bad zip'; log_url='https://x/log' } }
                try { Publish-ZsPackageToScm -FunctionAppName 'func-zscc-abc12345' -ZipPath $zip } catch { $out.failed = "$($_.Exception.Message)" }
            } finally { Remove-Item $zip -Force }
            $out
        }
        $r.refused | Should -Match 'Microsoft.Web/sites/publish/Action'
        $r.failed  | Should -Match 'bad zip'
    }

    It 'refuses a zip deploy from a machine that resolves the app to a public address' {
        $r = & (Get-Module ZscalerCloudConnector) {
            $script:ZsSession = @{ ShortId='abc12345'; LogBuffer=[System.Collections.Generic.List[string]]::new(); LogFile='' }
            function script:Resolve-ZsHostAddress { param([string]$HostName) $script:FakeAddresses }
            $out = @{}
            foreach ($case in @(@{ K='public'; A=@('52.1.2.3') }, @{ K='none'; A=@() }, @{ K='mixed'; A=@('10.0.1.4','52.1.2.3') })) {
                $script:FakeAddresses = $case.A
                $msg = ''
                try { Publish-ZsPackageToScm -FunctionAppName 'func-zscc-abc12345' -ZipPath '/nonexistent.zip' | Out-Null } catch { $msg = "$($_.Exception.Message)" }
                $out[$case.K] = $msg
            }
            $out
        }
        $r.public | Should -Match '^ZsPackagePushNeedsNetwork'
        $r.public | Should -Match 'resolves it to 52\.1\.2\.3'
        $r.none   | Should -Match 'cannot resolve it'
        $r.mixed  | Should -Match '^ZsPackagePushNeedsNetwork'
        & (Get-Module ZscalerCloudConnector) {
            Test-ZsPrivateAddress -Address '10.1.2.3'   | Should -BeTrue
            Test-ZsPrivateAddress -Address '172.20.0.4' | Should -BeTrue
            Test-ZsPrivateAddress -Address '192.168.9.9' | Should -BeTrue
            Test-ZsPrivateAddress -Address '100.70.1.1' | Should -BeTrue
            Test-ZsPrivateAddress -Address '172.32.0.1' | Should -BeFalse
            Test-ZsPrivateAddress -Address '52.1.2.3'   | Should -BeFalse
            Test-ZsPrivateAddress -Address 'not-an-ip'  | Should -BeFalse
        }
    }

    It 'builds the module package from the shipped wheel set, names it by content, and keeps no vendor files in it' {
        $r = & (Get-Module ZscalerCloudConnector) {
            $script:ZsSession = @{ ShortId='abc12345'; LogBuffer=[System.Collections.Generic.List[string]]::new(); LogFile='' }
            $a = Build-ZsFunctionPackage -FunctionPackage Module
            $b = Build-ZsFunctionPackage -FunctionPackage Module
            Add-Type -AssemblyName System.IO.Compression.FileSystem
            $z = [System.IO.Compression.ZipFile]::OpenRead($a.Path)
            try { $names = @($z.Entries | ForEach-Object { $_.FullName }) } finally { $z.Dispose() }
            $out = @{ A=$a; B=$b; Names=$names; Exists=(Test-Path $a.Path) }
            Remove-Item $a.Path, $b.Path -Force -ErrorAction SilentlyContinue
            $out
        }
        $r.Exists | Should -BeTrue
        $r.A.Temporary | Should -BeTrue
        $r.A.Hash | Should -Match '^[0-9a-f]{16}$'
        $r.A.Hash | Should -Be $r.B.Hash
        $r.Names | Should -Contain 'function_app.py'
        $r.Names | Should -Contain 'host.json'
        @($r.Names | Where-Object { $_ -like '.python_packages/lib/site-packages/*' }).Count | Should -BeGreaterThan 0
        @($r.Names | Where-Object { $_ -like 'vendor/*' -or $_ -like '*zscaler_cc_function_app.zip' -or $_ -like '*python_packages.zip' }).Count | Should -Be 0
    }
}

Describe 'Fail-fast on a dead lifecycle' {
    BeforeAll { $script:Root = Split-Path $PSScriptRoot -Parent }

    It 'reports where to look when the host never lists its functions' {
        $fa = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $fa | Should -Match 'Last error'
        $fa | Should -Match 'requests \| where name in'
        $fa | Should -Match 'Function App Down or Reporting Errors'
    }

    It 'leaves no deployment-ending storage lock to fail closed around' {
        $dep = Get-Content (Join-Path $script:Root 'Public/New-ZsDeployment.ps1') -Raw
        $dep | Should -Not -Match 'post-lockdown cold start'
        $dep | Should -Match 'Close-ZsRemoteState'
    }

    It 'refuses to deploy a source-only package' {
        $pub = Get-Content (Join-Path $script:Root 'Private/Publish-ZsFunctionPackage.ps1') -Raw
        $pub | Should -Match 'Refusing to deploy it'
    }
}

Describe 'Plan tier fidelity' {
    BeforeAll { $script:Root = Split-Path $PSScriptRoot -Parent }

    It 'maps P0v3 to its real ARM tier and compares plans by SKU name' {
        $fa = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $fa | Should -Match "'\^P0v3\$'\s+\{ 'Premium0V3' \}"
        $fa | Should -Match 'existingSku -ne \$AppServicePlanSku'
    }

    It 'detaches VNet integration for a genuine plan move' {
        $fa = Get-Content (Join-Path $script:Root 'Public/New-ZsLifecycleFunctionApp.ps1') -Raw
        $fa | Should -Match 'Detaching VNet integration for the plan move'
        $fa | Should -Match 'virtualNetworkSubnetId = \$null'
    }
}

Describe 'Portal ceiling and SCM identity' {
    BeforeAll { $script:Root = Split-Path $PSScriptRoot -Parent }

    It 'enforces the 16 per group ceiling in code, not only in documentation' {
        $vmss = Get-Content (Join-Path $script:Root 'Public/New-ZsCloudConnectorVmss.ps1') -Raw
        $vmss | Should -Match 'ValidateRange\(1,16\)\]\[int\]\$MaxInstances'
        $vmss | Should -Match 'ValidateRange\(1,16\)\]\[int\]\$ScheduledMinInstances'
        $dep = Get-Content (Join-Path $script:Root 'Public/New-ZsDeployment.ps1') -Raw
        $dep | Should -Match 'ZsExceedsEcGroupLimit'
        $dep | Should -Match 'ZsInvalidInstanceRange'
    }

    It 'accepts DeployerIpCidr on the orchestrator only, says it does nothing, and opens nothing to any address' {
        (Get-Command New-ZsDeployment).Parameters.ContainsKey('DeployerIpCidr') | Should -BeTrue
        foreach ($c in 'New-ZsLifecycleFunctionApp','New-ZsCloudConnectorVmss') {
            foreach ($p in 'DeployerIpCidr','DeployerSpObjectId','AllowedScmIpRanges','AllowPublicSiteAccess','AllowedSiteIpRanges') {
                (Get-Command $c).Parameters.ContainsKey($p) | Should -BeFalse -Because "$c -$p"
            }
        }
        $dep = Get-Content (Join-Path $script:Root 'Public/New-ZsDeployment.ps1') -Raw
        $dep | Should -Match '-DeployerIpCidr has no effect'
        $pub = Get-Content (Join-Path $script:Root 'Private/Publish-ZsFunctionPackage.ps1') -Raw
        $pub | Should -Not -Match 'DeployerIpCidr'
        foreach ($cfg in @('vmss','singlevm','twovms')) {
            (Get-Content (Join-Path $script:Root "Config/$cfg.json") -Raw | ConvertFrom-Json).PSObject.Properties.Name |
                Should -Not -Contain 'DeployerIpCidr'
        }
    }
}

Describe 'Dead code hygiene' {
    BeforeAll { $script:Root = Split-Path $PSScriptRoot -Parent }

    It 'the subnet planner and its math helpers travel together' {
        # Guard against reachability analysis that checks a file's functions but not the file:
        # Resolve-ZsSubnetPlan lives with the CIDR helpers it calls, and both must exist.
        $nm = Join-Path $script:Root 'Private/ZsNetworkMath.ps1'
        Test-Path $nm | Should -BeTrue
        (Get-Content $nm -Raw) | Should -Match 'function Resolve-ZsSubnetPlan'
        & (Get-Module ZscalerCloudConnector) {
            Get-Command Resolve-ZsSubnetPlan -ErrorAction SilentlyContinue | Should -Not -BeNullOrEmpty
            Get-Command Test-ZsCidrOverlap  -ErrorAction SilentlyContinue | Should -Not -BeNullOrEmpty
        }
    }

    It 'capacity recommendations respect the portal group limit' {
        $src = Get-Content (Join-Path $script:Root 'Public/Get-ZsCapacityPlan.ps1') -Raw
        $src | Should -Match 'PortalGroupLimit\s+= 16'
        $src | Should -Match 'if \(\$maxCount -gt 16\)'
    }
}

Describe 'Existing Network Resolution (Terraform parity)' {
    BeforeAll {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{
                TenantId='t'; SubscriptionId='11111111-1111-1111-1111-111111111111'
                ClientId='c'; ClientSecretSS=$null; AuthMethod='client_secret'
                Location='westus2'; Environment='dev'
                ResourceGroupName='rg-zscc-dev-westus2'
                DeploymentId='dep-pester'; ShortId='pstr01'
                DeployedAt=(Get-Date).ToString('yyyy-MM-ddTHH:mm:ssZ')
                Tokens=@{}; Connected=$true
                ArtifactRoot=$TestDrive; LogFile=(Join-Path $TestDrive 'pester.log')
                LogBuffer=[System.Collections.Generic.List[string]]::new()
                ZscalerConnected=$false; ZscalerApiKeySS=$null; ZscalerUsername=''; ZscalerPasswordSS=$null
                ZscalerSession=$null; ZscalerApiUrl=''
                MsalTokenResponse=$null; MsalTokenExpiry=$null
                BringYourOwnResourceGroup=$false
            }
            Initialize-ZsManifest -SubscriptionId $script:ZsSession.SubscriptionId -ResourceGroupName $script:ZsSession.ResourceGroupName -Location 'westus2'

            $script:TestVnetId = '/subscriptions/22222222-2222-2222-2222-222222222222/resourceGroups/rg-network-hub/providers/Microsoft.Network/virtualNetworks/vnet-hub'
            function script:New-PesterFakeSubnet([string]$Name, [hashtable]$Props) {
                [PSCustomObject]@{ name=$Name; id="$script:TestVnetId/subnets/$Name"; properties=[PSCustomObject](@{ provisioningState='Succeeded' } + $Props) }
            }
            $script:TestSubnets = @(
                New-PesterFakeSubnet 'sn-mgmt' @{ addressPrefix='10.50.0.0/27'
                    networkSecurityGroup=[PSCustomObject]@{ id='/subscriptions/x/resourceGroups/hub/providers/Microsoft.Network/networkSecurityGroups/nsg-hub-mgmt' } }
                New-PesterFakeSubnet 'sn-svc'  @{ addressPrefix='10.50.0.32/27' }
                New-PesterFakeSubnet 'sn-wl'   @{ addressPrefix='10.50.1.0/24' }
                New-PesterFakeSubnet 'sn-lb'   @{ addressPrefixes=@('10.50.0.64/27') }   # plural form on purpose
                New-PesterFakeSubnet 'sn-func' @{ addressPrefix='10.50.0.96/27'
                    delegations=@([PSCustomObject]@{ name='d'; properties=[PSCustomObject]@{ serviceName='Microsoft.Web/serverFarms' } })
                    serviceEndpoints=@([PSCustomObject]@{ service='Microsoft.KeyVault' }) }
                New-PesterFakeSubnet 'AzureBastionSubnet' @{ addressPrefix='10.50.0.128/26' }
            )
            $script:TestVnet = [PSCustomObject]@{
                name='vnet-hub'; id=$script:TestVnetId; location='westus2'
                properties=[PSCustomObject]@{
                    provisioningState='Succeeded'
                    addressSpace=[PSCustomObject]@{ addressPrefixes=@('10.50.0.0/16') }
                    subnets=$script:TestSubnets
                }
            }
        }
    }

    It 'resolves an existing network from Terraform-style names in one ARM read' {
        InModuleScope ZscalerCloudConnector {
            Mock Invoke-ArmGet { $script:TestVnet }
            $byo = @{
                VnetName='vnet-hub'; VnetResourceGroupName='rg-network-hub'
                VnetSubscriptionId='22222222-2222-2222-2222-222222222222'
                MgmtSubnetName='sn-mgmt'; ServiceSubnetName='sn-svc'
                WorkloadSubnetName='sn-wl'; LbSubnetName='sn-lb'; FuncAppSubnetName='sn-func'
            }
            $r = Resolve-ZsExistingNetwork -BringYourOwn $byo -WantBastion
            Should -Invoke Invoke-ArmGet -Times 1 -Exactly
            $r.VnetId | Should -Be $script:TestVnetId
            $r.CrossSubscription | Should -BeTrue
            $r.Subnets['snet-zscc-mgmt'].Id | Should -Be "$script:TestVnetId/subnets/sn-mgmt"
            $r.Subnets['snet-zscc-mgmt'].HasNsg | Should -BeTrue
            # addressPrefixes (plural) is read the way Terraform reads address_prefixes[0]
            $r.Subnets['snet-zscc-lb'].Prefix | Should -Be '10.50.0.64/27'
            $r.SubnetPlan.'snet-zscc-workload' | Should -Be '10.50.1.0/24'
            $r.BastionSubnet.Prefix | Should -Be '10.50.0.128/26'
            $r.SubnetPlan.'AzureBastionSubnet' | Should -Be '10.50.0.128/26'
        }
    }

    It 'reports every missing subnet together, naming what the VNet does have' {
        InModuleScope ZscalerCloudConnector {
            Mock Invoke-ArmGet { $script:TestVnet }
            $byo = @{
                VnetName='vnet-hub'; VnetResourceGroupName='rg-network-hub'
                VnetSubscriptionId='22222222-2222-2222-2222-222222222222'
                MgmtSubnetName='nope-a'; ServiceSubnetName='nope-b'
                WorkloadSubnetName='sn-wl'; LbSubnetName='sn-lb'
            }
            $err = $null
            try { Resolve-ZsExistingNetwork -BringYourOwn $byo } catch { $err = $_.Exception.Message }
            $err | Should -Match 'nope-a'
            $err | Should -Match 'nope-b'
            $err | Should -Match 'Subnets present'
            $err | Should -Match 'sn-mgmt'
        }
    }

    It 'refuses a subnet ID that disagrees with its name, or lives under another VNet' {
        InModuleScope ZscalerCloudConnector {
            Mock Invoke-ArmGet { $script:TestVnet }
            $base = @{
                VnetName='vnet-hub'; VnetResourceGroupName='rg-network-hub'
                VnetSubscriptionId='22222222-2222-2222-2222-222222222222'
                ServiceSubnetName='sn-svc'; WorkloadSubnetName='sn-wl'; LbSubnetName='sn-lb'
            }
            $disagree = $base + @{ MgmtSubnetName='sn-mgmt'; MgmtSubnetId="$script:TestVnetId/subnets/sn-svc" }
            { Resolve-ZsExistingNetwork -BringYourOwn $disagree } | Should -Throw -ExpectedMessage '*must agree*'

            $foreign = $base + @{ MgmtSubnetId='/subscriptions/22222222-2222-2222-2222-222222222222/resourceGroups/o/providers/Microsoft.Network/virtualNetworks/other/subnets/sn-x' }
            { Resolve-ZsExistingNetwork -BringYourOwn $foreign } | Should -Throw -ExpectedMessage '*not the resolved VNet*'
        }
    }

    It 'refuses a VNet in another region before anything is built against it' {
        InModuleScope ZscalerCloudConnector {
            Mock Invoke-ArmGet {
                $v = $script:TestVnet.PSObject.Copy(); $v.location = 'eastus2'; $v
            }
            $byo = @{
                VnetName='vnet-hub'; VnetResourceGroupName='rg-network-hub'
                VnetSubscriptionId='22222222-2222-2222-2222-222222222222'
                MgmtSubnetName='sn-mgmt'; ServiceSubnetName='sn-svc'
                WorkloadSubnetName='sn-wl'; LbSubnetName='sn-lb'
            }
            { Resolve-ZsExistingNetwork -BringYourOwn $byo } | Should -Throw -ExpectedMessage '*eastus2*'
        }
    }

    It 'returns null when the config names no network at all (greenfield)' {
        InModuleScope ZscalerCloudConnector {
            Resolve-ZsExistingNetwork -BringYourOwn @{ ResourceGroupName='rg-x' } | Should -BeNullOrEmpty
        }
    }

    It 'Get-ZsConfigValue reads hashtables and PSCustomObjects alike under strict mode' {
        InModuleScope ZscalerCloudConnector {
            Get-ZsConfigValue @{ A=' x ' } 'A'                | Should -Be 'x'
            Get-ZsConfigValue @{ A='x' } 'Missing'            | Should -Be ''
            Get-ZsConfigValue ([PSCustomObject]@{ A='y' }) 'A' | Should -Be 'y'
            Get-ZsConfigValue ([PSCustomObject]@{ A='y' }) 'Missing' | Should -Be ''
            Get-ZsConfigValue $null 'A'                        | Should -Be ''
        }
    }

    It 'NSG association is idempotent, replaces with a warning, and preserves subnet properties' {
        InModuleScope ZscalerCloudConnector {
            $subnet = New-PesterFakeSubnet 'sn-mgmt' @{ addressPrefix='10.50.0.0/27'
                networkSecurityGroup=[PSCustomObject]@{ id='/subscriptions/x/resourceGroups/hub/providers/Microsoft.Network/networkSecurityGroups/nsg-hub-mgmt' }
                natGateway=[PSCustomObject]@{ id='/nat/keepme' } }
            Mock Invoke-ArmGet { $subnet }
            Mock Invoke-ArmPut { }
            Mock Wait-ArmProvision { $subnet }

            # Same NSG: verified, no write.
            Set-ZsSubnetNsgAssociation -SubnetId $subnet.id -NsgId '/subscriptions/x/resourceGroups/hub/providers/Microsoft.Network/networkSecurityGroups/nsg-hub-mgmt' | Should -BeTrue
            Should -Invoke Invoke-ArmPut -Times 0 -Exactly

            # Different NSG: one write carrying the new NSG and the untouched NAT reference.
            Set-ZsSubnetNsgAssociation -SubnetId $subnet.id -NsgId '/new/nsg' | Should -BeTrue
            Should -Invoke Invoke-ArmPut -Times 1 -Exactly -ParameterFilter {
                $Body.properties.networkSecurityGroup.id -eq '/new/nsg' -and $Body.properties.natGateway.id -eq '/nat/keepme'
            }
        }
    }

    It 'stops a brought network before anything is attached when a subnet carries an NSG or NAT gateway the config does not name' {
        InModuleScope ZscalerCloudConnector {
            $hubNsg = '/subscriptions/x/resourceGroups/hub/providers/Microsoft.Network/networkSecurityGroups/nsg-hub-mgmt'
            $script:NsgTags = @{}
            # A copy, so the NAT gateways added below stay out of the other tests' network.
            $script:AttachVnet = $script:TestVnet | ConvertTo-Json -Depth 20 | ConvertFrom-Json
            Mock Write-ZsLog { }
            Mock Invoke-ArmGet { [PSCustomObject]@{ id=($Uri -split '\?')[0]; tags=[PSCustomObject]$script:NsgTags } } -ParameterFilter { $Uri -like '*/networkSecurityGroups/*' }
            Mock Invoke-ArmGet { $script:AttachVnet }
            $byo = @{
                VnetName='vnet-hub'; VnetResourceGroupName='rg-network-hub'
                VnetSubscriptionId='22222222-2222-2222-2222-222222222222'
                MgmtSubnetName='sn-mgmt'; ServiceSubnetName='sn-svc'
                WorkloadSubnetName='sn-wl'; LbSubnetName='sn-lb'; FuncAppSubnetName='sn-func'
            }
            $net = Resolve-ZsExistingNetwork -BringYourOwn $byo
            $stop = { param([hashtable]$Arguments) try { Assert-ZsSubnetAttachment -Network $net @Arguments; '' } catch { "$($_.FullyQualifiedErrorId)|$($_.Exception.Message)" } }

            # sn-mgmt carries the hub's NSG: refused unless named, and named only as a pair.
            $r = & $stop @{}
            $r | Should -BeLike 'ZsByoSubnetAttached*'
            $r | Should -BeLike '*sn-mgmt carries NSG nsg-hub-mgmt*'
            $r | Should -Not -BeLike '*sn-svc*'
            & $stop @{ MgmtNsgId=$hubNsg; ServiceNsgId='/subscriptions/x/resourceGroups/hub/providers/Microsoft.Network/networkSecurityGroups/nsg-hub-svc' } | Should -Be ''
            & $stop @{ MgmtNsgId=$hubNsg } | Should -BeLike '*supplied together or not at all*'

            # An NSG this module created is its own: a re-run passes.
            $script:NsgTags = @{ 'managed-by' = 'ZscalerCloudConnector-PSModule' }
            & $stop @{} | Should -Be ''

            # A NAT gateway on a connector or Function App subnet: the deployment's own passes, the
            # platform's is refused unless AttachNatGateway is false.
            $own = "/subscriptions/11111111-1111-1111-1111-111111111111/resourceGroups/rg-zscc-dev-westus2/providers/Microsoft.Network/natGateways/natgw-zscc-dev-westus2"
            $net.Subnets['snet-zscc-service'].Object.properties | Add-Member -NotePropertyName natGateway -NotePropertyValue ([PSCustomObject]@{ id=$own }) -Force
            & $stop @{} | Should -Be ''
            $net.Subnets['snet-zscc-funcapp'].Object.properties | Add-Member -NotePropertyName natGateway -NotePropertyValue ([PSCustomObject]@{ id='/subscriptions/x/resourceGroups/hub/providers/Microsoft.Network/natGateways/natgw-hub' }) -Force
            $r = & $stop @{}
            $r | Should -BeLike '*sn-func carries NAT gateway natgw-hub*AttachNatGateway*'
            & $stop @{ AttachNatGateway=$false } | Should -Be ''
            Should -Invoke Write-ZsLog -ParameterFilter { $Level -eq 'WARN' -and $Message -like '*sn-svc still carries this deployment''s NAT gateway*' }
        }
    }

    It 'service-endpoint reconciliation unions and skips when already present' {
        InModuleScope ZscalerCloudConnector {
            $subnet = New-PesterFakeSubnet 'sn-func' @{ addressPrefix='10.50.0.96/27'
                serviceEndpoints=@([PSCustomObject]@{ service='Microsoft.KeyVault' }) }
            Mock Invoke-ArmGet { $subnet }
            Mock Invoke-ArmPut { }
            Mock Wait-ArmProvision { $subnet }

            Add-ZsSubnetServiceEndpoint -SubnetId $subnet.id -Services @('Microsoft.Storage') | Should -BeTrue
            Should -Invoke Invoke-ArmPut -Times 1 -Exactly -ParameterFilter {
                $svcs = @($Body.properties.serviceEndpoints | ForEach-Object { $_.service })
                ($svcs -contains 'Microsoft.Storage') -and ($svcs -contains 'Microsoft.KeyVault')
            }

            $already = New-PesterFakeSubnet 'sn-func' @{ addressPrefix='10.50.0.96/27'
                serviceEndpoints=@([PSCustomObject]@{ service='Microsoft.Storage' }) }
            Mock Invoke-ArmGet { $already }
            Add-ZsSubnetServiceEndpoint -SubnetId $already.id -Services @('Microsoft.Storage') | Should -BeTrue
            Should -Invoke Invoke-ArmPut -Times 1 -Exactly   # unchanged: no second write
        }
    }

    It 'service-endpoint removal keeps the other endpoints as they are and skips when absent' {
        InModuleScope ZscalerCloudConnector {
            $subnet = New-PesterFakeSubnet 'sn-func' @{ addressPrefix='10.50.0.96/27'
                serviceEndpoints=@([PSCustomObject]@{ service='Microsoft.Storage'; locations=@('westus2') }, [PSCustomObject]@{ service='Microsoft.KeyVault'; locations=@('*') }) }
            Mock Invoke-ArmGet { $subnet }
            Mock Invoke-ArmPut { }
            Mock Wait-ArmProvision { $subnet }

            Remove-ZsSubnetServiceEndpoint -SubnetId $subnet.id -Services @('Microsoft.Storage') -Confirm:$false | Should -BeTrue
            Should -Invoke Invoke-ArmPut -Times 1 -Exactly -ParameterFilter {
                $kept = @($Body.properties.serviceEndpoints)
                $kept.Count -eq 1 -and $kept[0].service -eq 'Microsoft.KeyVault' -and @($kept[0].locations) -contains '*' -and $Body.properties.addressPrefix -eq '10.50.0.96/27'
            }

            $bare = New-PesterFakeSubnet 'sn-func' @{ addressPrefix='10.50.0.96/27' }
            Mock Invoke-ArmGet { $bare }
            Remove-ZsSubnetServiceEndpoint -SubnetId $bare.id -Services @('Microsoft.Storage') -Confirm:$false | Should -BeFalse
            Should -Invoke Invoke-ArmPut -Times 1 -Exactly   # nothing to remove: no second write
        }
    }

    It 'the NAT gateway associates by explicit subnet ID and filters placeholders' {
        InModuleScope ZscalerCloudConnector {
            Mock Test-ArmResource { [PSCustomObject]@{ Exists=$false; State=''; Resource=$null } }
            Mock Invoke-ArmPut { }
            Mock Wait-ArmProvision {
                param($Uri, $Label, $TimeoutSeconds, $PollSeconds)
                $bare = $Uri -replace '\?.*$',''
                foreach ($s in $script:TestSubnets) { if ($bare -ieq $s.id) { return $s } }
                [PSCustomObject]@{ id=$bare; name=($bare -split '/')[-1]
                    properties=[PSCustomObject]@{ provisioningState='Succeeded'; ipAddress='198.51.100.7' } }
            }
            Mock Invoke-ArmGet {
                param($Uri)
                $bare = $Uri -replace '\?.*$',''
                foreach ($s in $script:TestSubnets) { if ($bare -ieq $s.id) { return $s } }
                throw "404 $bare"
            }
            $plan = [PSCustomObject]@{ 'snet-zscc-mgmt'='10.50.0.0/27'; 'snet-zscc-service'='10.50.0.32/27' }
            $ids  = @("$script:TestVnetId/subnets/sn-mgmt", "$script:TestVnetId/subnets/sn-svc", '(placeholder)')
            $null = New-ZsPublicNetwork -SubnetPlan $plan -VnetPath $script:TestVnetId -Zones @('1') -AssociateSubnetIds $ids -Confirm:$false
            Should -Invoke Invoke-ArmPut -ParameterFilter { $Uri -like "*subnets/sn-mgmt*" -and $Body.properties.natGateway } -Times 1
            Should -Invoke Invoke-ArmPut -ParameterFilter { $Uri -like "*subnets/sn-svc*" }  -Times 1
            Should -Invoke Invoke-ArmPut -ParameterFilter { $Uri -like "*placeholder*" }     -Times 0 -Exactly
            Should -Invoke Invoke-ArmPut -ParameterFilter { $Uri -like "*subnets/snet-zscc-*" } -Times 0 -Exactly
        }
    }

    AfterAll {
        InModuleScope ZscalerCloudConnector { $script:ZsSession = $null; $script:ZsManifest = $null }
    }
}

Describe 'Org-Delta parity (behaviour)' {
    # Each cmdlet runs against an in-memory stand-in for Resource Manager: a PUT stores what it
    # sends, a GET returns what is stored, and every write is recorded in order. The assertions
    # read what the module actually asked Azure for.
    BeforeAll {
        InModuleScope ZscalerCloudConnector {
            $script:ZsSession = @{
                TenantId='t'; SubscriptionId='11111111-1111-1111-1111-111111111111'
                ClientId='c'; ClientSecretSS=$null; AuthMethod='client_secret'
                Location='westus2'; Environment='dev'
                ResourceGroupName='rg-zscc-dev-westus2'
                DeploymentId='dep-parity'; ShortId='pstr01'
                DeployedAt='2026-10-20T00:00:00Z'
                Tokens=@{}; Connected=$true
                ArtifactRoot=''; LogFile=''
                LogBuffer=[System.Collections.Generic.List[string]]::new()
                ZscalerConnected=$false; ZscalerApiKeySS=$null; ZscalerUsername=''; ZscalerPasswordSS=$null
                ZscalerSession=$null; ZscalerApiUrl=''
                MsalTokenResponse=$null; MsalTokenExpiry=$null
                BringYourOwnResourceGroup=$false
            }
            $script:Rg  = '/subscriptions/11111111-1111-1111-1111-111111111111/resourceGroups/rg-zscc-dev-westus2'
            $script:Sub = '/subscriptions/11111111-1111-1111-1111-111111111111'

            function script:Reset-ZsParityArm {
                $script:ArmStore  = @{}
                $script:ArmCalls  = [System.Collections.Generic.List[object]]::new()
                $script:ParityLog = [System.Collections.Generic.List[string]]::new()
                Initialize-ZsManifest -SubscriptionId $script:ZsSession.SubscriptionId -ResourceGroupName $script:ZsSession.ResourceGroupName -Location 'westus2'
            }
            function script:Get-ZsParityKey { param([string]$Uri) (($Uri -split '\?')[0]).ToLowerInvariant() }
            function script:Set-ZsParityResource {
                param([string]$Id, [hashtable]$Resource, [switch]$Owned)
                $r = @{} + $Resource
                $r['id'] = $Id; $r['name'] = ($Id -split '/')[-1]
                if ($Owned) { $r['tags'] = @{ 'managed-by' = 'ZscalerCloudConnector-PSModule' } }
                $o = $r | ConvertTo-Json -Depth 40 | ConvertFrom-Json
                $script:ArmStore[$Id.ToLowerInvariant()] = $o
                return $o
            }
            function script:Get-ZsParityCall {
                param([string]$Method, [string]$Match = '.')
                return ,@($script:ArmCalls | Where-Object { $_.Method -eq $Method -and $_.Uri -match $Match })
            }
            # One line per rule: name|priority|direction|access|protocol|destination ports|sources|destination.
            function script:Get-ZsParityRuleLine {
                param([object[]]$Rules)
                @($Rules | ForEach-Object {
                    $p = $_.properties
                    $src = if ($p.ContainsKey('sourceAddressPrefixes')) { @($p.sourceAddressPrefixes) -join ',' } else { $p.sourceAddressPrefix }
                    $dpt = if ($p.ContainsKey('destinationPortRanges')) { @($p.destinationPortRanges) -join ',' } else { $p.destinationPortRange }
                    '{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}' -f $_.name, $p.priority, $p.direction, $p.access, $p.protocol, $dpt, $src, $p.destinationAddressPrefix
                } | Sort-Object)
            }
            function script:Get-ZsParityErrorId {
                param([scriptblock]$Action)
                try { & $Action | Out-Null; return '' } catch { return [string]$_.FullyQualifiedErrorId }
            }
        }
    }

    BeforeEach {
        InModuleScope ZscalerCloudConnector {
            Reset-ZsParityArm
            Mock Assert-ZsConnected { }
            Mock Write-ZsLog { $script:ParityLog.Add("[$(if ($Level) { $Level } else { 'INFO' })] $Message") }
            Mock Start-Sleep { }
            Mock Test-ArmResource {
                $o = $script:ArmStore[(Get-ZsParityKey $Uri)]
                @{ Exists = ($null -ne $o); Resource = $o; State = $(if ($o) { 'Succeeded' } else { $null }) }
            }
            Mock Invoke-ArmGet {
                $o = $script:ArmStore[(Get-ZsParityKey $Uri)]
                if ($null -eq $o -and -not $AllowNotFound) { throw "NotFound (404): $Uri" }
                $o
            }
            Mock Invoke-ArmPut {
                $script:ArmCalls.Add([PSCustomObject]@{ Method='PUT'; Uri=$Uri; Body=$Body })
                if ($Body -is [hashtable]) { $null = Set-ZsParityResource -Id (($Uri -split '\?')[0]) -Resource $Body }
            }
            Mock Invoke-ArmRequest { $script:ArmCalls.Add([PSCustomObject]@{ Method=([string]$Method).ToUpperInvariant(); Uri=$Uri; Body=$Body }) }
            Mock Invoke-ArmPost {
                $script:ArmCalls.Add([PSCustomObject]@{ Method='POST'; Uri=$Uri; Body=$Body })
                $script:ArmStore[(Get-ZsParityKey $Uri)]
            }
            Mock Invoke-ArmDelete {
                $script:ArmCalls.Add([PSCustomObject]@{ Method='DELETE'; Uri=$Uri; Body=$null })
                $script:ArmStore.Remove((Get-ZsParityKey $Uri))
            }
            Mock Wait-ArmProvision { $script:ArmStore[(Get-ZsParityKey $Uri)] }
        }
    }

    AfterAll {
        Import-Module (Join-Path (Split-Path $PSScriptRoot -Parent) 'ZscalerCloudConnector.psd1') -Force
    }

    Context 'Network security groups' {
        It 'reads a brought subnet in a dry run and writes nothing, and leaves a subnet the run would create to the run' {
            InModuleScope ZscalerCloudConnector {
                $subnet = "$script:Sub/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/v/subnets/sn-mgmt"
                $ours   = "$script:Rg/providers/Microsoft.Network/networkSecurityGroups/nsg-zscc-mgmt-dev-westus2"
                $null = Set-ZsParityResource -Id $subnet -Resource @{ properties=@{ addressPrefix='10.0.0.0/26' } }
                Set-ZsSubnetNsgAssociation -SubnetId $subnet -NsgId $ours -WhatIf | Should -BeTrue
                Set-ZsSubnetNsgAssociation -SubnetId "$subnet-new" -NsgId $ours -WhatIf | Should -BeTrue
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0
                Set-ZsSubnetNsgAssociation -SubnetId $subnet -NsgId $ours -Confirm:$false | Should -BeTrue
                (Get-ZsParityCall -Method PUT -Match '/subnets/sn-mgmt\?').Count | Should -Be 1
                $script:ArmCalls.Clear()
                Set-ZsSubnetNsgAssociation -SubnetId $subnet -NsgId $ours -WhatIf | Should -BeTrue
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0
            }
        }

        It 'builds the management, service and function NSGs rule for rule as the Terraform nsg module does' {
            InModuleScope ZscalerCloudConnector {
                $r = New-ZsNetworkSecurity -PrivateEndpointClientCidrs @('10.0.1.0/26','10.0.4.0/27') -FunctionAppNsg -EnableSupportTunnel -Confirm:$false
                $puts = Get-ZsParityCall -Method PUT -Match '/networkSecurityGroups/'
                $puts.Count | Should -Be 3
                $rules = { param($n) @(($puts | Where-Object { $_.Uri -match "/networkSecurityGroups/$n\?" }).Body.properties.securityRules) }

                Get-ZsParityRuleLine (& $rules 'nsg-zscc-mgmt-dev-westus2') | Should -Be @(@(
                    'AllowDNSTcp|130|Outbound|Allow|Tcp|53|*|*'
                    'AllowDNSUdp|131|Outbound|Allow|Udp|53|*|*'
                    'AllowDTLS|100|Outbound|Allow|Udp|443|*|Internet'
                    'AllowHTTP|120|Outbound|Allow|Tcp|80|*|Internet'
                    'AllowICMP|120|Inbound|Allow|Icmp|*|VirtualNetwork|VirtualNetwork'
                    'AllowLBProbeIn|110|Inbound|Allow|Tcp|50000|AzureLoadBalancer|*'
                    'AllowNTP|140|Outbound|Allow|Udp|123|*|*'
                    'AllowPrivateEndpointsIn|130|Inbound|Allow|Tcp|443|10.0.1.0/26,10.0.4.0/27|*'
                    'AllowSSH|100|Inbound|Allow|Tcp|22|VirtualNetwork|*'
                    'AllowSupport|145|Outbound|Allow|Tcp|12002|*|199.168.148.101'
                    'AllowTLS|110|Outbound|Allow|Tcp|443|*|Internet'
                    'AllowVnetOut|150|Outbound|Allow|*|*|VirtualNetwork|VirtualNetwork'
                    'DenyAllIn|4096|Inbound|Deny|*|*|*|*'
                    'DenyAllOut|4096|Outbound|Deny|*|*|*|*'
                ) | Sort-Object)

                Get-ZsParityRuleLine (& $rules 'nsg-zscc-svc-dev-westus2') | Should -Be @(@(
                    'AllowWorkload|100|Inbound|Allow|*|*|VirtualNetwork|*'
                    'AllowLBProbeIn|110|Inbound|Allow|Tcp|50000|AzureLoadBalancer|*'
                    'DenyInternetIn|4096|Inbound|Deny|*|*|Internet|*'
                    'AllowDTLS|100|Outbound|Allow|Udp|443|*|Internet'
                    'AllowTLS|110|Outbound|Allow|Tcp|443|*|Internet'
                    'AllowVnetOut|120|Outbound|Allow|*|*|VirtualNetwork|VirtualNetwork'
                    'AllowHTTP|130|Outbound|Allow|Tcp|80|*|Internet'
                    'AllowKMS|140|Outbound|Allow|Tcp|1688|*|Internet'
                    'AllowRDPRelay|150|Outbound|Allow|Udp|3478|*|WindowsVirtualDesktop'
                    'DenyAllOut|4096|Outbound|Deny|*|*|*|*'
                ) | Sort-Object)

                Get-ZsParityRuleLine (& $rules 'nsg-zscc-func-dev-westus2') | Should -Be @(@(
                    'DenyAllIn|4096|Inbound|Deny|*|*|*|*'
                    'AllowPrivateEndpointsOut|100|Outbound|Allow|Tcp|443|*|VirtualNetwork'
                    'AllowHTTPSOut|110|Outbound|Allow|Tcp|443|*|Internet'
                    'AllowHTTPOut|120|Outbound|Allow|Tcp|80|*|Internet'
                    'AllowDNSUdpOut|130|Outbound|Allow|Udp|53|*|*'
                    'AllowDNSTcpOut|131|Outbound|Allow|Tcp|53|*|*'
                    'DenyAllOut|4096|Outbound|Deny|*|*|*|*'
                ) | Sort-Object)

                # Azure takes either the singular or the plural form of a prefix or port field, never both.
                foreach ($p in $puts) {
                    foreach ($rule in @($p.Body.properties.securityRules)) {
                        ($rule.properties.ContainsKey('sourceAddressPrefix') -xor $rule.properties.ContainsKey('sourceAddressPrefixes')) | Should -BeTrue -Because $rule.name
                        ($rule.properties.ContainsKey('destinationPortRange') -xor $rule.properties.ContainsKey('destinationPortRanges')) | Should -BeTrue -Because $rule.name
                    }
                }
                $r.FuncAppNsgId | Should -Match '/networkSecurityGroups/nsg-zscc-func-dev-westus2$'
            }
        }

        It 'leaves the support rule and the private endpoint rule out unless asked for, and lists several workload ranges in the plural field' {
            InModuleScope ZscalerCloudConnector {
                $null = New-ZsNetworkSecurity -WorkloadCidrs @('10.1.0.0/24','10.2.0.0/24') -Confirm:$false
                $puts = Get-ZsParityCall -Method PUT -Match '/networkSecurityGroups/'
                $puts.Count | Should -Be 2
                $mgmt = @(($puts | Where-Object { $_.Uri -match 'nsg-zscc-mgmt' }).Body.properties.securityRules)
                @($mgmt.name) | Should -Not -Contain 'AllowSupport'
                @($mgmt.name) | Should -Not -Contain 'AllowPrivateEndpointsIn'
                $wl = @(($puts | Where-Object { $_.Uri -match 'nsg-zscc-svc' }).Body.properties.securityRules | Where-Object { $_.name -eq 'AllowWorkload' })[0]
                $wl.properties.sourceAddressPrefixes | Should -Be @('10.1.0.0/24','10.2.0.0/24')
                $wl.properties.ContainsKey('sourceAddressPrefix') | Should -BeFalse
                @(($puts | Where-Object { $_.Uri -match 'nsg-zscc-svc' }).Body.properties.securityRules.name) | Should -Not -Contain 'AllowAllOut'
            }
        }

        It 'opens every port from the service subnet to the internet only when asked, ahead of DenyAllOut, and takes it out again' {
            InModuleScope ZscalerCloudConnector {
                $null = New-ZsNetworkSecurity -ServiceAllowAllOutbound -Confirm:$false
                $svc = @((Get-ZsParityCall -Method PUT -Match '/networkSecurityGroups/nsg-zscc-svc-').Body.properties.securityRules)
                @(Get-ZsParityRuleLine @($svc | Where-Object { $_.name -eq 'AllowAllOut' })) | Should -Be @('AllowAllOut|160|Outbound|Allow|*|*|*|Internet')
                $mgmt = @((Get-ZsParityCall -Method PUT -Match '/networkSecurityGroups/nsg-zscc-mgmt-').Body.properties.securityRules)
                @($mgmt.name) | Should -Not -Contain 'AllowAllOut'

                # Turned off again, the group this module owns is written back without it.
                $script:ArmCalls.Clear()
                $null = New-ZsNetworkSecurity -Confirm:$false
                $svc = @((Get-ZsParityCall -Method PUT -Match '/networkSecurityGroups/nsg-zscc-svc-').Body.properties.securityRules)
                $svc.Count | Should -BeGreaterThan 0
                @($svc.name) | Should -Not -Contain 'AllowAllOut'
            }
        }

        It 'rewrites a drifted NSG this module owns in one PUT, leaves one in sync alone, and only reports somebody else''s' {
            InModuleScope ZscalerCloudConnector {
                $want = Get-ZsFuncAppNsgRuleSet
                $old  = @($want | Where-Object { $_.name -ne 'AllowHTTPOut' })
                $idA  = "$script:Rg/providers/Microsoft.Network/networkSecurityGroups/nsg-a"
                $null = Set-ZsParityResource -Id $idA -Owned -Resource @{ location='westus2'; properties=@{ securityRules=$old } }
                $null = Set-ZsNsg -Name 'nsg-a' -Rules $want -Role 'FunctionApp' -Confirm:$false
                $put = Get-ZsParityCall -Method PUT
                $put.Count | Should -Be 1
                @($put[0].Body.properties.securityRules).Count | Should -Be 7
                $put[0].Body.tags['managed-by'] | Should -Be 'ZscalerCloudConnector-PSModule'

                # The same rules as Resource Manager returns them - both prefix forms, empty lists,
                # provisioning state, etags - compare equal, so a re-run writes nothing.
                $idC = "$script:Rg/providers/Microsoft.Network/networkSecurityGroups/nsg-c"
                $armShape = @($want | ForEach-Object {
                    $p = $_.properties
                    @{ name=$_.name; id="$idC/securityRules/$($_.name)"; etag='W/"1"'; type='Microsoft.Network/networkSecurityGroups/securityRules'
                       properties=@{ provisioningState='Succeeded'; priority=$p.priority; direction=$p.direction; access=$p.access; protocol=$p.protocol
                           sourcePortRange='*'; sourcePortRanges=@()
                           destinationPortRange=$(if ($p.ContainsKey('destinationPortRange')) { $p.destinationPortRange } else { $null })
                           destinationPortRanges=$(if ($p.ContainsKey('destinationPortRanges')) { @($p.destinationPortRanges) } else { @() })
                           sourceAddressPrefix=$p.sourceAddressPrefix; sourceAddressPrefixes=@()
                           destinationAddressPrefix=$p.destinationAddressPrefix; destinationAddressPrefixes=@() } }
                })
                $null = Set-ZsParityResource -Id $idC -Owned -Resource @{ location='westus2'; properties=@{ securityRules=$armShape } }
                $script:ArmCalls.Clear()
                $null = Set-ZsNsg -Name 'nsg-c' -Rules $want -Role 'FunctionApp' -Confirm:$false
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0

                $idB = "$script:Rg/providers/Microsoft.Network/networkSecurityGroups/nsg-b"
                $null = Set-ZsParityResource -Id $idB -Resource @{ location='westus2'; properties=@{ securityRules=$old } }
                $null = Set-ZsNsg -Name 'nsg-b' -Rules $want -Role 'FunctionApp' -Confirm:$false
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0
                ($script:ParityLog -join "`n") | Should -Match "somebody else's"
            }
        }
    }

    Context 'Load balancer' {
        It 'creates the internal load balancer with floating IP off, source IP affinity and the /?cchealth probe' {
            InModuleScope ZscalerCloudConnector {
                $null = New-ZsLoadBalancer -SubnetId '/sub/lb' -Zones @('1','2') -Confirm:$false
                $put = Get-ZsParityCall -Method PUT -Match '/loadBalancers/'
                $put.Count | Should -Be 1
                $b = $put[0].Body
                $b.sku.name | Should -Be 'Standard'
                $b.properties.frontendIPConfigurations[0].zones | Should -Be @('1','2','3')
                $rule = $b.properties.loadBalancingRules[0]
                $rule.name | Should -Be 'rule-haports'
                $rule.properties.protocol | Should -Be 'All'
                $rule.properties.frontendPort | Should -Be 0
                $rule.properties.backendPort | Should -Be 0
                $rule.properties.enableFloatingIP | Should -Be $false
                $rule.properties.loadDistribution | Should -Be 'SourceIP'
                $rule.properties.ContainsKey('idleTimeoutInMinutes') | Should -BeFalse
                $rule.properties.ContainsKey('disableOutboundSnat') | Should -BeFalse
                $rule.properties.probe.id | Should -Match '/probes/hp-50000$'
                $probe = $b.properties.probes[0]
                $probe.name | Should -Be 'hp-50000'
                $probe.properties.protocol | Should -Be 'Http'
                $probe.properties.port | Should -Be 50000
                $probe.properties.requestPath | Should -Be '/?cchealth'
                $probe.properties.intervalInSeconds | Should -Be 10
                $probe.properties.numberOfProbes | Should -Be 2
                $probe.properties.probeThreshold | Should -Be 2

                # A single zone pins the frontend to it.
                Reset-ZsParityArm
                $null = New-ZsLoadBalancer -SubnetId '/sub/lb' -Zones @('2') -Confirm:$false
                (Get-ZsParityCall -Method PUT -Match '/loadBalancers/')[0].Body.properties.frontendIPConfigurations[0].zones | Should -Be @('2')
            }
        }

        It 'brings a 5.4.1.0 load balancer to the same rule and probe in place, keeping its frontend and pool' {
            InModuleScope ZscalerCloudConnector {
                $lbId = "$script:Rg/providers/Microsoft.Network/loadBalancers/$(New-ZsResourceName -Prefix 'lb-zscc' -Environment 'dev' -Location 'westus2')"
                $null = Set-ZsParityResource -Id $lbId -Owned -Resource @{
                    location='westus2'; sku=@{ name='Standard'; tier='Regional' }
                    properties=@{
                        frontendIPConfigurations=@(@{ name='fe-zscc'; id="$lbId/frontendIPConfigurations/fe-zscc"; zones=@('1','2','3')
                            properties=@{ privateIPAddress='10.0.3.4'; privateIPAllocationMethod='Dynamic'; subnet=@{ id='/sub/lb' } } })
                        backendAddressPools=@(@{ name='be-zscc'; id="$lbId/backendAddressPools/be-zscc"
                            properties=@{ backendIPConfigurations=@(@{ id='/nic/cc1/ipConfigurations/ipconfig-svc' }, @{ id='/nic/cc2/ipConfigurations/ipconfig-svc' }) } })
                        probes=@(@{ name='hp-50000'; id="$lbId/probes/hp-50000"
                            properties=@{ protocol='Http'; port=50000; requestPath='/?cchealth'; intervalInSeconds=5; numberOfProbes=2; probeThreshold=1 } })
                        loadBalancingRules=@(@{ name='rule-haports'; id="$lbId/loadBalancingRules/rule-haports"
                            properties=@{ protocol='All'; frontendPort=0; backendPort=0; enableFloatingIP=$false; loadDistribution='Default'
                                idleTimeoutInMinutes=4; disableOutboundSnat=$true; probe=@{ id="$lbId/probes/hp-50000" } } })
                    }
                }
                $r = New-ZsLoadBalancer -SubnetId '/sub/lb' -Confirm:$false
                $put = Get-ZsParityCall -Method PUT
                $put.Count | Should -Be 1
                $p = $put[0].Body.properties
                $p.frontendIPConfigurations[0].properties.privateIPAddress | Should -Be '10.0.3.4'
                @($p.backendAddressPools[0].properties.backendIPConfigurations).Count | Should -Be 2
                $rule = @($p.loadBalancingRules | Where-Object { $_.name -eq 'rule-haports' })[0].properties
                $rule.enableFloatingIP | Should -Be $false
                $rule.loadDistribution | Should -Be 'SourceIP'
                @($rule.Keys) | Should -Not -Contain 'idleTimeoutInMinutes'
                @($rule.Keys) | Should -Not -Contain 'disableOutboundSnat'
                $probe = @($p.probes | Where-Object { $_.name -eq 'hp-50000' })[0].properties
                $probe.intervalInSeconds | Should -Be 10
                $probe.probeThreshold | Should -Be 2
                $r.FrontendIp | Should -Be '10.0.3.4'
                $r.BackendId | Should -Be "$lbId/backendAddressPools/be-zscc"

                # In line now: nothing more is written.
                $script:ArmCalls.Clear()
                $null = New-ZsLoadBalancer -SubnetId '/sub/lb' -Confirm:$false
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0

                # Floating IP turned on afterwards is turned off again, and nothing else changes.
                $live = $script:ArmStore[$lbId.ToLowerInvariant()]
                @($live.properties.loadBalancingRules | Where-Object { $_.name -eq 'rule-haports' })[0].properties.enableFloatingIP = $true
                $null = New-ZsLoadBalancer -SubnetId '/sub/lb' -Confirm:$false
                $put = Get-ZsParityCall -Method PUT
                $put.Count | Should -Be 1
                @($put[0].Body.properties.loadBalancingRules | Where-Object { $_.name -eq 'rule-haports' })[0].properties.enableFloatingIP | Should -Be $false
                $put[0].Body.properties.frontendIPConfigurations[0].properties.privateIPAddress | Should -Be '10.0.3.4'
                ($script:ParityLog -join "`n") | Should -Match 'reconciled: floating IP on -> floating IP off'
            }
        }

        It 'reports a load balancer of the same name it does not own, without changing it' {
            InModuleScope ZscalerCloudConnector {
                $lbId = "$script:Rg/providers/Microsoft.Network/loadBalancers/$(New-ZsResourceName -Prefix 'lb-zscc' -Environment 'dev' -Location 'westus2')"
                $null = Set-ZsParityResource -Id $lbId -Resource @{
                    location='westus2'; sku=@{ name='Standard' }
                    properties=@{
                        frontendIPConfigurations=@(@{ name='fe-zscc'; properties=@{ privateIPAddress='10.0.3.4' } })
                        backendAddressPools=@(@{ name='be-zscc'; id="$lbId/backendAddressPools/be-zscc" })
                        probes=@(); loadBalancingRules=@()
                    }
                }
                $null = New-ZsLoadBalancer -SubnetId '/sub/lb' -Confirm:$false
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0
                ($script:ParityLog -join "`n") | Should -Match 'no managed-by tag'
            }
        }
    }

    Context 'NAT gateway' {
        BeforeEach {
            InModuleScope ZscalerCloudConnector {
                $script:Vnet = "$script:Rg/providers/Microsoft.Network/virtualNetworks/vnet-zscc"
                foreach ($s in 'snet-zscc-mgmt','snet-zscc-service','snet-zscc-funcapp') {
                    $null = Set-ZsParityResource -Id "$script:Vnet/subnets/$s" -Resource @{ properties=@{ addressPrefix='10.0.0.0/27' } }
                }
                $script:NatIds = @("$script:Vnet/subnets/snet-zscc-mgmt", "$script:Vnet/subnets/snet-zscc-service", "$script:Vnet/subnets/snet-zscc-funcapp")
                $script:Plan = [PSCustomObject]@{ 'snet-zscc-funcapp' = '10.0.4.0/27' }
            }
        }

        It 'gives the StandardV2 gateway a StandardV2 address and a ten-minute idle timeout, on the connector and function subnets' {
            InModuleScope ZscalerCloudConnector {
                $r = New-ZsPublicNetwork -SubnetPlan $script:Plan -VnetPath $script:Vnet -AssociateSubnetIds $script:NatIds -Confirm:$false
                $pip = Get-ZsParityCall -Method PUT -Match '/publicIPAddresses/'
                $pip.Count | Should -Be 1
                $pip[0].Uri | Should -Match 'api-version=2025-03-01'
                $pip[0].Body.sku.name | Should -Be 'StandardV2'
                $pip[0].Body.properties.publicIPAllocationMethod | Should -Be 'Static'
                $pip[0].Body.ContainsKey('zones') | Should -BeFalse
                $nat = (Get-ZsParityCall -Method PUT -Match '/natGateways/')[0]
                $nat.Uri | Should -Match 'api-version=2025-03-01'
                $nat.Body.sku.name | Should -Be 'StandardV2'
                $nat.Body.ContainsKey('zones') | Should -BeFalse
                $nat.Body.properties.idleTimeoutInMinutes | Should -Be 10
                @($nat.Body.properties.publicIpAddresses).Count | Should -Be 1
                @($nat.Body.properties.publicIpPrefixes).Count | Should -Be 0
                $assoc = Get-ZsParityCall -Method PUT -Match '/subnets/'
                @($assoc | ForEach-Object { (($_.Uri -split '\?')[0] -split '/')[-1] }) | Should -Be @('snet-zscc-mgmt','snet-zscc-service','snet-zscc-funcapp')
                foreach ($a in $assoc) { $a.Body.properties.natGateway.id | Should -Match '/natGateways/natgw-zscc-dev-westus2$' }
                $r.Egress.Mode | Should -Be 'ip'
                $r.Egress.Created | Should -BeTrue
            }
        }

        It 'uses a /31 StandardV2 prefix in prefix mode, attached as the gateway''s prefix' {
            InModuleScope ZscalerCloudConnector {
                $r = New-ZsPublicNetwork -SubnetPlan $script:Plan -VnetPath $script:Vnet -AssociateSubnetIds $script:NatIds -PublicIpMode prefix -Confirm:$false
                (Get-ZsParityCall -Method PUT -Match '/publicIPAddresses/').Count | Should -Be 0
                $pfx = Get-ZsParityCall -Method PUT -Match '/publicIPPrefixes/'
                $pfx.Count | Should -Be 1
                $pfx[0].Body.sku.name | Should -Be 'StandardV2'
                $pfx[0].Body.properties.prefixLength | Should -Be 31
                $nat = (Get-ZsParityCall -Method PUT -Match '/natGateways/')[0].Body
                @($nat.properties.publicIpAddresses).Count | Should -Be 0
                @($nat.properties.publicIpPrefixes)[0].id | Should -Match '/publicIPPrefixes/ippre-natgw-zscc-dev-westus2$'
                $r.Egress.Mode | Should -Be 'prefix'
            }
        }

        It 'attaches a platform-supplied address only when it matches the mode and is StandardV2' {
            InModuleScope ZscalerCloudConnector {
                $base = @{ SubnetPlan=$script:Plan; VnetPath=$script:Vnet; AssociateSubnetIds=$script:NatIds; Confirm=$false }
                $ipId  = '/subscriptions/2/resourceGroups/rg-plat/providers/Microsoft.Network/publicIPAddresses/pip-egress'
                $pfxId = '/subscriptions/2/resourceGroups/rg-plat/providers/Microsoft.Network/publicIPPrefixes/ippre-egress'
                Get-ZsParityErrorId { New-ZsPublicNetwork @base -ExistingPublicIpId 'pip-egress' } | Should -Match '^ZsInvalidNatPublicIpId'
                Get-ZsParityErrorId { New-ZsPublicNetwork @base -ExistingPublicIpId $pfxId } | Should -Match '^ZsNatPublicIpModeMismatch'
                Get-ZsParityErrorId { New-ZsPublicNetwork @base -PublicIpMode prefix -ExistingPublicIpId $ipId } | Should -Match '^ZsNatPublicIpModeMismatch'
                Get-ZsParityErrorId { New-ZsPublicNetwork @base -ExistingPublicIpId $ipId } | Should -Match '^ZsNatPublicIpNotFound'
                $null = Set-ZsParityResource -Id $ipId -Resource @{ sku=@{ name='Standard' }; properties=@{ ipAddress='20.1.2.3' } }
                Get-ZsParityErrorId { New-ZsPublicNetwork @base -ExistingPublicIpId $ipId } | Should -Match '^ZsNatPublicIpSku'
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0

                $null = Set-ZsParityResource -Id $ipId -Resource @{ sku=@{ name='StandardV2' }; properties=@{ ipAddress='20.1.2.3' } }
                $r = New-ZsPublicNetwork @base -ExistingPublicIpId $ipId
                (Get-ZsParityCall -Method PUT -Match '/publicIPAddresses/').Count | Should -Be 0
                @((Get-ZsParityCall -Method PUT -Match '/natGateways/')[0].Body.properties.publicIpAddresses)[0].id | Should -Be $ipId
                $r.Egress.PublicIp | Should -Be '20.1.2.3'
                $r.Egress.Created | Should -BeFalse
                @($script:ZsManifest.Resources['PublicIP'])[0].PreExisting | Should -BeTrue
            }
        }

        It 'moves its own gateway off the 5.4.1.0 four-minute idle timeout, and leaves one it does not own as it is' {
            InModuleScope ZscalerCloudConnector {
                $pipId = "$script:Rg/providers/Microsoft.Network/publicIPAddresses/pip-natgw-zscc-dev-westus2"
                $natId = "$script:Rg/providers/Microsoft.Network/natGateways/natgw-zscc-dev-westus2"
                $null = Set-ZsParityResource -Id $pipId -Owned -Resource @{ sku=@{ name='StandardV2' }; properties=@{ ipAddress='20.9.9.9' } }
                $null = Set-ZsParityResource -Id $natId -Owned -Resource @{ location='westus2'; sku=@{ name='StandardV2' }
                    properties=@{ idleTimeoutInMinutes=4; publicIpAddresses=@(@{ id=$pipId }) } }
                $null = New-ZsPublicNetwork -SubnetPlan $script:Plan -VnetPath $script:Vnet -AssociateSubnetIds $script:NatIds -Confirm:$false
                $nat = Get-ZsParityCall -Method PUT -Match '/natGateways/'
                $nat.Count | Should -Be 1
                $nat[0].Body.properties.idleTimeoutInMinutes | Should -Be 10
                @($nat[0].Body.properties.publicIpAddresses)[0].id | Should -Be $pipId
                (Get-ZsParityCall -Method PUT -Match '/publicIPAddresses/').Count | Should -Be 0

                Reset-ZsParityArm
                foreach ($s in 'snet-zscc-mgmt','snet-zscc-service','snet-zscc-funcapp') {
                    $null = Set-ZsParityResource -Id "$script:Vnet/subnets/$s" -Resource @{ properties=@{ addressPrefix='10.0.0.0/27' } }
                }
                $null = Set-ZsParityResource -Id $pipId -Owned -Resource @{ sku=@{ name='StandardV2' }; properties=@{ ipAddress='20.9.9.9' } }
                $null = Set-ZsParityResource -Id $natId -Resource @{ location='westus2'; sku=@{ name='StandardV2' }
                    properties=@{ idleTimeoutInMinutes=4; publicIpAddresses=@(@{ id=$pipId }) } }
                $null = New-ZsPublicNetwork -SubnetPlan $script:Plan -VnetPath $script:Vnet -AssociateSubnetIds $script:NatIds -Confirm:$false
                (Get-ZsParityCall -Method PUT -Match '/natGateways/').Count | Should -Be 0
                ($script:ParityLog -join "`n") | Should -Match 'NAT gateway natgw-zscc-dev-westus2 differs'
            }
        }
    }

    Context 'Bastion' {
        BeforeEach {
            InModuleScope ZscalerCloudConnector {
                Mock Set-ZsSubnetNsgAssociation { $script:ArmCalls.Add([PSCustomObject]@{ Method='ASSOC'; Uri=$SubnetId; Body=$NsgId }); $true }
                $script:Vnet = "$script:Rg/providers/Microsoft.Network/virtualNetworks/vnet-zscc"
                $script:BasName = New-ZsResourceName -Prefix 'bas-zscc' -Environment 'dev' -Location 'westus2'
            }
        }

        It 'deploys Premium private-only with no public IP, its NSG on the subnet before the host' {
            InModuleScope ZscalerCloudConnector {
                $r = New-ZsBastion -VnetPath $script:Vnet -Confirm:$false
                (Get-ZsParityCall -Method PUT -Match '/publicIPAddresses/').Count | Should -Be 0
                $order = @($script:ArmCalls | ForEach-Object { if ($_.Method -eq 'ASSOC') { 'assoc' } elseif ($_.Uri -match '/networkSecurityGroups/') { 'nsg' } elseif ($_.Uri -match '/bastionHosts/') { 'bastion' } })
                $order | Should -Be @('nsg','assoc','bastion')
                $nsgRules = @((Get-ZsParityCall -Method PUT -Match '/networkSecurityGroups/')[0].Body.properties.securityRules)
                @($nsgRules | Where-Object { $_.name -eq 'AllowHttpsInbound' })[0].properties.sourceAddressPrefix | Should -Be 'VirtualNetwork'
                $nsgRules.Count | Should -Be 10
                $bas = (Get-ZsParityCall -Method PUT -Match '/bastionHosts/')[0]
                $bas.Uri | Should -Match 'api-version=2025-03-01'
                $bas.Body.sku.name | Should -Be 'Premium'
                $p = $bas.Body.properties
                $p.enablePrivateOnlyBastion | Should -BeTrue
                $p.ipConfigurations[0].properties.ContainsKey('publicIPAddress') | Should -BeFalse
                $p.ipConfigurations[0].properties.subnet.id | Should -Be "$script:Vnet/subnets/AzureBastionSubnet"
                $p.enableTunneling | Should -BeTrue
                $p.enableIpConnect | Should -BeTrue
                $p.enableShareableLink | Should -BeFalse
                $p.enableFileCopy | Should -BeFalse
                $p.enableKerberos | Should -BeFalse
                $p.scaleUnits | Should -Be 2
                $r.PrivateOnly | Should -BeTrue
            }
        }

        It 'gives a Standard Bastion its public IP and opens 443 from the internet' {
            InModuleScope ZscalerCloudConnector {
                $r = New-ZsBastion -VnetPath $script:Vnet -Sku Standard -Confirm:$false
                $pip = Get-ZsParityCall -Method PUT -Match '/publicIPAddresses/'
                $pip.Count | Should -Be 1
                $pip[0].Body.sku.name | Should -Be 'Standard'
                $bas = (Get-ZsParityCall -Method PUT -Match '/bastionHosts/')[0].Body.properties
                $bas.enablePrivateOnlyBastion | Should -BeFalse
                $bas.ipConfigurations[0].properties.publicIPAddress.id | Should -Match '/publicIPAddresses/'
                $nsgRules = @((Get-ZsParityCall -Method PUT -Match '/networkSecurityGroups/')[0].Body.properties.securityRules)
                @($nsgRules | Where-Object { $_.name -eq 'AllowHttpsInbound' })[0].properties.sourceAddressPrefix | Should -Be 'Internet'
                $r.PrivateOnly | Should -BeFalse
            }
        }

        It 'replaces a 5.4.1.0 public Bastion with a private-only one and removes its public IP' {
            InModuleScope ZscalerCloudConnector {
                $basId = "$script:Rg/providers/Microsoft.Network/bastionHosts/$script:BasName"
                $pipId = "$script:Rg/providers/Microsoft.Network/publicIPAddresses/pip-bas-zscc-dev-westus2"
                $null = Set-ZsParityResource -Id $pipId -Owned -Resource @{ sku=@{ name='Standard' }; properties=@{ ipAddress='20.5.5.5' } }
                $null = Set-ZsParityResource -Id $basId -Owned -Resource @{ location='westus2'; sku=@{ name='Standard' }
                    properties=@{ scaleUnits=2; ipConfigurations=@(@{ name='bastion-ipcfg'; properties=@{ publicIPAddress=@{ id=$pipId }; subnet=@{ id="$script:Vnet/subnets/AzureBastionSubnet" } } }) } }
                $null = New-ZsBastion -VnetPath $script:Vnet -Confirm:$false
                $seq = @($script:ArmCalls | Where-Object { $_.Method -in 'PUT','DELETE' -and $_.Uri -notmatch '/networkSecurityGroups/' } | ForEach-Object { "$($_.Method) $((($_.Uri -split '\?')[0] -split '/')[-2])" })
                $seq | Should -Be @('DELETE bastionHosts','DELETE publicIPAddresses','PUT bastionHosts')
                (Get-ZsParityCall -Method PUT -Match '/bastionHosts/')[0].Body.properties.enablePrivateOnlyBastion | Should -BeTrue
            }
        }
    }

    Context 'Workload route table' {
        It 'points its own table''s default route back at the load balancer and turns BGP propagation off, keeping other routes' {
            InModuleScope ZscalerCloudConnector {
                $vnet = "$script:Rg/providers/Microsoft.Network/virtualNetworks/vnet-zscc"
                $rtId = "$script:Rg/providers/Microsoft.Network/routeTables/$(New-ZsResourceName -Prefix 'rt-zscc-wl' -Environment 'dev' -Location 'westus2')"
                $null = Set-ZsParityResource -Id $rtId -Owned -Resource @{ location='westus2'; properties=@{ disableBgpRoutePropagation=$false
                    routes=@(
                        @{ name='default-to-zscc'; properties=@{ addressPrefix='0.0.0.0/0'; nextHopType='VirtualAppliance'; nextHopIpAddress='10.0.3.9' } }
                        @{ name='r-onprem'; properties=@{ addressPrefix='10.10.0.0/16'; nextHopType='VirtualNetworkGateway' } }
                    ) } }
                $null = Set-ZsParityResource -Id "$vnet/subnets/snet-zscc-workload" -Resource @{ properties=@{ addressPrefix='10.0.10.0/24'; routeTable=@{ id=$rtId } } }
                $null = New-ZsPrivateNetwork -NextHopIp '10.0.3.4' -WorkloadSubnetCidr '10.0.10.0/24' -VnetPath $vnet -Confirm:$false
                $put = Get-ZsParityCall -Method PUT -Match '/routeTables/'
                $put.Count | Should -Be 1
                $put[0].Body.properties.disableBgpRoutePropagation | Should -BeTrue
                $routes = @($put[0].Body.properties.routes)
                $routes.Count | Should -Be 2
                $def = @($routes | Where-Object { $_.name -eq 'default-to-zscc' })[0]
                $def.properties.nextHopType | Should -Be 'VirtualAppliance'
                $def.properties.nextHopIpAddress | Should -Be '10.0.3.4'
                @($routes | Where-Object { $_.name -eq 'r-onprem' }).Count | Should -Be 1
                (Get-ZsParityCall -Method PUT -Match '/subnets/').Count | Should -Be 0

                Reset-ZsParityArm
                $null = Set-ZsParityResource -Id $rtId -Resource @{ location='westus2'; properties=@{ disableBgpRoutePropagation=$false; routes=@() } }
                $null = Set-ZsParityResource -Id "$vnet/subnets/snet-zscc-workload" -Resource @{ properties=@{ addressPrefix='10.0.10.0/24'; routeTable=@{ id=$rtId } } }
                $null = New-ZsPrivateNetwork -NextHopIp '10.0.3.4' -WorkloadSubnetCidr '10.0.10.0/24' -VnetPath $vnet -Confirm:$false
                (Get-ZsParityCall -Method PUT -Match '/routeTables/').Count | Should -Be 0
                ($script:ParityLog -join "`n") | Should -Match 'no managed-by tag'
            }
        }
    }

    Context 'Connector scale sets' {
        BeforeEach {
            InModuleScope ZscalerCloudConnector {
                Mock New-ZsLifecycleFunctionApp { [PSCustomObject]@{ FunctionApp='func-zscc-pstr01'; FunctionAppId='/fa'; StorageAccount='stzsccpstr01'
                    StorageUri='/st?x'; StoragePath='/st'; AppInsightsId='/ai'; IdentityPrincipalId='fa-principal'; FuncAppSubnetId='/sub/func' } }
                Mock Test-AcceleratedNetworkingSupport { $true }
                Mock Set-ZsHealthRemediationRole { $script:ArmCalls.Add([PSCustomObject]@{ Method='REMEDIATION'; Uri=$ConnectorIdentityId
                    Body=@{ Principal=$PrincipalId; Subnets=$SubnetIds; Role=$RoleName; Vmss=$VmssIds } }) }
                $script:VmssArgs = @{ MgmtSubnetId='/sub/mgmt'; ServiceSubnetId='/sub/svc'; LbBackendId='/lb/be-zscc'
                    CcIdentityResourceId='/id/cc'; CcIdentityClientId='cc-client'; KeyVaultUri='https://kv-zscc-1.vault.azure.net/'
                    ProvisioningUrl='https://connector.zscalerthree.net/api/v1/provUrl?name=az'; SshPublicKey='ssh-rsa AAAA'; Confirm=$false }
            }
        }

        It 'builds each zone''s scale set as Terraform does: management NIC primary, service NIC forwarding into the backend pool' {
            InModuleScope ZscalerCloudConnector {
                $null = New-ZsCloudConnectorVmss @script:VmssArgs -Zones @('1','2') -ScheduledScaling
                $vmss = Get-ZsParityCall -Method PUT -Match '/virtualMachineScaleSets/'
                $vmss.Count | Should -Be 2
                $b = $vmss[0].Body
                $b.zones | Should -Be @('1')
                $vmss[1].Body.zones | Should -Be @('2')
                $b.sku.capacity | Should -Be 2
                $b.tags['LegacyVMNVA'] | Should -Be 'true'
                $b.properties.orchestrationMode | Should -Be 'Flexible'
                $b.properties.platformFaultDomainCount | Should -Be 1
                $vp = $b.properties.virtualMachineProfile
                $vp.scheduledEventsProfile.terminateNotificationProfile.enable | Should -BeTrue
                $vp.scheduledEventsProfile.terminateNotificationProfile.notBeforeTimeout | Should -Be 'PT5M'
                $vp.storageProfile.osDisk.managedDisk.storageAccountType | Should -Be 'Premium_LRS'
                $nics = $vp.networkProfile.networkInterfaceConfigurations
                $nics[0].name | Should -Be 'nic-mgmt'
                $nics[0].properties.primary | Should -BeTrue
                $nics[0].properties.enableIPForwarding | Should -BeFalse
                $nics[0].properties.enableAcceleratedNetworking | Should -BeFalse
                $nics[0].properties.ipConfigurations[0].properties.subnet.id | Should -Be '/sub/mgmt'
                $nics[0].properties.ipConfigurations[0].properties.ContainsKey('loadBalancerBackendAddressPools') | Should -BeFalse
                $nics[1].name | Should -Be 'nic-svc'
                $nics[1].properties.primary | Should -BeFalse
                $nics[1].properties.enableIPForwarding | Should -BeTrue
                $nics[1].properties.enableAcceleratedNetworking | Should -BeTrue
                $nics[1].properties.ipConfigurations[0].properties.subnet.id | Should -Be '/sub/svc'
                $nics[1].properties.ipConfigurations[0].properties.loadBalancerBackendAddressPools[0].id | Should -Be '/lb/be-zscc'
                $ud = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($vp.userData))
                ($ud -split "`n") | Should -Be @('[ZSCALER]','CC_URL=connector.zscalerthree.net/api/v1/provUrl?name=az',
                    'AZURE_VAULT_URL=https://kv-zscc-1.vault.azure.net/','HTTP_PROBE_PORT=50000','AZURE_MANAGED_IDENTITY_CLIENT_ID=cc-client','FIPS_ENABLED=False')
                $vp.osProfile.customData | Should -Be $vp.userData
            }
        }

        It 'scales on the connectors'' own CPU metric with the Terraform thresholds, windows, cooldowns and schedule' {
            InModuleScope ZscalerCloudConnector {
                $null = New-ZsCloudConnectorVmss @script:VmssArgs -Zones @('1','2') -ScheduledScaling
                $as = Get-ZsParityCall -Method PUT -Match '/autoscaleSettings/'
                $as.Count | Should -Be 2
                $as[0].Body.properties.enabled | Should -BeTrue
                $as[0].Body.properties.targetResourceUri | Should -Match '/virtualMachineScaleSets/vmss-zscc-z1-dev-westus2$'
                $profiles = @($as[0].Body.properties.profiles)
                $profiles.Count | Should -Be 2
                $def = $profiles[0]
                $def.name | Should -Be 'default-profile'
                $def.capacity.minimum | Should -Be '2'; $def.capacity.maximum | Should -Be '4'; $def.capacity.default | Should -Be '2'
                @($def.recurrence.schedule.days).Count | Should -Be 7
                $def.recurrence.schedule.hours | Should -Be @(17)
                $def.recurrence.schedule.minutes | Should -Be @(0)
                foreach ($prof in $profiles) {
                    $out = $prof.rules[0]; $in = $prof.rules[1]
                    foreach ($rule in @($out, $in)) {
                        $rule.metricTrigger.metricName | Should -Be 'smedge_metrics'
                        $rule.metricTrigger.metricNamespace | Should -Be 'Zscaler/CloudConnectors'
                        $rule.metricTrigger.dimensions[0].DimensionName | Should -Be 'metric_name'
                        $rule.metricTrigger.dimensions[0].Values | Should -Be @('smedge_cpu_utilization')
                        $rule.metricTrigger.timeGrain | Should -Be 'PT1M'
                        $rule.metricTrigger.statistic | Should -Be 'Average'
                        $rule.metricTrigger.timeAggregation | Should -Be 'Average'
                        $rule.scaleAction.type | Should -Be 'ChangeCount'
                        $rule.scaleAction.value | Should -Be '1'
                    }
                    $out.metricTrigger.operator | Should -Be 'GreaterThan'; $out.metricTrigger.threshold | Should -Be 70
                    $out.metricTrigger.timeWindow | Should -Be 'PT5M'
                    $out.scaleAction.direction | Should -Be 'Increase'; $out.scaleAction.cooldown | Should -Be 'PT5M'
                    $in.metricTrigger.operator | Should -Be 'LessThan'; $in.metricTrigger.threshold | Should -Be 30
                    $in.metricTrigger.timeWindow | Should -Be 'PT10M'
                    $in.scaleAction.direction | Should -Be 'Decrease'; $in.scaleAction.cooldown | Should -Be 'PT10M'
                }
                $sch = $profiles[1]
                $sch.name | Should -Be 'scheduled-profile'
                $sch.capacity.minimum | Should -Be '1'; $sch.capacity.default | Should -Be '1'; $sch.capacity.maximum | Should -Be '4'
                $sch.recurrence.schedule.days | Should -Be @('Monday','Tuesday','Wednesday','Thursday','Friday')
                $sch.recurrence.schedule.hours | Should -Be @(9)
                $sch.recurrence.schedule.timeZone | Should -Be 'Pacific Standard Time'

                $rem = Get-ZsParityCall -Method REMEDIATION
                $rem.Count | Should -Be 1
                $rem[0].Uri | Should -Be '/id/cc'
                $rem[0].Body.Role | Should -Be 'Virtual Machine Contributor'
                @($rem[0].Body.Vmss).Count | Should -Be 2

                # Without scheduled scaling there is one profile and no recurrence.
                Reset-ZsParityArm
                $null = New-ZsCloudConnectorVmss @script:VmssArgs -Zones @('1')
                $one = @((Get-ZsParityCall -Method PUT -Match '/autoscaleSettings/')[0].Body.properties.profiles)
                $one.Count | Should -Be 1
                $one[0].ContainsKey('recurrence') | Should -BeFalse
            }
        }

        It 'refuses capacities Azure would reject before anything is created' {
            InModuleScope ZscalerCloudConnector {
                Mock New-ZsLifecycleFunctionApp { throw 'not reached' }
                Get-ZsParityErrorId { New-ZsCloudConnectorVmss @script:VmssArgs -MinInstances 3 -DesiredInstances 2 -MaxInstances 4 } | Should -Match '^ZsInvalidInstanceRange'
                Get-ZsParityErrorId { New-ZsCloudConnectorVmss @script:VmssArgs -MinInstances 2 -DesiredInstances 5 -MaxInstances 4 } | Should -Match '^ZsInvalidInstanceRange'
                Get-ZsParityErrorId { New-ZsCloudConnectorVmss @script:VmssArgs -MaxInstances 4 -ScheduledScaling -ScheduledMinInstances 5 } | Should -Match '^ZsInvalidInstanceRange'
                Get-ZsParityErrorId { New-ZsCloudConnectorVmss @script:VmssArgs -MaxInstances 17 } | Should -Match 'ParameterArgumentValidationError'
                $script:ArmCalls.Count | Should -Be 0
            }
        }

        It 'surfaces the reason when a step inside the scale set deployment fails' {
            InModuleScope ZscalerCloudConnector {
                Mock Invoke-ArmPut {
                    if ($Uri -match '/virtualMachineScaleSets/') { throw [System.InvalidOperationException]::new("RequestDisallowedByPolicy: 'Network interfaces should disable IP forwarding'") }
                }
                $msg = ''
                try { New-ZsCloudConnectorVmss @script:VmssArgs -Zones @('1') | Out-Null } catch { $msg = $_.Exception.Message }
                $msg | Should -Match 'RequestDisallowedByPolicy'
                $msg | Should -Match 'IP forwarding'
            }
        }

        It 'updates an existing scale set''s bootstrap and LegacyVMNVA tag by PATCH, leaving its capacity to autoscale' {
            InModuleScope ZscalerCloudConnector {
                $id = "$script:Rg/providers/Microsoft.Compute/virtualMachineScaleSets/vmss-zscc-z1-dev-westus2"
                $oldUd = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("[ZSCALER]`nCC_URL=https://connector.zscalerthree.net/api/v1/provUrl?name=az"))
                $null = Set-ZsParityResource -Id $id -Owned -Resource @{ location='westus2'; sku=@{ name='Standard_D2s_v3'; capacity=3 }
                    properties=@{ orchestrationMode='Flexible'; virtualMachineProfile=@{ userData=$oldUd } } }
                $null = New-ZsCloudConnectorVmss @script:VmssArgs -Zones @('1')
                (Get-ZsParityCall -Method PUT -Match '/virtualMachineScaleSets/').Count | Should -Be 0
                $patch = Get-ZsParityCall -Method PATCH -Match '/virtualMachineScaleSets/'
                $patch.Count | Should -Be 1
                $patch[0].Body.ContainsKey('sku') | Should -BeFalse
                $patch[0].Body.tags['LegacyVMNVA'] | Should -Be 'true'
                $patch[0].Body.tags['managed-by'] | Should -Be 'ZscalerCloudConnector-PSModule'
                $vp = $patch[0].Body.properties.virtualMachineProfile
                [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($vp.userData)) | Should -Match '(?m)^CC_URL=connector\.zscalerthree\.net/'
                $vp.osProfile.customData | Should -Be $vp.userData
                (Get-ZsParityCall -Method PUT -Match '/autoscaleSettings/').Count | Should -Be 1

                # In line: nothing patched.
                $null = Set-ZsParityResource -Id $id -Owned -Resource @{ location='westus2'; sku=@{ name='Standard_D2s_v3'; capacity=3 }
                    properties=@{ orchestrationMode='Flexible'; virtualMachineProfile=@{ userData=$vp.userData } } }
                ($script:ArmStore[$id.ToLowerInvariant()]).tags | Add-Member -NotePropertyName 'LegacyVMNVA' -NotePropertyValue 'true' -Force
                $script:ArmCalls.Clear()
                $null = New-ZsCloudConnectorVmss @script:VmssArgs -Zones @('1')
                (Get-ZsParityCall -Method PATCH).Count | Should -Be 0
            }
        }

        It 'dry-runs over an existing scale set through its reconcile, writing nothing, with a placeholder for a zone it would add' {
            InModuleScope ZscalerCloudConnector {
                $script:ZsSession.ResourceGroupName = 'rg-zscc-dev-westus2'
                $id = "$script:Rg/providers/Microsoft.Compute/virtualMachineScaleSets/vmss-zscc-z1-dev-westus2"
                $oldUd = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("[ZSCALER]`nCC_URL=https://connector.zscalerthree.net/api/v1/provUrl?name=az"))
                $null = Set-ZsParityResource -Id $id -Owned -Resource @{ location='westus2'; sku=@{ name='Standard_D2s_v3'; capacity=3 }
                    properties=@{ orchestrationMode='Flexible'; virtualMachineProfile=@{ userData=$oldUd } } }
                $r = New-ZsCloudConnectorVmss @script:VmssArgs -Zones @('1','2') -WhatIf
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0
                (Get-ZsParityCall -Method PATCH).Count | Should -Be 0
                Should -Invoke New-ZsLifecycleFunctionApp -Times 1 -Exactly
                @($r.Zones | ForEach-Object { $_.VmssId }) | Should -Be @($id, '(VMSS z2 created at deploy time)')
            }
        }
    }

    Context 'Health remediation rights' {
        It 'grants Virtual Machine Contributor on the group and the subnets, Managed Identity Operator on the identity, and drops the old per-scale-set grant' {
            InModuleScope ZscalerCloudConnector {
                Mock Set-ZsRoleAssignment { $script:ArmCalls.Add([PSCustomObject]@{ Method='ROLE'; Uri=$Scope; Body=$RoleDefinitionId }) }
                $legacy = Resolve-ZsRoleDefinitionScope -RoleName $script:ZsLegacyRemediationRoleName
                $null = Set-ZsParityResource -Id $legacy.ResourceId -Resource @{ properties=@{ roleName=$script:ZsLegacyRemediationRoleName } }
                $vmss = "$script:Rg/providers/Microsoft.Compute/virtualMachineScaleSets/vmss-zscc-z1-dev-westus2"
                $null = Set-ZsParityResource -Id "$vmss/providers/Microsoft.Authorization/roleAssignments" -Resource @{ value=@(
                    @{ id="$vmss/providers/Microsoft.Authorization/roleAssignments/old"; name='old'; properties=@{ roleDefinitionId=$legacy.ResourceId; scope=$vmss; principalId='p' } }
                    @{ id="$script:Rg/providers/Microsoft.Authorization/roleAssignments/inherited"; name='inherited'; properties=@{ roleDefinitionId=$legacy.ResourceId; scope=$script:Rg; principalId='p' } }
                    @{ id="$vmss/providers/Microsoft.Authorization/roleAssignments/other"; name='other'; properties=@{ roleDefinitionId="$script:Sub/providers/Microsoft.Authorization/roleDefinitions/acdd72a7-3385-48ef-bd42-f606fba81ae7"; scope=$vmss; principalId='p' } }
                ) }
                Set-ZsHealthRemediationRole -PrincipalId 'p' -ConnectorIdentityId '/id/cc' -SubnetIds @('/sub/mgmt','/sub/svc') -VmssIds @($vmss) -Confirm:$false
                $roles = Get-ZsParityCall -Method ROLE
                @($roles.Uri) | Should -Be @($script:Rg, '/sub/mgmt', '/sub/svc', '/id/cc')
                $roles[0].Body | Should -Match '/roleDefinitions/9980e02c-c2be-4d73-94e8-173b1dc7cf3c$'
                $roles[1].Body | Should -Be $roles[0].Body
                $roles[3].Body | Should -Match '/roleDefinitions/f1a07417-d97a-45cb-824c-7a7467783830$'
                $del = Get-ZsParityCall -Method DELETE
                $del.Count | Should -Be 1
                $del[0].Uri | Should -Match '/roleAssignments/old\?'
                @($script:ZsManifest.Resources['RoleDefinition'])[0].ResourceId | Should -Be $legacy.ResourceId
            }
        }

        It 'defines a replacement role with exactly the actions replacement takes, once, and grants that instead' {
            InModuleScope ZscalerCloudConnector {
                Mock Set-ZsRoleAssignment { $script:ArmCalls.Add([PSCustomObject]@{ Method='ROLE'; Uri=$Scope; Body=$RoleDefinitionId }) }
                # The platform's VNet in a group of its own, in another subscription.
                $hub = '/subscriptions/99999999-9999-9999-9999-999999999999/resourceGroups/hub-rg'
                $subnets = @("$hub/providers/Microsoft.Network/virtualNetworks/hub-vnet/subnets/mgmt", "$hub/providers/Microsoft.Network/virtualNetworks/hub-vnet/subnets/svc")
                # MD5 of subscription|group|name.
                $roleId = "$script:Rg/providers/Microsoft.Authorization/roleDefinitions/d847d8c8-3dac-4d2f-d986-4418babb8f68"
                $run = { Set-ZsHealthRemediationRole -PrincipalId 'p' -ConnectorIdentityId '/id/cc' -SubnetIds $subnets -CreateRole -Confirm:$false }

                & $run
                $defs = Get-ZsParityCall -Method PUT -Match '/roleDefinitions/'
                $defs.Count | Should -Be 1
                ($defs[0].Uri -split '\?')[0] | Should -Be $roleId
                $p = $defs[0].Body.properties
                $p.roleName | Should -Be 'ZSCC Connector Replacement pstr01'
                @($p.permissions[0].actions | Sort-Object) | Should -Be @(@(
                    'Microsoft.Compute/virtualMachineScaleSets/write'
                    'Microsoft.Compute/virtualMachineScaleSets/delete/action'
                    'Microsoft.Compute/virtualMachines/write'
                    'Microsoft.Compute/virtualMachines/delete'
                    'Microsoft.Network/networkInterfaces/write'
                    'Microsoft.Network/networkInterfaces/delete'
                    'Microsoft.Network/networkInterfaces/join/action'
                    'Microsoft.Compute/disks/write'
                    'Microsoft.Compute/disks/delete'
                    'Microsoft.Network/loadBalancers/backendAddressPools/join/action'
                    'Microsoft.Network/virtualNetworks/subnets/join/action'
                ) | Sort-Object)
                @($p.permissions[0].dataActions).Count | Should -Be 0
                @($p.assignableScopes) | Should -Be @($script:Rg, $hub)
                $roles = Get-ZsParityCall -Method ROLE
                @($roles.Uri) | Should -Be (@($script:Rg) + $subnets + '/id/cc')
                @($roles[0..2] | ForEach-Object { $_.Body } | Sort-Object -Unique) | Should -Be @($roleId)
                $roles[3].Body | Should -Match '/roleDefinitions/f1a07417-d97a-45cb-824c-7a7467783830$'
                @($script:ZsManifest.Resources['RoleDefinition'] | Where-Object { $_.ResourceId -eq $roleId }).Count | Should -Be 1

                # The next run finds the role as it was left, writes nothing, and records it again for teardown.
                Initialize-ZsManifest -SubscriptionId $script:ZsSession.SubscriptionId -ResourceGroupName $script:ZsSession.ResourceGroupName -Location 'westus2'
                $script:ArmCalls.Clear()
                & $run
                (Get-ZsParityCall -Method PUT -Match '/roleDefinitions/').Count | Should -Be 0
                @($script:ZsManifest.Resources['RoleDefinition'] | Where-Object { $_.ResourceId -eq $roleId }).Count | Should -Be 1

                # One widened by hand is put back.
                $live = $script:ArmStore[$roleId.ToLowerInvariant()]
                $live.properties.permissions[0].actions = @($live.properties.permissions[0].actions) + 'Microsoft.Compute/virtualMachines/runCommand/action'
                $script:ArmCalls.Clear()
                & $run
                (Get-ZsParityCall -Method PUT -Match '/roleDefinitions/').Count | Should -Be 1
            }
        }

        It 'takes back the Virtual Machine Contributor grants it made once its own role replaces them, and its own once that is no longer asked for' {
            InModuleScope ZscalerCloudConnector {
                Mock Set-ZsRoleAssignment { $script:ArmCalls.Add([PSCustomObject]@{ Method='ROLE'; Uri=$Scope; Body=$RoleDefinitionId }) }
                # The names Set-ZsRoleAssignment gives its assignments.
                $nameOf = { param($scope, $role)
                    $md5 = [System.Security.Cryptography.MD5]::Create()
                    try { [guid]::new($md5.ComputeHash([Text.Encoding]::UTF8.GetBytes("$($scope.ToLower())|$($role.ToLower())|p"))).ToString() } finally { $md5.Dispose() } }
                $vmc = "$script:Sub/providers/Microsoft.Authorization/roleDefinitions/9980e02c-c2be-4d73-94e8-173b1dc7cf3c"
                $own = "$script:Rg/providers/Microsoft.Authorization/roleDefinitions/d847d8c8-3dac-4d2f-d986-4418babb8f68"
                $subnet = "$script:Sub/resourceGroups/rg-net/providers/Microsoft.Network/virtualNetworks/v/subnets/mgmt"
                $grantsOf = { param($role) @($script:Rg, $subnet) | ForEach-Object { "$_/providers/Microsoft.Authorization/roleAssignments/$(& $nameOf $_ $role)" } }
                foreach ($id in (& $grantsOf $vmc)) { $null = Set-ZsParityResource -Id $id -Resource @{ properties=@{ roleDefinitionId=$vmc; principalId='p' } } }
                # Somebody else's grant of the same role, under a name of their own.
                $null = Set-ZsParityResource -Id "$script:Rg/providers/Microsoft.Authorization/roleAssignments/theirs" -Resource @{ properties=@{ roleDefinitionId=$vmc; principalId='p' } }

                Set-ZsHealthRemediationRole -PrincipalId 'p' -ConnectorIdentityId '/id/cc' -SubnetIds @($subnet) -CreateRole -Confirm:$false
                @((Get-ZsParityCall -Method DELETE) | ForEach-Object { ($_.Uri -split '\?')[0] } | Sort-Object) | Should -Be @(& $grantsOf $vmc | Sort-Object)

                foreach ($id in (& $grantsOf $own)) { $null = Set-ZsParityResource -Id $id -Resource @{ properties=@{ roleDefinitionId=$own; principalId='p' } } }
                Initialize-ZsManifest -SubscriptionId $script:ZsSession.SubscriptionId -ResourceGroupName $script:ZsSession.ResourceGroupName -Location 'westus2'
                $script:ArmCalls.Clear()
                Set-ZsHealthRemediationRole -PrincipalId 'p' -ConnectorIdentityId '/id/cc' -SubnetIds @($subnet) -Confirm:$false
                @((Get-ZsParityCall -Method DELETE) | ForEach-Object { ($_.Uri -split '\?')[0] } | Sort-Object) | Should -Be @(& $grantsOf $own | Sort-Object)
                @((Get-ZsParityCall -Method ROLE) | ForEach-Object { $_.Body } | Select-Object -First 2 | Sort-Object -Unique) | Should -Be @($vmc)
                # The role stays defined until teardown, which deletes it once nothing is assigned to it.
                (Get-ZsParityCall -Method PUT -Match '/roleDefinitions/').Count | Should -Be 0
                @($script:ZsManifest.Resources['RoleDefinition'] | Where-Object { $_.ResourceId -eq $own }).Count | Should -Be 1
                $script:ArmStore.ContainsKey("$script:Rg/providers/Microsoft.Authorization/roleAssignments/theirs".ToLowerInvariant()) | Should -BeTrue
            }
        }

        It 'sees at teardown that a role defined at the resource group is still assigned, though Azure names it under the subscription' {
            InModuleScope ZscalerCloudConnector {
                $guid = 'd847d8c8-3dac-4d2f-d986-4418babb8f68'
                $null = Set-ZsParityResource -Id "$script:Sub/providers/Microsoft.Authorization/roleAssignments" -Resource @{ value=@(
                    @{ id="$script:Rg/providers/Microsoft.Authorization/roleAssignments/a1"; name='a1'
                       properties=@{ roleDefinitionId="$script:Sub/providers/Microsoft.Authorization/roleDefinitions/$guid"; scope=$script:Rg; principalId='p' } }) }
                $use = Test-ZsRoleDefinitionInUse -RoleDefinitionId "$script:Rg/providers/Microsoft.Authorization/roleDefinitions/$guid"
                $use.InUse | Should -BeTrue
                $use.Count | Should -Be 1
            }
        }

        It 'previews the switch to its own role in a dry run: no role written, no grant made or taken back' {
            InModuleScope ZscalerCloudConnector {
                $vmc = "$script:Sub/providers/Microsoft.Authorization/roleDefinitions/9980e02c-c2be-4d73-94e8-173b1dc7cf3c"
                $cc  = "$script:Rg/providers/Microsoft.ManagedIdentity/userAssignedIdentities/id-zscc-cc"
                foreach ($scope in @($script:Rg, $cc)) { $null = Set-ZsParityResource -Id "$scope/providers/Microsoft.Authorization/roleAssignments" -Resource @{ value=@() } }
                $null = Set-ZsParityResource -Id "$script:Rg/providers/Microsoft.Authorization/roleAssignments/$(Get-ZsRoleAssignmentName -Scope $script:Rg -RoleDefinitionId $vmc -PrincipalId 'p')" `
                    -Resource @{ properties=@{ roleDefinitionId=$vmc; principalId='p' } }
                Set-ZsHealthRemediationRole -PrincipalId 'p' -ConnectorIdentityId $cc -CreateRole -WhatIf
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0
                (Get-ZsParityCall -Method DELETE).Count | Should -Be 0
                $script:ZsManifest.Resources.Contains('RoleDefinition') | Should -BeFalse
                $script:ZsManifest.Resources.Contains('RoleAssignment') | Should -BeFalse
            }
        }

        It 'keeps the grant of its own role when RemediationRoleName names that role instead of CreateRemediationRole defining it' {
            InModuleScope ZscalerCloudConnector {
                Mock Set-ZsRoleAssignment { $script:ArmCalls.Add([PSCustomObject]@{ Method='ROLE'; Uri=$Scope; Body=$RoleDefinitionId }) }
                $guid = 'd847d8c8-3dac-4d2f-d986-4418babb8f68'
                $own  = "$script:Rg/providers/Microsoft.Authorization/roleDefinitions/$guid"
                $null = Set-ZsParityResource -Id $own -Resource @{ properties=@{ roleName='ZSCC Connector Replacement pstr01' } }
                # The lookup by name returns the role under the subscription.
                $null = Set-ZsParityResource -Id "$script:Sub/providers/Microsoft.Authorization/roleDefinitions" -Resource @{ value=@(
                    @{ id="$script:Sub/providers/Microsoft.Authorization/roleDefinitions/$guid"; properties=@{ roleName='ZSCC Connector Replacement pstr01' } }) }
                # The grant an earlier CreateRemediationRole run made.
                $null = Set-ZsParityResource -Id "$script:Rg/providers/Microsoft.Authorization/roleAssignments/$(Get-ZsRoleAssignmentName -Scope $script:Rg -RoleDefinitionId $own -PrincipalId 'p')" `
                    -Resource @{ properties=@{ roleDefinitionId="$script:Sub/providers/Microsoft.Authorization/roleDefinitions/$guid"; principalId='p' } }
                Set-ZsHealthRemediationRole -PrincipalId 'p' -ConnectorIdentityId '/id/cc' -RoleName 'ZSCC Connector Replacement pstr01' -Confirm:$false
                (Get-ZsParityCall -Method DELETE).Count | Should -Be 0
                (Get-ZsParityCall -Method ROLE)[0].Body | Should -Be "$script:Sub/providers/Microsoft.Authorization/roleDefinitions/$guid"
            }
        }

        It 'asks before each grant, so a dry run makes none and records none' {
            InModuleScope ZscalerCloudConnector {
                $role = "$script:Sub/providers/Microsoft.Authorization/roleDefinitions/9980e02c-c2be-4d73-94e8-173b1dc7cf3c"
                $null = Set-ZsParityResource -Id "$script:Rg/providers/Microsoft.Authorization/roleAssignments" -Resource @{ value=@() }
                Set-ZsRoleAssignment -Scope $script:Rg -RoleDefinitionId $role -PrincipalId 'p' -WhatIf
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0
                $script:ZsManifest.Resources.Contains('RoleAssignment') | Should -BeFalse
            }
        }

        It 'counts an existing role assignment only when it sits at the scope or above it' {
            InModuleScope ZscalerCloudConnector {
                $role = "$script:Sub/providers/Microsoft.Authorization/roleDefinitions/9980e02c-c2be-4d73-94e8-173b1dc7cf3c"
                $vmss = "$script:Rg/providers/Microsoft.Compute/virtualMachineScaleSets/v1"
                $list = "$script:Rg/providers/Microsoft.Authorization/roleAssignments"
                $null = Set-ZsParityResource -Id $list -Resource @{ value=@(@{ id="$vmss/providers/Microsoft.Authorization/roleAssignments/a1"; name='a1'
                    properties=@{ roleDefinitionId=$role; scope=$vmss; principalId='p' } }) }
                Set-ZsRoleAssignment -Scope $script:Rg -RoleDefinitionId $role -PrincipalId 'p'
                (Get-ZsParityCall -Method PUT -Match '/roleAssignments/').Count | Should -Be 1

                $script:ArmCalls.Clear()
                $null = Set-ZsParityResource -Id $list -Resource @{ value=@(@{ id="$script:Sub/providers/Microsoft.Authorization/roleAssignments/a2"; name='a2'
                    properties=@{ roleDefinitionId=$role; scope=$script:Sub; principalId='p' } }) }
                Set-ZsRoleAssignment -Scope $script:Rg -RoleDefinitionId $role -PrincipalId 'p'
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0
            }
        }

        It 'still owns an assignment 5.4.1.0 made with a group-scoped custom role, so teardown removes it' {
            InModuleScope ZscalerCloudConnector {
                # A brownfield deployment defines its custom roles at the resource group, and 5.4.1.0
                # named the assignment from that group-scoped definition ID.
                $guid = '0d8bc9b8-2a6f-4b54-a0a3-6d6f7c1d2e01'
                $role = "$script:Rg/providers/Microsoft.Authorization/roleDefinitions/$guid"
                $md5 = [System.Security.Cryptography.MD5]::Create()
                $name = [guid]::new($md5.ComputeHash([Text.Encoding]::UTF8.GetBytes("$($script:Rg.ToLower())|$($role.ToLower())|p"))).ToString()
                $md5.Dispose()
                $null = Set-ZsParityResource -Id "$script:Rg/providers/Microsoft.Authorization/roleAssignments" -Resource @{ value=@(
                    @{ id="$script:Rg/providers/Microsoft.Authorization/roleAssignments/$name"; name=$name
                       properties=@{ roleDefinitionId="$script:Sub/providers/Microsoft.Authorization/roleDefinitions/$guid"; scope=$script:Rg; principalId='p' } }) }
                Set-ZsRoleAssignment -Scope $script:Rg -RoleDefinitionId $role -PrincipalId 'p'
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0
                $entry = @($script:ZsManifest.Resources['RoleAssignment'] | Where-Object { $_.Name -eq $name })
                $entry.Count | Should -Be 1
                $entry[0].PreExisting | Should -BeFalse
            }
        }
    }

    Context 'Private DNS' {
        It 'uses the platform''s zone as it is in hub mode, and otherwise its own zone with the link the VNet already has' {
            InModuleScope ZscalerCloudConnector {
                $vnet = '/subscriptions/22222222-2222-2222-2222-222222222222/resourceGroups/rg-spoke/providers/Microsoft.Network/virtualNetworks/vnet-spoke'
                $hubZone = '/subscriptions/33333333-3333-3333-3333-333333333333/resourceGroups/rg-dns/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net'
                $null = Set-ZsParityResource -Id $hubZone -Resource @{ location='global' }
                Resolve-ZsPrivateDnsZone -ZoneName 'privatelink.vaultcore.azure.net' -VnetId $vnet -HubResourceGroupName 'rg-dns' `
                    -HubSubscriptionId '33333333-3333-3333-3333-333333333333' -Confirm:$false | Should -Be $hubZone
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0
                @($script:ZsManifest.Resources['PrivateDnsZone'])[0].PreExisting | Should -BeTrue
                { Resolve-ZsPrivateDnsZone -ZoneName 'privatelink.blob.core.windows.net' -VnetId $vnet -HubResourceGroupName 'rg-dns' `
                    -HubSubscriptionId '33333333-3333-3333-3333-333333333333' -Confirm:$false } | Should -Throw '*was not found*'

                $own = "$script:Rg/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.windows.net"
                $null = Set-ZsParityResource -Id "$own/virtualNetworkLinks" -Resource @{ value=@(@{ id="$own/virtualNetworkLinks/platform-link"; name='platform-link'
                    properties=@{ virtualNetwork=@{ id=$vnet } } }) }
                Resolve-ZsPrivateDnsZone -ZoneName 'privatelink.queue.core.windows.net' -VnetId $vnet -Confirm:$false | Should -Be $own
                (Get-ZsParityCall -Method PUT -Match 'privateDnsZones/privatelink\.queue\.core\.windows\.net\?').Count | Should -Be 1
                (Get-ZsParityCall -Method PUT -Match '/virtualNetworkLinks/').Count | Should -Be 0

                $tbl = "$script:Rg/providers/Microsoft.Network/privateDnsZones/privatelink.table.core.windows.net"
                Resolve-ZsPrivateDnsZone -ZoneName 'privatelink.table.core.windows.net' -VnetId $vnet -Confirm:$false | Should -Be $tbl
                $link = Get-ZsParityCall -Method PUT -Match 'privatelink\.table\.core\.windows\.net/virtualNetworkLinks/link-zscc-pstr01\?'
                $link.Count | Should -Be 1
                $link[0].Body.properties.registrationEnabled | Should -BeFalse
                $link[0].Body.properties.virtualNetwork.id | Should -Be $vnet
            }
        }

        It 'explains how to use the hub''s zones when Azure refuses a second zone of the same name on the VNet' {
            InModuleScope ZscalerCloudConnector {
                Mock Invoke-ArmPut { if ($Uri -match '/virtualNetworkLinks/') { throw 'BadRequest: A virtual network cannot be linked to multiple zones with overlapping namespaces.' } }
                { Resolve-ZsPrivateDnsZone -ZoneName 'privatelink.blob.core.windows.net' -VnetId '/vnet/x' -Confirm:$false } |
                    Should -Throw '*PrivateDnsZoneResourceGroupName*'
            }
        }
    }

    Context 'Key Vault' {
        It 'creates the vault private with a deny-all firewall, and writes the secrets through Resource Manager' {
            InModuleScope ZscalerCloudConnector {
                Mock Wait-ArmProvision {
                    $o = $script:ArmStore[(Get-ZsParityKey $Uri)]
                    if ($Uri -match '/vaults/') { $o.properties | Add-Member -NotePropertyName 'vaultUri' -NotePropertyValue "https://$($o.name).vault.azure.net/" -Force }
                    $o
                }
                Mock Set-ZsRoleAssignment { $script:ArmCalls.Add([PSCustomObject]@{ Method='ROLE'; Uri=$Scope; Body=$RoleDefinitionId }) }
                Mock Resolve-ZsPrivateDnsZone { "/zones/$ZoneName" }
                Mock Set-ZsPrivateEndpoint { $script:ArmCalls.Add([PSCustomObject]@{ Method='PE'; Uri=$Name; Body=@{ Group=$GroupId; Zones=$ZoneIds } }); [PSCustomObject]@{ Id='/pe'; PrivateIp='10.0.1.5' } }
                $r = New-ZsKeyVault -IdentityPrincipalId 'cc' -AdminUser 'admin@x' -ApiKey (ConvertTo-SecureString 'ApiKeyValue-7f3a' -AsPlainText -Force) `
                    -AdminPassword (ConvertTo-SecureString 'PasswordValue-9c1e' -AsPlainText -Force) -VnetId '/vnet' -PrivateEndpointSubnetId '/sub/mgmt' -Confirm:$false
                $vaultPut = Get-ZsParityCall -Method PUT -Match '/vaults/kv-zscc-[0-9a-f]{8}\?'
                $vaultPut.Count | Should -Be 1
                $p = $vaultPut[0].Body.properties
                $p.publicNetworkAccess | Should -Be 'Disabled'
                $p.networkAcls.defaultAction | Should -Be 'Deny'
                $p.networkAcls.bypass | Should -Be 'AzureServices'
                $p.enableRbacAuthorization | Should -BeTrue
                $p.enablePurgeProtection | Should -BeTrue
                $p.enabledForDeployment | Should -BeFalse
                $p.enabledForTemplateDeployment | Should -BeFalse
                $secrets = Get-ZsParityCall -Method PUT -Match '/secrets/'
                @($secrets | ForEach-Object { (($_.Uri -split '\?')[0] -split '/')[-1] }) | Should -Be @('api-key','username','password')
                $secrets[0].Uri | Should -Match 'api-version=2023-07-01'
                @($secrets | ForEach-Object { $_.Body.properties.value }) | Should -Be @('ApiKeyValue-7f3a','admin@x','PasswordValue-9c1e')
                $pe = Get-ZsParityCall -Method PE
                $pe[0].Body.Group | Should -Be 'vault'
                $pe[0].Body.Zones | Should -Be @('/zones/privatelink.vaultcore.azure.net')
                $r.VaultUri | Should -Match '^https://kv-zscc-[0-9a-f]{8}\.vault\.azure\.net$'
                ($script:ParityLog -join "`n") | Should -Not -Match 'ApiKeyValue-7f3a|PasswordValue-9c1e'
            }
        }
    }

    Context 'Lifecycle Function App' {
        BeforeEach {
            InModuleScope ZscalerCloudConnector {
                Mock Resolve-ZsPrivateDnsZone { "/zones/$ZoneName" }
                Mock Set-ZsPrivateEndpoint { $script:ArmCalls.Add([PSCustomObject]@{ Method='PE'; Uri=$Name; Body=@{ Group=$GroupId; Target=$TargetId; Zones=$ZoneIds } }); [PSCustomObject]@{ Id="/pe/$Name"; PrivateIp='10.0.1.9' } }
                Mock Set-ZsFunctionAppRole { }
                Mock Set-ZsRoleAssignment { $script:ArmCalls.Add([PSCustomObject]@{ Method='ROLE'; Uri=$Scope; Body=$RoleDefinitionId }) }
                Mock New-ZsWorkspace { [PSCustomObject]@{ id='/ws' } }
                Mock New-ZsAppInsights { [PSCustomObject]@{ id='/ai'; properties=[PSCustomObject]@{ ConnectionString='InstrumentationKey=00000000-0000-0000-0000-000000000000' } } }
                Mock Build-ZsFunctionPackage { [PSCustomObject]@{ Path='/tmp/zscc-func-test.zip'; Hash='0123456789abcdef'; SizeKB=9024; Temporary=$false } }
                Mock Publish-ZsPackageToScm { $script:ArmCalls.Add([PSCustomObject]@{ Method='PUSH'; Uri=$FunctionAppName; Body=$ZipPath }) }
                $script:FaPath = "$script:Rg/providers/Microsoft.Web/sites/func-zscc-pstr01"
                $script:StorPath = "$script:Rg/providers/Microsoft.Storage/storageAccounts/stzsccpstr01"
                $script:PlanPath = "$script:Rg/providers/Microsoft.Web/serverfarms/asp-zscc-dev-westus2"
                $null = Set-ZsParityResource -Id "$script:Rg/providers/Microsoft.ManagedIdentity/userAssignedIdentities/id-zscc-funcapp-dev-westus2" -Owned `
                    -Resource @{ location='westus2'; properties=@{ principalId='fa-principal'; clientId='fa-client' } }
                $null = Set-ZsParityResource -Id "$script:FaPath/functions" -Resource @{ value=@(@{ name='func-zscc-pstr01/healthMonitor' }, @{ name='func-zscc-pstr01/synchronizeCloudResources' }) }
                $script:FaArgs = @{ KeyVaultUri='https://kv-zscc-1.vault.azure.net'; KeyVaultId="$script:Rg/providers/Microsoft.KeyVault/vaults/kv-zscc-1"
                    ProvisioningUrl='https://connector.zscalerthree.net/api/v1/provUrl?name=az'; VmssNames='vmss-zscc-z1-dev-westus2,vmss-zscc-z2-dev-westus2'
                    FuncAppSubnetId='/sub/func'; PrivateEndpointSubnetId='/sub/mgmt'; VnetId='/vnet'; Confirm=$false }
            }
        }

        It 'creates the storage account and the app private from the first request, running Zscaler''s package from its URL' {
            InModuleScope ZscalerCloudConnector {
                $r = New-ZsLifecycleFunctionApp @script:FaArgs
                $st = (Get-ZsParityCall -Method PUT -Match '/storageAccounts/stzsccpstr01\?')[0].Body
                $st.kind | Should -Be 'StorageV2'
                $st.properties.publicNetworkAccess | Should -Be 'Disabled'
                $st.properties.networkAcls.defaultAction | Should -Be 'Deny'
                @($st.properties.networkAcls.ipRules).Count | Should -Be 0
                @($st.properties.networkAcls.virtualNetworkRules).Count | Should -Be 0
                $st.properties.allowSharedKeyAccess | Should -BeFalse
                $st.properties.allowBlobPublicAccess | Should -BeFalse
                $st.properties.minimumTlsVersion | Should -Be 'TLS1_2'

                $pe = Get-ZsParityCall -Method PE
                @($pe | ForEach-Object { $_.Body.Group }) | Should -Be @('blob','queue','table')
                @($pe.Uri) | Should -Be @('pe-blob-stzsccpstr01','pe-queue-stzsccpstr01','pe-table-stzsccpstr01')
                foreach ($e in $pe) { $e.Body.Target | Should -Be $script:StorPath }
                $pe[1].Body.Zones | Should -Be @('/zones/privatelink.queue.core.windows.net')

                $plan = (Get-ZsParityCall -Method PUT -Match '/serverfarms/')[0].Body
                $plan.sku.name | Should -Be 'P0v3'
                $plan.properties.reserved | Should -BeTrue

                $site = (Get-ZsParityCall -Method PUT -Match '/sites/func-zscc-pstr01\?')[0].Body
                $site.kind | Should -Be 'functionapp,linux'
                $site.properties.publicNetworkAccess | Should -Be 'Disabled'
                $site.properties.virtualNetworkSubnetId | Should -Be '/sub/func'
                $site.properties.httpsOnly | Should -BeTrue
                $sc = $site.properties.siteConfig
                $sc.linuxFxVersion | Should -Be 'Python|3.11'
                $sc.alwaysOn | Should -BeTrue
                $sc.vnetRouteAllEnabled | Should -BeTrue
                $sc.ipSecurityRestrictionsDefaultAction | Should -Be 'Deny'
                $sc.scmIpSecurityRestrictionsDefaultAction | Should -Be 'Deny'
                $sc.ftpsState | Should -Be 'Disabled'
                $sc.minTlsVersion | Should -Be '1.2'
                $set = @{}; foreach ($s in $sc.appSettings) { $set[$s.name] = $s.value }
                $set['CC_URL'] | Should -Be 'connector.zscalerthree.net/api/v1/provUrl?name=az'
                $set['WEBSITE_RUN_FROM_PACKAGE'] | Should -Be $script:ZsVendorPackageUrl
                $set['VMSS_NAME'] | Should -Be '["vmss-zscc-z1-dev-westus2","vmss-zscc-z2-dev-westus2"]'
                $set['SUBSCRIPTION_ID'] | Should -Be '/subscriptions/11111111-1111-1111-1111-111111111111'
                $set['MANAGED_IDENTITY'] | Should -Be 'fa-client'
                $set['RESOURCE_GROUP'] | Should -Be 'rg-zscc-dev-westus2'
                $set['VAULT_URL'] | Should -Be 'https://kv-zscc-1.vault.azure.net'
                $set['TERMINATE_UNHEALTHY_INSTANCES'] | Should -Be 'true'
                $set['AzureWebJobsStorage__accountName'] | Should -Be 'stzsccpstr01'
                $set['AzureWebJobsStorage__credential'] | Should -Be 'managedidentity'
                $set['AzureWebJobsStorage__clientId'] | Should -Be 'fa-client'
                foreach ($absent in 'AzureWebJobsStorage','WEBSITE_RUN_FROM_PACKAGE_BLOB_MI_RESOURCE_ID','WEBSITE_CONTENTSHARE','WEBSITE_CONTENTAZUREFILECONNECTIONSTRING','HC_DATA_POINTS','SYNC_CRON') {
                    $set.ContainsKey($absent) | Should -BeFalse -Because $absent
                }

                @((Get-ZsParityCall -Method PUT -Match '/basicPublishingCredentialsPolicies/') | ForEach-Object { $_.Body.properties.allow }) | Should -Be @($false, $false)
                $roles = @((Get-ZsParityCall -Method ROLE) | Where-Object { $_.Uri -eq $script:StorPath })
                @($roles | ForEach-Object { ($_.Body -split '/')[-1] }) | Should -Be @('b7e6dc6d-f1e8-4753-8033-0f276bb0955b','974c5e8b-45b9-4653-ba55-5f855dd0fb88','0a9a7e1f-b9d0-4cc4-a60d-0319b160aaa3','17d1049b-9a84-46fb-8f53-869881c3d3ab')
                (Get-ZsParityCall -Method POST -Match '/restart').Count | Should -Be 0
                @($script:ArmCalls | Where-Object { $_.Uri -match 'syncfunctiontriggers' }).Count | Should -Be 0
                Should -Invoke Build-ZsFunctionPackage -Times 0 -Exactly
                Should -Invoke Publish-ZsPackageToScm -Times 0 -Exactly
                (Get-ZsParityCall -Method PE -Match '^pe-func-').Count | Should -Be 0
                $r.IdentityPrincipalId | Should -Be 'fa-principal'
            }
        }

        It 'closes a 5.4.1.0 app and storage, and rewrites its settings without the scheme or the old content share' {
            InModuleScope ZscalerCloudConnector {
                $null = Set-ZsParityResource -Id $script:StorPath -Owned -Resource @{ location='westus2'
                    properties=@{ publicNetworkAccess='Enabled'; allowSharedKeyAccess=$true
                        networkAcls=@{ defaultAction='Deny'; ipRules=@(@{ value='20.1.1.1' }); virtualNetworkRules=@(@{ id='/sub/func' }) } } }
                $null = Set-ZsParityResource -Id $script:PlanPath -Owned -Resource @{ location='westus2'; sku=@{ name='P0v3'; tier='Premium0V3' } }
                $null = Set-ZsParityResource -Id $script:FaPath -Owned -Resource @{ location='westus2'
                    properties=@{ publicNetworkAccess='Enabled'; serverFarmId=$script:PlanPath; virtualNetworkSubnetId='/sub/func' } }
                $null = Set-ZsParityResource -Id "$script:FaPath/config/appsettings/list" -Resource @{ properties=@{
                    CC_URL='https://connector.zscalerthree.net/api/v1/provUrl?name=az'; AzureWebJobsStorage='DefaultEndpointsProtocol=https;AccountKey=x'
                    WEBSITE_CONTENTSHARE='func'; WEBSITE_CONTENTAZUREFILECONNECTIONSTRING='x'; ZS_CC_BASE_URL='old' } }
                # The network this module created, with the storage service endpoint 5.4.1.0 added.
                $null = Set-ZsParityResource -Id '/vnet' -Owned -Resource @{ location='westus2'; properties=@{} }
                $null = Set-ZsParityResource -Id '/sub/func' -Resource @{ properties=@{ addressPrefix='10.157.108.224/27'
                    serviceEndpoints=@(@{ service='Microsoft.Storage'; locations=@('westus2') }, @{ service='Microsoft.KeyVault'; locations=@('*') })
                    delegations=@(@{ name='Microsoft.Web.serverFarms'; properties=@{ serviceName='Microsoft.Web/serverFarms' } }) } }

                $null = New-ZsLifecycleFunctionApp @script:FaArgs
                # Closed only once its endpoints are in place, and the subnet's storage endpoint goes
                # after that: the host keeps its queues and tables throughout.
                $order = @($script:ArmCalls | ForEach-Object { '{0} {1}' -f $_.Method, (($_.Uri -split '\?')[0]) })
                $iTable = [array]::IndexOf($order, 'PE pe-table-stzsccpstr01')
                $iClose = [array]::IndexOf($order, "PATCH $script:StorPath")
                $iSub   = [array]::IndexOf($order, 'PUT /sub/func')
                $iTable | Should -BeGreaterOrEqual 0
                $iClose | Should -BeGreaterThan $iTable
                $iSub   | Should -BeGreaterThan $iClose
                $sub = (Get-ZsParityCall -Method PUT -Match '^/sub/func\?')[0].Body.properties
                @($sub.serviceEndpoints | ForEach-Object { $_.service }) | Should -Be @('Microsoft.KeyVault')
                @($sub.delegations).Count | Should -Be 1

                $stPatch = Get-ZsParityCall -Method PATCH -Match '/storageAccounts/'
                $stPatch.Count | Should -Be 1
                $stPatch[0].Body.properties.publicNetworkAccess | Should -Be 'Disabled'
                $stPatch[0].Body.properties.networkAcls.defaultAction | Should -Be 'Deny'
                @($stPatch[0].Body.properties.networkAcls.ipRules).Count | Should -Be 0
                @($stPatch[0].Body.properties.networkAcls.virtualNetworkRules).Count | Should -Be 0
                $stPatch[0].Body.properties.allowSharedKeyAccess | Should -BeFalse
                (Get-ZsParityCall -Method PUT -Match '/storageAccounts/stzsccpstr01\?').Count | Should -Be 0

                $sitePatch = Get-ZsParityCall -Method PATCH -Match '/sites/func-zscc-pstr01\?'
                $sitePatch.Count | Should -Be 1
                $sitePatch[0].Body.properties.publicNetworkAccess | Should -Be 'Disabled'
                (Get-ZsParityCall -Method PUT -Match '/sites/func-zscc-pstr01\?').Count | Should -Be 0

                $web = (Get-ZsParityCall -Method PUT -Match '/config/web\?')[0].Body.properties
                $web.vnetRouteAllEnabled | Should -BeTrue
                $web.scmIpSecurityRestrictionsDefaultAction | Should -Be 'Deny'
                $settings = (Get-ZsParityCall -Method PUT -Match '/config/appsettings\?')[0].Body.properties
                $settings['CC_URL'] | Should -Be 'connector.zscalerthree.net/api/v1/provUrl?name=az'
                $settings['WEBSITE_RUN_FROM_PACKAGE'] | Should -Be $script:ZsVendorPackageUrl
                foreach ($gone in 'AzureWebJobsStorage','WEBSITE_CONTENTSHARE','WEBSITE_CONTENTAZUREFILECONNECTIONSTRING','ZS_CC_BASE_URL') {
                    $settings.ContainsKey($gone) | Should -BeFalse -Because $gone
                }
            }
        }

        It 'zip-deploys a module package onto the plan disk through the app private endpoint, and records it on the app' {
            InModuleScope ZscalerCloudConnector {
                $r = New-ZsLifecycleFunctionApp @script:FaArgs -FunctionPackage Module -VmssNames ''
                $site = (Get-ZsParityCall -Method PUT -Match '/sites/func-zscc-pstr01\?')[0].Body
                $set = @{}; foreach ($x in $site.properties.siteConfig.appSettings) { $set[$x.name] = $x.value }
                $set['WEBSITE_RUN_FROM_PACKAGE'] | Should -Be '1'
                $set.ContainsKey('WEBSITE_RUN_FROM_PACKAGE_BLOB_MI_RESOURCE_ID') | Should -BeFalse
                $set['CC_COMPUTER_PREFIX'] | Should -Be 'vm-zscc-pstr01'
                $order = @($script:ArmCalls | ForEach-Object { '{0} {1}' -f $_.Method, (($_.Uri -split '\?')[0]) })
                $iPe   = [array]::IndexOf($order, 'PE pe-func-zscc-pstr01')
                $iPush = [array]::IndexOf($order, 'PUSH func-zscc-pstr01')
                $iTag  = [array]::IndexOf($order, "PATCH $script:FaPath/providers/Microsoft.Resources/tags/default")
                $iPe   | Should -BeGreaterOrEqual 0
                $iPush | Should -BeGreaterThan $iPe
                $iTag  | Should -BeGreaterThan $iPush
                (Get-ZsParityCall -Method PE -Match '^pe-func-')[0].Body.Group | Should -Be 'sites'
                $tag = (Get-ZsParityCall -Method PATCH -Match '/tags/default')[0].Body
                $tag.operation | Should -Be 'Merge'
                $tag.properties.tags['zscc-function-package'] | Should -Be '0123456789abcdef'
                # The deployer is granted nothing on the storage account: only the function identity's four roles.
                @((Get-ZsParityCall -Method ROLE) | Where-Object { $_.Uri -eq $script:StorPath }).Count | Should -Be 4
                $r.PackagePending | Should -BeFalse
            }
        }

        It 'does not deploy a package the app already has' {
            InModuleScope ZscalerCloudConnector {
                $null = Set-ZsParityResource -Id $script:FaPath -Owned -Resource @{ location='westus2'
                    properties=@{ publicNetworkAccess='Disabled'; serverFarmId=$script:PlanPath; virtualNetworkSubnetId='/sub/func' } }
                $script:ArmStore[$script:FaPath.ToLowerInvariant()].tags | Add-Member -NotePropertyName 'zscc-function-package' -NotePropertyValue '0123456789abcdef' -Force
                $null = Set-ZsParityResource -Id $script:PlanPath -Owned -Resource @{ location='westus2'; sku=@{ name='P0v3'; tier='Premium0V3' } }
                $null = Set-ZsParityResource -Id "$script:FaPath/config/appsettings/list" -Resource @{ properties=@{ WEBSITE_RUN_FROM_PACKAGE='1' } }
                $r = New-ZsLifecycleFunctionApp @script:FaArgs -FunctionPackage Module -VmssNames ''
                Should -Invoke Publish-ZsPackageToScm -Times 0 -Exactly
                (Get-ZsParityCall -Method PATCH -Match '/tags/default').Count | Should -Be 0
                $r.PackagePending | Should -BeFalse
                ($script:ParityLog -join "`n") | Should -Match 'Function package 0123456789abcdef is already deployed'
            }
        }

        It 'carries on without the package from outside the network, and reports it pending' {
            InModuleScope ZscalerCloudConnector {
                Mock Publish-ZsPackageToScm { throw [System.InvalidOperationException]::new('ZsPackagePushNeedsNetwork: the function package is zip-deployed to func-zscc-pstr01 through its private endpoint, ... and this machine resolves it to 52.1.2.3.') }
                $r = New-ZsLifecycleFunctionApp @script:FaArgs -FunctionPackage Module -VmssNames ''
                $r.PackagePending | Should -BeTrue
                (Get-ZsParityCall -Method PATCH -Match '/tags/default').Count | Should -Be 0
                ($script:ParityLog -join "`n") | Should -Match '\[WARN\] ZsPackagePushNeedsNetwork: .+ The deployment carries on without it'
                @($script:ArmCalls | Where-Object { $_.Uri -match '/restart' }).Count | Should -Be 0
            }
        }

        It 'reads the function list once and restarts nothing when no private endpoint can fill it' {
            InModuleScope ZscalerCloudConnector {
                $null = Set-ZsParityResource -Id "$script:FaPath/functions" -Resource @{ value=@() }
                $null = New-ZsLifecycleFunctionApp @script:FaArgs
                @($script:ArmCalls | Where-Object { $_.Uri -match '/restart' }).Count | Should -Be 0
                Should -Invoke Start-Sleep -Times 0 -Exactly
                $log = $script:ParityLog -join "`n"
                $log | Should -Match '\[INFO\] Function host not confirmed: Resource Manager lists func-zscc-pstr01''s functions only through a private endpoint'
                $log | Should -Not -Match '\[WARN\] Resource Manager does not list'
            }
        }

        It 'leaves the storage service endpoint on a network it did not create' {
            InModuleScope ZscalerCloudConnector {
                $null = Set-ZsParityResource -Id '/vnet' -Resource @{ location='westus2'; properties=@{} }
                $null = Set-ZsParityResource -Id '/sub/func' -Resource @{ properties=@{ addressPrefix='10.157.108.224/27'
                    serviceEndpoints=@(@{ service='Microsoft.Storage'; locations=@('westus2') }) } }
                $null = New-ZsLifecycleFunctionApp @script:FaArgs
                (Get-ZsParityCall -Method PUT -Match '^/sub/func\?').Count | Should -Be 0
            }
        }

        It 'refuses the plans that need an Azure Files share, and a run without the network, before creating anything' {
            InModuleScope ZscalerCloudConnector {
                Get-ZsParityErrorId { New-ZsLifecycleFunctionApp @script:FaArgs -AppServicePlanSku Y1 } | Should -Match '^ZsPlanNeedsPublicStorage'
                Get-ZsParityErrorId { New-ZsLifecycleFunctionApp @script:FaArgs -AppServicePlanSku EP1 } | Should -Match '^ZsPlanNeedsPublicStorage'
                $noNet = @{} + $script:FaArgs; $noNet.Remove('FuncAppSubnetId')
                Get-ZsParityErrorId { New-ZsLifecycleFunctionApp @noNet } | Should -Match '^ZsFunctionNeedsNetwork'
                $script:ArmCalls.Count | Should -Be 0
            }
        }
    }

    Context 'Alerts' {
        It 'alerts on the load balancer probe and on the function log with queries that stop at the filter, and removes only its own 5.4.1.0 metric rules' {
            InModuleScope ZscalerCloudConnector {
                $ma = "$script:Rg/providers/Microsoft.Insights/metricAlerts"
                $null = Set-ZsParityResource -Id $ma -Resource @{ value=@(
                    @{ id="$ma/alert-zscc-smedge-stale-pstr01"; name='alert-zscc-smedge-stale-pstr01'; tags=@{ 'managed-by'='ZscalerCloudConnector-PSModule' } }
                    @{ id="$ma/alert-zscc-cc-unhealthy-pstr01"; name='alert-zscc-cc-unhealthy-pstr01'; tags=@{ 'managed-by'='terraform-zscc' } }
                    @{ id="$ma/alert-zscc-func-heartbeat-theirs"; name='alert-zscc-func-heartbeat-theirs' }
                    @{ id="$ma/alert-zscc-lb-health-pstr01"; name='alert-zscc-lb-health-pstr01'; tags=@{ 'managed-by'='ZscalerCloudConnector-PSModule' } }
                ) }
                $null = New-ZsMonitorAlerts -AppInsightsId '/ai' -LoadBalancerId '/lb' -NotificationEmail 'ops@example.com' -Confirm:$false
                @((Get-ZsParityCall -Method DELETE) | ForEach-Object { (($_.Uri -split '\?')[0] -split '/')[-1] }) | Should -Be @('alert-zscc-smedge-stale-pstr01','alert-zscc-cc-unhealthy-pstr01')

                $lb = (Get-ZsParityCall -Method PUT -Match '/metricAlerts/alert-zscc-lb-health-pstr01\?')[0].Body.properties
                $lb.scopes | Should -Be @('/lb')
                $lb.severity | Should -Be 1
                $lb.evaluationFrequency | Should -Be 'PT1M'
                $lb.windowSize | Should -Be 'PT5M'
                $lb.criteria.allOf[0].metricName | Should -Be 'DipAvailability'
                $lb.criteria.allOf[0].operator | Should -Be 'LessThan'
                $lb.criteria.allOf[0].threshold | Should -Be 50

                $logs = Get-ZsParityCall -Method PUT -Match '/scheduledQueryRules/'
                $logs.Count | Should -Be 3
                foreach ($l in $logs) {
                    $c = $l.Body.properties.criteria.allOf[0]
                    $c.query | Should -Not -Match 'summarize'
                    $c.timeAggregation | Should -Be 'Count'
                    $l.Body.properties.evaluationFrequency | Should -Be 'PT15M'
                    $l.Body.properties.scopes | Should -Be @('/ai')
                }
                $hb = @($logs | Where-Object { $_.Uri -match 'func-heartbeat' })[0].Body.properties
                $hb.windowSize | Should -Be 'PT1H'
                $hb.criteria.allOf[0].operator | Should -Be 'LessThan'
                $hb.criteria.allOf[0].threshold | Should -Be 1
                $hb.criteria.allOf[0].query | Should -Match 'name == "synchronizeCloudResources"'
                $verdict = @($logs | Where-Object { $_.Uri -match 'health-verdict' })[0].Body.properties.criteria.allOf[0]
                $verdict.query | Should -Match 'Instance is unhealthy, adding it to the termination list'
                $verdict.operator | Should -Be 'GreaterThan'
                $verdict.threshold | Should -Be 0

                # The heartbeat window is the shortest one a 15-minute rule accepts that covers two syncs.
                foreach ($case in @(@{ M=7; W='PT15M' }, @{ M=30; W='PT1H' }, @{ M=45; W='PT2H' }, @{ M=600; W='P1D' })) {
                    Reset-ZsParityArm
                    $null = New-ZsMonitorAlerts -AppInsightsId '/ai' -LoadBalancerId '/lb' -SyncIntervalMinutes $case.M -Confirm:$false
                    (Get-ZsParityCall -Method PUT -Match 'scheduledQueryRules/alert-zscc-func-heartbeat-')[0].Body.properties.windowSize | Should -Be $case.W
                }
            }
        }
    }

    Context 'Preflight' {
        It 'asks for the rights the deployment really uses' {
            InModuleScope ZscalerCloudConnector {
                $ip = @((Get-ZsRequiredActions -Mode Greenfield -Topology VMSS -Bastion -BastionSku Premium -NatPublicIpMode ip).Action)
                $ip | Should -Contain 'Microsoft.KeyVault/vaults/secrets/write'
                $ip | Should -Not -Contain 'Microsoft.KeyVault/vaults/secrets/setSecret/action'
                @($ip | Where-Object { $_ -eq 'Microsoft.Network/publicIPAddresses/write' }).Count | Should -Be 1 -Because 'the NAT egress needs one; a Premium Bastion has none'
                $ip | Should -Contain 'Microsoft.Compute/virtualMachines/write'
                $ip | Should -Contain 'Microsoft.Network/loadBalancers/backendAddressPools/join/action'
                $ip | Should -Contain 'Microsoft.Authorization/roleAssignments/write'
                $pfx = @((Get-ZsRequiredActions -Mode Greenfield -Topology VMSS -Bastion -BastionSku Premium -NatPublicIpMode prefix).Action)
                $pfx | Should -Contain 'Microsoft.Network/publicIPPrefixes/write'
                $pfx | Should -Not -Contain 'Microsoft.Network/publicIPAddresses/write'
                $std = @((Get-ZsRequiredActions -Mode Greenfield -Topology VMSS -Bastion -BastionSku Standard -NatPublicIpMode prefix).Action)
                $std | Should -Contain 'Microsoft.Network/publicIPAddresses/write'
                $own = @((Get-ZsRequiredActions -Mode Greenfield -Topology VMSS -NatPublicIpMode ip -NatExistingPublicIp).Action)
                $own | Should -Not -Contain 'Microsoft.Network/publicIPAddresses/write'
            }
        }

        It 'checks policy against the shapes the deployment really creates, IP forwarding included' {
            InModuleScope ZscalerCloudConnector {
                Mock Invoke-ArmPost {
                    $script:ArmCalls.Add([PSCustomObject]@{ Method='POST'; Uri=$Uri; Body=$Body })
                    if ($Body.resourceDetails.resourceContent.type -eq 'Microsoft.Network/networkInterfaces') {
                        return [PSCustomObject]@{ contentEvaluationResult=[PSCustomObject]@{ policyEvaluations=@([PSCustomObject]@{ evaluationResult='NonCompliant'
                            policyInfo=[PSCustomObject]@{ policyDefinitionId='/providers/Microsoft.Authorization/policyDefinitions/88c0b9da-ce96-4b03-9635-f29a937e2900'
                                policyDefinitionDisplayName='Network interfaces should disable IP forwarding'; policyDefinitionEffect='deny' } }) } }
                    }
                    [PSCustomObject]@{ fieldRestrictions=@(); contentEvaluationResult=[PSCustomObject]@{ policyEvaluations=@() } }
                }
                $res = Test-ZsPolicyRestrictions -Scope $script:Rg -Location 'westus2' -Topology VMSS -Bastion -BastionSku Premium
                $content = @((Get-ZsParityCall -Method POST) | ForEach-Object { $_.Body.resourceDetails.resourceContent })
                $byType = { param($t) ,@($content | Where-Object { $_.type -eq $t }) }
                (& $byType 'Microsoft.Network/networkInterfaces')[0].properties.enableIPForwarding | Should -BeTrue
                (& $byType 'Microsoft.Storage/storageAccounts')[0].properties.publicNetworkAccess | Should -Be 'Disabled'
                (& $byType 'Microsoft.KeyVault/vaults')[0].properties.publicNetworkAccess | Should -Be 'Disabled'
                (& $byType 'Microsoft.Web/sites')[0].properties.publicNetworkAccess | Should -Be 'Disabled'
                (& $byType 'Microsoft.Network/bastionHosts')[0].properties.enablePrivateOnlyBastion | Should -BeTrue
                (& $byType 'Microsoft.Network/natGateways')[0].sku.name | Should -Be 'StandardV2'
                (& $byType 'Microsoft.Network/publicIPAddresses').Count | Should -Be 1 -Because 'the NAT egress only'
                (& $byType 'Microsoft.Network/publicIPAddresses')[0].sku.name | Should -Be 'StandardV2'
                (& $byType 'Microsoft.Compute/virtualMachineScaleSets')[0].properties.orchestrationMode | Should -Be 'Flexible'
                $res.Blockers.Count | Should -Be 1
                $res.Blockers[0].Resource | Should -Match 'IP forwarding'
                $res.Blockers[0].PolicyDefinitionDisplayName | Should -Be 'Network interfaces should disable IP forwarding'
            }
        }
    }

    Context 'Post-deployment validation' {
        It 'checks the load balancer rule and that the vault, storage and function app take no public traffic' {
            InModuleScope ZscalerCloudConnector {
                $seed = {
                    param([string]$KvAccess, [bool]$Floating)
                    Reset-ZsParityArm
                    $net = "$script:Rg/providers/Microsoft.Network"
                    $null = Set-ZsParityResource -Id $script:Rg -Resource @{ location='westus2' }
                    $null = Set-ZsParityResource -Id "$net/virtualNetworks" -Resource @{ value=@(@{ name='vnet-zscc'; properties=@{ virtualNetworkPeerings=@()
                        subnets=@(@('snet-zscc-mgmt','snet-zscc-service','snet-zscc-workload','snet-zscc-lb') | ForEach-Object { @{ name=$_ } }) } }) }
                    $null = Set-ZsParityResource -Id "$net/networkSecurityGroups" -Resource @{ value=@(@{ name='nsg-a' }, @{ name='nsg-b' }) }
                    $null = Set-ZsParityResource -Id "$net/loadBalancers" -Resource @{ value=@(@{ name='lb-zscc'; sku=@{ name='Standard' }; properties=@{
                        probes=@(@{ properties=@{ port=50000 } })
                        loadBalancingRules=@(@{ name='rule-haports'; properties=@{ frontendPort=0; enableFloatingIP=$Floating; loadDistribution='SourceIP' } }) } }) }
                    $null = Set-ZsParityResource -Id "$net/routeTables" -Resource @{ value=@(@{ properties=@{ disableBgpRoutePropagation=$true
                        routes=@(@{ properties=@{ addressPrefix='0.0.0.0/0' } }) } }) }
                    $null = Set-ZsParityResource -Id "$script:Rg/providers/Microsoft.Compute/virtualMachines" -Resource @{ value=@() }
                    $null = Set-ZsParityResource -Id "$net/networkInterfaces" -Resource @{ value=@() }
                    $null = Set-ZsParityResource -Id "$script:Rg/providers/Microsoft.KeyVault/vaults" -Resource @{ value=@(@{ name='kv-zscc-1'; properties=@{ publicNetworkAccess=$KvAccess } }) }
                    $null = Set-ZsParityResource -Id "$script:Rg/providers/Microsoft.Storage/storageAccounts" -Resource @{ value=@(@{ name='stzsccpstr01'; properties=@{ publicNetworkAccess='Disabled' } }) }
                    $site = "$script:Rg/providers/Microsoft.Web/sites/func-zscc-pstr01"
                    $null = Set-ZsParityResource -Id "$script:Rg/providers/Microsoft.Web/sites" -Resource @{ value=@(@{ name='func-zscc-pstr01'; id=$site }) }
                    $null = Set-ZsParityResource -Id $site -Resource @{ properties=@{ publicNetworkAccess='Disabled' } }
                }
                & $seed 'Disabled' $false
                $good = Test-ZsDeployment -Zones @('1')
                & $seed 'Enabled' $true
                $bad = Test-ZsDeployment -Zones @('1')
                ($bad.Failed - $good.Failed) | Should -Be 2
                ($good.Passed - $bad.Passed) | Should -Be 2
                $log = $script:ParityLog -join "`n"
                $log | Should -Match "Key Vault kv-zscc-1 has public network access 'Enabled'"
                $log | Should -Match 'LB rule rule-haports has floating IP on'
            }
        }
    }

    Context 'Orchestration dry run' {
        It 'dry-runs a brownfield VMSS deployment from a config that leaves the optional fields out' {
            InModuleScope ZscalerCloudConnector -Parameters @{ Td = $TestDrive } {
                param($Td)
                $vnetId = '/subscriptions/22222222-2222-2222-2222-222222222222/resourceGroups/rg-network-hub/providers/Microsoft.Network/virtualNetworks/vnet-hub'
                $sub = { param($n, $p) @{ name=$n; id="$vnetId/subnets/$n"; properties=(@{ provisioningState='Succeeded' } + $p) } }
                $null = Set-ZsParityResource -Id $vnetId -Resource @{ location='westus2'; properties=@{ provisioningState='Succeeded'
                    addressSpace=@{ addressPrefixes=@('10.50.0.0/16') }; dhcpOptions=@{ dnsServers=@() }
                    subnets=@( (& $sub 'sn-mgmt' @{ addressPrefix='10.50.0.0/26' }), (& $sub 'sn-svc' @{ addressPrefix='10.50.0.64/26' }),
                        (& $sub 'sn-wl' @{ addressPrefix='10.50.1.0/24' }), (& $sub 'sn-lb' @{ addressPrefix='10.50.0.128/27' }),
                        (& $sub 'sn-func' @{ addressPrefix='10.50.0.160/27'; delegations=@(@{ name='d'; properties=@{ serviceName='Microsoft.Web/serverFarms' } }) }) ) } }
                Mock Resolve-ZsDeploymentScope { $script:ZsSession.ResourceGroupName = $ResourceGroupName
                    [PSCustomObject]@{ Mode='Brownfield'; ResourceGroupName=$ResourceGroupName; Scope="/subscriptions/x/resourceGroups/$ResourceGroupName"; Exists=$true } }
                Mock New-ZsSshKey { throw 'no key generation in a dry run' }
                # Only what a hand-written brownfield file carries: no NoBastion, no greenfield CIDRs.
                $cfgPath = Join-Path $Td 'byo-minimal.json'
                @{ Mode='Brownfield'; Topology='VMSS'; CcCount=2; MinInstances=2; MaxInstances=4; Zones=@('1','2')
                   BringYourOwn=@{ ResourceGroupName='rg-zscc-byo'; VnetName='vnet-hub'; VnetResourceGroupName='rg-network-hub'
                       VnetSubscriptionId='22222222-2222-2222-2222-222222222222'; MgmtSubnetName='sn-mgmt'; ServiceSubnetName='sn-svc'
                       WorkloadSubnetName='sn-wl'; LbSubnetName='sn-lb'; FuncAppSubnetName='sn-func' } } | ConvertTo-Json -Depth 5 | Set-Content -Path $cfgPath
                # The last real run's manifest, which teardown reads.
                $manifest = Join-Path $Td 'm.json'
                Set-Content -Path $manifest -Value '{"Status":"Succeeded"}'
                $r = New-ZsDeployment -ConfigFile $cfgPath -ApiKey 'k' -AdminUser 'a@b.c' -AdminPassword 'p' -SshPublicKey 'ssh-rsa AAAA' `
                    -ProvisioningUrl 'https://connector.zscalerthree.net/api/v1/provUrl?name=x' -ManifestPath $manifest -SkipPrerequisites -WhatIf
                $r.Status | Should -Be 'Succeeded'
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0
                (Get-ZsParityCall -Method PATCH).Count | Should -Be 0
                (Get-ZsParityCall -Method DELETE).Count | Should -Be 0
                (Get-Content -Path $manifest -Raw).Trim() | Should -Be '{"Status":"Succeeded"}'
            }
        }

        It 'previews a re-run over a 5.4.1.0 network without writing, and the real run then makes the writes it skipped' {
            InModuleScope ZscalerCloudConnector {
                # The brownfield dry run above leaves the session on its own resource group.
                $script:ZsSession.ResourceGroupName = 'rg-zscc-dev-westus2'
                $net  = "$script:Rg/providers/Microsoft.Network"
                $vnet = "$net/virtualNetworks/vnet-zscc-dev-westus2"
                $natId = "$net/natGateways/natgw-zscc-dev-westus2"
                $rtId  = "$net/routeTables/rt-zscc-wl-dev-westus2"
                $seed = {
                    Reset-ZsParityArm
                    # What 5.4.1.0 left: Azure's four-minute NAT idle timeout, and a route table pointing
                    # at a frontend the load balancer no longer has, not yet on the workload subnet.
                    $null = Set-ZsParityResource -Id "$net/publicIPAddresses/pip-natgw-zscc-dev-westus2" -Owned -Resource @{ properties=@{ ipAddress='20.1.2.3' } }
                    $null = Set-ZsParityResource -Id $natId -Owned -Resource @{ location='westus2'; properties=@{ idleTimeoutInMinutes=4
                        publicIpAddresses=@(@{ id="$net/publicIPAddresses/pip-natgw-zscc-dev-westus2" }) } }
                    foreach ($sn in 'snet-zscc-mgmt','snet-zscc-service') { $null = Set-ZsParityResource -Id "$vnet/subnets/$sn" -Resource @{ properties=@{ addressPrefix='10.0.0.0/26'; natGateway=@{ id=$natId } } } }
                    $null = Set-ZsParityResource -Id "$vnet/subnets/snet-zscc-workload" -Resource @{ properties=@{ addressPrefix='10.0.3.0/24' } }
                    $null = Set-ZsParityResource -Id $rtId -Owned -Resource @{ location='westus2'; properties=@{ disableBgpRoutePropagation=$true
                        routes=@(@{ name='default-to-zscc'; properties=@{ addressPrefix='0.0.0.0/0'; nextHopType='VirtualAppliance'; nextHopIpAddress='10.0.2.4' } }) } }
                }
                $run = { param([switch]$DryRun)
                    [PSCustomObject]@{
                        Pub = New-ZsPublicNetwork -SubnetPlan ([PSCustomObject]@{}) -VnetPath $vnet -Zones @('1') -AssociateSubnetIds @("$vnet/subnets/snet-zscc-mgmt","$vnet/subnets/snet-zscc-service") -WhatIf:$DryRun -Confirm:$false
                        Rt  = New-ZsPrivateNetwork -NextHopIp '10.0.2.5' -WorkloadSubnetCidr '10.0.3.0/24' -VnetPath $vnet -WhatIf:$DryRun -Confirm:$false
                    } }

                & $seed
                $preview = & $run -DryRun
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0
                (Get-ZsParityCall -Method PATCH).Count | Should -Be 0
                $preview.Pub.Egress.NatGwId | Should -Be $natId
                $preview.Pub.Egress.PublicIp | Should -Be '20.1.2.3'
                $preview.Rt.RouteTableId | Should -Be $rtId

                & $seed
                $null = & $run
                @((Get-ZsParityCall -Method PUT).Uri | ForEach-Object { (($_ -split '\?')[0] -split '/')[-1] }) | Should -Be @('natgw-zscc-dev-westus2', 'rt-zscc-wl-dev-westus2', 'snet-zscc-workload')
                (Get-ZsParityCall -Method PUT -Match '/natGateways/')[0].Body.properties.idleTimeoutInMinutes | Should -Be 10
                (Get-ZsParityCall -Method PUT -Match '/routeTables/')[0].Body.properties.routes[-1].properties.nextHopIpAddress | Should -Be '10.0.2.5'
            }
        }

        It 'goes through an existing Monitor Private Link scope in a dry run, writing nothing' {
            InModuleScope ZscalerCloudConnector {
                $ws    = "$script:Rg/providers/Microsoft.OperationalInsights/workspaces/log-zscc-dev-westus2"
                $ai    = "$script:Rg/providers/Microsoft.Insights/components/appi-zscc-pstr01"
                $scope = "$script:Rg/providers/microsoft.insights/privateLinkScopes/ampls-zscc-pstr01"
                $null = Set-ZsParityResource -Id $ai -Resource @{ properties=@{ WorkspaceResourceId=$ws } }
                $null = Set-ZsParityResource -Id $scope -Resource @{ properties=@{ accessModeSettings=@{ ingestionAccessMode='PrivateOnly'; queryAccessMode='Open' } } }
                Mock Resolve-ZsPrivateDnsZone { "/zones/$ZoneName" }
                Mock Set-ZsPrivateEndpoint { [PSCustomObject]@{ Id="$script:Rg/providers/Microsoft.Network/privateEndpoints/$Name"; PrivateIp='10.0.0.9' } }
                $r = New-ZsMonitorPrivateLink -ComponentId $ai -PrivateEndpointSubnetId '/sn' -VnetId '/vnet' -WhatIf
                $r.ScopeId | Should -Be $scope
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0
                Should -Invoke Set-ZsPrivateEndpoint -Times 1 -Exactly

                # With no scope yet, placeholders stand in.
                Reset-ZsParityArm
                $null = Set-ZsParityResource -Id $ai -Resource @{ properties=@{ WorkspaceResourceId=$ws } }
                (New-ZsMonitorPrivateLink -ComponentId $ai -PrivateEndpointSubnetId '/sn' -VnetId '/vnet' -WhatIf).ScopeId | Should -Match '^\('
            }
        }

        It 'stops at the platform''s NSG before its first write, and leaves the platform''s NAT gateway alone when told to' {
            InModuleScope ZscalerCloudConnector -Parameters @{ Td = $TestDrive } {
                param($Td)
                $vnetId = '/subscriptions/22222222-2222-2222-2222-222222222222/resourceGroups/rg-network-hub/providers/Microsoft.Network/virtualNetworks/vnet-hub'
                $hubNat = @{ id='/subscriptions/22222222-2222-2222-2222-222222222222/resourceGroups/rg-network-hub/providers/Microsoft.Network/natGateways/natgw-hub' }
                $sub = { param($n, $p) @{ name=$n; id="$vnetId/subnets/$n"; properties=(@{ provisioningState='Succeeded' } + $p) } }
                $seed = { param([hashtable]$MgmtExtra)
                    $null = Set-ZsParityResource -Id $vnetId -Resource @{ location='westus2'; properties=@{ provisioningState='Succeeded'
                        addressSpace=@{ addressPrefixes=@('10.50.0.0/16') }; dhcpOptions=@{ dnsServers=@() }
                        subnets=@( (& $sub 'sn-mgmt' (@{ addressPrefix='10.50.0.0/26'; natGateway=$hubNat } + $MgmtExtra)), (& $sub 'sn-svc' @{ addressPrefix='10.50.0.64/26'; natGateway=$hubNat }),
                            (& $sub 'sn-wl' @{ addressPrefix='10.50.1.0/24' }), (& $sub 'sn-lb' @{ addressPrefix='10.50.0.128/27' }),
                            (& $sub 'sn-func' @{ addressPrefix='10.50.0.160/27'; natGateway=$hubNat; delegations=@(@{ name='d'; properties=@{ serviceName='Microsoft.Web/serverFarms' } }) }) ) } } }
                Mock Resolve-ZsDeploymentScope { $script:ZsSession.ResourceGroupName = $ResourceGroupName
                    [PSCustomObject]@{ Mode='Brownfield'; ResourceGroupName=$ResourceGroupName; Scope="/subscriptions/x/resourceGroups/$ResourceGroupName"; Exists=$true } }
                Mock New-ZsSshKey { throw 'no key generation here' }
                Mock New-ZsPublicNetwork { }
                $cfgPath = Join-Path $Td 'byo-platform-egress.json'
                @{ Mode='Brownfield'; Topology='VMSS'; CcCount=2; MinInstances=2; MaxInstances=4; Zones=@('1','2')
                   BringYourOwn=@{ ResourceGroupName='rg-zscc-byo'; VnetName='vnet-hub'; VnetResourceGroupName='rg-network-hub'
                       VnetSubscriptionId='22222222-2222-2222-2222-222222222222'; MgmtSubnetName='sn-mgmt'; ServiceSubnetName='sn-svc'
                       WorkloadSubnetName='sn-wl'; LbSubnetName='sn-lb'; FuncAppSubnetName='sn-func'; AttachNatGateway=$false } } | ConvertTo-Json -Depth 5 | Set-Content -Path $cfgPath
                $run = { param([switch]$DryRun)
                    New-ZsDeployment -ConfigFile $cfgPath -ApiKey 'k' -AdminUser 'a@b.c' -AdminPassword 'p' -SshPublicKey 'ssh-rsa AAAA' `
                        -ProvisioningUrl 'https://connector.zscalerthree.net/api/v1/provUrl?name=x' -ManifestPath (Join-Path $Td 'm.json') -SkipPrerequisites -WhatIf:$DryRun -Confirm:$false }

                # The platform's NSG on the management subnet: refused by name, before anything is written.
                & $seed @{ networkSecurityGroup=@{ id='/subscriptions/22222222-2222-2222-2222-222222222222/resourceGroups/rg-network-hub/providers/Microsoft.Network/networkSecurityGroups/nsg-hub-mgmt' } }
                $err = $null
                try { & $run } catch { $err = $_ }
                $err.FullyQualifiedErrorId | Should -BeLike 'ZsByoSubnetAttached*'
                $err.Exception.Message | Should -BeLike '*sn-mgmt carries NSG nsg-hub-mgmt*'
                $err.Exception.Message | Should -Not -BeLike '*NAT gateway*'
                (Get-ZsParityCall -Method PUT).Count | Should -Be 0

                # Without it, the platform's NAT gateway stays the subnets' way out and none is created.
                Reset-ZsParityArm
                & $seed @{}
                $r = & $run -DryRun
                $r.Status | Should -Be 'Succeeded'
                @($r.NatGatewayIps).Count | Should -Be 0
                Should -Invoke New-ZsPublicNetwork -Times 0 -Exactly
                ($script:ParityLog -join "`n") | Should -Match 'No NAT gateway: AttachNatGateway is false'
            }
        }
    }

    Context 'Cloud-init and orchestration' {
        It 'hands the connectors and the function the provisioning URL without a scheme' {
            InModuleScope ZscalerCloudConnector {
                ConvertTo-ZsCcUrl -Url 'HTTPS://connector.zscaler.net/api/v1/provUrl?name=a' | Should -Be 'connector.zscaler.net/api/v1/provUrl?name=a'
                ConvertTo-ZsCcUrl -Url 'http://connector.zscaler.net/x' | Should -Be 'connector.zscaler.net/x'
                ConvertTo-ZsCcUrl -Url 'connector.zscaler.net/x' | Should -Be 'connector.zscaler.net/x'
                ConvertTo-ZsCcUrl -Url '' | Should -Be ''
                $ud = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String((Get-ZsConnectorUserData -ProvisioningUrl 'https://connector.zscaler.net/x' -KeyVaultUri 'https://kv/' -HttpProbePort 50000)))
                ($ud -split "`n") | Should -Be @('[ZSCALER]','CC_URL=connector.zscaler.net/x','AZURE_VAULT_URL=https://kv/','HTTP_PROBE_PORT=50000','FIPS_ENABLED=False')
            }
        }

        It 'puts the NAT gateway on the management, service and function subnets, and checks capacity before writing anything' {
            $dep = Get-Content (Join-Path (Split-Path $PSScriptRoot -Parent) 'Public/New-ZsDeployment.ps1') -Raw
            $dep | Should -Match ([regex]::Escape("foreach (`$natKey in @('snet-zscc-mgmt','snet-zscc-service','snet-zscc-funcapp'))"))
            $dep | Should -Match ([regex]::Escape('$cfg.CcCount -lt $MinInstances -or $cfg.CcCount -gt $MaxInstances'))
            $dep | Should -Match ([regex]::Escape('$ScheduledMinInstances -gt $MaxInstances'))
            $check = $dep.IndexOf('$cfg.CcCount -lt $MinInstances')
            $check | Should -BeLessThan $dep.IndexOf('Acquire deployment state lock')
            $check | Should -BeLessThan $dep.IndexOf('New-ZsResourceGroup')
        }
    }
}
