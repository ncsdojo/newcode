<#
.SYNOPSIS
    Standalone test suite for scope resolution, effective-permission evaluation, Azure Policy
    discovery, ARM failure classification, logging behaviour, and teardown safety.

.DESCRIPTION
    Runs without Pester and without an Azure subscription: ARM is mocked inside module scope, so the
    suite executes the real evaluation logic against controlled responses. Run it before release and
    after any change to the access or teardown paths.

        pwsh -File Tests/Access/Run-AccessTests.ps1

    Exits non-zero when any assertion fails, so it can gate a pipeline.

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.3.0.11
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>
[CmdletBinding()]
param([string]$ModulePath = '')

$ErrorActionPreference = 'Stop'
if (-not $ModulePath) { $ModulePath = Join-Path (Split-Path (Split-Path $PSScriptRoot -Parent) -Leaf | ForEach-Object { Split-Path (Split-Path $PSScriptRoot -Parent) -Parent }) '' }
$root = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
if (-not (Test-Path (Join-Path $root 'ZscalerCloudConnector.psd1'))) { $root = Split-Path $PSScriptRoot -Parent | Split-Path -Parent }

$total = 0; $failed = 0
foreach ($file in (Get-ChildItem $PSScriptRoot -Filter 'Test-*.ps1' | Sort-Object Name)) {
    Write-Host "`n### $($file.BaseName)" -ForegroundColor Cyan
    $out = & $file.FullName 2>&1
    $out | ForEach-Object { Write-Host $_ }
    $line = $out | Where-Object { $_ -match 'failures:\s*(\d+)' } | Select-Object -Last 1
    if ($line -match 'failures:\s*(\d+)') { $failed += [int]$Matches[1] }
    $total += @($out | Where-Object { $_ -match '^\s+(PASS|FAIL)\s' }).Count
}
Write-Host "`n=== $total assertions, $failed failed ===" -ForegroundColor $(if ($failed) { 'Red' } else { 'Green' })
exit $(if ($failed) { 1 } else { 0 })
