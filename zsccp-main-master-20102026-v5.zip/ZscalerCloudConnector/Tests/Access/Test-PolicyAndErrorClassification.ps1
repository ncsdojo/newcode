$ErrorActionPreference='Stop'
Import-Module (Join-Path (Split-Path (Split-Path $PSScriptRoot -Parent) -Parent) 'ZscalerCloudConnector.psd1') -Force
& (Get-Module ZscalerCloudConnector) {
  $global:zsfail = 0
  function Check($name,$cond){ if($cond){"  PASS  $name"} else {$global:zsfail++; "  FAIL  $name"} }
  function Err([string]$json){
    $ex = [System.Net.Http.HttpRequestException]::new('arm')
    $r = [System.Management.Automation.ErrorRecord]::new($ex,'Arm.Test',[System.Management.Automation.ErrorCategory]::ConnectionError,$null)
    $r.ErrorDetails = [System.Management.Automation.ErrorDetails]::new($json)
    return $r
  }

  "== Policy denial: structured additionalInfo =="
  $policyJson = @'
{"error":{"code":"RequestDisallowedByPolicy","message":"Resource 'pip-zscc' was disallowed by policy.","additionalInfo":[{"type":"PolicyViolation","info":{"policyDefinitionDisplayName":"Deny public IP addresses","policyAssignmentDisplayName":"Corp network guardrails","policyDefinitionEffect":"deny","policyAssignmentScope":"/subscriptions/abc","policyDefinitionId":"/providers/Microsoft.Authorization/policyDefinitions/1e30110a","policyAssignmentId":"/subscriptions/abc/providers/Microsoft.Authorization/policyAssignments/net-guard","evaluationDetails":{"reason":"Public IP addresses are not permitted in this subscription"}}}]}}
'@
  $f = Resolve-ZsArmFailure -ErrorRecord (Err $policyJson)
  Check "classified as Policy"        ($f.Kind -eq 'Policy')
  Check "definition name captured"    ($f.PolicyName -eq 'Deny public IP addresses')
  Check "assignment name captured"    ($f.PolicyAssignment -eq 'Corp network guardrails')
  Check "assignment scope captured"   ($f.PolicyScope -eq '/subscriptions/abc')
  Check "reason surfaces as detail"   ($f.Detail -eq 'Public IP addresses are not permitted in this subscription')
  Check "summary names the policy"    ($f.Summary -like "*Corp network guardrails*" -and $f.Summary -like "*Deny public IP addresses*")

  "== Policy denial: identifiers only in the message =="
  $msgOnly = '{"error":{"code":"RequestDisallowedByPolicy","message":"Resource was disallowed by policy. Policy identifiers: ''[{\"policyAssignment\":{\"name\":\"require-tags\",\"id\":\"/subscriptions/a/providers/Microsoft.Authorization/policyAssignments/require-tags\"},\"policyDefinition\":{\"name\":\"x\",\"id\":\"/providers/Microsoft.Authorization/policyDefinitions/require-tag-value\"}}]''."}}'
  $f2 = Resolve-ZsArmFailure -ErrorRecord (Err $msgOnly)
  Check "message fallback classified"  ($f2.Kind -eq 'Policy')
  Check "assignment from message"      ($f2.PolicyAssignment -eq 'require-tags')
  Check "definition from message"      ($f2.PolicyName -eq 'require-tag-value')

  "== RBAC failure =="
  $rbac = '{"error":{"code":"AuthorizationFailed","message":"The client ''zscc-sp'' with object id ''1234'' does not have authorization to perform action ''Microsoft.Network/natGateways/write'' over scope ''/subscriptions/abc/resourceGroups/rg-net''."}}'
  $f3 = Resolve-ZsArmFailure -ErrorRecord (Err $rbac)
  Check "classified as Permission"   ($f3.Kind -eq 'Permission')
  Check "action extracted"           ($f3.Action -eq 'Microsoft.Network/natGateways/write')
  Check "scope extracted"            ($f3.Scope -eq '/subscriptions/abc/resourceGroups/rg-net')

  "== Quota vs permission vs registration =="
  $quota = '{"error":{"code":"OperationNotAllowed","message":"Operation results in exceeding quota limits of Core. Maximum allowed: 4, Current in use: 4, Additional requested: 2."}}'
  Check "quota classified"           ((Resolve-ZsArmFailure -ErrorRecord (Err $quota)).Kind -eq 'Quota')
  $reg = '{"error":{"code":"MissingSubscriptionRegistration","message":"The subscription is not registered to use namespace ''Microsoft.Network''."}}'
  $f4 = Resolve-ZsArmFailure -ErrorRecord (Err $reg)
  Check "registration classified"    ($f4.Kind -eq 'Registration')
  Check "namespace named"            ($f4.Action -eq 'Microsoft.Network')
  $unk = '{"error":{"code":"SomethingElse","message":"boom"}}'
  Check "unknown left unclassified"  ((Resolve-ZsArmFailure -ErrorRecord (Err $unk)).Kind -eq 'Unclassified')

  "== NoRegisteredProviderFound: api-version vs registration =="
  # Same error code, two unrelated causes. Only the api-version case enumerates supported versions,
  # and misreading it as a registration problem hides a defect in the caller behind an Owner ask.
  $apiv = '{"error":{"code":"NoRegisteredProviderFound","message":"No registered resource provider found for location ''global'' and API version ''2022-10-01'' for type ''metricalerts''. The supported api-versions are ''2017-09-01-preview, 2018-03-01, 2024-01-01-preview''."}}'
  $f5 = Resolve-ZsArmFailure -ErrorRecord (Err $apiv)
  Check "api-version classified"     ($f5.Kind -eq 'ApiVersion')
  Check "not called registration"    ($f5.Kind -ne 'Registration')
  Check "sent version extracted"     ($f5.Action -eq '2022-10-01')
  Check "type extracted"             ($f5.Scope -eq 'metricalerts')
  Check "supported list surfaced"    ($f5.Detail -match '2018-03-01')
  # Without the version list it is a real registration failure and must stay one.
  $noreg = '{"error":{"code":"NoRegisteredProviderFound","message":"The subscription is not registered to use namespace ''Microsoft.Insights''."}}'
  Check "bare code still registration" ((Resolve-ZsArmFailure -ErrorRecord (Err $noreg)).Kind -eq 'Registration')

  "== checkPolicyRestrictions response parsing =="
  $resp = [pscustomobject]@{
    fieldRestrictions = @([pscustomobject]@{ field='location'; restrictions=@(
        [pscustomobject]@{ result='Deny'; policy=[pscustomobject]@{ policyDefinitionDisplayName='Allowed locations'; policyAssignmentDisplayName='Geo restriction'; policyAssignmentId='/subscriptions/a/.../geo'; policyDefinitionId='/providers/.../allowed-locations'; policyAssignmentScope='/subscriptions/a' } },
        [pscustomobject]@{ result='Audit'; policy=[pscustomobject]@{ policyDefinitionDisplayName='Audit only'; policyAssignmentDisplayName='Audit only' } }) })
    contentEvaluationResult = [pscustomobject]@{ policyEvaluations = @(
        [pscustomobject]@{ evaluationResult='NonCompliant'; policyInfo=[pscustomobject]@{ policyDefinitionDisplayName='Deny public IP'; policyAssignmentDisplayName='Net guard'; policyDefinitionEffect='deny'; policyAssignmentId='/x'; policyDefinitionId='/y'; policyAssignmentScope='/subscriptions/a' } },
        [pscustomobject]@{ evaluationResult='Compliant';    policyInfo=[pscustomobject]@{ policyDefinitionDisplayName='Fine'; policyDefinitionEffect='audit' } }) }
  }
  $d = Get-ZsPolicyDenials -Response $resp -Label 'Public IP address'
  Check "only denials returned"        (@($d).Count -eq 2)
  Check "field restriction named"      (@($d | Where-Object PolicyAssignmentDisplayName -eq 'Geo restriction').Count -eq 1)
  Check "content denial named"         (@($d | Where-Object PolicyAssignmentDisplayName -eq 'Net guard').Count -eq 1)
  Check "audit not treated as blocker" (@($d | Where-Object PolicyDefinitionDisplayName -eq 'Audit only').Count -eq 0)
  Check "compliant not a blocker"      (@($d | Where-Object PolicyDefinitionDisplayName -eq 'Fine').Count -eq 0)
  Check "resource label carried"       ($d[0].Resource -eq 'Public IP address')
  Check "null response is safe"        (@(Get-ZsPolicyDenials -Response $null).Count -eq 0)
  Check "empty response is safe"       (@(Get-ZsPolicyDenials -Response ([pscustomobject]@{})).Count -eq 0)

  "== Name falls back to the id's last segment =="
  $bare = [pscustomobject]@{ contentEvaluationResult = [pscustomobject]@{ policyEvaluations = @(
      [pscustomobject]@{ evaluationResult='NonCompliant'; policyInfo=[pscustomobject]@{ policyDefinitionEffect='deny'; policyDefinitionId='/providers/Microsoft.Authorization/policyDefinitions/no-public-ip'; policyAssignmentId='/subscriptions/a/providers/Microsoft.Authorization/policyAssignments/guardrail-42' } }) } }
  $bd = Get-ZsPolicyDenials -Response $bare -Label 'Public IP'
  Check "definition name from id"  ($bd[0].PolicyDefinitionDisplayName -eq 'no-public-ip')
  Check "assignment name from id"  ($bd[0].PolicyAssignmentDisplayName -eq 'guardrail-42')

  "== Causes that are not permission problems are not reported as ones =="
  # None of these is a missing role, and reporting one as such sends the operator nowhere.
  $linked = Resolve-ZsArmFailure -ErrorRecord (Err ('{"error":{"code":"LinkedAuthorizationFailed","message":"The client has permission to perform action ''Microsoft.Network/privateEndpoints/write'' on scope ''/subscriptions/a/rg1''; however, it does not have permission to perform action ''Microsoft.Network/virtualNetworks/subnets/join/action'' on the linked scope(s) ''/subscriptions/a/rg2/providers/Microsoft.Network/virtualNetworks/vnet/subnets/s''."}}'))
  Check "linked RBAC is not plain RBAC"  ($linked.Kind -eq 'LinkedPermission')
  Check "linked action named"            ($linked.Action -match 'subnets/join/action')
  Check "linked scope named"             ($linked.Scope -match 'subnets/s')

  $pol = Resolve-ZsArmFailure -ErrorRecord (Err '{"error":{"code":"RequestDisallowedByPolicy","message":"Resource was disallowed by policy."}}')
  Check "policy is not RBAC"             ($pol.Kind -eq 'Policy')
  # The remedy is the renderer's business; the classifier reports only what the policy said.
  # ERROR lines go to the host's error line rather than a stream, so the session's log buffer,
  # which records every line, is what is read back.
  $script:ZsSession = @{ LogFile=''; LogBuffer=[System.Collections.Generic.List[string]]::new() }
  Write-ZsArmFailure -ErrorRecord (Err '{"error":{"code":"RequestDisallowedByPolicy","message":"Resource was disallowed by policy."}}') -Context 'Creating X' 2>$null
  $polOut = $script:ZsSession.LogBuffer -join "`n"
  Check "operator told no role helps"    ($polOut -match 'No role assignment overrides')

  $dep = Resolve-ZsArmFailure -ErrorRecord (Err '{"error":{"code":"InUseSubnetCannotBeDeleted","message":"Subnet snet is in use by /subscriptions/a/resourceGroups/rg/providers/Microsoft.Network/networkInterfaces/nic-1/ipConfigurations/ip and cannot be deleted."}}')
  Check "still-referenced is Dependency" ($dep.Kind -eq 'Dependency')
  Check "the referrer is named"          ($dep.Scope -match 'nic-1')

  $tr = Resolve-ZsArmFailure -ErrorRecord (Err '{"error":{"code":"Conflict","message":"Cannot modify resource while in provisioning state: ''Provisioning''. Try again in a few minutes."}}')
  Check "provisioning state is Transient" ($tr.Kind -eq 'Transient')

  # And the boundaries hold: a real RBAC gap stays a real RBAC gap.
  Check "real RBAC unchanged"            ((Resolve-ZsArmFailure -ErrorRecord (Err '{"error":{"code":"AuthorizationFailed","message":"The client does not have authorization to perform action ''Microsoft.KeyVault/vaults/delete'' over scope ''/subscriptions/a/rg''."}}')).Kind -eq 'Permission')

  "`n  failures: $($global:zsfail)"
}
