$ErrorActionPreference='Stop'
Import-Module (Join-Path (Split-Path (Split-Path $PSScriptRoot -Parent) -Parent) 'ZscalerCloudConnector.psd1') -Force
$script:fail = 0
function Check($name,$cond){ if($cond){"  PASS  $name"} else {$script:fail++; "  FAIL  $name"} }

# Exercise internals in module scope.
& (Get-Module ZscalerCloudConnector) {

  function Check($name,$cond){ if($cond){"  PASS  $name"} else {$global:zsfail++; "  FAIL  $name"} }
  $global:zsfail = 0

  "== Wildcard action matching =="
  Check "exact match"            ((ConvertTo-ZsActionRegex -Pattern 'microsoft.network/virtualnetworks/write') -eq '^microsoft\.network/virtualnetworks/write$')
  Check "dot is escaped"         ('microsoftXnetwork/vnets/write' -notmatch (ConvertTo-ZsActionRegex -Pattern 'microsoft.network/vnets/write'))
  Check "star spans separators"  ('microsoft.network/virtualnetworks/subnets/write' -match (ConvertTo-ZsActionRegex -Pattern 'microsoft.network/*'))
  Check "*/read matches"         ('microsoft.compute/disks/read' -match (ConvertTo-ZsActionRegex -Pattern '*/read'))
  Check "*/read excludes write"  ('microsoft.compute/disks/write' -notmatch (ConvertTo-ZsActionRegex -Pattern '*/read'))

  "== RBAC evaluation semantics =="
  $owner      = [pscustomobject]@{ actions=@('*'); notActions=@(); dataActions=@(); notDataActions=@() }
  $contrib    = [pscustomobject]@{ actions=@('*'); notActions=@('Microsoft.Authorization/*/Write','Microsoft.Authorization/*/Delete'); dataActions=@(); notDataActions=@() }
  $netContrib = [pscustomobject]@{ actions=@('Microsoft.Network/*'); notActions=@(); dataActions=@(); notDataActions=@() }
  $uaa        = [pscustomobject]@{ actions=@('Microsoft.Authorization/*'); notActions=@(); dataActions=@(); notDataActions=@() }

  Check "Owner grants roleAssignments/write"    ((Test-ZsActionGranted -Action 'Microsoft.Authorization/roleAssignments/write' -Sets @($owner)).Granted)
  Check "Contributor denied roleAssign/write"   (-not (Test-ZsActionGranted -Action 'Microsoft.Authorization/roleAssignments/write' -Sets @($contrib)).Granted)
  Check "Contributor grants vnet write"         ((Test-ZsActionGranted -Action 'Microsoft.Network/virtualNetworks/write' -Sets @($contrib)).Granted)
  Check "notActions are case-insensitive"       (-not (Test-ZsActionGranted -Action 'microsoft.authorization/roleassignments/WRITE' -Sets @($contrib)).Granted)
  Check "roles are additive across sets"        ((Test-ZsActionGranted -Action 'Microsoft.Authorization/roleAssignments/write' -Sets @($contrib,$uaa)).Granted)
  Check "notAction in one role not global"      ((Test-ZsActionGranted -Action 'Microsoft.Network/virtualNetworks/write' -Sets @($contrib,$netContrib)).Granted)
  Check "missing action reported missing"       (-not (Test-ZsActionGranted -Action 'Microsoft.Compute/virtualMachines/write' -Sets @($netContrib)).Granted)

  "== Data actions evaluated separately =="
  $kvOfficer = [pscustomobject]@{ actions=@(); notActions=@(); dataActions=@('Microsoft.KeyVault/vaults/secrets/*'); notDataActions=@() }
  Check "setSecret via dataActions"   ((Test-ZsActionGranted -Action 'Microsoft.KeyVault/vaults/secrets/setSecret/action' -Sets @($kvOfficer) -DataAction).Granted)
  Check "control plane not satisfied" (-not (Test-ZsActionGranted -Action 'Microsoft.KeyVault/vaults/secrets/setSecret/action' -Sets @($kvOfficer)).Granted)
  Check "wildcard actions != dataActions" (-not (Test-ZsActionGranted -Action 'Microsoft.KeyVault/vaults/secrets/setSecret/action' -Sets @($netContrib) -DataAction).Granted)

  "== Deny assignments override grants =="
  $denyNet = [pscustomobject]@{ name='deny-net'; properties=[pscustomobject]@{
      denyAssignmentName='Block network writes'
      permissions=@([pscustomobject]@{ actions=@('Microsoft.Network/*/write'); notActions=@(); dataActions=@(); notDataActions=@() })
      principals=@([pscustomobject]@{ id='00000000-0000-0000-0000-000000000000' })
      excludePrincipals=@() } }
  $r = Test-ZsActionGranted -Action 'Microsoft.Network/virtualNetworks/write' -Sets @($owner) -DenyAssignments @($denyNet) -PrincipalId 'abc'
  Check "deny beats Owner"        (-not $r.Granted -and $r.Denied)
  Check "deny names the assignment" ($r.DeniedBy -eq 'Block network writes')
  $excl = [pscustomobject]@{ name='deny-net'; properties=[pscustomobject]@{
      denyAssignmentName='Block network writes'
      permissions=@([pscustomobject]@{ actions=@('Microsoft.Network/*/write'); notActions=@(); dataActions=@(); notDataActions=@() })
      principals=@([pscustomobject]@{ id='00000000-0000-0000-0000-000000000000' })
      excludePrincipals=@([pscustomobject]@{ id='abc' }) } }
  Check "excludePrincipals honoured" ((Test-ZsActionGranted -Action 'Microsoft.Network/virtualNetworks/write' -Sets @($owner) -DenyAssignments @($excl) -PrincipalId 'abc').Granted)

  "== Required action matrix is scope-shaped =="
  $gf = Get-ZsRequiredActions -Mode Greenfield -Topology VMSS -IdentityRoleMode LeastPrivilege
  $bf = Get-ZsRequiredActions -Mode Brownfield -Topology VMSS -IdentityRoleMode LeastPrivilege
  Check "greenfield needs RG write"        ($gf.Action -contains 'Microsoft.Resources/subscriptions/resourceGroups/write')
  Check "brownfield does not"              (-not ($bf.Action -contains 'Microsoft.Resources/subscriptions/resourceGroups/write'))
  Check "VMSS asks for scale set write"    ($gf.Action -contains 'Microsoft.Compute/virtualMachineScaleSets/write')
  Check "VM topology asks for VM write"    ((Get-ZsRequiredActions -Mode Greenfield -Topology VM).Action -contains 'Microsoft.Compute/virtualMachines/write')
  # RoleMode None only skips the control-plane roles. The vault, storage and remediation grants are
  # made whatever the mode, so the deployer needs roleAssignments/write either way.
  $none = Get-ZsRequiredActions -Mode Greenfield -IdentityRoleMode None -FunctionRoleMode None
  Check "RoleMode None still assigns roles" ($none.Action -contains 'Microsoft.Authorization/roleAssignments/write')
  Check "RoleMode None needs no roleDefs"   (-not ($none.Action -contains 'Microsoft.Authorization/roleDefinitions/write'))
  Check "LeastPrivilege needs roleDefs"    ($gf.Action -contains 'Microsoft.Authorization/roleDefinitions/write')
  # Locking is only half the transaction: an identity that can write a lock but not read or remove
  # one deploys fine and can never tear down, because every locked resource refuses its own delete.
  Check "needs locks/write"                ($gf.Action -contains 'Microsoft.Authorization/locks/write')
  Check "needs locks/read for teardown"    ($gf.Action -contains 'Microsoft.Authorization/locks/read')
  Check "needs locks/delete for teardown"  ($gf.Action -contains 'Microsoft.Authorization/locks/delete')
  Check "roleDefs flagged subscription"    ((($gf | Where-Object Action -eq 'Microsoft.Authorization/roleDefinitions/write').RequiredScope) -eq 'Subscription')
  Check "marketplace flagged subscription" ((($bf | Where-Object Action -like '*MarketplaceOrdering*').RequiredScope) -eq 'Subscription')
  Check "vnet write is deployment scope"   ((($bf | Where-Object Action -eq 'Microsoft.Network/virtualNetworks/write').RequiredScope) -eq 'Deployment')
  Check "Defender only when requested"     (-not ($gf.Action -contains 'Microsoft.Security/pricings/write'))
  Check "Defender included when asked"     ((Get-ZsRequiredActions -Mode Greenfield -Defender).Action -contains 'Microsoft.Security/pricings/write')
  Check "every entry has a purpose"        (@($gf | Where-Object { -not $_.Purpose }).Count -eq 0)

  "`n  failures: $($global:zsfail)"
}
