$ErrorActionPreference='Stop'
Import-Module (Join-Path (Split-Path (Split-Path $PSScriptRoot -Parent) -Parent) 'ZscalerCloudConnector.psd1') -Force
& (Get-Module ZscalerCloudConnector) {
  $global:zsfail = 0
  function Check($name,$cond){ if($cond){"  PASS  $name"} else {$global:zsfail++; "  FAIL  $name"} }

  $sub='11111111-1111-1111-1111-111111111111'
  $rg='rg-customer-shared'
  $rgPath="/subscriptions/$sub/resourceGroups/$rg"
  $script:ZsSession = @{ SubscriptionId=$sub; ResourceGroupName=$rg; Location='westus2'; LogFile=$null; LogBuffer=[System.Collections.Generic.List[string]]::new(); Connected=$true; ShortId='abcd1234'; DeploymentId='dep-1'; ArtifactRoot='/tmp/zsart'; Environment='prod'; DeployedAt='2026-08-19T00:00:00Z' }

  $global:deleted = [System.Collections.Generic.List[string]]::new()
  function Get-ArmToken { 'tok' }
  function Invoke-ArmRequest { param($Uri,$Method='Get',$Body,$MaxRetries=3,[switch]$AllowNotFound)
    if($Method -eq 'Delete'){ $global:deleted.Add(($Uri -split '\?')[0]) }
    return $null }
  function Invoke-ArmGet { param($Uri,[switch]$AllowNotFound)
    if($Uri -like '*roleAssignments*'){ return [pscustomobject]@{ value=@() } }
    return [pscustomobject]@{ value=@() } }
  function Test-ArmResource { param($Uri)
    if(($Uri -split '\?')[0] -in $global:deleted){ return @{ Exists=$false } }
    return @{ Exists=$true; Resource=[pscustomobject]@{ id=$Uri }; State='Succeeded' } }
  function Wait-ZsResourcesGone { param($Resources,$TimeoutSeconds,$PollSeconds) return @() }

  # A brownfield manifest: the module created resources inside a group it does NOT own.
  $script:ZsManifest = [ordered]@{
    SchemaVersion='3.0'; DeploymentId='dep-1'; SubscriptionId=$sub; ResourceGroup=$rg
    Resources=[ordered]@{
      ManagedIdentity = @([ordered]@{ Name='id-zscc'; ResourceId="$rgPath/providers/Microsoft.ManagedIdentity/userAssignedIdentities/id-zscc" })
      Vmss            = @([ordered]@{ Name='vmss-zscc'; ResourceId="$rgPath/providers/Microsoft.Compute/virtualMachineScaleSets/vmss-zscc" })
      RoleAssignment  = @(
        [ordered]@{ Name='ra-new'; ResourceId="$rgPath/providers/Microsoft.Authorization/roleAssignments/ra-new"; PreExisting=$false }
        [ordered]@{ Name='ra-old'; ResourceId="$rgPath/providers/Microsoft.Authorization/roleAssignments/ra-old"; PreExisting=$true })
      RoleDefinition  = @([ordered]@{ Name='ZSCC Connector Network Reader'; ResourceId="/subscriptions/$sub/providers/Microsoft.Authorization/roleDefinitions/role-guid" })
    }
    Outputs=[ordered]@{}; Errors=[System.Collections.Generic.List[string]]::new()
  }

  "== Brownfield teardown leaves the customer's group alone =="
  try { $res = Remove-ZsDeployment -Force -Confirm:$false 3>$null 6>$null } catch { "ERR: $($_.Exception.Message)"; $_.ScriptStackTrace; return }
  $rgDeleted = @($global:deleted | Where-Object { $_ -eq $rgPath }).Count -gt 0
  Check "resource group NOT deleted"      (-not $rgDeleted)
  Check "result says RG not removed"      (-not $res.ResourceGroupRemoved)
  Check "scale set deleted"               (@($global:deleted | Where-Object { $_ -like '*virtualMachineScaleSets/vmss-zscc' }).Count -eq 1)
  Check "identity deleted"                (@($global:deleted | Where-Object { $_ -like '*userAssignedIdentities/id-zscc' }).Count -eq 1)
  Check "our role assignment removed"     (@($global:deleted | Where-Object { $_ -like '*roleAssignments/ra-new' }).Count -eq 1)
  Check "pre-existing assignment kept"    (@($global:deleted | Where-Object { $_ -like '*roleAssignments/ra-old' }).Count -eq 0)
  Check "unused custom role removed"      (@($global:deleted | Where-Object { $_ -like '*roleDefinitions/role-guid' }).Count -eq 1)
  Check "identity removed after vmss"     ([array]::IndexOf($global:deleted.ToArray(),"$rgPath/providers/Microsoft.ManagedIdentity/userAssignedIdentities/id-zscc") -gt [array]::IndexOf($global:deleted.ToArray(),"$rgPath/providers/Microsoft.Compute/virtualMachineScaleSets/vmss-zscc"))

  "== -RemoveResourceGroup refused on a group we do not own =="
  $global:deleted.Clear()
  $threw=$null; try { Remove-ZsDeployment -RemoveResourceGroup -Force -Confirm:$false 3>$null 6>$null } catch { $threw=$_ }
  Check "switch refused"                  ($null -ne $threw)
  Check "explains it is brownfield"       ($threw.Exception.Message -like '*was not created by this module*')
  Check "says nothing was removed"        ($threw.Exception.Message -like '*Nothing has been removed*')
  Check "and truly deleted nothing"       ($global:deleted.Count -eq 0)

  "== Greenfield: the switch is honoured =="
  $global:deleted.Clear()
  $script:ZsManifest.Resources['ResourceGroup'] = @([ordered]@{ Name=$rg; ResourceId=$rgPath })
  $res2 = Remove-ZsDeployment -RemoveResourceGroup -Force -Confirm:$false 3>$null 6>$null
  Check "resource group deleted"          (@($global:deleted | Where-Object { $_ -eq $rgPath }).Count -eq 1)
  Check "result reports RG removed"       ($res2.ResourceGroupRemoved)

  "== Greenfield without the switch still keeps the group =="
  $global:deleted.Clear()
  $res3 = Remove-ZsDeployment -Force -Confirm:$false 3>$null 6>$null
  Check "RG kept by default"              (@($global:deleted | Where-Object { $_ -eq $rgPath }).Count -eq 0)
  Check "resources still removed"         ($res3.Removed -gt 0)

  "== A custom role still in use elsewhere is kept =="
  $global:deleted.Clear()
  $script:ZsManifest.Resources.Remove('ResourceGroup')
  function Invoke-ArmGet { param($Uri,[switch]$AllowNotFound)
    if($Uri -like '*roleAssignments*'){ return [pscustomobject]@{ value=@([pscustomobject]@{ properties=[pscustomobject]@{ roleDefinitionId="/subscriptions/$sub/providers/Microsoft.Authorization/roleDefinitions/role-guid" } }) } }
    return [pscustomobject]@{ value=@() } }
  $null = Remove-ZsDeployment -Force -Confirm:$false 3>$null 6>$null
  Check "in-use custom role kept"         (@($global:deleted | Where-Object { $_ -like '*roleDefinitions/role-guid' }).Count -eq 0)

  "== WhatIf performs no deletions =="
  $global:deleted.Clear()
  $null = Remove-ZsDeployment -WhatIf 3>$null 6>$null
  Check "WhatIf deleted nothing"          ($global:deleted.Count -eq 0)

  "== A mistyped switch cannot become a silent real run =="
  # --whatif is not a PowerShell switch. With positional binding on, it binds as a value to
  # whichever parameter is free, and the run proceeds for real instead of previewing.
  $global:deleted.Clear()
  $threw = $false
  try { $null = Remove-ZsDeployment -ResourceGroupName $rg -Force -Confirm:$false --whatif 3>$null 6>$null }
  catch { $threw = $true }
  Check "stray --whatif rejected"         ($threw)
  Check "stray --whatif deleted nothing"  ($global:deleted.Count -eq 0)

  "== A named manifest that does not exist stops the run =="
  # The tag scan is a wider inventory than the manifest, so falling back to it silently would delete
  # from a list the operator never asked for. This also catches a --switch that reached the parameter.
  $global:deleted.Clear()
  $threw = $false
  try { $null = Remove-ZsDeployment -ResourceGroupName $rg -ManifestPath '--whatif' -Force -Confirm:$false 3>$null 6>$null }
  catch { $threw = $true }
  Check "missing manifest is an error"    ($threw)
  Check "missing manifest deleted nothing" ($global:deleted.Count -eq 0)

  "== A scoped component is deleted after the scope that holds it =="
  # ARM refuses the component with 409 while the private link scope still has a scopedResources
  # child pointing at it, and refuses the scope while a private endpoint terminates on it.
  $ord = (Get-ZsTeardownOrder -Resources @(
    [pscustomobject]@{ Name='appi';   Type='microsoft.insights/components' }
    [pscustomobject]@{ Name='ampls';  Type='microsoft.insights/privateLinkScopes' }
    [pscustomobject]@{ Name='pe';     Type='Microsoft.Network/privateEndpoints' }
  )).Name
  Check "scope before component"          ([array]::IndexOf($ord,'ampls') -lt [array]::IndexOf($ord,'appi'))
  Check "endpoint before scope"           ([array]::IndexOf($ord,'pe') -lt [array]::IndexOf($ord,'ampls'))

  "== Ownership, not which run created it, decides deletion =="
  # A first run stopped by a missing permission leaves resources behind, and the re-run verifies
  # them rather than creating them. They are still this module's, and a teardown that spared them
  # would leave a deployment that can never be removed. The managed-by tag is what says so.
  Check "module tag means owned"          (Test-ZsModuleOwned -Resource ([pscustomobject]@{ tags=[pscustomobject]@{ 'managed-by'='ZscalerCloudConnector-PSModule' } }))
  Check "customer resource not owned"     (-not (Test-ZsModuleOwned -Resource ([pscustomobject]@{ tags=[pscustomobject]@{ 'owner'='platform' } })))
  Check "untagged not owned"              (-not (Test-ZsModuleOwned -Resource ([pscustomobject]@{ id='/x' })))
  Check "Get-ZsTags round-trips"          (Test-ZsModuleOwned -Resource ([pscustomobject]@{ tags=[pscustomobject](Get-ZsTags) }))

  "== A resource belonging to someone else is unlocked but not deleted =="
  # A vault the customer brought carries no managed-by tag, so it is flagged and never deleted —
  # but it is on the manifest, because the deployment locked it and must take that lock back off.
  $global:deleted.Clear()
  $script:ZsManifest.Resources.Remove('ResourceGroup')
  $adoptedKv = "$rgPath/providers/Microsoft.KeyVault/vaults/kv-zscc-earlier"
  $script:ZsManifest.Resources['KeyVault'] = @([ordered]@{ Name='kv-zscc-earlier'; ResourceId=$adoptedKv; PreExisting=$true })
  $outsideVnet = "$rgPath/providers/Microsoft.Network/virtualNetworks/vnet-someone-else"
  function Invoke-ArmGet { param($Uri,[switch]$AllowNotFound)
    if($Uri -like '*Authorization/locks?*'){ return [pscustomobject]@{ value=@(
      [pscustomobject]@{ id="$adoptedKv/providers/Microsoft.Authorization/locks/zscc-protect";   name='zscc-protect'; properties=[pscustomobject]@{ level='CanNotDelete' } },
      [pscustomobject]@{ id="$outsideVnet/providers/Microsoft.Authorization/locks/zscc-protect"; name='zscc-protect'; properties=[pscustomobject]@{ level='CanNotDelete' } }) } }
    if($Uri -like '*roleAssignments*'){ return [pscustomobject]@{ value=@() } }
    return [pscustomobject]@{ value=@() } }
  $adopt = Remove-ZsDeployment -Force -Confirm:$false 3>$null 6>$null
  Check "adopted resource unlocked"       (@($global:deleted | Where-Object { $_ -like "$adoptedKv/providers/*locks/zscc-protect" }).Count -eq 1)
  Check "adopted resource NOT deleted"    (@($global:deleted | Where-Object { $_ -notlike '*/locks/*' -and $_ -like '*kv-zscc-earlier*' }).Count -eq 0)
  Check "adopted counted as skipped"      ($adopt.Skipped -ge 1)
  Check "lock outside manifest stays"     (@($global:deleted | Where-Object { $_ -like '*vnet-someone-else*' }).Count -eq 0)
  $script:ZsManifest.Resources.Remove('KeyVault')

  "== A lock on a resource outside the manifest is left in place =="
  # The lock that blocked the real teardown sat on a key vault this deployment reused rather than
  # created. Other things in a shared group may rely on that protection, so it is not this
  # cmdlet's to remove — even though it carries this module's name, since a second deployment in
  # the same group writes the same name.
  $global:deleted.Clear()
  $script:ZsManifest.Resources.Remove('ResourceGroup')
  $reusedKv = "$rgPath/providers/Microsoft.KeyVault/vaults/kv-zscc-otherdeployment"
  $ourVmss  = "$rgPath/providers/Microsoft.Compute/virtualMachineScaleSets/vmss-zscc"
  function Invoke-ArmGet { param($Uri,[switch]$AllowNotFound)
    if($Uri -like '*Authorization/locks?*'){ return [pscustomobject]@{ value=@(
      [pscustomobject]@{ id="$reusedKv/providers/Microsoft.Authorization/locks/zscc-protect"; name='zscc-protect'; properties=[pscustomobject]@{ level='CanNotDelete'; notes='Zscaler CC - KeyVault' } },
      [pscustomobject]@{ id="$ourVmss/providers/Microsoft.Authorization/locks/zscc-protect";  name='zscc-protect'; properties=[pscustomobject]@{ level='CanNotDelete'; notes='Zscaler CC - Vmss' } },
      [pscustomobject]@{ id="$rgPath/providers/Microsoft.Authorization/locks/corp-governance"; name='corp-governance'; properties=[pscustomobject]@{ level='CanNotDelete'; notes='Platform team' } }) } }
    if($Uri -like '*roleAssignments*'){ return [pscustomobject]@{ value=@() } }
    return [pscustomobject]@{ value=@() } }
  $null = Remove-ZsDeployment -Force -Confirm:$false 3>$null 6>$null
  Check "lock on our resource removed"    (@($global:deleted | Where-Object { $_ -like "$ourVmss/providers/*locks/zscc-protect" }).Count -eq 1)
  Check "reused resource stays locked"    (@($global:deleted | Where-Object { $_ -like '*kv-zscc-otherdeployment*' }).Count -eq 0)
  Check "group-scope lock stays"          (@($global:deleted | Where-Object { $_ -like '*locks/corp-governance*' }).Count -eq 0)

  "== -RemoveResourceGroup removes every lock first =="
  # The whole group is going, and it only got here because this module created it, so nothing else
  # lives there to be protected. Every lock must be off before the resources go.
  $global:deleted.Clear()
  $script:ZsManifest.Resources['ResourceGroup'] = @([ordered]@{ Name=$rg; ResourceId=$rgPath })
  $null = Remove-ZsDeployment -RemoveResourceGroup -Force -Confirm:$false 3>$null 6>$null
  Check "reused resource unlocked too"    (@($global:deleted | Where-Object { $_ -like '*kv-zscc-otherdeployment*locks/zscc-protect' }).Count -eq 1)
  Check "foreign lock removed too"        (@($global:deleted | Where-Object { $_ -like '*locks/corp-governance*' }).Count -eq 1)
  $firstResource = [array]::FindIndex([string[]]@($global:deleted), [Predicate[string]]{ param($s) $s -notlike '*/locks/*' })
  $lastLock      = [array]::FindLastIndex([string[]]@($global:deleted), [Predicate[string]]{ param($s) $s -like '*/locks/*' })
  Check "all locks off before deletes"    ($lastLock -lt $firstResource)
  # Resource Manager resolves the order for a group delete, so the resources are not walked one at
  # a time first: that takes the long way to the same end state through every ordering hazard, and
  # still cannot reach the instances, disks and interfaces Azure made underneath them.
  $rgDeletes = @($global:deleted | Where-Object { $_ -match '/resourceGroups/[^/]+$' })
  $perResource = @($global:deleted | Where-Object { $_ -notlike '*/locks/*' -and $_ -notmatch '/resourceGroups/[^/]+$' -and $_ -notmatch 'roleAssignments|roleDefinitions' })
  Check "resources not deleted singly"    ($perResource.Count -eq 0)
  Check "the group itself is deleted"     ($rgDeletes.Count -eq 1)
  Check "role assignments still removed"  (@($global:deleted | Where-Object { $_ -match 'roleAssignments' }).Count -ge 1)

  "== A ScopeLocked failure states what this run did with that lock =="
  # Asserting a missing locks/delete for a lock the run never tried to remove sends an operator
  # after a permission they hold. Disposition is recorded, and permissions named only on a denial.
  $global:deleted.Clear()
  $blockedPe = "$rgPath/providers/Microsoft.Network/privateEndpoints/pe-kv"
  $blockingKv = "$rgPath/providers/Microsoft.KeyVault/vaults/kv-other"
  foreach ($k in @($script:ZsManifest.Resources.Keys)) { $script:ZsManifest.Resources.Remove($k) }
  $script:ZsManifest.Resources['PrivateEndpoint'] = @([ordered]@{ Name='pe-kv'; ResourceId=$blockedPe })
  function Invoke-ArmGet { param($Uri,[switch]$AllowNotFound)
    if($Uri -like '*Authorization/locks?*'){ return [pscustomobject]@{ value=@(
      [pscustomobject]@{ id="$blockingKv/providers/Microsoft.Authorization/locks/zscc-protect"; name='zscc-protect'; properties=[pscustomobject]@{ level='CanNotDelete' } }) } }
    if($Uri -like '*roleAssignments*'){ return [pscustomobject]@{ value=@() } }
    return [pscustomobject]@{ value=@() } }
  function Invoke-ArmRequest { param($Uri,$Method='Get',$Body,$MaxRetries=3,[switch]$AllowNotFound)
    if($Method -eq 'Delete'){
      $global:deleted.Add(($Uri -split '\?')[0])
      if($Uri -like '*privateEndpoints/pe-kv*'){ throw "ScopeLocked The scope '$blockedPe' cannot perform delete operation because following scope(s) are locked: '$blockingKv'. Please remove the lock and try again." } }
    return $null }
  $log = Remove-ZsDeployment -Force -Confirm:$false 3>&1 6>&1 | Out-String
  Check "no lock removal attempted"       (@($global:deleted | Where-Object { $_ -like '*/locks/*' }).Count -eq 0)
  Check "names the blocking scope"        ($log -match 'kv-other')
  Check "states none was attempted"       ($log -match 'No removal was attempted')
  Check "denies it is a permissions issue"($log -match 'not a permissions problem')
  Check "no unfounded locks/delete claim" ($log -notmatch 'locks/delete')
  $script:ZsManifest.Resources.Remove('PrivateEndpoint')

  "== An unmodelled dependency is retried once; a lock is not =="
  # The order table encodes every dependency the module knows of, but not one added by a later
  # Azure feature. Those clear themselves once the referencing resource is gone, so they get a
  # second attempt — and only they do: a lock is exactly as true the second time.
  $global:deleted.Clear()
  foreach ($k in @($script:ZsManifest.Resources.Keys)) { $script:ZsManifest.Resources.Remove($k) }
  $blockedId = "$rgPath/providers/Contoso.Widget/gadgets/blocked"
  $blockerId = "$rgPath/providers/Contoso.Widget/holders/blocker"
  $lockedId  = "$rgPath/providers/Microsoft.KeyVault/vaults/kv-locked"
  $script:ZsManifest.Resources['Blocked'] = @([ordered]@{ Name='blocked'; ResourceId=$blockedId })
  $script:ZsManifest.Resources['Blocker'] = @([ordered]@{ Name='blocker'; ResourceId=$blockerId })
  $script:ZsManifest.Resources['Locked']  = @([ordered]@{ Name='kv-locked'; ResourceId=$lockedId })
  $global:blockerGone = $false
  function Invoke-ArmGet { param($Uri,[switch]$AllowNotFound)
    if($Uri -like '*Authorization/locks?*'){ return [pscustomobject]@{ value=@() } }
    return [pscustomobject]@{ value=@() } }
  function Invoke-ArmRequest { param($Uri,$Method='Get',$Body,$MaxRetries=3,[switch]$AllowNotFound)
    if($Method -ne 'Delete'){ return $null }
    $id = ($Uri -split '\?')[0]
    $global:deleted.Add($id)
    if($id -eq $blockerId){ $global:blockerGone = $true; return $null }
    if($id -eq $blockedId -and -not $global:blockerGone){ throw "InUseSubnetCannotBeDeleted blocked is in use by $blockerId and cannot be deleted." }
    if($id -eq $lockedId){ throw "ScopeLocked The scope '$lockedId' cannot perform delete operation because following scope(s) are locked: '$lockedId'." }
    return $null }
  $rr = Remove-ZsDeployment -Force -Confirm:$false 3>$null 6>$null
  Check "dependency failure retried"      (@($global:deleted | Where-Object { $_ -eq $blockedId }).Count -eq 2)
  Check "retry happened after blocker"    ([array]::IndexOf([string[]]@($global:deleted), $blockerId) -lt [array]::LastIndexOf([string[]]@($global:deleted), $blockedId))
  Check "locked resource tried once only" (@($global:deleted | Where-Object { $_ -eq $lockedId }).Count -eq 1)
  Check "only the lock counts failed"     ($rr.Failed -eq 1)

  "`n  failures: $($global:zsfail)"
}
