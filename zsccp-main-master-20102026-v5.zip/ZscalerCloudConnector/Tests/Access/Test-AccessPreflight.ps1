$ErrorActionPreference='Stop'
Import-Module (Join-Path (Split-Path (Split-Path $PSScriptRoot -Parent) -Parent) 'ZscalerCloudConnector.psd1') -Force
& (Get-Module ZscalerCloudConnector) {
  $global:zsfail = 0
  function Check($name,$cond){ if($cond){"  PASS  $name"} else {$global:zsfail++; "  FAIL  $name"} }

  $sub='11111111-1111-1111-1111-111111111111'
  $script:ZsSession = @{ SubscriptionId=$sub; ResourceGroupName='rg-zscc-prod-westus2'; Location='westus2'; Environment='prod'; LogFile=$null; LogBuffer=[System.Collections.Generic.List[string]]::new(); Connected=$true }

  # oid-bearing JWT so identity resolution exercises the real decoder.
  function b64u([string]$s){ [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($s)).TrimEnd('=').Replace('+','-').Replace('/','_') }
  $jwt = "$(b64u '{"alg":"none"}').$(b64u '{"oid":"aaaa-oid","appid":"bbbb-appid","tid":"tenant","idtyp":"app","app_displayname":"zscc-deployer"}').sig"
  function Get-ArmToken { $global:tok }
  $global:tok = $jwt

  Check "oid read from token"      ((Get-ZsTokenClaims).ObjectId -eq 'aaaa-oid')
  Check "appid distinct from oid"  ((Get-ZsTokenClaims).AppId -eq 'bbbb-appid')
  Check "app token typed correctly"((Get-ZsTokenClaims).IdentityType -eq 'ServicePrincipal')
  Check "garbage token is safe"    (& { $global:tok='not-a-jwt'; $r=(Get-ZsTokenClaims).ObjectId -eq ''; $global:tok=$jwt; $r })

  # --- Mock ARM ---
  $global:perms = @{}      # scope -> permission sets
  $global:policyResp = $null
  $global:policyFor = $null  # optional: resource content -> response, for type-specific denials
  $global:existingIp = $null # what a GET of the deployment's public IP returns
  function Invoke-WebRequest { param($Uri,$Method,$Headers,[switch]$SkipHttpErrorCheck,$TimeoutSec)
    [pscustomobject]@{ StatusCode = 204 } }   # every RG exists
  function Invoke-ArmGet { param($Uri,[switch]$AllowNotFound)
    if($Uri -like '*denyAssignments*'){ return [pscustomobject]@{ value=@() } }
    if($Uri -like '*/permissions*'){
      $scope = ($Uri -split '/providers/')[0]
      if($global:perms.ContainsKey($scope)){ return [pscustomobject]@{ value=$global:perms[$scope] } }
      return [pscustomobject]@{ value=@() }
    }
    if($Uri -like '*/providers/Microsoft.Network/publicIP*'){ return $global:existingIp }
    throw "unexpected GET $Uri" }
  function Invoke-ArmPost { param($Uri,$Body)
    if($global:policyFor){ return & $global:policyFor $Body.resourceDetails.resourceContent }
    return $global:policyResp }

  $owner      = [pscustomobject]@{ actions=@('*'); notActions=@(); dataActions=@('*'); notDataActions=@() }
  $contribOnly= [pscustomobject]@{ actions=@('*'); notActions=@('Microsoft.Authorization/*/Write','Microsoft.Authorization/*/Delete'); dataActions=@('*'); notDataActions=@() }

  "== Greenfield, Owner on subscription =="
  $global:perms = @{ "/subscriptions/$sub" = @($owner) }
  $global:policyResp = [pscustomobject]@{ fieldRestrictions=@(); contentEvaluationResult=[pscustomobject]@{ policyEvaluations=@() } }
  $r = Test-ZsAccess -Topology VMSS -Quiet 3>$null 6>$null
  Check "greenfield passes"         ($r.Ready)
  Check "scope is the subscription" ($r.Scope -eq "/subscriptions/$sub")
  Check "mode is Greenfield"        ($r.Mode -eq 'Greenfield')
  Check "nothing missing"           (@($r.Missing).Count -eq 0)
  Check "all required granted"      ($r.Granted -eq $r.Required)

  "== Brownfield, Contributor on the RG only =="
  $rgScope = "/subscriptions/$sub/resourceGroups/rg-net"
  $global:perms = @{ $rgScope = @($contribOnly); "/subscriptions/$sub" = @() }
  $threw=$null; try { Test-ZsAccess -ResourceGroupName 'rg-net' -Topology VMSS -Quiet 3>$null 6>$null } catch { $threw=$_ }
  Check "brownfield gap stops run"        ($null -ne $threw)
  $msg = $threw.Exception.Message
  Check "reports the RG scope"            ($msg -like "*$rgScope*")
  Check "flags roleAssignments/write"     ($msg -like '*Microsoft.Authorization/roleAssignments/write*')
  Check "flags subscription-level gaps"   ($msg -like '*subscription level and cannot be granted on a resource group*')
  Check "names marketplace as sub-level"  ($msg -like '*MarketplaceOrdering*')
  Check "hints at RBAC Administrator"     ($msg -like '*Role Based Access Control Administrator*')
  Check "hints roleDefs need subscription"($msg -like '*Custom role definitions are written at subscription scope*')
  Check "says nothing was deployed"       ($msg -like '*Nothing has been deployed*')
  Check "vnet write not flagged missing"  ($msg -notlike '*Microsoft.Network/virtualNetworks/write*')

  "== Brownfield, correctly permissioned across both scopes =="
  $global:perms = @{ $rgScope = @($owner); "/subscriptions/$sub" = @($owner) }
  $r3 = Test-ZsAccess -ResourceGroupName 'rg-net' -Topology VMSS -Quiet 3>$null 6>$null
  Check "brownfield passes"           ($r3.Ready)
  Check "scope is the resource group" ($r3.Scope -eq $rgScope)
  Check "mode is Brownfield"          ($r3.Mode -eq 'Brownfield')

  "== A brought VNet in the platform's resource group =="
  $netRg = "/subscriptions/$sub/resourceGroups/rg-hub"
  $rbacAdmin = [pscustomobject]@{ actions=@('Microsoft.Authorization/roleAssignments/write','Microsoft.Authorization/*/read'); notActions=@(); dataActions=@(); notDataActions=@() }
  $global:perms = @{ $rgScope = @($owner); "/subscriptions/$sub" = @($owner); $netRg = @($rbacAdmin) }
  $r8 = Test-ZsAccess -ResourceGroupName 'rg-net' -Topology VMSS -IdentityRoleMode NetworkContributor -NetworkResourceGroupId $netRg -GrantSubnetRemediation -Quiet 3>$null 6>$null
  Check "subnet grant needs role assignment rights there"  ($r8.Ready)
  $threw8=$null; try { Test-ZsAccess -ResourceGroupName 'rg-net' -Topology VMSS -IdentityRoleMode NetworkContributor -NetworkResourceGroupId $netRg -GrantSubnetRemediation -CreateRemediationRole -Quiet 3>$null 6>$null } catch { $threw8=$_ }
  Check "replacement role needs roleDefinitions/write there" ($null -ne $threw8 -and $threw8.Exception.Message -like "*Missing at $netRg, the VNet's resource group:*Microsoft.Authorization/roleDefinitions/write*")
  Check "and the deployment group is not blamed"            ($null -ne $threw8 -and $threw8.Exception.Message -notlike "*Missing at $rgScope*")
  $global:perms[$netRg] = @()
  $threw9=$null; try { Test-ZsAccess -ResourceGroupName 'rg-net' -Topology VMSS -IdentityRoleMode NetworkContributor -NetworkResourceGroupId $netRg -GrantSubnetRemediation -Quiet 3>$null 6>$null } catch { $threw9=$_ }
  Check "subnet grant without rights there stops the run"  ($null -ne $threw9 -and $threw9.Exception.Message -like '*roleAssignments/write  — Grant the function identity its remediation role on the connector subnets*')
  Check "names the platform team's way out"                ($null -ne $threw9 -and $threw9.Exception.Message -like '*GrantFunctionSubnetJoin to false*')
  $r10 = Test-ZsAccess -ResourceGroupName 'rg-net' -Topology VMSS -IdentityRoleMode NetworkContributor -NetworkResourceGroupId $netRg -Quiet 3>$null 6>$null
  Check "no subnet grant, nothing asked of that group"     ($r10.Ready)
  $r11 = Test-ZsAccess -Topology VMSS -IdentityRoleMode NetworkContributor -NetworkResourceGroupId $netRg -GrantSubnetRemediation -Quiet 3>$null 6>$null
  Check "a subscription scope covers the VNet's group"     ($r11.Ready)

  "== With built-in roles, only the replacement role needs roleDefinitions/write =="
  $noRoleDefs = [pscustomobject]@{ actions=@('*'); notActions=@('Microsoft.Authorization/roleDefinitions/*'); dataActions=@('*'); notDataActions=@() }
  $global:perms = @{ $rgScope = @($noRoleDefs); "/subscriptions/$sub" = @($owner) }
  $r7 = Test-ZsAccess -ResourceGroupName 'rg-net' -Topology VMSS -IdentityRoleMode NetworkContributor -Quiet 3>$null 6>$null
  Check "built-in roles need no role definitions" ($r7.Ready)
  $threw7=$null; try { Test-ZsAccess -ResourceGroupName 'rg-net' -Topology VMSS -IdentityRoleMode NetworkContributor -CreateRemediationRole -Quiet 3>$null 6>$null } catch { $threw7=$_ }
  Check "replacement role needs roleDefinitions/write" ($null -ne $threw7 -and $threw7.Exception.Message -like '*Microsoft.Authorization/roleDefinitions/write*')

  "== Policy blocker names the policy =="
  $global:policyResp = [pscustomobject]@{
    fieldRestrictions=@()
    contentEvaluationResult=[pscustomobject]@{ policyEvaluations=@(
      [pscustomobject]@{ evaluationResult='NonCompliant'; policyInfo=[pscustomobject]@{ policyDefinitionDisplayName='Deny public IP addresses'; policyAssignmentDisplayName='Corp network guardrails'; policyDefinitionEffect='deny'; policyAssignmentScope="/subscriptions/$sub"; policyAssignmentId='/a'; policyDefinitionId='/b' } }) } }
  $threw3=$null; try { Test-ZsAccess -Topology VMSS -Quiet 3>$null 6>$null } catch { $threw3=$_ }
  Check "policy denial stops the run"  ($null -ne $threw3)
  Check "policy assignment named"      ($threw3.Exception.Message -like '*Corp network guardrails*')
  Check "policy definition named"      ($threw3.Exception.Message -like '*Deny public IP addresses*')
  Check "assignment scope shown"       ($threw3.Exception.Message -like "*assigned at: /subscriptions/$sub*")
  Check "suggests an exemption"        ($threw3.Exception.Message -like '*exemption*')

  "== A public IP deny stops only a run that would create the NAT egress address =="
  $global:policyFor = { param($content)
    $evals = @()
    if($content.type -eq 'Microsoft.Network/publicIPAddresses'){
      $evals = @([pscustomobject]@{ evaluationResult='NonCompliant'; policyInfo=[pscustomobject]@{ policyDefinitionDisplayName='Not allowed resource types'; policyAssignmentDisplayName='Org-Delta'; policyDefinitionEffect='deny'; policyAssignmentScope="/subscriptions/$sub"; policyAssignmentId='/a'; policyDefinitionId='/b' } })
    }
    [pscustomobject]@{ fieldRestrictions=@(); contentEvaluationResult=[pscustomobject]@{ policyEvaluations=$evals } } }
  $threw5=$null; try { Test-ZsAccess -Topology VMSS -Quiet 3>$null 6>$null } catch { $threw5=$_ }
  Check "new egress address is refused"   ($null -ne $threw5 -and $threw5.Exception.Message -like '*NAT egress*')
  $global:existingIp = [pscustomobject]@{ id="/subscriptions/$sub/resourceGroups/rg-zscc-prod-westus2/providers/Microsoft.Network/publicIPAddresses/pip-natgw-zscc-prod-westus2" }
  $r5 = Test-ZsAccess -Topology VMSS -Quiet 3>$null 6>$null
  Check "existing egress address reused"  ($r5.Ready)
  $global:existingIp = $null
  $r6 = Test-ZsAccess -Topology VMSS -NoNatGateway -Quiet 3>$null 6>$null
  $egressActions = { param($req) @($req | Where-Object { $_.Action -like 'Microsoft.Network/natGateways/*' -or $_.Action -like 'Microsoft.Network/publicIP*' }).Count }
  Check "platform egress is not refused for its address" ($r6.Ready)
  Check "platform egress needs no NAT or address rights" ((& $egressActions (Get-ZsRequiredActions -Mode Greenfield -Topology VMSS -NoNatGateway)) -eq 0 -and
                                                          (& $egressActions (Get-ZsRequiredActions -Mode Greenfield -Topology VMSS)) -gt 0)
  $global:policyFor = $null

  "== Permissions unreadable is a clean stop, not a crash =="
  function Invoke-ArmGet { param($Uri,[switch]$AllowNotFound)
    if($Uri -like '*/permissions*'){ throw [System.Management.Automation.ErrorRecord]::new([Exception]::new('403 forbidden'),'Arm.AuthorizationFailed','PermissionDenied',$null) }
    return [pscustomobject]@{ value=@() } }
  $threw4=$null; try { Test-ZsAccess -Quiet 3>$null 6>$null } catch { $threw4=$_ }
  Check "unreadable permissions stop run" ($null -ne $threw4)
  Check "names permissions/read"          ($threw4.Exception.Message -like '*Microsoft.Authorization/permissions/read*')
  Check "mentions Reader as the fix"      ($threw4.Exception.Message -like '*Reader*')

  "`n  failures: $($global:zsfail)"
}
