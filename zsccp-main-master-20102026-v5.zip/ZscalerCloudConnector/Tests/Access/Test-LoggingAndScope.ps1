$ErrorActionPreference='Stop'
Import-Module (Join-Path (Split-Path (Split-Path $PSScriptRoot -Parent) -Parent) 'ZscalerCloudConnector.psd1') -Force
& (Get-Module ZscalerCloudConnector) {
  $global:zsfail = 0
  function Check($name,$cond){ if($cond){"  PASS  $name"} else {$global:zsfail++; "  FAIL  $name"} }

  "== Logging contract =="
  $log = [System.IO.Path]::GetTempFileName()
  $script:ZsSession = @{ LogFile=$log; LogBuffer=[System.Collections.Generic.List[string]]::new(); SubscriptionId='11111111-1111-1111-1111-111111111111'; ResourceGroupName='rg-zscc-prod-westus2'; Location='westus2' }

  $console = Write-ZsLog "milestone line" -Level INFO -InformationVariable iv 6>&1
  Write-ZsLog "diagnostic detail" -Level DEBUG
  Write-ZsLog "a warning" -Level WARN 3>$null
  $content = Get-Content $log -Raw

  Check "DEBUG reaches the file"            ($content -match 'diagnostic detail')
  Check "DEBUG recorded as INFO"            ($content -match '\[INFO\] diagnostic detail')
  Check "DEBUG never labelled DEBUG"        ($content -notmatch '\[DEBUG\]')
  Check "INFO recorded as INFO"             ($content -match '\[INFO\] milestone line')
  Check "WARN keeps its level"              ($content -match '\[WARN\] a warning')
  Check "file lines are timestamped"        ($content -match '^\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}\] \[INFO\]')

  # Capture what actually reaches the console streams.
  $info = & { Write-ZsLog "on screen" -Level INFO } 6>&1 | Out-String
  $dbg  = & { Write-ZsLog "off screen" -Level DEBUG } 6>&1 3>&1 | Out-String
  Check "INFO prints to console"            ($info -match 'on screen')
  Check "DEBUG prints nothing"              ([string]::IsNullOrWhiteSpace($dbg))
  Check "console line has no timestamp"     ($info -notmatch '\d{4}-\d{2}-\d{2}')
  Check "console line has no level tag"     ($info -notmatch '\[INFO\]')
  Check "buffer mirrors the file"           ($script:ZsSession.LogBuffer.Count -ge 3)
  Remove-Item $log -Force

  "== Scope resolution =="
  $script:ZsSession.LogFile = $null
  $global:heads = @{}
  function Invoke-WebRequest { param($Uri,$Method,$Headers,[switch]$SkipHttpErrorCheck,$TimeoutSec)
    foreach($k in $global:heads.Keys){ if($Uri -like "*$k*"){ return [pscustomobject]@{ StatusCode=$global:heads[$k] } } }
    return [pscustomobject]@{ StatusCode=404 } }
  function Get-ArmToken { 'faketoken' }

  $global:heads = @{ 'rg-existing'=204 }
  $s = Resolve-ZsDeploymentScope -ResourceGroupName 'rg-existing'
  Check "existing BYO RG -> Brownfield"     ($s.Mode -eq 'Brownfield')
  Check "scope is the resource group"       ($s.Scope -eq '/subscriptions/11111111-1111-1111-1111-111111111111/resourceGroups/rg-existing')
  Check "ScopeKind is ResourceGroup"        ($s.Kind -eq 'ResourceGroup')
  Check "session RG rebound immediately"    ($script:ZsSession.ResourceGroupName -eq 'rg-existing')

  $script:ZsSession.ResourceGroupName = 'rg-zscc-prod-westus2'
  $global:heads = @{}
  $s2 = Resolve-ZsDeploymentScope -ResourceGroupName ''
  Check "no BYO RG -> Greenfield"           ($s2.Mode -eq 'Greenfield')
  Check "scope is the subscription"         ($s2.Scope -eq '/subscriptions/11111111-1111-1111-1111-111111111111')
  Check "greenfield leaves RG name alone"   ($script:ZsSession.ResourceGroupName -eq 'rg-zscc-prod-westus2')

  $global:heads = @{ 'rg-missing'=404 }
  $threw=$null; try { Resolve-ZsDeploymentScope -ResourceGroupName 'rg-missing' } catch { $threw=$_ }
  Check "missing BYO RG stops the run"      ($null -ne $threw)
  Check "message names the group"           ($threw.Exception.Message -like "*'rg-missing' does not exist*")
  Check "message says nothing deployed"     ($threw.Exception.Message -like '*Nothing has been deployed*')
  Check "no silent fall back to greenfield" ($threw.Exception.Message -notlike '*Greenfield*')

  $global:heads = @{ 'rg-locked'=403 }
  $threw2=$null; try { Resolve-ZsDeploymentScope -ResourceGroupName 'rg-locked' } catch { $threw2=$_ }
  Check "unreadable BYO RG stops the run"   ($null -ne $threw2)
  Check "403 distinguished from 404"        ($threw2.Exception.Message -like '*exists, but*cannot read it*')
  Check "names the missing permission"      ($threw2.Exception.Message -like '*Microsoft.Resources/subscriptions/resourceGroups/read*')

  "== Teardown helpers =="
  Check "ARM type parsed from id"    ((Resolve-ZsArmTypeFromId -ResourceId '/subscriptions/a/resourceGroups/b/providers/Microsoft.Network/virtualNetworks/vnet1') -eq 'Microsoft.Network/virtualNetworks')
  Check "nested type parsed"         ((Resolve-ZsArmTypeFromId -ResourceId '/subscriptions/a/resourceGroups/b/providers/Microsoft.Network/virtualNetworks/v/subnets/s') -eq 'Microsoft.Network/virtualNetworks/subnets')
  Check "non-provider id is empty"   ((Resolve-ZsArmTypeFromId -ResourceId '/subscriptions/a/resourceGroups/b') -eq '')

  $res = @(
    [pscustomobject]@{ Name='vnet';  Type='Microsoft.Network/virtualNetworks' }
    [pscustomobject]@{ Name='vmss';  Type='Microsoft.Compute/virtualMachineScaleSets' }
    [pscustomobject]@{ Name='id';    Type='Microsoft.ManagedIdentity/userAssignedIdentities' }
    [pscustomobject]@{ Name='nic';   Type='Microsoft.Network/networkInterfaces' }
    [pscustomobject]@{ Name='pip';   Type='Microsoft.Network/publicIPAddresses' }
    [pscustomobject]@{ Name='nat';   Type='Microsoft.Network/natGateways' }
    [pscustomobject]@{ Name='odd';   Type='Contoso.Widget/things' }
  )
  $ord = (Get-ZsTeardownOrder -Resources $res).Name
  Check "compute deleted first"      ($ord[0] -eq 'vmss')
  Check "identity deleted last"      ($ord[-1] -eq 'id')
  Check "vnet after its nic"         ([array]::IndexOf($ord,'vnet') -gt [array]::IndexOf($ord,'nic'))
  # A subnet's delete is what clears its NAT gateway reference, and a NAT gateway holds its
  # public IP until it is gone: the network, then the gateway, then the address.
  Check "nat gateway after the vnet, its pip after it" ([array]::IndexOf($ord,'nat') -gt [array]::IndexOf($ord,'vnet') -and [array]::IndexOf($ord,'pip') -gt [array]::IndexOf($ord,'nat'))
  Check "unknown type sorts middle"  ([array]::IndexOf($ord,'odd') -gt 0 -and [array]::IndexOf($ord,'odd') -lt ($ord.Count-1))
  Check "network api-version chosen" ((Resolve-ZsTeardownApiVersion -ResourceType 'Microsoft.Network/virtualNetworks') -eq $script:ApiVersions.Network)
  Check "unknown ns falls back"      ((Resolve-ZsTeardownApiVersion -ResourceType 'Contoso.Widget/things') -eq $script:ApiVersions.ResourceGroup)

  # Microsoft.Insights versions each type separately. A namespace-wide value is wrong for every one
  # of these, and ARM reports that as NoRegisteredProviderFound, which reads as a registration
  # problem and sends the operator chasing a provider that is already registered.
  Check "metricAlerts per-type"      ((Resolve-ZsTeardownApiVersion -ResourceType 'Microsoft.Insights/metricAlerts') -eq $script:ApiVersions.MetricAlert)
  Check "scheduledQueryRules per-type" ((Resolve-ZsTeardownApiVersion -ResourceType 'Microsoft.Insights/scheduledQueryRules') -eq $script:ApiVersions.ScheduledQuery)
  Check "components per-type"        ((Resolve-ZsTeardownApiVersion -ResourceType 'microsoft.insights/components') -eq $script:ApiVersions.AppInsights)
  Check "actionGroups per-type"      ((Resolve-ZsTeardownApiVersion -ResourceType 'Microsoft.Insights/actionGroups') -eq $script:ApiVersions.ActionGroup)
  Check "privateLinkScopes per-type" ((Resolve-ZsTeardownApiVersion -ResourceType 'microsoft.insights/privateLinkScopes') -eq $script:ApiVersions.PrivateLinkScope)
  Check "autoscale keeps namespace"  ((Resolve-ZsTeardownApiVersion -ResourceType 'Microsoft.Insights/autoscaleSettings') -eq $script:ApiVersions.Insights)
  Check "nested child uses parent"   ((Resolve-ZsTeardownApiVersion -ResourceType 'microsoft.insights/privateLinkScopes/scopedResources') -eq $script:ApiVersions.PrivateLinkScope)
  # The delete path must agree with the create path, or a resource that deploys cannot be torn down.
  Check "delete matches create"      ((Resolve-ZsTeardownApiVersion -ResourceType 'Microsoft.Insights/components') -eq $script:ApiVersions.AppInsights)

  "`n  failures: $($global:zsfail)"
}
