"""
Behavioural tests for the lifecycle function's health evaluation and portal contract.

Run with:  python3 Tests/test_function_app.py

Only the pure decision logic is exercised: grace period, health verdict, EC group parsing,
API key obfuscation and app setting coercion. Nothing here reaches Azure or the portal, so
the suite runs anywhere Python 3 does and needs none of the vendored dependencies.
"""

import datetime
import os
import sys
import types

# Importing the function module would otherwise leave __pycache__ inside the deployment
# payload, which then ships to the Functions host.
sys.dont_write_bytecode = True

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "FunctionApp"))

# The module imports the Functions and Identity packages at load time. Stub them so the
# decision logic can be imported without the runtime present.
_functions = types.ModuleType("azure.functions")


class _App:
    def timer_trigger(self, **_kwargs):
        def decorate(fn):
            return fn
        return decorate


_functions.FunctionApp = _App
_functions.TimerRequest = object
_azure = types.ModuleType("azure")
_azure.functions = _functions
_identity = types.ModuleType("azure.identity")
_identity.ManagedIdentityCredential = object
sys.modules.update({"azure": _azure, "azure.functions": _functions, "azure.identity": _identity})

import function_app as fa  # noqa: E402

FAILURES = []


def check(name, condition):
    print(("PASS " if condition else "FAIL ") + name)
    if not condition:
        FAILURES.append(name)


DP, UNHEALTHY, CONSECUTIVE, GRACE = 10, 7, 5, 30
NOW = datetime.datetime.now(datetime.timezone.utc)
OLD = {"name": "old", "time_created": NOW - datetime.timedelta(minutes=90)}
FRESH = {"name": "fresh", "time_created": NOW - datetime.timedelta(minutes=5)}


def test_grace_period():
    evaluate, _ = fa.check_grace_period(FRESH, [None] * 5, DP, GRACE)
    check("booting instance with no healthy sample is exempt", evaluate is False)

    evaluate, values = fa.check_grace_period(OLD, [], DP, GRACE)
    check("long lived with no metrics evaluates as fully unhealthy",
          evaluate is True and values == [None] * DP)

    evaluate, values = fa.check_grace_period(FRESH, [None, None, 100, 0, 0], DP, GRACE)
    check("one healthy sample ends the grace period early",
          evaluate is True and values == [100, 0, 0])

    evaluate, values = fa.check_grace_period(OLD, [100] * 30, DP, GRACE)
    check("long history is truncated to the evaluation window", len(values) == DP)


def test_health_verdict():
    check("ten healthy samples is healthy",
          fa.determine_health("x", [100] * 10, DP, UNHEALTHY, CONSECUTIVE) is True)
    check("seven of ten unhealthy is unhealthy",
          fa.determine_health("x", [0] * 7 + [100] * 3, DP, UNHEALTHY, CONSECUTIVE) is False)
    check("five alternating failures stay healthy",
          fa.determine_health("x", [0, 100] * 5, DP, UNHEALTHY, CONSECUTIVE) is True)
    check("five consecutive failures is unhealthy",
          fa.determine_health("x", [100] * 5 + [0] * 5, DP, UNHEALTHY, CONSECUTIVE) is False)
    check("absent samples count as unhealthy",
          fa.determine_health("x", [None] * 10, DP, UNHEALTHY, CONSECUTIVE) is False)
    check("a short window cannot reach the count threshold",
          fa.determine_health("x", [0] * 4, DP, UNHEALTHY, CONSECUTIVE) is True)


def test_portal_contract():
    group = {
        "id": 77,
        "name": "vnet-rg-sub-westus3-vmss",
        "ecVMs": [
            {"id": 101, "name": "cc-1", "metaConfig": {"uuid": "AAAA-1111"}},
            {"id": 102, "name": "cc-2", "metaConfig": {"uuid": "102"}},
            {"id": 103, "name": "cc-3", "metaConfig": {}},
        ],
    }
    members = fa.extract_group_members(group)
    check("members are read from ecVMs", len(members) == 1)
    check("correlation key is the metaConfig uuid, lowercased",
          members[0]["uuid"] == "aaaa-1111")
    check("group id travels with the member", members[0]["group_id"] == 77)
    check("a uuid equal to the member id is rejected as uncorrelatable",
          all(m["vm_id"] != 102 for m in members))
    check("a member with no uuid is skipped rather than guessed at",
          all(m["vm_id"] != 103 for m in members))
    check("an unrecognised payload yields nothing instead of raising",
          fa.extract_group_members({"id": 1, "somethingElse": []}) == [])
    check("group name follows the registration contract",
          fa.ec_group_name("vnet", "rg", "sub", "westus3", "vmss")
          == "vnet-rg-sub-westus3-vmss")


def test_api_key_obfuscation():
    seed = "abcdefghijkl"
    timestamp, key = fa.obfuscate_api_key(seed)
    n = str(timestamp)[-6:]
    r = str(int(n) >> 1).zfill(6)
    expected = "".join(seed[int(d)] for d in n) + "".join(seed[int(d) + 2] for d in r)
    check("obfuscation matches the reference algorithm", key == expected)


def test_settings():
    os.environ["HC_UNHEALTHY_THRESHOLD"] = "8"
    check("numeric settings are coerced from their string form",
          fa._int_setting("HC_UNHEALTHY_THRESHOLD", default=7) == 8)

    os.environ["HC_DATA_POINTS"] = "not-a-number"
    check("a malformed numeric setting falls back to the default",
          fa._int_setting("HC_DATA_POINTS", default=10) == 10)

    os.environ["TERMINATE_UNHEALTHY_INSTANCES"] = "false"
    check("remediation can be switched off by app setting",
          fa._bool_setting("TERMINATE_UNHEALTHY_INSTANCES", default=True) is False)

    os.environ.pop("AZURE_SUBSCRIPTION_ID", None)
    os.environ["SUBSCRIPTION_ID"] = "/subscriptions/1234/"
    check("the Zscaler-form subscription path is accepted",
          fa.subscription_id() == "1234")
    os.environ["AZURE_SUBSCRIPTION_ID"] = "abcd"
    check("the Zscaler name takes precedence over the legacy name",
          fa.subscription_id() == "1234")
    os.environ.pop("SUBSCRIPTION_ID", None)
    check("the legacy name still works alone",
          fa.subscription_id() == "abcd")

    os.environ["VMSS_NAME"] = '["v1","v2"]'
    check("VMSS_NAME parses as a JSON list", fa.vmss_names() == ["v1", "v2"])
    os.environ["VMSS_NAME"] = "v1,v2"
    check("VMSS_NAME parses as a comma separated list", fa.vmss_names() == ["v1", "v2"])


def main():
    test_grace_period()
    test_health_verdict()
    test_portal_contract()
    test_api_key_obfuscation()
    test_settings()
    print(f"\n{len(FAILURES)} failure(s)")
    return 1 if FAILURES else 0


if __name__ == "__main__":
    sys.exit(main())
