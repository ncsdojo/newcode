# PowerShell 7 requirement
if ($PSVersionTable.PSVersion.Major -lt 7) {
    $msg = @"
ZscalerCloudConnector requires PowerShell 7 or later.
You are running PowerShell $($PSVersionTable.PSVersion).

Install PowerShell 7:
  Windows:   winget install Microsoft.PowerShell
  macOS:     brew install powershell
  Linux:     https://learn.microsoft.com/en-us/powershell/scripting/install/installing-powershell-on-linux

After installing, open a new terminal with 'pwsh' and re-import the module.
"@
    Write-Warning $msg
    throw "PowerShell 7+ is required. Current version: $($PSVersionTable.PSVersion)"
}

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$script:ZsSession  = $null
$script:ZsManifest = $null

# Sleep prevention
# Long deployments (Bastion alone takes 7 minutes) can be interrupted by system sleep.
# On Windows, SetThreadExecutionState keeps the system awake while the module is active.
# Suspend-ZsSleep / Resume-ZsSleep are called by New-ZsDeployment at start/end.
$script:SleepPrevented = $false

if ($IsWindows -or [System.Runtime.InteropServices.RuntimeInformation]::IsOSPlatform([System.Runtime.InteropServices.OSPlatform]::Windows)) {
    Add-Type -TypeDefinition @"
    using System.Runtime.InteropServices;
    public static class SleepGuard {
        [DllImport("kernel32.dll")]
        public static extern uint SetThreadExecutionState(uint esFlags);
        public const uint ES_CONTINUOUS       = 0x80000000;
        public const uint ES_SYSTEM_REQUIRED  = 0x00000001;
        public const uint ES_DISPLAY_REQUIRED = 0x00000002;
    }
"@ -ErrorAction SilentlyContinue
}

function Suspend-ZsSleep {
    [CmdletBinding()] param()
    if (-not $script:SleepPrevented) {
        try {
            [SleepGuard]::SetThreadExecutionState(
                [SleepGuard]::ES_CONTINUOUS -bor [SleepGuard]::ES_SYSTEM_REQUIRED
            ) | Out-Null
            $script:SleepPrevented = $true
        } catch { }
    }
}

function Resume-ZsSleep {
    [CmdletBinding()] param()
    if ($script:SleepPrevented) {
        try {
            [SleepGuard]::SetThreadExecutionState([SleepGuard]::ES_CONTINUOUS) | Out-Null
            $script:SleepPrevented = $false
        } catch { }
    }
}

. "$PSScriptRoot/Config/ZscalerDefaults.ps1"
foreach ($f in (Get-ChildItem "$PSScriptRoot/Private" -Filter '*.ps1')) { . $f.FullName }
foreach ($f in (Get-ChildItem "$PSScriptRoot/Public"  -Filter '*.ps1')) { . $f.FullName }

Export-ModuleMember -Function @(
    'Connect-ZscalerAzure','Connect-ZscalerCloud','Disconnect-ZscalerAzure','Disconnect-ZscalerCloud'
    'New-ZsResourceGroup','New-ZsNetworkSecurity','New-ZsNetworkFoundation'
    'New-ZsPublicNetwork','New-ZsPrivateNetwork','New-ZsVnetPeering'
    'New-ZsIdentity','New-ZsKeyVault','New-ZsLifecycleFunctionApp','New-ZsLoadBalancer'
    'Approve-ZsMarketplaceTerms','New-ZsCloudConnector','New-ZsCloudConnectorVmss','New-ZsDnsResolver'
    'New-ZsProvisioningUrl','New-ZsSshKey'
    'New-ZsDeploymentConfig','Export-ZsDeploymentConfig'
    'New-ZsDeployment','Remove-ZsDeployment','Reset-ZsConnectors'
    'Test-ZsAccess','Test-ZsPrerequisites','Test-ZsDeployment','Get-ZsDeploymentManifest','Compare-ZsDeployment','Get-ZsUsableZones'
    'Set-ZsDefenderPlans','New-ZsDiagnostics','Get-ZsCapacityPlan','New-ZsBastion','New-ZsMonitorAlerts','New-ZsMonitorPrivateLink'
)
