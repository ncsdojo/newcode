<#
.SYNOPSIS
    Part of the ZscalerCloudConnector module (ConvertFrom-ZsSecureString).

.NOTES
    Module   : ZscalerCloudConnector
    Version  : 5.4.1.0
    Author   : NCS Dojo
    Copyright: (c) 2026 NCS Dojo. MIT License.
#>

Set-StrictMode -Version Latest

$script:ApiVersions = [ordered]@{
    ResourceGroup = '2024-03-01';   Network       = '2024-01-01'
    # natGateways and their public IPs only: the StandardV2 zone-redundant SKU is newer than the
    # api-version the rest of Microsoft.Network runs on here, and bumping the shared version for
    # one SKU would put every network resource on a surface this module has not been run against.
    # 2025-03-01 is the first stable Microsoft.Network api-version whose NatGatewaySkuName enum
    # includes StandardV2 (per the Azure REST API specs and the versioned REST reference;
    # 2025-01-01 and earlier list only Standard and reject the value).
    NatGateway    = '2025-03-01'
    # bastionHosts only. enablePrivateOnlyBastion - a Premium Bastion with no public IP - is not
    # in the 2024-01-01 schema the rest of Microsoft.Network uses here; 2025-03-01 is the first
    # stable api-version in the REST specs that carries it.
    Bastion       = '2025-03-01'
    Compute       = '2024-07-01';   Identity      = '2023-01-31'
    KeyVault      = '2023-07-01'
    Authorization = '2022-04-01';   Marketplace   = '2021-01-01'
    Lock          = '2020-05-01';   DnsResolver   = '2022-07-01'
    Features      = '2021-07-01';   Providers     = '2021-04-01'
    Subscription  = '2022-12-01';   Storage       = '2023-05-01'
    AppService    = '2023-12-01';   Web           = '2023-12-01'
    Insights      = '2022-10-01';        LogAnalytics = '2023-09-01'
    Security      = '2024-01-01';   SecurityContact = '2023-12-01-preview'
    PrivateDns    = '2020-06-01'
    AppInsights   = '2020-02-02';   MetricAlert   = '2018-03-01'
    ActionGroup   = '2023-01-01';   ScheduledQuery = '2023-12-01'
    PrivateLinkScope = '2021-09-01'
    # Microsoft.Resources/tags, to merge one tag onto a resource without rewriting it.
    Tags          = '2021-04-01'
}

# The name every lock this module writes carries. Teardown does not match on it: it lists the locks
# in the resource group and removes those sitting on resources its manifest lists, whatever they are
# called. The name is for the operator reading the portal, and for the notes on the lock itself.
$script:ZsLockName = 'zscc-protect'

# The managed-by tag values that mean "this deployment stack built it". Two implementations write
# the same deployment: this module, and the Terraform configuration that mirrors it. Teardown from
# either side has to recognise both, or a deployment built with one and reconciled by the other
# becomes undeletable by both.
$script:ZsOwnedByTag  = 'ZscalerCloudConnector-PSModule'
# Set when Azure Policy denies a custom role definition PUT during a run. Policy applies to
# the whole scope, so once one custom role is refused, attempting the next one just produces
# the same 403 and the same wall of policy identifiers; later sites read this and go straight
# to their built-in fallback with one line instead.
$script:ZsCustomRoleDenial = $null
$script:ZsOwnedByTags = @('ZscalerCloudConnector-PSModule', 'terraform-zscc')

$script:Endpoints = @{
    Arm     = 'https://management.azure.com'
    Login   = 'https://login.microsoftonline.com'
    Storage = 'https://storage.azure.com'
}

$script:ZscalerClouds = @{
    zscaler      = @{ Connector = 'https://connector.zscaler.net'  }
    zscalerone   = @{ Connector = 'https://connector.zscalerone.net'  }
    zscalertwo   = @{ Connector = 'https://connector.zscalertwo.net'  }
    zscalerthree = @{ Connector = 'https://connector.zscalerthree.net'  }
    zscloud      = @{ Connector = 'https://connector.zscloud.net'  }
    zscalergov   = @{ Connector = 'https://connector.zscalergov.net'  }
}

$script:CcImage = @{
    Publisher = 'zscaler1579058425289'; Offer = 'zia_cloud_connector'
    Sku       = 'zs_ser_gen1_cc_01';   Version = 'latest'
    DefaultVmSize = 'Standard_D2s_v3'
}

$script:CcFormFactorMap = @{
    Small  = @('Standard_D2s_v3')
    Medium = @('Standard_D4s_v3','Standard_F4s_v2')
    Large  = @('Standard_D4s_v3','Standard_F8s_v2')
}

$script:Roles = @{
    NetworkContributor = '4d97b98b-1d4f-4787-a291-c67834d212e7'
    Reader             = 'acdd72a7-3385-48ef-bd42-f606fba81ae7'
    KvSecretsOfficer   = 'b86a8fe4-44ce-4948-aee5-eccb2c155cd7'
    KvSecretsUser      = '4633458b-17de-408a-b874-0445c86b69e6'
    # Identity-based AzureWebJobsStorage. The host needs Blob Data Owner (not merely
    # Contributor) because it creates and manages blob leases for singleton locks and
    # the host key container, and Queue/Table Data Contributor for the durable/monitor
    # bookkeeping the Functions host performs even when a function uses neither.
    StorageBlobDataOwner        = 'b7e6dc6d-f1e8-4753-8033-0f276bb0955b'
    StorageQueueDataContributor = '974c5e8b-45b9-4653-ba55-5f855dd0fb88'
    StorageTableDataContributor = '0a9a7e1f-b9d0-4cc4-a60d-0319b160aaa3'
    # Required alongside the data-plane roles for identity-based AzureWebJobsStorage: the host
    # reads account properties at startup, which no data role covers. Assigned at the storage
    # account only, never at the resource group.
    StorageAccountContributor   = '17d1049b-9a84-46fb-8f53-869881c3d3ab'
    # Health remediation. Replacing a connector in a Flexible scale set writes the scale set,
    # the connector VM, its NICs and disk, and joins the backend pool and both subnets; Virtual
    # Machine Contributor carries all of it. Managed Identity Operator is the built-in role for
    # assigning the connector identity to the replacement.
    VirtualMachineContributor   = '9980e02c-c2be-4d73-94e8-173b1dc7cf3c'
    ManagedIdentityOperator     = 'f1a07417-d97a-45cb-824c-7a7467783830'
    # Microsoft.Insights/Metrics/Write, which publishing smedge_metrics needs. Network Contributor
    # does not carry it, so a connector identity on that role gets this one beside it.
    MonitoringMetricsPublisher  = '3913510d-42f4-4e42-8a64-420c390055eb'
}

# Least-privilege actions for the connector managed identity.
$script:CcIdentityActions = @(
    'Microsoft.Network/networkInterfaces/read'
    'Microsoft.Network/networkInterfaces/ipconfigurations/read'
    'Microsoft.Network/virtualNetworks/subnets/read'
    'Microsoft.Network/loadBalancers/read'
)

# Data actions for the connector managed identity. Metrics/Write lets the appliance
# publish smedge_metrics (Zscaler/CloudConnectors namespace) to Azure Monitor —
# the custom metric the VMSS autoscale rules evaluate. Without it, metric-driven
# scale-out/scale-in never fires.
$script:CcIdentityDataActions = @(
    'Microsoft.Insights/Metrics/Write'
)

# Replacing an unhealthy connector in a Flexible scale set, and nothing more: the custom role
# CreateRemediationRole defines in place of Virtual Machine Contributor. The identity's assign
# action comes from Managed Identity Operator, granted beside it.
$script:RemediationActions = @(
    'Microsoft.Compute/virtualMachineScaleSets/write'
    'Microsoft.Compute/virtualMachineScaleSets/delete/action'
    'Microsoft.Compute/virtualMachines/write'
    'Microsoft.Compute/virtualMachines/delete'
    'Microsoft.Network/networkInterfaces/write'
    'Microsoft.Network/networkInterfaces/delete'
    'Microsoft.Network/networkInterfaces/join/action'
    'Microsoft.Compute/disks/write'
    'Microsoft.Compute/disks/delete'
    'Microsoft.Network/loadBalancers/backendAddressPools/join/action'
    'Microsoft.Network/virtualNetworks/subnets/join/action'
)


# Least-privilege actions for the lifecycle Function App identity.
# The function reads VMs and VMSS instances to discover live connectors, and reads
# secrets from Key Vault (granted separately at vault scope). It performs no writes
# against any Azure resource, so nothing here is a write action.
$script:FuncIdentityActions = @(
    'Microsoft.Compute/virtualMachines/read'
    'Microsoft.Compute/virtualMachineScaleSets/read'
    'Microsoft.Compute/virtualMachineScaleSets/virtualMachines/read'
    'Microsoft.Compute/virtualMachineScaleSets/virtualMachines/instanceView/read'
    'Microsoft.Resources/subscriptions/resourceGroups/read'
)

# The custom role 5.4.1.0 assigned at each scale set for health remediation. It can delete a
# connector but not start its replacement, which also writes the VM, its NICs and disk. Re-runs
# find its assignments by this name and remove them.
$script:ZsLegacyRemediationRoleName = 'ZSCC Lifecycle Function Health Remediation'

# Zscaler's published lifecycle package, version 1.0.3, pinned to the commit that released it so
# the bytes behind the URL cannot change: 31,256,639 bytes, SHA-256
# 8cbe698b57164c757f80e93961867408bb9d172185a246833b9b78e86f671361. The Function App runs straight
# from it, so the deployment never writes to the private storage account's data plane.
$script:ZsVendorPackageUrl = 'https://raw.githubusercontent.com/zscaler/terraform-azurerm-cloud-connector-modules/6ca00169e6db4b983200d46c632b64fb29c427a7/modules/terraform-zscc-function-app-azure/zscaler_cc_function_app.zip'

# Tag on the Function App naming the content hash of the local package last zip-deployed to it, so a
# re-run pushes only a package that changed, and a run from outside the network can tell whether the
# app already has its code.
$script:ZsPackageTag = 'zscc-function-package'

# remotesupport.<cloud>.net on the commercial cloud, the address Zscaler's own module opens
# TCP 12002 to. Other clouds resolve elsewhere; pass -SupportServerIp there.
$script:ZsSupportServerIp = '199.168.148.101'

# The privatelink zones this deployment's private endpoints register in, by role.
$script:ZsPrivateDnsZones = [ordered]@{
    vault = 'privatelink.vaultcore.azure.net'
    blob  = 'privatelink.blob.core.windows.net'
    queue = 'privatelink.queue.core.windows.net'
    table = 'privatelink.table.core.windows.net'
    sites = 'privatelink.azurewebsites.net'
}

# The healthy value of the connectors' own health signal. Distinct from smedge_metrics, which
# drives autoscale: a connector can keep publishing telemetry while reporting unhealthy.
$script:CcHealthyValue = 100

$script:ZpaDomains = @(
    '*.prod.zpath.net','*.zpagov.net','*.zpatwo.net','*.zscloud.net'
    '*.zscaler.net','*.zscalergov.net','*.zscalerone.net'
    '*.zscalertwo.net','*.zscalerthree.net','*.private.zscaler.com'
)

$script:ZsSession  = $null
$script:ZsManifest = $null

function ConvertFrom-ZsSecureString {
    param([Parameter(Mandatory)][SecureString]$Secure)
    $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
    try   { return [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
    finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

function ConvertTo-ZsSecureString {
    <#
    .SYNOPSIS Normalizes a credential argument to a SecureString.
    .DESCRIPTION Parameters that accept a secret are typed [object] so callers may pass either a plain
        string (convenient at the command line) or a SecureString (from Read-Host -AsSecureString). This
        converts a plain string and passes a SecureString through unchanged, so every entry point handles
        both forms identically instead of repeating the coercion inline.
    .PARAMETER Value The credential: a String or a SecureString.
    .PARAMETER Name Field name, used only in the error when the type is neither.
    .OUTPUTS [SecureString]
    #>
    [CmdletBinding()]
    [OutputType([SecureString])]
    param([AllowNull()][object]$Value, [string]$Name = 'value')
    if ($null -eq $Value) { return $null }
    if ($Value -is [SecureString]) { return $Value }
    if ($Value -is [string])       { return (ConvertTo-SecureString $Value -AsPlainText -Force) }
    throw "$Name must be a String or SecureString."
}

function Assert-ZsConnected {
    <#
    .SYNOPSIS Asserts an active session and terminates cleanly if absent.
    .DESCRIPTION Guards both session types from one place. Default checks the Azure session; -Cloud
        checks the Zscaler session. The error is raised through the caller's $PSCmdlet when supplied, so
        it surfaces from the invoked cmdlet with no internal path.
    .PARAMETER Cmdlet The calling $PSCmdlet.
    .PARAMETER Cloud Check the Zscaler session instead of the Azure session.
    #>
    param([System.Management.Automation.PSCmdlet]$Cmdlet = $null, [switch]$Cloud)
    if ($Cloud) {
        if (-not $script:ZsSession -or -not $script:ZsSession.ZscalerConnected) {
            Write-ZsError -Message 'No active Zscaler session. Run Connect-ZscalerCloud first, then retry.' -ErrorId 'ZsCloudNotConnected' -Category ConnectionError -Cmdlet $Cmdlet
        }
    }
    elseif (-not $script:ZsSession -or -not $script:ZsSession.Connected) {
        Write-ZsError -Message 'Not connected to Azure. Run Connect-ZscalerAzure first, then retry.' -ErrorId 'ZsNotConnected' -Category ConnectionError -Cmdlet $Cmdlet
    }
}

function New-ZsErrorRecord {
    <#
    .SYNOPSIS Builds a clean ErrorRecord whose displayed text is only the message.
    .DESCRIPTION Returns an ErrorRecord with ErrorDetails set so that, when surfaced through
        ThrowTerminatingError or $PSCmdlet, the operator sees a single professional line with no script
        path, line number, or source underline.
    .PARAMETER Message Operator-facing message.
    .PARAMETER ErrorId Short stable identifier.
    .PARAMETER Category PowerShell error category.
    .OUTPUTS [System.Management.Automation.ErrorRecord]
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    [OutputType([System.Management.Automation.ErrorRecord])]
    param(
        [Parameter(Mandatory)][string]$Message,
        [string]$ErrorId = 'ZsValidation',
        [System.Management.Automation.ErrorCategory]$Category = [System.Management.Automation.ErrorCategory]::InvalidArgument
    )
    $record = [System.Management.Automation.ErrorRecord]::new(
        [System.InvalidOperationException]::new($Message),
        $ErrorId, $Category, $null
    )
    $record.ErrorDetails = [System.Management.Automation.ErrorDetails]::new($Message)
    return $record
}

function Write-ZsError {
    <#
    .SYNOPSIS Surfaces a clean, friendly terminating error from the calling cmdlet.
    .DESCRIPTION Builds an ErrorRecord and terminates. When the caller is an advanced function, the error
        is raised through its $PSCmdlet so it appears to originate from the cmdlet the operator invoked,
        with no internal script path or line number. Falls back to a plain throw of the same clean record.
    .PARAMETER Message Operator-facing message.
    .PARAMETER ErrorId Short stable identifier.
    .PARAMETER Category PowerShell error category.
    .PARAMETER Cmdlet The calling $PSCmdlet, passed so the error surfaces from the caller's scope.
    .NOTES Author: NCS Dojo. Copyright (c) 2026 NCS Dojo. MIT License.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Message,
        [string]$ErrorId = 'ZsValidation',
        [System.Management.Automation.ErrorCategory]$Category = [System.Management.Automation.ErrorCategory]::InvalidArgument,
        [System.Management.Automation.PSCmdlet]$Cmdlet = $null
    )
    $record = New-ZsErrorRecord -Message $Message -ErrorId $ErrorId -Category $Category
    if ($Cmdlet) { $Cmdlet.ThrowTerminatingError($record) }
    else { throw $record }
}
