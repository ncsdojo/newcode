provider "azurerm" {
  subscription_id = var.subscription_id
  # Providers are pre-registered by the platform owner. A deployer with rights only at
  # the resource group must never try to register them at the subscription.
  resource_provider_registrations = "none"
  # Storage data plane over Entra ID - shared keys are disabled on the account.
  storage_use_azuread = true
  features {
    # Deleted outright on destroy, rather than soft-deleted for 14 days with its name
    # still reserved.
    log_analytics_workspace {
      permanently_delete_on_destroy = true
    }
    # A purge-protected vault cannot be purged, so the provider is not asked to. Asking
    # makes it read the deleted vault back, which needs rights at the subscription and
    # fails the destroy after the vault has already gone. Without purge protection the
    # vault is purged, so a rebuild can reuse its name; see the README for the rights.
    key_vault {
      purge_soft_delete_on_destroy = !var.enable_purge_protection
    }
    # Azure gives every new Application Insights a Failure Anomalies alert rule, wired to
    # the subscription's shared "Application Insights Smart Detection" action group, which
    # can sit in a resource group whoever runs Terraform cannot read. Disabling the rule
    # rewrites it, and Azure checks the caller against that linked action group too, so
    # the apply fails there with LinkedAuthorizationFailed - after waiting, up to an hour,
    # for the rule to appear. Off, so the provider never touches the rule. The monitoring
    # module's rules are the ones that watch the function; the generated rule only adds
    # Azure's smart-detection emails to monitoring-role holders, and stays behind on a
    # destroy.
    application_insights {
      disable_generated_rule = false
    }
    # azurerm_storage_account reads its queue and static website settings over the data
    # plane, which a storage account with public access disabled refuses from outside the
    # network. Nothing here sets either, so the provider leaves them alone, and plans and
    # applies work from anywhere.
    storage {
      data_plane_available = false
    }
  }
}

# Used for what azurerm has no resource for: syncing the Function App's triggers after
# it is created, and writing the Key Vault secrets through Resource Manager rather than
# the vault's own endpoint, which is private.
provider "azapi" {
  subscription_id            = var.subscription_id
  skip_provider_registration = true
}
