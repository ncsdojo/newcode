# Zscaler's lifecycle function and everything it needs to run: a storage account and the
# private endpoints it is reached through, an App Service plan, Application Insights, and
# the app itself.
#
# The function runs on timers. It reconciles what the Zscaler portal believes about the
# connectors against what is actually running in the scale sets, and replaces connectors
# that report unhealthy.
#
# Locked down at both ends:
#
# - Storage. Public network access is off from the moment the account is created, which
#   is what Org-Delta's "Storage accounts should disable public network access" policy
#   requires. The app reaches its blobs, queues and tables through private endpoints in
#   the management subnet, resolved through the privatelink zones linked to the VNet.
#   There are no IP rules and no service endpoint: with public access off, Azure ignores
#   both.
# - The app. Public network access is off too. It is timer-triggered and nothing
#   legitimate ever calls it; the optional private endpoint is only for operators inside
#   the network. Outbound, every connection it makes is routed into the VNet
#   (vnet_route_all_enabled) and leaves through the NAT gateway, under the function
#   subnet's NSG, which allows HTTPS, HTTP and DNS and nothing else.
#
# Triggers sync when the host starts. Microsoft requires a trigger sync whenever
# WEBSITE_RUN_FROM_PACKAGE is a URL, and accepts a restart as one: the host performs a
# background trigger sync after it starts. On this Dedicated plan the host starts without
# being asked - Always On has the platform request the app every five minutes - and a new
# package URL is an app setting change, which restarts it. The timers run inside that
# host rather than in a platform scale controller. Nothing in the apply waits for the
# host to come up: README step 4 is that check, and the monitoring module's heartbeat
# alert reports timers that never run.
#
# Nothing here uses a storage account key. The app authenticates to storage as its
# managed identity, which is why the plan has to be a Dedicated tier - Consumption and
# Elastic Premium mount their content share over Azure Files, and that needs a key.
#
# The vendor package. Terraform never needs to reach the storage data plane:
#
# - By default the app runs straight from Zscaler's published zip, pinned to a commit so
#   the bytes behind the URL cannot change (function_package_url). The app fetches it
#   over its own outbound path when it starts.
# - With function_package_url = null a copy you place in function_package/ is uploaded
#   into the private storage account instead, and the app reads it through the blob
#   private endpoint. The upload, and reading the blob back on every refresh, are
#   data-plane calls, so every plan and apply then has to run from a host inside the
#   network that resolves the privatelink zones.
#
# Application Insights sits with the app it instruments; the monitoring module only reads
# its id.

resource "azurerm_storage_account" "func" {
  name                            = local.storage_name
  location                        = var.location
  resource_group_name             = var.resource_group_name
  account_kind                    = "StorageV2"
  account_tier                    = "Standard"
  account_replication_type        = var.storage_replication_type
  min_tls_version                 = "TLS1_2"
  https_traffic_only_enabled      = true
  allow_nested_items_to_be_public = false
  shared_access_key_enabled       = false
  # Off at creation, not closed afterwards: the policy refuses the create request itself
  # when it asks for public access.
  public_network_access_enabled = false
  # Shared keys are off, so key auth is not a fallback anyone should be offered. This
  # makes Entra the default path in the portal and in tooling rather than a choice.
  default_to_oauth_authentication = true
  tags                            = var.tags
}

# The firewall behind public_network_access_enabled = false: should public access ever be
# switched back on, it still denies everything. No IP or VNet rules, because nothing
# reaches this account except through its private endpoints.
resource "azurerm_storage_account_network_rules" "lockdown" {
  storage_account_id = azurerm_storage_account.func.id
  default_action     = "Deny"
  bypass             = ["AzureServices"]
}

# Blob, queue and table: the function host keeps its timer schedules, locks and
# bookkeeping in all three. No file endpoint, because a Dedicated plan has no Azure Files
# content share.
resource "azurerm_private_endpoint" "storage" {
  for_each            = local.storage_endpoints
  name                = each.value.name
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = var.private_endpoint_subnet_id
  tags                = var.tags

  private_service_connection {
    name                           = each.value.name
    private_connection_resource_id = azurerm_storage_account.func.id
    is_manual_connection           = false
    subresource_names              = [each.key]
  }

  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = [each.value.zone_id]
  }
}

moved {
  from = azurerm_private_endpoint.storage_blob[0]
  to   = azurerm_private_endpoint.storage["blob"]
}

# The function host keeps its own state in blobs, queues and tables, so its identity
# needs all four of these before the app will start.
resource "azurerm_role_assignment" "funcapp_storage" {
  for_each             = local.host_storage_roles
  scope                = azurerm_storage_account.func.id
  role_definition_name = each.value
  principal_id         = var.funcapp_principal_id
}

# Uploading your copy of the package - only when function_package_url is null.
#
# Terraform uploads the package as itself, over Entra ID, so it has to grant itself the
# blob role first. Shared keys are off, so there is no other way in.
resource "azurerm_role_assignment" "deployer_blob" {
  count                = local.upload_package ? 1 : 0
  scope                = azurerm_storage_account.func.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = var.deployer_object_id
}

resource "time_sleep" "storage_rbac" {
  count           = local.upload_package ? 1 : 0
  create_duration = var.rbac_propagation_delay
  depends_on      = [azurerm_role_assignment.deployer_blob]
}

resource "azurerm_storage_container" "packages" {
  count                 = local.upload_package ? 1 : 0
  name                  = "function-packages"
  storage_account_id    = azurerm_storage_account.func.id
  container_access_type = "private"
}

resource "azurerm_storage_blob" "func_package" {
  count = local.upload_package ? 1 : 0
  name  = local.pkg_blob_name
  # Built from the account id because a container created through storage_account_name
  # keeps a data-plane URL as its id until an apply moves it to storage_account_id.
  storage_container_id = "${azurerm_storage_account.func.id}/blobServices/default/containers/${azurerm_storage_container.packages[0].name}"
  type                 = "Block"
  content_type         = "application/zip"
  source               = local.pkg_path
  # After the role grant has settled, and only once the blob private endpoint exists:
  # with public access off, that endpoint is the only way to the blob.
  depends_on = [time_sleep.storage_rbac, azurerm_private_endpoint.storage]

  lifecycle {
    precondition {
      condition     = local.pkg_exists
      error_message = "Vendor function package not found at ${local.pkg_path}. Download Zscaler's official zip from their terraform repository (modules/terraform-zscc-function-app-azure/zscaler_cc_function_app.zip, main branch) and place it there, or set function_package_url to run from Zscaler's published copy instead."
    }
  }
}

moved {
  from = azurerm_role_assignment.deployer_blob
  to   = azurerm_role_assignment.deployer_blob[0]
}

moved {
  from = time_sleep.storage_rbac
  to   = time_sleep.storage_rbac[0]
}

moved {
  from = azurerm_storage_container.packages
  to   = azurerm_storage_container.packages[0]
}

moved {
  from = azurerm_storage_blob.func_package
  to   = azurerm_storage_blob.func_package[0]
}

resource "azurerm_service_plan" "func" {
  name                = local.service_plan_name
  location            = var.location
  resource_group_name = var.resource_group_name
  os_type             = "Linux"
  sku_name            = var.app_service_plan_sku
  tags                = var.tags
}

resource "azurerm_log_analytics_workspace" "zscc" {
  name                = local.log_analytics_name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "PerGB2018"
  retention_in_days   = var.log_retention_in_days
  tags                = var.tags
}

resource "azurerm_application_insights" "zscc" {
  name = local.app_insights_name
  # Not every region offers Application Insights - West Central US does not - so it can
  # sit in a neighbouring region while its workspace stays with everything else.
  location            = coalesce(var.app_insights_location, var.location)
  resource_group_name = var.resource_group_name
  workspace_id        = azurerm_log_analytics_workspace.zscc.id
  # Typed "web" because that is what the vendor package emits, even though the app is
  # timer-triggered and has no HTTP surface of its own.
  application_type = "web"
  tags             = var.tags
}

resource "azurerm_linux_function_app" "sync" {
  name                          = var.name
  location                      = var.location
  resource_group_name           = var.resource_group_name
  service_plan_id               = azurerm_service_plan.func.id
  storage_account_name          = azurerm_storage_account.func.name
  storage_uses_managed_identity = true
  virtual_network_subnet_id     = var.subnet_id
  functions_extension_version   = "~4"
  tags                          = var.tags

  # Sent explicitly rather than left to the provider default. The request always carries
  # httpsOnly, and an Azure Policy that appends httpsOnly = true fails the whole
  # deployment with a 409 unless the value we send already matches.
  https_only = true
  # No inbound path from the internet, whether or not the private endpoint is on. The
  # timers fire inside the app, and Always On is the platform's own request, so neither
  # needs one.
  public_network_access_enabled = false

  # The app runs on a user-assigned identity and has no system-assigned one to fall back
  # on, so the identity that resolves Key Vault references has to be named explicitly.
  key_vault_reference_identity_id = var.funcapp_identity_id

  # No basic auth for deployments - Entra only.
  ftp_publish_basic_authentication_enabled       = false
  webdeploy_publish_basic_authentication_enabled = false

  identity {
    type         = "UserAssigned"
    identity_ids = [var.funcapp_identity_id]
  }

  site_config {
    # A Dedicated plan unloads an idle app, and an unloaded app does not fire its timer.
    # This one is timer-triggered and nothing else, so without always_on the lifecycle
    # sync silently stops running between cold starts. The provider default is false.
    always_on = true
    # Set explicitly for the same reason as https_only above: policies that append these
    # fields fail the request when it already carries them with a different value.
    http2_enabled       = true
    minimum_tls_version = "1.2"
    ftps_state          = "Disabled"
    # Every outbound connection - storage and Key Vault through their private endpoints,
    # the Zscaler portal API, Resource Manager, Entra ID, Application Insights and the
    # package download - goes into the VNet, so the function subnet's NSG governs it and
    # the NAT gateway is its one egress address.
    vnet_route_all_enabled                 = true
    ip_restriction_default_action          = "Deny"
    scm_ip_restriction_default_action      = "Deny"
    application_insights_connection_string = azurerm_application_insights.zscc.connection_string
    application_stack {
      python_version = "3.11"
    }
  }

  app_settings = local.app_settings

  # The host reads and writes storage as soon as it starts, and with public access off it
  # can only do that once the identity has its roles and the private endpoints exist.
  depends_on = [
    azurerm_role_assignment.funcapp_storage,
    azurerm_private_endpoint.storage,
  ]
}

# State from earlier versions holds a Resource Manager trigger sync. It is an action,
# with nothing in Azure to delete, so Terraform forgets it.
removed {
  from = azapi_resource_action.sync_triggers
  lifecycle {
    destroy = false
  }
}

# Optional. The app is timer-triggered and nothing legitimate ever calls it, so this is
# only for operators inside the network who want the portal's function views.
resource "azurerm_private_endpoint" "funcapp" {
  count               = var.enable_private_endpoint ? 1 : 0
  name                = "pe-${var.name}"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = var.private_endpoint_subnet_id
  tags                = var.tags

  private_service_connection {
    name                           = "pe-${var.name}"
    private_connection_resource_id = azurerm_linux_function_app.sync.id
    is_manual_connection           = false
    subresource_names              = ["sites"]
  }

  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = [var.private_dns_zone_id]
  }
}
