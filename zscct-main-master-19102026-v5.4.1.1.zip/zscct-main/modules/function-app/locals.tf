locals {
  storage_name       = substr(lower("${var.name_prefix}st${var.name_suffix}${substr(var.short_id, 0, 4)}"), 0, 24)
  app_insights_name  = "${var.name_prefix}appi${var.name_suffix}"
  service_plan_name  = "${var.name_prefix}plan${var.name_suffix}"
  log_analytics_name = "${var.name_prefix}log${var.name_suffix}"

  # One private endpoint per storage service the function host uses. The blob endpoint
  # keeps the name it had when it was the only one, so an environment that already has
  # it keeps it rather than replacing it.
  storage_endpoints = {
    blob = {
      name    = "pe-${local.storage_name}"
      zone_id = var.blob_private_dns_zone_id
    }
    queue = {
      name    = "pe-${local.storage_name}-queue"
      zone_id = var.queue_private_dns_zone_id
    }
    table = {
      name    = "pe-${local.storage_name}-table"
      zone_id = var.table_private_dns_zone_id
    }
  }

  # Where the package comes from. A URL runs the app straight from Zscaler's published
  # zip; null uploads a local copy into the private storage account.
  upload_package = var.function_package_url == null

  # The local copy goes in the module's function_package folder; function_package_path lets
  # a caller point at one held elsewhere (an artifact cache, a CI drop) instead.
  pkg_path   = coalesce(var.function_package_path, "${path.module}/function_package/zscaler_cc_function_app.zip")
  pkg_exists = fileexists(local.pkg_path)

  # Content-hashed name: a changed zip produces a new blob, which updates
  # WEBSITE_RUN_FROM_PACKAGE and restarts the app onto the new package. Only hashed when
  # the zip is being uploaded, so a URL deployment does not need a local copy at all.
  pkg_blob_name = "zscc-func-${var.short_id}-${local.upload_package ? try(filemd5(local.pkg_path), "missing") : "unused"}.zip"

  package_url = local.upload_package ? azurerm_storage_blob.func_package[0].url : var.function_package_url

  # Identity-based host storage needs all four: the host uses blob, queue and table directly,
  # and Storage Account Contributor to read account properties at startup.
  host_storage_roles = {
    blob  = "Storage Blob Data Owner"
    queue = "Storage Queue Data Contributor"
    table = "Storage Table Data Contributor"
    acct  = "Storage Account Contributor"
  }

  # Settings the vendor package reads. Names are fixed by the package and must not be renamed.
  #
  # CC_URL goes in without a scheme, as Zscaler's own module passes it: the package
  # prefixes https:// itself, and given the scheme it resolves the host as "https" and
  # every sync fails.
  app_settings = merge(
    {
      SUBSCRIPTION_ID               = "/subscriptions/${var.subscription_id}"
      MANAGED_IDENTITY              = var.funcapp_client_id
      RESOURCE_GROUP                = var.resource_group_name
      VMSS_NAME                     = jsonencode(var.vmss_names)
      VAULT_URL                     = var.key_vault_uri
      CC_URL                        = trimprefix(var.provisioning_url, "https://")
      TERMINATE_UNHEALTHY_INSTANCES = var.disable_health_remediation ? "false" : "true"
      WEBSITE_RUN_FROM_PACKAGE      = local.package_url
      # Host storage over managed identity: no connection string, no shared keys.
      AzureWebJobsStorage__credential            = "managedidentity"
      AzureWebJobsStorage__clientId              = var.funcapp_client_id
      ApplicationInsightsAgent_EXTENSION_VERSION = "~3"
      XDT_MicrosoftApplicationInsights_Mode      = "recommended"
    },
    # Run-from-package over managed identity: no SAS. Only for the uploaded blob - a
    # public URL needs no token, and sending one to it is pointless.
    local.upload_package ? {
      WEBSITE_RUN_FROM_PACKAGE_BLOB_MI_RESOURCE_ID = var.funcapp_identity_id
    } : {},
  )
}
