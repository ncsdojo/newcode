# Vendor function package

By default nothing needs to go in this folder. The Function App runs straight from
Zscaler's published `zscaler_cc_function_app.zip` (version 1.0.3), at a URL pinned to the
commit that released it:

```
https://raw.githubusercontent.com/zscaler/terraform-azurerm-cloud-connector-modules/6ca00169e6db4b983200d46c632b64fb29c427a7/modules/terraform-zscc-function-app-azure/zscaler_cc_function_app.zip
```

A commit-pinned URL cannot change underneath the app. For reference, that file is
31,256,639 bytes with SHA-256
`8cbe698b57164c757f80e93961867408bb9d172185a246833b9b78e86f671361`
(MD5 `afea19813d47369cba6a0b95a51bc15d`). The app downloads it over its own outbound path
(VNet integration, then the NAT gateway), so `raw.githubusercontent.com` on TCP 443 has to
be reachable from the function subnet wherever egress is filtered.

Running from the URL is what lets the whole apply work from outside the network: the
storage account has public network access disabled (Org-Delta policy), so Terraform could
only upload a copy through its private endpoint.

## Uploading a copy instead

Set `function_package_url = null` in the environment's tfvars to upload this folder's
zip into the private storage account and run from that. Then:

- Place Zscaler's official `zscaler_cc_function_app.zip` here, or point
  `function_package_path` at a copy elsewhere (an artifact cache, a CI drop). The plan
  fails with a clear precondition message while it is absent.
- Run every plan and apply from a host inside the network that resolves the
  privatelink zones. Uploading the zip, and reading it back on every refresh, are
  data-plane calls, and the account answers only on its private endpoint.

It is not redistributed here: it is proprietary, and its `version.py` carries an explicit
notice prohibiting copying. Download it from Zscaler's terraform repository at
`modules/terraform-zscc-function-app-azure/zscaler_cc_function_app.zip` on the `main`
branch.

Re-applies: a changed zip produces a new content-hashed blob name, updates
WEBSITE_RUN_FROM_PACKAGE, and restarts the app onto the new package. A new pinned URL
does the same. The host syncs its own triggers when it starts.

The app fetches the package every time it restarts, so the URL - or the storage account,
in blob mode - has to be reachable then, not only at deployment. With the default URL
that makes `raw.githubusercontent.com` a dependency of every restart. Blob mode removes
it, at the cost of running every plan and apply from inside the network.
