variable "name" {
  description = "Function App name. Also seeds the private endpoint name, pe-<name>."
  type        = string
}

variable "short_id" {
  description = "8-char deployment id. Its first four characters keep the storage account name globally unique, and it appears in the package blob name."
  type        = string
}

variable "name_prefix" {
  description = "Leading name component, <app><environment>arm - e.g. ccprdarm."
  type        = string
}

variable "name_suffix" {
  description = "Trailing name component, <region><instance> - e.g. uw2001."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Group everything here is created in. Also passed to the function as RESOURCE_GROUP."
  type        = string
}

variable "tags" {
  description = "Tags applied to every taggable resource here."
  type        = map(string)
  default     = {}
}

variable "subscription_id" {
  description = "Target subscription, passed to the function as SUBSCRIPTION_ID."
  type        = string
  sensitive   = true
}

variable "app_service_plan_sku" {
  description = "App Service plan tier: Basic, Standard or Premium v2-v4."
  type        = string
  default     = "P0v3"
  validation {
    # Consumption, Elastic Premium and Workflow plans mount their content share over Azure
    # Files, which needs the storage key this configuration disables. Flex Consumption is
    # a different resource type, Free and Shared cannot run always_on, and Isolated needs
    # an App Service Environment.
    condition     = can(regex("(?i)^(B[1-3]|S[1-3]|P[1-3]v2|P[0-3]v3|P[1-5]mv3|P[0-3]v4|P[1-5]mv4)$", var.app_service_plan_sku))
    error_message = "app_service_plan_sku must be a Basic, Standard or Premium v2-v4 tier, e.g. B1, S1, P0v3 or P1v3. Consumption, Flex Consumption, Elastic Premium, Workflow, Free, Shared and Isolated plans cannot host this app as configured."
  }
}

variable "funcapp_identity_id" {
  description = "Function user-assigned identity resource id."
  type        = string
}

variable "funcapp_client_id" {
  description = "Function identity client id, used by MANAGED_IDENTITY and the host storage connection."
  type        = string
}

variable "funcapp_principal_id" {
  description = "Function identity object id, granted the four host storage roles."
  type        = string
}

variable "deployer_object_id" {
  description = "Object id of the principal running Terraform. Granted Storage Blob Data Contributor when the apply uploads the package (function_package_url = null)."
  type        = string
}

variable "subnet_id" {
  description = "Delegated Function App subnet, the app's VNet integration. All of its outbound traffic leaves through here."
  type        = string
}

variable "private_endpoint_subnet_id" {
  description = "Subnet the storage and Function App private endpoints terminate in - the management subnet."
  type        = string
}

variable "private_dns_zone_id" {
  description = "privatelink.azurewebsites.net zone id for the endpoint's DNS zone group. Only used when enable_private_endpoint is true."
  type        = string
  default     = null
}

variable "blob_private_dns_zone_id" {
  description = "privatelink.blob.core.windows.net zone id for the storage account's blob private endpoint. Required: the account has public access disabled, so the function reaches its blobs only through that endpoint."
  type        = string
  nullable    = false
}

variable "queue_private_dns_zone_id" {
  description = "privatelink.queue.core.windows.net zone id for the storage account's queue private endpoint. Required, for the same reason as the blob zone."
  type        = string
  nullable    = false
}

variable "table_private_dns_zone_id" {
  description = "privatelink.table.core.windows.net zone id for the storage account's table private endpoint. Required, for the same reason as the blob zone."
  type        = string
  nullable    = false
}

variable "key_vault_uri" {
  description = "Vault URI, passed to the function as VAULT_URL."
  type        = string
}

variable "provisioning_url" {
  description = "Connector provisioning URL, with or without https://. Passed to the function as CC_URL, without the scheme."
  type        = string
}

variable "vmss_names" {
  description = "Scale set names the function manages, in zone order. Serialised into the VMSS_NAME app setting. Deterministic, so it does not order the app behind the scale sets."
  type        = list(string)
}

variable "disable_health_remediation" {
  description = "true: unhealthy connectors are evaluated and logged but never terminated."
  type        = bool
  default     = false
}

variable "enable_private_endpoint" {
  description = "Give the Function App a private endpoint, for operators inside the network. Public inbound access is disabled either way."
  type        = bool
  default     = false
}

variable "function_package_url" {
  description = "URL the app runs its package from. The default is Zscaler's published 1.0.3 zip, pinned to the commit that released it so the content cannot change. Null uploads a copy you place in function_package/ (or at function_package_path) into the private storage account instead, which needs every plan and apply to run from inside the network."
  type        = string
  default     = "https://raw.githubusercontent.com/zscaler/terraform-azurerm-cloud-connector-modules/6ca00169e6db4b983200d46c632b64fb29c427a7/modules/terraform-zscc-function-app-azure/zscaler_cc_function_app.zip"

  validation {
    condition     = var.function_package_url == null || can(regex("^https://", var.function_package_url))
    error_message = "function_package_url must be an https:// URL, or null to upload a local copy of the zip."
  }
}

variable "function_package_path" {
  description = "Override the path to the vendor zip that is uploaded when function_package_url is null. Null uses function_package/zscaler_cc_function_app.zip in this module, where the copy is placed."
  type        = string
  default     = null
}

variable "log_retention_in_days" {
  description = "Log Analytics retention. 30 days is the PerGB2018 included minimum."
  type        = number
  default     = 30
}

variable "rbac_propagation_delay" {
  description = "How long to wait after granting the deployer the blob role before uploading the package. Only used when function_package_url is null."
  type        = string
  default     = "60s"
}

variable "app_insights_location" {
  description = "Region for Application Insights where location does not offer it, e.g. westus2 for a West Central US deployment. Null keeps it in location. The Log Analytics workspace always stays in location."
  type        = string
  default     = null
}

variable "storage_replication_type" {
  description = "Function storage redundancy. ZRS where the region has availability zones; LRS where it does not, because ZRS needs them."
  type        = string
  default     = "ZRS"
  validation {
    condition     = contains(["ZRS", "LRS"], var.storage_replication_type)
    error_message = "storage_replication_type must be ZRS or LRS."
  }
}
