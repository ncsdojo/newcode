# Values used across this environment.
#
# The first block is the only part that differs from the greenfield template. This one
# attaches to a resource group, VNet, subnets and DNS zones somebody else created, so
# these read from the data sources in data.tf; greenfield builds its own and reads from
# modules instead. Everything after it is the same in both files.
locals {
  # Attaches to an existing foundation
  #
  # Every foundation value used below is named here, and nothing below this block
  # references a data source directly, so swapping any of it back to a module this
  # deployment creates means editing these lines and nothing else.
  resource_group_name = data.azurerm_resource_group.zscc.name
  resource_group_id   = data.azurerm_resource_group.zscc.id

  mgmt_subnet_id     = data.azurerm_subnet.mgmt.id
  service_subnet_id  = data.azurerm_subnet.service.id
  funcapp_subnet_id  = data.azurerm_subnet.funcapp.id
  lb_subnet_id       = data.azurerm_subnet.lb.id
  workload_subnet_id = one(data.azurerm_subnet.workload[*].id)
  bastion_subnet_id  = one(data.azurerm_subnet.bastion[*].id)
  # The management NSG allows SSH from the Bastion range, so read that range off the
  # subnet rather than asking for it again as a variable.
  bastion_subnet_cidr = one(data.azurerm_subnet.bastion[*].address_prefixes[0])

  # The hub owns these zones and has already linked them to this VNet. Azure will not
  # accept a second zone of the same name on the same VNet, so this environment creates
  # neither the zone nor the link and just points its endpoints at what is already there.
  vault_dns_zone_id = data.azurerm_private_dns_zone.vault.id
  sites_dns_zone_id = one(data.azurerm_private_dns_zone.sites[*].id)
  blob_dns_zone_id  = one(data.azurerm_private_dns_zone.blob[*].id)

  # The same in every environment

  # The two halves every name is built from. The module supplies the type token that
  # sits between them.
  name_prefix = "${var.app_code}${var.env_code}arm"
  name_suffix = "${var.region_code}${var.instance}"

  key_vault_name    = "${local.name_prefix}kv${local.name_suffix}${substr(var.kv_suffix, 0, 4)}"
  function_app_name = "${local.name_prefix}func${local.name_suffix}"

  tags = merge({
    "zscaler-deployment-id" = var.short_id
    "environment"           = var.environment
    "managed-by"            = "terraform-zscc"
  }, var.additional_tags)

  # Needed by compute (which creates the scale sets) and by function-app (which only
  # needs the names). Deterministic, so the Function App is not ordered behind
  # scale sets it does not depend on.
  vmss_names = { for z in var.zones : z => "${local.name_prefix}vms-z${z}-${local.name_suffix}" }
}
