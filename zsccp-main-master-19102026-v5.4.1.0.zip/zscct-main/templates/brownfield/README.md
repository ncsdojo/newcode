# brownfield

For a target where the **foundation already exists** and belongs to somebody
else. This environment creates none of it. The resource group, virtual network,
subnets and private DNS zones are read by `data.tf` and everything else is built
on top of them.

Modelled on `environments/westus2/prod`.

What the platform team must provide before this can apply:

- A resource group for the deployment
- Four subnets on the hub virtual network: management and service at /26 or
  larger, a load balancer subnet, and a Function App subnet delegated to
  `Microsoft.Web/serverFarms` with the `Microsoft.Storage` service endpoint
- Endpoint network policies disabled on the management subnet, because the
  private endpoints terminate there
- Either no NSG or NAT gateway on the management, service and Function App
  subnets, or `attach_nsgs` / `attach_nat_gateway` set to false for the ones the
  platform attaches itself. Terraform will not take over an attachment that is
  already there
- `privatelink.vaultcore.azure.net` and `privatelink.blob.core.windows.net`
  already created and already linked to that virtual network
- Any custom roles you want used instead of the built-in ones, already defined;
  name them in `connector_role_names`, `function_role_names` or
  `remediation_role_name`
- `Microsoft.Authorization/locks/*` on the resource group for whoever runs
  Terraform, or `enable_resource_locks = false`
- A machine inside the network to run Terraform from after the vault closes

After the first apply, one grant from the platform team, because this deployment
cannot assign roles where the subnets live:

- `Microsoft.Network/virtualNetworks/subnets/join/action` (Network Contributor, or
  a custom role with that action) on the management and service subnets, for the
  principal in the `funcapp_principal_id` output. See step 6 of the top-level
  README for the grants the same write may also need. When the function replaces an
  unhealthy connector it writes the scale set, which joins those subnets. Without
  the grant the unhealthy connector is still removed, but the restore fails with
  `LinkedAuthorizationFailed` and the scale set refills only to its autoscale
  minimum.

The route that steers workload traffic to the connectors is attached by the
platform team to their own subnets, pointing at the `lb_frontend_ip` this
deployment outputs. The exception is a subnet named in `workload_subnet_name`,
such as a temporary validation subnet, which gets a route table from this
deployment; set it back to `""` and apply before that subnet is deleted. AVD
session hosts running Zscaler Client Connector for VDI also need
`185.46.212.80/32` sent to the load balancer: name their route tables in
`spoke_route_tables` and this deployment adds the route, or add it by hand. See
"Routing AVD session hosts" in the top-level README.

Deploy into the virtual network's own subscription. Azure attaches NICs, private
endpoints, NSGs, NAT gateways and route tables only to a virtual network in
their own subscription, so a hub that lives in a connectivity subscription means
deploying into that subscription. The private DNS zones are the exception: where
they live in another subscription, set `private_dns_subscription_id` and the
`dns` provider alias in `providers.tf` reads them from there.

See `../README.md` for how to copy and fill this in.
