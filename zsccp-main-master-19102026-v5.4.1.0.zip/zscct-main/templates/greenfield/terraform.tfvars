# ==============================================================================
# greenfield template
#
# Creates its own VNet, subnets and DNS zones, so the network inputs here are CIDRs.
# The resource group is pre-created and named below.
#
# Secrets are NOT here. Export them before applying:
#   $env:TF_VAR_zscaler_api_key  = "<portal api key>"
#   $env:TF_VAR_zscaler_username = "<portal admin>"
#   $env:TF_VAR_zscaler_password = "<portal password>"
#
# The values below are sized for a disposable environment: a single zone, smaller
# capacity, no resource locks, and purge protection off so the vault can be rebuilt.
# ==============================================================================

# A. Azure basics
subscription_id     = "<azure-subscription-guid>"
resource_group_name = "<name-of-the-pre-created-group>"
location            = "<azure-region>"
environment         = "<environment>"

# LLD naming tokens. Names are built as
#   <app_code><env_code>arm  +  <type>  +  <region_code><instance>
# e.g. cc + dev + arm + nsg-mgmt- + uw2 + 001  ->  ccdevarmnsg-mgmt-uw2001
app_code    = "cc"
env_code    = "<3-char-env-code>"
region_code = "<3-char-region-code>"
instance    = "001"

# B. Uniqueness - must differ from every other environment (storage account and
#    key vault names are globally unique).
# PowerShell:  -join ((48..57)+(97..102) | Get-Random -Count 8 | % {[char]$_})
# or bash:     openssl rand -hex 4     (run twice, one per line)
short_id  = "<8-hex>"
kv_suffix = "<8-hex>"

# C. Network plan - 10.0.0.0/23.
#
# Regions without availability zones (UK West and West Central US among ours): set
# zones_enabled = false and zones = ["1"]. That builds one regional scale set, a load
# balancer frontend with no zone, and LRS storage for the function. Two connectors are
# enough there, so set desired_instances and min_instances to 2 in section H.
zones_enabled = true

# One management and one service subnet, shared by connectors in every zone. Both /26
# so max_instances can rise without re-addressing. The NAT gateway in front of them is
# zone-redundant, so nothing here is pinned to a zone.
vnet_address_space   = "10.0.0.0/23"
zones                = ["1"]
mgmt_subnet_cidr     = "10.0.0.0/26"
service_subnet_cidr  = "10.0.0.64/26"
lb_subnet_cidr       = "10.0.0.128/27"
funcapp_subnet_cidr  = "10.0.0.160/27"
bastion_subnet_cidr  = "10.0.1.0/26" # only used if enable_bastion = true
workload_subnet_cidr = "10.0.1.128/25"
ssh_source_cidr      = "10.0.1.0/26" # ignored while enable_bastion = true
enable_bastion       = true

# D. Zscaler side - a provisioning template this environment shares with no other
provisioning_url = "<connector provisioning URL>"
zscaler_cloud    = "<e.g. zscalertwo>"

# E. Connector access
# ssh-keygen -t rsa -b 4096 -f zscc_key -N ""   -> paste zscc_key.pub content
ssh_public_key = "<ssh-rsa AAAA...>"

# F. Behavior
# Roles by name - built-in, or custom roles the platform team already defined.
connector_role_names = ["Reader", "Monitoring Metrics Publisher"]
function_role_names  = ["Reader"]

disable_health_remediation = false
accept_marketplace_terms   = false # owner accepted terms at the subscription
notification_email         = []    # e.g. ["ops@example.com"]

# Locks off: dev is rebuilt and experimented on, and a CanNotDelete lock refuses deleting
# anything it covers, by hand as well. Purge protection off so a rebuild can reuse the
# vault name - once on it cannot be turned off, and a soft-deleted vault holds its name
# for 90 days.
enable_resource_locks   = false
enable_purge_protection = false

# G. Two-phase apply
kv_locked                 = false                # flip to true for the SECOND apply
storage_deployer_ip_rules = ["<your-public-ip>"] # curl ifconfig.me

# H. Capacity - one connector, room for two
desired_instances = 1
min_instances     = 1
max_instances     = 2

# I. Optional overrides (defaults shown; uncomment to change)
# app_insights_location = null  # e.g. "westus2" where Application Insights is not offered, such as West Central US
# vm_size                          = "Standard_D2s_v3"
# http_probe_port                  = 50000
# enable_support_tunnel            = true
# support_server_ip                = "199.168.148.101"  # remotesupport.<cloud>.net on Zscaler's commercial clouds
# encrypt_at_host                  = false
# app_service_plan_sku             = "P0v3"   # must stay Dedicated: storage keys are disabled
# enable_function_private_endpoint = false
# scheduled_scaling                = false
# workload_cidrs                   = []
# additional_tags                  = { "cost-centre" = "", "owner" = "" }
