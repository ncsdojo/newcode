# greenfield template - copy to environments/<region>/<environment>
#
# This file only wires modules together. Resources are declared in the modules and
# names are built there too.
#
# This environment builds its own VNet, subnets and DNS zones, and attaches to a
# pre-created resource group. The brownfield template attaches to all four. Below the
# foundation the two files are the same, except where brownfield attaches to somebody
# else's subnets.

# Foundation
#
# Only greenfield has this section. brownfield looks the VNet, subnets and DNS zones up
# in data.tf instead. Both look up the resource group.

module "vnet" {
  source = "../../../modules/network/vnet"

  name_prefix = local.name_prefix

  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  address_space       = var.vnet_address_space
  tags                = local.tags
}

module "subnets" {
  source = "../../../modules/network/subnets"

  name_prefix = local.name_prefix
  name_suffix = local.name_suffix

  virtual_network_name                = module.vnet.name
  virtual_network_resource_group_name = module.vnet.resource_group_name
  vnet_address_space                  = var.vnet_address_space

  mgmt_subnet_cidr     = var.mgmt_subnet_cidr
  service_subnet_cidr  = var.service_subnet_cidr
  workload_subnet_cidr = var.workload_subnet_cidr
  lb_subnet_cidr       = var.lb_subnet_cidr
  funcapp_subnet_cidr  = var.funcapp_subnet_cidr
  bastion_subnet_cidr  = var.bastion_subnet_cidr
  enable_bastion       = var.enable_bastion
}

module "private_dns" {
  source = "../../../modules/network/private-dns"

  name_prefix = local.name_prefix
  name_suffix = local.name_suffix

  resource_group_name = local.resource_group_name
  virtual_network_id  = module.vnet.id
  tags                = local.tags

  enable_function_private_endpoint = var.enable_function_private_endpoint
  enable_storage_private_endpoint  = var.enable_storage_private_endpoint
}

# Network services

module "nsg" {
  source = "../../../modules/network/nsg"

  name_prefix = local.name_prefix

  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  tags                = local.tags

  mgmt_subnet_id    = local.mgmt_subnet_id
  service_subnet_id = local.service_subnet_id

  bastion_subnet_cidr   = local.bastion_subnet_cidr
  ssh_source_cidr       = var.ssh_source_cidr
  enable_support_tunnel = var.enable_support_tunnel
  support_server_ip     = var.support_server_ip
  http_probe_port       = var.http_probe_port
  workload_cidrs        = var.workload_cidrs
}

module "nat_gateway" {
  source = "../../../modules/network/nat-gateway"

  name_prefix = local.name_prefix

  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  tags                = local.tags

  mgmt_subnet_id    = local.mgmt_subnet_id
  service_subnet_id = local.service_subnet_id
  funcapp_subnet_id = local.funcapp_subnet_id
}

module "load_balancer" {
  source = "../../../modules/network/load-balancer"

  name_prefix = local.name_prefix

  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  tags                = local.tags

  zones           = var.zones
  zones_enabled   = var.zones_enabled
  subnet_id       = local.lb_subnet_id
  http_probe_port = var.http_probe_port
}

module "route_table" {
  source = "../../../modules/network/route-table"

  name_prefix = local.name_prefix

  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  tags                = local.tags

  workload_subnet_id = local.workload_subnet_id
  next_hop_ip        = module.load_balancer.frontend_private_ip
}

# count rather than a variable inside the module, so turning Bastion off means this is
# not evaluated at all.
module "bastion" {
  source = "../../../modules/network/bastion"
  count  = var.enable_bastion ? 1 : 0

  name_prefix = local.name_prefix

  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  tags                = local.tags
  subnet_id           = local.bastion_subnet_id
}

# The connectors and everything that supports them

module "identity" {
  source = "../../../modules/identity"

  name_prefix = local.name_prefix

  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  resource_group_id   = local.resource_group_id
  tags                = local.tags

  connector_role_names = var.connector_role_names
  function_role_names  = var.function_role_names
}

module "key_vault" {
  source = "../../../modules/key-vault"

  name                = local.key_vault_name
  location            = var.location
  resource_group_name = local.resource_group_name
  tags                = local.tags

  tenant_id          = data.azurerm_client_config.current.tenant_id
  deployer_object_id = data.azurerm_client_config.current.object_id

  cc_principal_id      = module.identity.cc_principal_id
  funcapp_principal_id = module.identity.funcapp_principal_id

  enable_purge_protection = var.enable_purge_protection
  locked                  = var.kv_locked

  zscaler_api_key  = var.zscaler_api_key
  zscaler_username = var.zscaler_username
  zscaler_password = var.zscaler_password

  private_endpoint_subnet_id = local.mgmt_subnet_id
  private_dns_zone_id        = local.vault_dns_zone_id
}

module "function_app" {
  source = "../../../modules/function-app"

  name                = local.function_app_name
  short_id            = var.short_id
  name_prefix         = local.name_prefix
  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  tags                = local.tags

  subscription_id      = var.subscription_id
  app_service_plan_sku = var.app_service_plan_sku
  # ZRS needs availability zones, so a region without them falls back to LRS.
  storage_replication_type = var.zones_enabled ? "ZRS" : "LRS"
  app_insights_location    = var.app_insights_location

  funcapp_identity_id  = module.identity.funcapp_identity_id
  funcapp_client_id    = module.identity.funcapp_client_id
  funcapp_principal_id = module.identity.funcapp_principal_id
  deployer_object_id   = data.azurerm_client_config.current.object_id

  subnet_id                  = local.funcapp_subnet_id
  private_endpoint_subnet_id = local.mgmt_subnet_id
  private_dns_zone_id        = local.sites_dns_zone_id

  enable_storage_private_endpoint = var.enable_storage_private_endpoint
  blob_private_dns_zone_id        = local.blob_dns_zone_id

  key_vault_uri              = module.key_vault.vault_uri
  provisioning_url           = var.provisioning_url
  vmss_names                 = [for z in var.zones : local.vmss_names[z]]
  disable_health_remediation = var.disable_health_remediation

  storage_deployer_ip_rules = var.storage_deployer_ip_rules
  enable_private_endpoint   = var.enable_function_private_endpoint
  function_package_path     = var.function_package_path
}

module "compute" {
  source = "../../../modules/compute"

  zones               = var.zones
  zones_enabled       = var.zones_enabled
  vmss_names          = local.vmss_names
  name_prefix         = local.name_prefix
  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  tags                = local.tags

  vm_size                = var.vm_size
  image_version          = var.image_version
  admin_username         = var.admin_username
  ssh_public_key         = var.ssh_public_key
  encrypt_at_host        = var.encrypt_at_host
  accelerated_networking = var.accelerated_networking

  mgmt_subnet_id             = local.mgmt_subnet_id
  service_subnet_id          = local.service_subnet_id
  lb_backend_address_pool_id = module.load_balancer.backend_address_pool_id

  cc_identity_id        = module.identity.cc_identity_id
  cc_identity_client_id = module.identity.cc_client_id
  key_vault_uri         = module.key_vault.vault_uri

  provisioning_url = var.provisioning_url
  zscaler_cloud    = var.zscaler_cloud
  http_probe_port  = var.http_probe_port

  desired_instances          = var.desired_instances
  min_instances              = var.min_instances
  max_instances              = var.max_instances
  scale_out_threshold        = var.scale_out_threshold
  scale_in_threshold         = var.scale_in_threshold
  scale_out_cooldown_minutes = var.scale_out_cooldown_minutes
  scale_in_cooldown_minutes  = var.scale_in_cooldown_minutes

  scheduled_scaling       = var.scheduled_scaling
  scheduled_min_instances = var.scheduled_min_instances
  scheduled_days          = var.scheduled_days
  scheduled_start_hour    = var.scheduled_start_hour
  scheduled_start_minute  = var.scheduled_start_minute
  scheduled_end_hour      = var.scheduled_end_hour
  scheduled_end_minute    = var.scheduled_end_minute
  scheduled_timezone      = var.scheduled_timezone

  disable_health_remediation = var.disable_health_remediation
  funcapp_principal_id       = module.identity.funcapp_principal_id
  remediation_role_name      = var.remediation_role_name
  accept_marketplace_terms   = var.accept_marketplace_terms

  # Connectors read their credentials from the vault at boot, so none of them should
  # start before the identity has access, the secrets are written and egress works.
  # Passing the subnet and identity ids only gets us part of that ordering; these cover
  # the rest.
  depends_on = [
    module.identity,
    module.key_vault,
    module.nat_gateway,
  ]
}

module "monitoring" {
  source = "../../../modules/monitoring"

  name_prefix = local.name_prefix
  name_suffix = local.name_suffix

  # The log alerts sit with the Application Insights they query.
  location            = coalesce(var.app_insights_location, var.location)
  resource_group_name = local.resource_group_name
  tags                = local.tags

  notification_email    = var.notification_email
  sync_interval_minutes = var.sync_interval_minutes
  app_insights_id       = module.function_app.app_insights_id
  load_balancer_id      = module.load_balancer.id
}

module "locks" {
  source = "../../../modules/locks"

  enabled = var.enable_resource_locks

  # This environment built the VNet, so it is ours to lock. brownfield leaves it out of
  # this map.
  scopes = {
    vnet   = local.vnet_id
    kv     = module.key_vault.id
    lb     = module.load_balancer.id
    ident  = module.identity.cc_identity_id
    nat_ip = module.nat_gateway.public_ip_id
    rt     = module.route_table.id
  }

  # Listed here so the locks are created last and, on a destroy, removed first.
  depends_on = [
    module.subnets,
    module.private_dns,
    module.nsg,
    module.nat_gateway,
    module.load_balancer,
    module.route_table,
    module.identity,
    module.key_vault,
    module.function_app,
  ]
}
