# The internal load balancer the connectors sit behind.
#
# HA ports, so it forwards every protocol and port rather than a named list, and a
# health probe on the connector's own /?cchealth endpoint.
#
# Its frontend address is the next hop for the workload route table and for any spoke
# route table, and one of the addresses Zscaler Client Connector for VDI can be installed
# against (its SERVERIP option). The rule at the bottom of this file sets client IP
# persistence, as Zscaler recommends, and floating IP, as Zscaler's own module does.

resource "azurerm_lb" "zscc" {
  name                = local.name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "Standard"
  sku_tier            = "Regional"
  tags                = var.tags

  frontend_ip_configuration {
    name                          = local.frontend_name
    subnet_id                     = var.subnet_id
    private_ip_address_allocation = "Dynamic"
    zones                         = local.frontend_zones
  }
}

resource "azurerm_lb_backend_address_pool" "zscc" {
  name            = "be-zscc"
  loadbalancer_id = azurerm_lb.zscc.id
}

resource "azurerm_lb_probe" "cchealth" {
  name                = "hp-${var.http_probe_port}"
  loadbalancer_id     = azurerm_lb.zscc.id
  protocol            = "Http"
  port                = var.http_probe_port
  request_path        = "/?cchealth"
  interval_in_seconds = 10
  number_of_probes    = 2
  probe_threshold     = 2
}

resource "azurerm_lb_rule" "haports" {
  name                           = "rule-haports"
  loadbalancer_id                = azurerm_lb.zscc.id
  frontend_ip_configuration_name = local.frontend_name
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.zscc.id]
  probe_id                       = azurerm_lb_probe.cchealth.id
  protocol                       = "All"
  frontend_port                  = 0
  backend_port                   = 0

  # Client IP persistence. Zscaler recommends source IP affinity (2-tuple) hashing on a
  # load balancer in front of Cloud or Branch Connector. In Azure that is SourceIP, which
  # hashes the source and destination addresses only; Azure's Default is the 5-tuple,
  # which adds both ports and the protocol.
  #
  # It matters for Zscaler Client Connector for VDI. In point-to-point mode, the client's
  # default, the tunnel has a fixed destination address and port and copies each inner
  # flow's source port into its own header, so the 5-tuple hash can spread one session
  # host's tunnel across several connectors. SourceIP keeps everything a host sends to
  # one address on one connector, and routed workload traffic still spreads across
  # connectors by destination.
  #
  # Not SourceIPProtocol: that is a 3-tuple hash, not the 2-tuple Zscaler recommends.
  load_distribution = "SourceIP"

  # Floating IP, which Zscaler's own module hardcodes to true. Traffic addressed to the
  # frontend itself - from a VDI client installed with this address as its SERVERIP, for
  # one - reaches the connector still addressed to the frontend. Without floating IP,
  # Azure rewrites that destination to the connector's own service NIC address.
  floating_ip_enabled = true

  # idle_timeout_in_minutes is deliberately absent. Azure does not honour it on an HA
  # ports rule that a route table forwards into, and neither does Zscaler's module set it.

  # No disable_outbound_snat either: it only has meaning on a public load balancer.
  # Connector egress is the NAT gateway's job.
}
