output "mgmt_id" {
  description = "Management NSG id."
  value       = azurerm_network_security_group.mgmt.id
}

output "service_id" {
  description = "Service NSG id."
  value       = azurerm_network_security_group.svc.id
}
