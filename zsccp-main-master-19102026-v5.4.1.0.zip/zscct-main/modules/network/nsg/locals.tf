locals {
  mgmt_name = "${var.name_prefix}nsg-mgmt-${var.name_suffix}"
  svc_name  = "${var.name_prefix}nsg-svc-${var.name_suffix}"

  # SSH comes from the Bastion range whenever there is one, whether this deployment built
  # the Bastion or is pointing at one the platform team already runs. Only where there is
  # no Bastion at all does the caller nominate a jump range instead.
  #
  # Deliberately not keyed off whether we deploy a Bastion: prod uses an existing one, so
  # "no Bastion of our own" and "no Bastion range" are different questions.
  ssh_source = var.bastion_subnet_cidr != "" ? var.bastion_subnet_cidr : var.ssh_source_cidr

  mgmt_rules = concat([
    { name = "AllowSSH", priority = 100, direction = "Inbound", access = "Allow", protocol = "Tcp", dest_port = "22", src = local.ssh_source, dst = "*" },
    { name = "AllowLBProbeIn", priority = 110, direction = "Inbound", access = "Allow", protocol = "Tcp", dest_port = tostring(var.http_probe_port), src = "AzureLoadBalancer", dst = "*" },
    { name = "AllowICMP", priority = 120, direction = "Inbound", access = "Allow", protocol = "Icmp", dest_port = "*", src = "VirtualNetwork", dst = "VirtualNetwork" },
    { name = "DenyAllIn", priority = 4096, direction = "Inbound", access = "Deny", protocol = "*", dest_port = "*", src = "*", dst = "*" },
    { name = "AllowDTLS", priority = 100, direction = "Outbound", access = "Allow", protocol = "Udp", dest_port = "443", src = "*", dst = "Internet" },
    { name = "AllowTLS", priority = 110, direction = "Outbound", access = "Allow", protocol = "Tcp", dest_port = "443", src = "*", dst = "Internet" },
    { name = "AllowHTTP", priority = 120, direction = "Outbound", access = "Allow", protocol = "Tcp", dest_port = "80", src = "*", dst = "Internet" },
    { name = "AllowDNSTcp", priority = 130, direction = "Outbound", access = "Allow", protocol = "Tcp", dest_port = "53", src = "*", dst = "*" },
    { name = "AllowDNSUdp", priority = 131, direction = "Outbound", access = "Allow", protocol = "Udp", dest_port = "53", src = "*", dst = "*" },
    { name = "AllowNTP", priority = 140, direction = "Outbound", access = "Allow", protocol = "Udp", dest_port = "123", src = "*", dst = "*" },
    { name = "AllowVnetOut", priority = 150, direction = "Outbound", access = "Allow", protocol = "*", dest_port = "*", src = "VirtualNetwork", dst = "VirtualNetwork" },
    { name = "DenyAllOut", priority = 4096, direction = "Outbound", access = "Deny", protocol = "*", dest_port = "*", src = "*", dst = "*" },
    ], var.enable_support_tunnel ? [
    # How Zscaler Support reaches a connector to assist: the connector connects out to
    # Zscaler's remote-support server on TCP 12002. Zscaler's own module adds this rule,
    # on by default and limited to that one address, and so does this one.
    { name = "AllowSupport", priority = 145, direction = "Outbound", access = "Allow", protocol = "Tcp", dest_port = "12002", src = "*", dst = var.support_server_ip },
  ] : [])

  # Named workload ranges if given, otherwise the whole VNet. Azure takes either a single
  # prefix or a list on a rule, never both, so one of these is always null.
  svc_workload_src  = length(var.workload_cidrs) == 1 ? var.workload_cidrs[0] : (length(var.workload_cidrs) == 0 ? "VirtualNetwork" : null)
  svc_workload_srcs = length(var.workload_cidrs) > 1 ? var.workload_cidrs : null

  svc_rules = [
    { name = "AllowWorkload", priority = 100, direction = "Inbound", access = "Allow", protocol = "*", dest_port = "*", src = "VirtualNetwork", dst = "*" },
    { name = "AllowLBProbeIn", priority = 110, direction = "Inbound", access = "Allow", protocol = "Tcp", dest_port = tostring(var.http_probe_port), src = "AzureLoadBalancer", dst = "*" },
    { name = "DenyInternetIn", priority = 4096, direction = "Inbound", access = "Deny", protocol = "*", dest_port = "*", src = "Internet", dst = "*" },
    { name = "AllowDTLS", priority = 100, direction = "Outbound", access = "Allow", protocol = "Udp", dest_port = "443", src = "*", dst = "Internet" },
    { name = "AllowTLS", priority = 110, direction = "Outbound", access = "Allow", protocol = "Tcp", dest_port = "443", src = "*", dst = "Internet" },
    { name = "AllowVnetOut", priority = 120, direction = "Outbound", access = "Allow", protocol = "*", dest_port = "*", src = "VirtualNetwork", dst = "VirtualNetwork" },
    # Tunnelled traffic leaves on 443 whatever the workload asked for. Traffic the
    # forwarding policy sends DIRECT leaves on its own destination port, and three of the
    # endpoints Azure Virtual Desktop session hosts require are not on 443: certificate
    # checks on TCP 80, Windows activation (azkms.core.windows.net) on TCP 1688, and
    # relayed RDP on UDP 3478. Exclude any of them from ZIA without these rules and the
    # connectors drop them here instead. Relayed RDP goes to the WindowsVirtualDesktop
    # service tag rather than the whole internet; Microsoft lists it against that tag.
    { name = "AllowHTTP", priority = 130, direction = "Outbound", access = "Allow", protocol = "Tcp", dest_port = "80", src = "*", dst = "Internet" },
    { name = "AllowKMS", priority = 140, direction = "Outbound", access = "Allow", protocol = "Tcp", dest_port = "1688", src = "*", dst = "Internet" },
    { name = "AllowRDPRelay", priority = 150, direction = "Outbound", access = "Allow", protocol = "Udp", dest_port = "3478", src = "*", dst = "WindowsVirtualDesktop" },
    { name = "DenyAllOut", priority = 4096, direction = "Outbound", access = "Deny", protocol = "*", dest_port = "*", src = "*", dst = "*" },
  ]
}
