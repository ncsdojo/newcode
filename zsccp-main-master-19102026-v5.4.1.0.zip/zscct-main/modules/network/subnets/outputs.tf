output "mgmt_id" {
  description = "Management subnet. The private endpoints terminate here."
  value       = azurerm_subnet.mgmt.id
}

output "service_id" {
  description = "Service subnet, where the connectors' data-path NICs live."
  value       = azurerm_subnet.service.id
}

output "workload_id" {
  description = "Workload subnet. The route table module associates itself with this."
  value       = azurerm_subnet.workload.id
}

output "lb_id" {
  description = "Load balancer frontend subnet."
  value       = azurerm_subnet.lb.id
}

output "funcapp_id" {
  description = "Delegated Function App subnet, carrying the Microsoft.Storage service endpoint."
  value       = azurerm_subnet.funcapp.id
}

output "bastion_id" {
  description = "AzureBastionSubnet id, or null when Bastion is disabled."
  value       = one(azurerm_subnet.bastion[*].id)
}
