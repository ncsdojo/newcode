output "vault_zone_id" {
  description = "privatelink.vaultcore.azure.net zone id, for the Key Vault private endpoint's DNS zone group."
  value       = azurerm_private_dns_zone.vault.id
}

output "sites_zone_id" {
  description = "privatelink.azurewebsites.net zone id, or null when the Function App has no private endpoint."
  value       = one(azurerm_private_dns_zone.sites[*].id)
}

output "blob_zone_id" {
  description = "privatelink.blob.core.windows.net zone id, or null when the storage account has no private endpoint."
  value       = one(azurerm_private_dns_zone.blob[*].id)
}
