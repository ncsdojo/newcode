variable "name_prefix" {
  description = "Leading name component, <app><environment>arm - e.g. ccprdarm."
  type        = string
}

variable "name_suffix" {
  description = "Trailing name component, <region><instance> - e.g. uw2001."
  type        = string
}

variable "resource_group_name" {
  description = "Group the zones and links are created in."
  type        = string
}

variable "virtual_network_id" {
  description = "Virtual network the zones are linked to."
  type        = string
}

variable "tags" {
  description = "Tags applied to the zones and links."
  type        = map(string)
  default     = {}
}

variable "enable_storage_private_endpoint" {
  description = "Create privatelink.blob.core.windows.net and its link, for the function storage account's private endpoint."
  type        = bool
  default     = true
}

variable "enable_function_private_endpoint" {
  description = "Create privatelink.azurewebsites.net and its link. Only needed when the Function App has a private endpoint."
  type        = bool
  default     = false
}
