locals {
  name     = "${var.name_prefix}bas${var.name_suffix}"
  pip_name = "${var.name_prefix}pipbas${var.name_suffix}"
}
