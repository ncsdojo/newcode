variable "name_prefix" {
  description = "Leading name component, <app><environment>arm - e.g. ccprdarm."
  type        = string
}

variable "name_suffix" {
  description = "Trailing name component, <region><instance> - e.g. uw2001."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Deployment group the Bastion and its public IP are created in."
  type        = string
}

variable "tags" {
  description = "Tags applied to the Bastion host and its public IP."
  type        = map(string)
  default     = {}
}

variable "subnet_id" {
  description = "AzureBastionSubnet id, from subnets.bastion_id."
  type        = string
}
