# Azure Bastion and its public IP - how an operator gets an SSH session to a connector
# without any of them having a public address.
#
# There is no on/off variable here. The environment puts count on the module call, so
# when Bastion is off this module is not evaluated at all.
#
# AzureBastionSubnet itself belongs to the subnets module, because its range is part of
# the subnet plan and doubles as the SSH source on the management NSG.

resource "azurerm_public_ip" "bastion" {
  name                = local.pip_name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "Standard"
  allocation_method   = "Static"
  tags                = var.tags
}

resource "azurerm_bastion_host" "zscc" {
  name                = local.name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "Standard"
  scale_units         = 2
  tunneling_enabled   = true
  ip_connect_enabled  = true
  tags                = var.tags

  ip_configuration {
    name                 = "bastion-ipcfg"
    subnet_id            = var.subnet_id
    public_ip_address_id = azurerm_public_ip.bastion.id
  }
}
