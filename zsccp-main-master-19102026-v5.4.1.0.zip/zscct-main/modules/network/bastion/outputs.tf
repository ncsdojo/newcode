output "name" {
  description = "Bastion host name."
  value       = azurerm_bastion_host.zscc.name
}

output "id" {
  description = "Bastion host id."
  value       = azurerm_bastion_host.zscc.id
}

output "public_ip" {
  description = "Bastion public IP address."
  value       = azurerm_public_ip.bastion.ip_address
}
