output "public_ip" {
  description = "The NAT egress address - allowlist this in the Zscaler portal."
  value       = azurerm_public_ip.natgw.ip_address
}

output "public_ip_id" {
  description = "Id of the NAT egress public IP. Locked, because losing it means a new address to allowlist."
  value       = azurerm_public_ip.natgw.id
}

output "gateway_id" {
  description = "NAT gateway id."
  value       = azurerm_nat_gateway.zscc.id
}
