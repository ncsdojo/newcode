variable "name_prefix" {
  description = "Leading name component, <app><environment>arm - e.g. ccprdarm."
  type        = string
}

variable "name_suffix" {
  description = "Trailing name component, <region><instance> - e.g. uw2001."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Deployment group the gateway and its public IP are created in."
  type        = string
}

variable "tags" {
  description = "Tags applied to the gateway and its public IP."
  type        = map(string)
  default     = {}
}

variable "mgmt_subnet_id" {
  description = "Management subnet, routed through the gateway."
  type        = string
}

variable "service_subnet_id" {
  description = "Service subnet, routed through the gateway."
  type        = string
}

variable "funcapp_subnet_id" {
  description = "Function App subnet, routed through the same gateway."
  type        = string
}
