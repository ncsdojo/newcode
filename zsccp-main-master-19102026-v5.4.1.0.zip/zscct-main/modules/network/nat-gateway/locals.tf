locals {
  natgw_name = "${var.name_prefix}nat${var.name_suffix}"
  pip_name   = "${var.name_prefix}pip${var.name_suffix}"
}
