# One zone-redundant NAT gateway with a static public IP, plus the subnet associations.
#
# This is how the connectors, and the lifecycle function through its VNet integration,
# reach the internet. Outbound through a load balancer is a public load balancer
# feature, so the internal one gives the connectors no way out, and Microsoft recommends
# a NAT gateway for outbound connectivity from a subnet. Without one, a connector falls
# back to Azure's default outbound access where its subnet still has it, which Microsoft
# advises against: the address can change, and virtual networks created from 31 March
# 2026 default to private subnets that have none.
#
# The load balancer's subnet is deliberately not associated. It holds only the frontend
# address, which receives traffic and never starts a connection, and a NAT gateway only
# carries connections that start in its subnets, and their replies.
#
# StandardV2 spans every availability zone in the region on its own, so one gateway
# survives losing a zone. That is why there is one here rather than one per zone - and
# why neither resource sets `zones`, which would pin them to a single one.
#
# One gateway also means one public IP to allowlist in the Zscaler portal.

resource "azurerm_public_ip" "natgw" {
  name                = local.pip_name
  location            = var.location
  resource_group_name = var.resource_group_name
  # Must match the gateway's SKU - a StandardV2 gateway will not accept a Standard IP.
  sku               = "StandardV2"
  allocation_method = "Static"
  tags              = var.tags
}

resource "azurerm_nat_gateway" "zscc" {
  name                = local.natgw_name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku_name            = "StandardV2"
  # Ten minutes, as in Zscaler's own module, rather than Azure's four-minute default.
  # Azure silently drops a flow once it has been idle that long, and sends a reset only
  # if traffic later arrives on it. Microsoft's general advice is to keep the default and
  # use TCP keepalives; this follows Zscaler's choice for its own connectors.
  idle_timeout_in_minutes = 10
  tags                    = var.tags
}

resource "azurerm_nat_gateway_public_ip_association" "zscc" {
  nat_gateway_id       = azurerm_nat_gateway.zscc.id
  public_ip_address_id = azurerm_public_ip.natgw.id
}

# A gateway can serve several subnets; a subnet can only have one gateway.
resource "azurerm_subnet_nat_gateway_association" "mgmt" {
  subnet_id      = var.mgmt_subnet_id
  nat_gateway_id = azurerm_nat_gateway.zscc.id
}

resource "azurerm_subnet_nat_gateway_association" "service" {
  subnet_id      = var.service_subnet_id
  nat_gateway_id = azurerm_nat_gateway.zscc.id
}

resource "azurerm_subnet_nat_gateway_association" "funcapp" {
  subnet_id      = var.funcapp_subnet_id
  nat_gateway_id = azurerm_nat_gateway.zscc.id
}
