# The Cloud Connectors themselves: one scale set per zone, each with its own autoscale
# policy. In a region without availability zones, one regional scale set instead.
#
# Every connector gets two NICs. The management NIC is where an operator SSHes in; the
# service NIC carries customer traffic, has IP forwarding on, and is the one the load
# balancer sends to.
#
# Autoscale runs off smedge_cpu_utilization, a metric the connectors publish about
# themselves rather than anything Azure measures. If those samples stop arriving,
# autoscale silently stops reacting, and no metric alert can say so: Azure records a
# custom metric that stops arriving as no data, not as zero.
#
# The remediation role is here because its scope is these scale sets, and the
# marketplace agreement because it accepts terms for exactly this image.

resource "azurerm_orchestrated_virtual_machine_scale_set" "cc" {
  for_each                    = toset(var.zones)
  name                        = var.vmss_names[each.value]
  location                    = var.location
  resource_group_name         = var.resource_group_name
  sku_name                    = var.vm_size
  instances                   = var.desired_instances
  platform_fault_domain_count = 1
  # No zone at all where the region has none - Azure rejects any zone there.
  zones                      = var.zones_enabled ? [each.value] : null
  user_data_base64           = local.userdata_b64
  encryption_at_host_enabled = var.encrypt_at_host
  tags                       = local.scale_set_tags

  plan {
    name      = local.image.sku
    publisher = local.image.publisher
    product   = local.image.offer
  }

  identity {
    type         = "UserAssigned"
    identity_ids = [var.cc_identity_id]
  }

  os_profile {
    custom_data = local.userdata_b64
    linux_configuration {
      admin_username                  = var.admin_username
      computer_name_prefix            = local.computer_name_prefix
      disable_password_authentication = true
      admin_ssh_key {
        username   = var.admin_username
        public_key = var.ssh_public_key
      }
    }
  }

  source_image_reference {
    publisher = local.image.publisher
    offer     = local.image.offer
    sku       = local.image.sku
    # Resolved per instance at creation time, so "latest" lets a scale-out build on a
    # newer image than the fleet already running. Pin an exact version in prod. Changing
    # it only affects instances created afterwards - flexible orchestration does not
    # reimage existing ones - so cycle the fleet after a bump.
    version = var.image_version
  }

  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Premium_LRS"
  }

  # Management NIC. SSH arrives here. No IP forwarding: it never carries transit
  # traffic. It is not in the backend pool, so no load-balanced traffic reaches it.
  network_interface {
    name                          = "nic-mgmt"
    primary                       = true
    enable_ip_forwarding          = false
    enable_accelerated_networking = false

    ip_configuration {
      name      = "ipconfig-mgmt"
      primary   = true
      subnet_id = var.mgmt_subnet_id
    }
  }

  # Service NIC. Customer traffic arrives here from the load balancer, and so does the
  # load balancer's health probe, because this is the NIC in the backend pool. IP
  # forwarding is on because the connector routes through it rather than terminating it.
  network_interface {
    name                          = "nic-svc"
    primary                       = false
    enable_ip_forwarding          = true
    enable_accelerated_networking = var.accelerated_networking

    ip_configuration {
      name                                   = "ipconfig-svc"
      primary                                = true
      subnet_id                              = var.service_subnet_id
      load_balancer_backend_address_pool_ids = [var.lb_backend_address_pool_id]
    }
  }

  boot_diagnostics {}

  # Gives an instance five minutes' warning before Azure takes it away, so it can drain
  # rather than dropping sessions.
  termination_notification {
    enabled = true
    timeout = "PT5M"
  }

  lifecycle {
    # instances only sets the size at creation. After that autoscale owns it; an apply
    # that reset it would undo autoscale, scaling a busy fleet back in mid-load.
    ignore_changes = [instances]

    # This URL is baked into cloud-init and is how the connector finds its portal. Get it
    # wrong and the instances come up but never register.
    precondition {
      condition     = can(regex("^(https://)?connector\\.${var.zscaler_cloud}\\.", var.provisioning_url))
      error_message = "provisioning_url (${var.provisioning_url}) does not point at the declared zscaler_cloud '${var.zscaler_cloud}'. Expected ${local.zscaler_base_url}/..., with or without https://."
    }
    # Without availability zones there is one regional scale set, not one per zone.
    precondition {
      condition     = var.zones_enabled || length(var.zones) == 1
      error_message = "zones_enabled = false builds one regional scale set, so zones must hold a single key, e.g. [\"1\"]. Got ${jsonencode(var.zones)}."
    }
  }
}

resource "azurerm_monitor_autoscale_setting" "cc" {
  for_each            = toset(var.zones)
  name                = local.autoscale_names[each.value]
  location            = var.location
  resource_group_name = var.resource_group_name
  target_resource_id  = azurerm_orchestrated_virtual_machine_scale_set.cc[each.value].id
  enabled             = true
  tags                = var.tags

  lifecycle {
    precondition {
      condition     = var.min_instances <= var.desired_instances && var.desired_instances <= var.max_instances
      error_message = "Autoscale capacity must satisfy min_instances <= desired_instances <= max_instances (currently ${var.min_instances}/${var.desired_instances}/${var.max_instances}). Azure rejects a default outside the min-max range."
    }
    precondition {
      condition     = !var.scheduled_scaling || var.scheduled_min_instances <= var.max_instances
      error_message = "scheduled_min_instances (${var.scheduled_min_instances}) cannot exceed max_instances (${var.max_instances})."
    }
    precondition {
      # Zscaler will not accept more than 16 connectors in one EC group, and there is one
      # group per scale set. A higher ceiling just builds VMs that can never register.
      # Add zones instead.
      condition     = var.max_instances <= 16
      error_message = "max_instances (${var.max_instances}) exceeds the Zscaler portal limit of 16 connectors per EC group. Add zones rather than raising the per-scale-set ceiling."
    }
  }

  profile {
    name = "default-profile"

    capacity {
      default = var.desired_instances
      minimum = var.min_instances
      maximum = var.max_instances
    }

    # When scheduled scaling is on, this recurrence is what hands control back to normal
    # capacity at the end of the window.
    dynamic "recurrence" {
      for_each = var.scheduled_scaling ? [1] : []
      content {
        timezone = var.scheduled_timezone
        days     = local.all_days
        hours    = [var.scheduled_end_hour]
        minutes  = [var.scheduled_end_minute]
      }
    }

    dynamic "rule" {
      for_each = local.scale_rules
      content {
        metric_trigger {
          metric_name        = "smedge_metrics"
          metric_namespace   = "Zscaler/CloudConnectors"
          metric_resource_id = azurerm_orchestrated_virtual_machine_scale_set.cc[each.value].id
          time_grain         = "PT1M"
          statistic          = "Average"
          time_window        = rule.value.time_window
          time_aggregation   = "Average"
          operator           = rule.value.operator
          threshold          = rule.value.threshold

          dimensions {
            name     = "metric_name"
            operator = "Equals"
            values   = ["smedge_cpu_utilization"]
          }
        }
        scale_action {
          direction = rule.value.direction
          type      = "ChangeCount"
          value     = "1"
          cooldown  = "PT${rule.value.cooldown_minutes}M"
        }
      }
    }
  }

  # The scheduled profile: same rules, its own floor, and a recurrence that starts the
  # window. Only created when scheduled scaling is turned on.
  dynamic "profile" {
    for_each = var.scheduled_scaling ? [1] : []
    content {
      name = "scheduled-profile"

      capacity {
        default = var.scheduled_min_instances
        minimum = var.scheduled_min_instances
        maximum = var.max_instances
      }

      recurrence {
        timezone = var.scheduled_timezone
        days     = var.scheduled_days
        hours    = [var.scheduled_start_hour]
        minutes  = [var.scheduled_start_minute]
      }

      dynamic "rule" {
        for_each = local.scale_rules
        content {
          metric_trigger {
            metric_name        = "smedge_metrics"
            metric_namespace   = "Zscaler/CloudConnectors"
            metric_resource_id = azurerm_orchestrated_virtual_machine_scale_set.cc[each.value].id
            time_grain         = "PT1M"
            statistic          = "Average"
            time_window        = rule.value.time_window
            time_aggregation   = "Average"
            operator           = rule.value.operator
            threshold          = rule.value.threshold

            dimensions {
              name     = "metric_name"
              operator = "Equals"
              values   = ["smedge_cpu_utilization"]
            }
          }
          scale_action {
            direction = rule.value.direction
            type      = "ChangeCount"
            value     = "1"
            cooldown  = "PT${rule.value.cooldown_minutes}M"
          }
        }
      }
    }
  }
}

# Lets the lifecycle function terminate an unhealthy connector. Virtual Machine
# Contributor by default: wider than the four actions the function actually uses, but
# scoped to these scale sets and nothing else. A custom role the platform team already
# defined can be named instead.
#
# Starting the replacement also writes the scale set, which joins the connector subnets,
# so the function needs subnets/join/action on them too, granted where the subnets live.
# The same write references the load balancer pool and the connector identity, which
# may need grants of their own; see the README.
resource "azurerm_role_assignment" "remediation" {
  for_each             = var.disable_health_remediation ? toset([]) : toset(var.zones)
  scope                = azurerm_orchestrated_virtual_machine_scale_set.cc[each.value].id
  role_definition_name = var.remediation_role_name
  principal_id         = var.funcapp_principal_id
}

# Off by default, on the assumption the platform owner already accepted the image terms
# for the subscription. Turning it on needs MarketplaceOrdering rights at the subscription.
resource "azurerm_marketplace_agreement" "cc" {
  count     = var.accept_marketplace_terms ? 1 : 0
  publisher = local.image.publisher
  offer     = local.image.offer
  plan      = local.image.sku
}
