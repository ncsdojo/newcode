variable "zones" {
  description = "Availability zones. One scale set and one autoscale setting per zone."
  type        = list(string)
}

variable "zones_enabled" {
  description = "false in a region without availability zones. Builds one regional scale set with no zone, so zones must then hold a single key, which only names it."
  type        = bool
  default     = true
}

variable "vmss_names" {
  description = "Scale set name per zone. Passed in rather than derived here because the Function App needs the same names before the scale sets exist."
  type        = map(string)
}

variable "name_prefix" {
  description = "Leading name component, <app><environment>arm - e.g. ccprdarm."
  type        = string
}

variable "name_suffix" {
  description = "Trailing name component, <region><instance> - e.g. uw2001."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Group the scale sets and autoscale settings are created in."
  type        = string
}

variable "tags" {
  description = "Tags applied to the scale sets and autoscale settings."
  type        = map(string)
  default     = {}
}

variable "vm_size" {
  description = "Connector VM size."
  type        = string
  default     = "Standard_D2s_v3"
}

variable "image_version" {
  description = "Marketplace image version. An exact x.y.z, or 'latest' resolved per instance at creation time."
  type        = string
  default     = "latest"

  validation {
    condition     = var.image_version == "latest" || can(regex("^[0-9]+[.][0-9]+[.][0-9]+$", var.image_version))
    error_message = "image_version must be 'latest' or an exact marketplace version such as 25.12.1."
  }
}

variable "admin_username" {
  description = "Connector admin login. Password auth is disabled; this is the SSH key owner."
  type        = string
  default     = "zsroot"
}

variable "ssh_public_key" {
  description = "OpenSSH public key for CC admin login."
  type        = string
}

variable "encrypt_at_host" {
  description = "Encryption at host. Requires the feature to be registered on the subscription."
  type        = bool
  default     = false
}

variable "accelerated_networking" {
  description = "Accelerated networking on the service NIC. The management NIC never uses it."
  type        = bool
  default     = true
}

variable "enable_legacy_vm_nva_tag" {
  description = "Tag the scale sets LegacyVMNVA = true, which keeps the connectors off Azure hosts with the MANA network adapter. Turn off once Zscaler's connector image supports MANA."
  type        = bool
  default     = true
}

variable "mgmt_subnet_id" {
  description = "Management subnet, shared by the management NIC of every connector in every zone."
  type        = string
}

variable "service_subnet_id" {
  description = "Service subnet, shared by the service NIC of every connector in every zone."
  type        = string
}

variable "lb_backend_address_pool_id" {
  description = "Backend pool the service NIC joins."
  type        = string
}

variable "cc_identity_id" {
  description = "Connector user-assigned identity resource id."
  type        = string
}

variable "cc_identity_client_id" {
  description = "Connector identity client id, written into cloud-init."
  type        = string
}

variable "key_vault_uri" {
  description = "Vault URI, written into cloud-init as AZURE_VAULT_URL."
  type        = string
}

variable "provisioning_url" {
  description = "Connector provisioning URL from the Zscaler console, with or without https://. Written into cloud-init as CC_URL, without the scheme."
  type        = string
}

variable "zscaler_cloud" {
  description = "Zscaler cloud name. Checked against provisioning_url by a precondition."
  type        = string
}

variable "http_probe_port" {
  description = "Health probe port the connector listens on, written into cloud-init."
  type        = number
  default     = 50000
}

# Capacity

variable "desired_instances" {
  description = "Capacity each scale set is created with, and the autoscale default used while no metrics arrive. Changing it later does not resize a scale set directly; autoscale applies the new default only while metrics are missing."
  type        = number
  default     = 2
}

variable "min_instances" {
  description = "Autoscale floor per scale set."
  type        = number
  default     = 2
}

variable "max_instances" {
  description = "Autoscale ceiling per scale set. Capped at 16 by the Zscaler EC group limit."
  type        = number
  default     = 4
}

variable "scale_out_threshold" {
  description = "smedge_cpu_utilization above which a scale set adds an instance."
  type        = number
  default     = 70
}

variable "scale_in_threshold" {
  description = "smedge_cpu_utilization below which a scale set removes an instance."
  type        = number
  default     = 30
}

variable "scale_out_cooldown_minutes" {
  description = "Cooldown after a scale-out action."
  type        = number
  default     = 5
}

variable "scale_in_cooldown_minutes" {
  description = "Cooldown after a scale-in action."
  type        = number
  default     = 10
}

# Scheduled scaling

variable "scheduled_scaling" {
  description = "Add a recurring autoscale profile with its own floor, active from scheduled_start to scheduled_end on scheduled_days."
  type        = bool
  default     = false
}

variable "scheduled_min_instances" {
  description = "Instance floor during the scheduled window."
  type        = number
  default     = 1
}

variable "scheduled_days" {
  description = "Days the scheduled profile applies."
  type        = list(string)
  default     = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
}

variable "scheduled_start_hour" {
  description = "Hour the scheduled profile takes over (0-23)."
  type        = number
  default     = 9
}

variable "scheduled_start_minute" {
  description = "Minute the scheduled profile takes over (0-59)."
  type        = number
  default     = 0
}

variable "scheduled_end_hour" {
  description = "Hour the default profile resumes (0-23)."
  type        = number
  default     = 17
}

variable "scheduled_end_minute" {
  description = "Minute the default profile resumes (0-59)."
  type        = number
  default     = 0
}

variable "scheduled_timezone" {
  description = "Windows time zone id for the scheduled profile, e.g. 'Pacific Standard Time'."
  type        = string
  default     = "Pacific Standard Time"
}

# Remediation and marketplace terms

variable "disable_health_remediation" {
  description = "true: unhealthy connectors are evaluated and logged but never terminated; no remediation role is created."
  type        = bool
  default     = false
}

variable "funcapp_principal_id" {
  description = "Function identity object id, granted the remediation role on each scale set."
  type        = string
}

variable "remediation_role_name" {
  description = "Role granted to the function on each scale set so it can terminate unhealthy connectors: a built-in role or an existing custom role, by name."
  type        = string
  default     = "Virtual Machine Contributor"
}

variable "accept_marketplace_terms" {
  description = "false assumes the platform owner accepted the Zscaler CC image terms at the subscription. true creates the agreement, which needs subscription-scope MarketplaceOrdering rights."
  type        = bool
  default     = false
}
