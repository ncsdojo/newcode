locals {
  autoscale_names      = { for z in var.zones : z => "${var.name_prefix}as-z${z}-${var.name_suffix}" }
  computer_name_prefix = "zscc${var.name_suffix}"
  zscaler_base_url     = "connector.${var.zscaler_cloud}.net"

  # Marketplace image coordinates. The plan block, the source image reference and the
  # marketplace agreement must all agree, so they read from one place.
  image = {
    publisher = "zscaler1579058425289"
    offer     = "zia_cloud_connector"
    sku       = "zs_ser_gen1_cc_01"
  }

  # cloud-init. This is what the connector reads to find its portal, its vault and the
  # identity it authenticates with.
  #
  # CC_URL carries no scheme - the same value the function app gets. Zscaler's own module
  # feeds both from one input, and the function package fails when given a scheme.
  cc_url = trimprefix(var.provisioning_url, "https://")
  userdata = join("\n", [
    "[ZSCALER]",
    "CC_URL=${local.cc_url}",
    "AZURE_VAULT_URL=${var.key_vault_uri}",
    "HTTP_PROBE_PORT=${var.http_probe_port}",
    "AZURE_MANAGED_IDENTITY_CLIENT_ID=${var.cc_identity_client_id}",
    # Every Zscaler example sends this key, defaulted off. FIPS mode is a provisioning-time
    # decision that cannot be changed on a built connector, so it is spelled out rather
    # than left to whatever the appliance assumes when the key is absent.
    "FIPS_ENABLED=False",
  ])
  userdata_b64 = base64encode(local.userdata)

  # LegacyVMNVA keeps the connectors off Azure hosts with the MANA network adapter.
  # Microsoft is moving the general-purpose families, Dsv3 included, onto MANA hardware,
  # and an appliance whose image has no MANA driver falls back to the slower synthetic
  # NIC there, which Microsoft warns can mean intermittent connectivity and lower
  # throughput. Zscaler's own module sets this tag until its connector image supports
  # MANA.
  #
  # Azure reads the tag when it places a VM, so a connector that is already running only
  # gets the benefit once it is stopped and started, redeployed or replaced. Microsoft
  # has said it honours the tag until 31 May 2027.
  scale_set_tags = merge(var.tags, var.enable_legacy_vm_nva_tag ? { LegacyVMNVA = "true" } : {})

  all_days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

  # Every profile scales on the same two rules.
  scale_rules = [
    { direction = "Increase", operator = "GreaterThan", threshold = var.scale_out_threshold, time_window = "PT5M", cooldown_minutes = var.scale_out_cooldown_minutes },
    { direction = "Decrease", operator = "LessThan", threshold = var.scale_in_threshold, time_window = "PT10M", cooldown_minutes = var.scale_in_cooldown_minutes },
  ]
}
