# Vendor function package

Place Zscaler's official `zscaler_cc_function_app.zip` in this folder before running
`terraform plan`. The plan fails with a clear precondition message while it is absent.

It is not redistributed here: it is proprietary, and its `version.py` carries an explicit
notice prohibiting copying. Download it from Zscaler's terraform repository at
`modules/terraform-zscc-function-app-azure/zscaler_cc_function_app.zip` on the `main`
branch. This is byte-for-byte the same artifact the PowerShell module publishes in its
default Vendor mode, so both deployment paths run identical function code.

To hold the zip outside the module - an artifact cache, a shared drop, a CI workspace -
set the module's `function_package_path` input instead of copying it here.

Re-applies: a changed zip produces a new content-hashed blob name, updates
WEBSITE_RUN_FROM_PACKAGE, and restarts the app onto the new package. Refreshing the blob
after the storage lockdown requires your public IP in `storage_deployer_ip_rules`, and
Terraform running from outside the deployment region: storage ignores IP rules for
requests from its own region.
