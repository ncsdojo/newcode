locals {
  storage_name       = substr(lower("${var.name_prefix}st${var.name_suffix}${substr(var.short_id, 0, 4)}"), 0, 24)
  app_insights_name  = "${var.name_prefix}appi${var.name_suffix}"
  service_plan_name  = "${var.name_prefix}plan${var.name_suffix}"
  log_analytics_name = "${var.name_prefix}log${var.name_suffix}"

  # The vendor package ships with the module by default; function_package_path lets a caller
  # point at a copy held elsewhere (an artifact cache, a CI drop) without editing the module.
  pkg_path   = coalesce(var.function_package_path, "${path.module}/function_package/zscaler_cc_function_app.zip")
  pkg_exists = fileexists(local.pkg_path)

  # Content-hashed name: a changed zip produces a new blob, which updates
  # WEBSITE_RUN_FROM_PACKAGE and restarts the app onto the new package.
  pkg_blob_name = "zscc-func-${var.short_id}-${try(filemd5(local.pkg_path), "missing")}.zip"

  # Identity-based host storage needs all four: the host uses blob, queue and table directly,
  # and Storage Account Contributor to read account properties at startup.
  host_storage_roles = {
    blob  = "Storage Blob Data Owner"
    queue = "Storage Queue Data Contributor"
    table = "Storage Table Data Contributor"
    acct  = "Storage Account Contributor"
  }

  # Settings the vendor package reads. Names are fixed by the package and must not be renamed.
  #
  # CC_URL goes in without a scheme, as Zscaler's own module passes it: the package
  # prefixes https:// itself, and given the scheme it resolves the host as "https" and
  # every sync fails.
  app_settings = {
    SUBSCRIPTION_ID               = "/subscriptions/${var.subscription_id}"
    MANAGED_IDENTITY              = var.funcapp_client_id
    RESOURCE_GROUP                = var.resource_group_name
    VMSS_NAME                     = jsonencode(var.vmss_names)
    VAULT_URL                     = var.key_vault_uri
    CC_URL                        = trimprefix(var.provisioning_url, "https://")
    TERMINATE_UNHEALTHY_INSTANCES = var.disable_health_remediation ? "false" : "true"
    # Run-from-package over managed identity: no SAS, no shared keys.
    WEBSITE_RUN_FROM_PACKAGE                     = azurerm_storage_blob.func_package.url
    WEBSITE_RUN_FROM_PACKAGE_BLOB_MI_RESOURCE_ID = var.funcapp_identity_id
    AzureWebJobsStorage__credential              = "managedidentity"
    AzureWebJobsStorage__clientId                = var.funcapp_client_id
    ApplicationInsightsAgent_EXTENSION_VERSION   = "~3"
    XDT_MicrosoftApplicationInsights_Mode        = "recommended"
  }
}
