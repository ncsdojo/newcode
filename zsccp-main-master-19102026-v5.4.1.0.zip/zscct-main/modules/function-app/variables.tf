variable "name" {
  description = "Function App name. Also seeds the private endpoint name, pe-<name>."
  type        = string
}

variable "short_id" {
  description = "8-char deployment id. Its first four characters keep the storage account name globally unique, and it appears in the package blob name."
  type        = string
}

variable "name_prefix" {
  description = "Leading name component, <app><environment>arm - e.g. ccprdarm."
  type        = string
}

variable "name_suffix" {
  description = "Trailing name component, <region><instance> - e.g. uw2001."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Group everything here is created in. Also passed to the function as RESOURCE_GROUP."
  type        = string
}

variable "tags" {
  description = "Tags applied to every taggable resource here."
  type        = map(string)
  default     = {}
}

variable "subscription_id" {
  description = "Target subscription, passed to the function as SUBSCRIPTION_ID."
  type        = string
  sensitive   = true
}

variable "app_service_plan_sku" {
  description = "App Service plan tier: Basic, Standard or Premium v2-v4."
  type        = string
  default     = "P0v3"
  validation {
    # Consumption, Elastic Premium and Workflow plans mount their content share over Azure
    # Files, which needs the storage key this configuration disables. Flex Consumption is
    # a different resource type, Free and Shared cannot run always_on, and Isolated needs
    # an App Service Environment.
    condition     = can(regex("(?i)^(B[1-3]|S[1-3]|P[1-3]v2|P[0-3]v3|P[1-5]mv3|P[0-3]v4|P[1-5]mv4)$", var.app_service_plan_sku))
    error_message = "app_service_plan_sku must be a Basic, Standard or Premium v2-v4 tier, e.g. B1, S1, P0v3 or P1v3. Consumption, Flex Consumption, Elastic Premium, Workflow, Free, Shared and Isolated plans cannot host this app as configured."
  }
}

variable "funcapp_identity_id" {
  description = "Function user-assigned identity resource id."
  type        = string
}

variable "funcapp_client_id" {
  description = "Function identity client id, used by MANAGED_IDENTITY and the host storage connection."
  type        = string
}

variable "funcapp_principal_id" {
  description = "Function identity object id, granted the four host storage roles."
  type        = string
}

variable "deployer_object_id" {
  description = "Object id of the principal running Terraform. Granted Storage Blob Data Contributor so the apply can upload the package."
  type        = string
}

variable "subnet_id" {
  description = "Delegated Function App subnet. Also the VNet rule on the locked storage firewall."
  type        = string
}

variable "private_endpoint_subnet_id" {
  description = "Subnet the storage and Function App private endpoints terminate in - the management subnet."
  type        = string
}

variable "private_dns_zone_id" {
  description = "privatelink.azurewebsites.net zone id for the endpoint's DNS zone group. Only used when enable_private_endpoint is true."
  type        = string
  default     = null
}

variable "enable_storage_private_endpoint" {
  description = "Give the function storage account a blob private endpoint in the management subnet, so a deployment host inside the network can refresh the package blob after the firewall closes."
  type        = bool
  default     = true
}

variable "blob_private_dns_zone_id" {
  description = "privatelink.blob.core.windows.net zone id for the storage endpoint's DNS zone group. Required when enable_storage_private_endpoint is true."
  type        = string
  default     = null
}

variable "key_vault_uri" {
  description = "Vault URI, passed to the function as VAULT_URL."
  type        = string
}

variable "provisioning_url" {
  description = "Connector provisioning URL, with or without https://. Passed to the function as CC_URL, without the scheme."
  type        = string
}

variable "vmss_names" {
  description = "Scale set names the function manages, in zone order. Serialised into the VMSS_NAME app setting. Deterministic, so it does not order the app behind the scale sets."
  type        = list(string)
}

variable "disable_health_remediation" {
  description = "true: unhealthy connectors are evaluated and logged but never terminated."
  type        = bool
  default     = false
}

variable "storage_deployer_ip_rules" {
  description = "Public IPs kept on the locked storage firewall so later applies can refresh the package blob. Single addresses go in bare, without a /32. Storage ignores IP rules for requests from its own region, so run Terraform from outside the deployment region."
  type        = list(string)
  default     = []
  validation {
    # Azure's storage firewall takes public IPv4 only, rejects /31 and /32 prefixes, and
    # refuses RFC1918 ranges. Catching that here beats a 400 from the API mid-apply.
    condition = alltrue([
      for ip in var.storage_deployer_ip_rules :
      can(cidrnetmask(length(split("/", ip)) == 1 ? "${ip}/32" : ip)) &&
      !endswith(ip, "/31") && !endswith(ip, "/32") &&
      !can(regex("^(10\\.|192\\.168\\.|172\\.(1[6-9]|2[0-9]|3[01])\\.)", ip))
    ])
    error_message = "storage_deployer_ip_rules must be public IPv4 addresses or CIDR ranges. Azure rejects IPv6, /31 and /32 prefixes (use the bare address), and RFC1918 private ranges (10.x, 172.16-31.x, 192.168.x)."
  }
}

variable "enable_private_endpoint" {
  description = "Place the Function App behind a Private Endpoint and disable public inbound access."
  type        = bool
  default     = false
}

variable "function_package_path" {
  description = "Override the path to the vendor zip. Null uses the copy bundled at function_package/zscaler_cc_function_app.zip."
  type        = string
  default     = null
}

variable "log_retention_in_days" {
  description = "Log Analytics retention. 30 days is the PerGB2018 included minimum."
  type        = number
  default     = 30
}

variable "rbac_propagation_delay" {
  description = "How long to wait after granting the deployer the blob role before uploading the package."
  type        = string
  default     = "60s"
}

variable "app_insights_location" {
  description = "Region for Application Insights where location does not offer it, e.g. westus2 for a West Central US deployment. Null keeps it in location. The Log Analytics workspace always stays in location."
  type        = string
  default     = null
}

variable "storage_replication_type" {
  description = "Function storage redundancy. ZRS where the region has availability zones; LRS where it does not, because ZRS needs them."
  type        = string
  default     = "ZRS"
  validation {
    condition     = contains(["ZRS", "LRS"], var.storage_replication_type)
    error_message = "storage_replication_type must be ZRS or LRS."
  }
}
