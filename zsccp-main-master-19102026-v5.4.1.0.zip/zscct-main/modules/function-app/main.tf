# Zscaler's lifecycle function and everything it needs to run: a storage account, the
# vendor package, an App Service plan, Application Insights, the app itself, the storage
# firewall that gets closed behind it, and the trigger sync that starts it.
#
# The function runs on timers. It reconciles what the Zscaler portal believes about the
# connectors against what is actually running in the scale sets, and replaces connectors
# that report unhealthy.
#
# Nothing here uses a storage account key. The app authenticates to storage as its
# managed identity, which is why the plan has to be a Dedicated tier - Consumption and
# Elastic Premium mount their content share over Azure Files, and that needs a key.
#
# Application Insights sits with the app it instruments; the monitoring module only reads
# its id.

resource "azurerm_storage_account" "func" {
  name                            = local.storage_name
  location                        = var.location
  resource_group_name             = var.resource_group_name
  account_kind                    = "StorageV2"
  account_tier                    = "Standard"
  account_replication_type        = var.storage_replication_type
  min_tls_version                 = "TLS1_2"
  https_traffic_only_enabled      = true
  allow_nested_items_to_be_public = false
  shared_access_key_enabled       = false
  # Shared keys are off, so key auth is not a fallback anyone should be offered. This
  # makes Entra the default path in the portal and in tooling rather than a choice.
  default_to_oauth_authentication = true
  tags                            = var.tags
}

# Terraform uploads the package as itself, over Entra ID, so it has to grant itself the
# blob role first. Shared keys are off, so there is no other way in.
resource "azurerm_role_assignment" "deployer_blob" {
  scope                = azurerm_storage_account.func.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = var.deployer_object_id
}

resource "time_sleep" "storage_rbac" {
  create_duration = var.rbac_propagation_delay
  depends_on      = [azurerm_role_assignment.deployer_blob]
}

resource "azurerm_storage_container" "packages" {
  name                  = "function-packages"
  storage_account_id    = azurerm_storage_account.func.id
  container_access_type = "private"
}

resource "azurerm_storage_blob" "func_package" {
  name = local.pkg_blob_name
  # Built from the account id because a container created through storage_account_name
  # keeps a data-plane URL as its id until an apply moves it to storage_account_id.
  storage_container_id = "${azurerm_storage_account.func.id}/blobServices/default/containers/${azurerm_storage_container.packages.name}"
  type                 = "Block"
  content_type         = "application/zip"
  source               = local.pkg_path
  # After the role grant has settled, and before the blob private endpoint on a destroy,
  # because that endpoint is how a host inside the network reaches the blob.
  depends_on = [time_sleep.storage_rbac, azurerm_private_endpoint.storage_blob]

  lifecycle {
    precondition {
      condition     = local.pkg_exists
      error_message = "Vendor function package not found at ${local.pkg_path}. Download Zscaler's official zip from their terraform repository (modules/terraform-zscc-function-app-azure/zscaler_cc_function_app.zip, main branch) and place it there; it is proprietary and not redistributed."
    }
  }
}

# The function host keeps its own state in blobs, queues and tables, so its identity
# needs all four of these before the app will start.
resource "azurerm_role_assignment" "funcapp_storage" {
  for_each             = local.host_storage_roles
  scope                = azurerm_storage_account.func.id
  role_definition_name = each.value
  principal_id         = var.funcapp_principal_id
}

resource "azurerm_service_plan" "func" {
  name                = local.service_plan_name
  location            = var.location
  resource_group_name = var.resource_group_name
  os_type             = "Linux"
  sku_name            = var.app_service_plan_sku
  tags                = var.tags
}

resource "azurerm_log_analytics_workspace" "zscc" {
  name                = local.log_analytics_name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "PerGB2018"
  retention_in_days   = var.log_retention_in_days
  tags                = var.tags
}

resource "azurerm_application_insights" "zscc" {
  name = local.app_insights_name
  # Not every region offers Application Insights - West Central US does not - so it can
  # sit in a neighbouring region while its workspace stays with everything else.
  location            = coalesce(var.app_insights_location, var.location)
  resource_group_name = var.resource_group_name
  workspace_id        = azurerm_log_analytics_workspace.zscc.id
  # Typed "web" because that is what the vendor package emits, even though the app is
  # timer-triggered and has no HTTP surface of its own.
  application_type = "web"
  tags             = var.tags
}

resource "azurerm_linux_function_app" "sync" {
  name                          = var.name
  location                      = var.location
  resource_group_name           = var.resource_group_name
  service_plan_id               = azurerm_service_plan.func.id
  storage_account_name          = azurerm_storage_account.func.name
  storage_uses_managed_identity = true
  virtual_network_subnet_id     = var.subnet_id
  functions_extension_version   = "~4"
  tags                          = var.tags

  # Sent explicitly rather than left to the provider default. The request always carries
  # httpsOnly, and an Azure Policy that appends httpsOnly = true fails the whole
  # deployment with a 409 unless the value we send already matches.
  https_only                    = true
  public_network_access_enabled = !var.enable_private_endpoint

  # The app runs on a user-assigned identity and has no system-assigned one to fall back
  # on, so the identity that resolves Key Vault references has to be named explicitly.
  key_vault_reference_identity_id = var.funcapp_identity_id

  # No basic auth for deployments - Entra only.
  ftp_publish_basic_authentication_enabled       = false
  webdeploy_publish_basic_authentication_enabled = false

  identity {
    type         = "UserAssigned"
    identity_ids = [var.funcapp_identity_id]
  }

  site_config {
    # A Dedicated plan unloads an idle app, and an unloaded app does not fire its timer.
    # This one is timer-triggered and nothing else, so without always_on the lifecycle
    # sync silently stops running between cold starts. The provider default is false.
    always_on = true
    # Set explicitly for the same reason as https_only above: policies that append these
    # fields fail the request when it already carries them with a different value.
    http2_enabled                          = true
    minimum_tls_version                    = "1.2"
    ftps_state                             = "Disabled"
    vnet_route_all_enabled                 = true
    ip_restriction_default_action          = "Deny"
    scm_ip_restriction_default_action      = "Deny"
    application_insights_connection_string = azurerm_application_insights.zscc.connection_string
    application_stack {
      python_version = "3.11"
    }
  }

  app_settings = local.app_settings

  depends_on = [azurerm_role_assignment.funcapp_storage]
}

# A new Function App does not load its package or start its timers until its triggers
# are synced. Done here so a deployment cannot finish green with the lifecycle function
# never running, and again whenever the package changes. Runs after the storage account
# closes, so a sync that succeeds has done so behind the firewall.
resource "azapi_resource_action" "sync_triggers" {
  type        = "Microsoft.Web/sites@2024-04-01"
  resource_id = azurerm_linux_function_app.sync.id
  action      = "syncfunctiontriggers"
  method      = "POST"

  depends_on = [azurerm_storage_account_network_rules.lockdown]

  lifecycle {
    replace_triggered_by = [azurerm_storage_blob.func_package]
  }
}

# Closes the storage account to everything but the Function App subnet and the deployer.
#
# The app's runtime traffic leaves through its VNet integration, so the subnet rule is
# what lets it in. Its public outbound addresses would be no use here: storage ignores IP
# rules for requests from its own region. For the same reason the deployer IP rule only
# works for a deployer outside this region; one inside the network uses the blob private
# endpoint instead.
resource "azurerm_storage_account_network_rules" "lockdown" {
  storage_account_id         = azurerm_storage_account.func.id
  default_action             = "Deny"
  bypass                     = ["AzureServices"]
  virtual_network_subnet_ids = [var.subnet_id]
  ip_rules                   = var.storage_deployer_ip_rules

  depends_on = [azurerm_storage_blob.func_package]
}

# The deployment host reaches the package blob through this once the firewall closes,
# so later plans can refresh it from inside the network. Queue and table traffic from
# the app keeps using the subnet's service endpoint.
resource "azurerm_private_endpoint" "storage_blob" {
  count               = var.enable_storage_private_endpoint ? 1 : 0
  name                = "pe-${azurerm_storage_account.func.name}"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = var.private_endpoint_subnet_id
  tags                = var.tags

  private_service_connection {
    name                           = "pe-${azurerm_storage_account.func.name}"
    private_connection_resource_id = azurerm_storage_account.func.id
    is_manual_connection           = false
    subresource_names              = ["blob"]
  }

  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = [var.blob_private_dns_zone_id]
  }

  lifecycle {
    precondition {
      condition     = var.blob_private_dns_zone_id != null
      error_message = "enable_storage_private_endpoint is true but no privatelink.blob.core.windows.net zone id was given."
    }
  }
}

# Optional. The app is timer-triggered and nothing legitimate ever calls it, so the
# endpoint plus public access off removes the front door entirely.
resource "azurerm_private_endpoint" "funcapp" {
  count               = var.enable_private_endpoint ? 1 : 0
  name                = "pe-${var.name}"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = var.private_endpoint_subnet_id
  tags                = var.tags

  private_service_connection {
    name                           = "pe-${var.name}"
    private_connection_resource_id = azurerm_linux_function_app.sync.id
    is_manual_connection           = false
    subresource_names              = ["sites"]
  }

  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = [var.private_dns_zone_id]
  }
}
