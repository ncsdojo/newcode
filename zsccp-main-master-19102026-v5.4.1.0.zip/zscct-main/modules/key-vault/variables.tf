variable "name" {
  description = "Key Vault name. Also seeds the private endpoint name, pe-<name>."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Group the vault and its private endpoint are created in."
  type        = string
}

variable "tags" {
  description = "Tags applied to every taggable resource here."
  type        = map(string)
  default     = {}
}

variable "tenant_id" {
  description = "Entra tenant id, from data.azurerm_client_config."
  type        = string
}

variable "deployer_object_id" {
  description = "Object id of the principal running Terraform. Granted Key Vault Secrets Officer so the apply can write the secrets."
  type        = string
}

variable "cc_principal_id" {
  description = "Connector identity object id, granted Key Vault Secrets User."
  type        = string
}

variable "funcapp_principal_id" {
  description = "Function identity object id, granted Key Vault Secrets User."
  type        = string
}

variable "enable_purge_protection" {
  description = "Key Vault purge protection. Irreversible once applied."
  type        = bool
  default     = true
}

variable "locked" {
  description = "false for the first apply (Terraform writes secrets over the public endpoint), then true + re-apply for the end state: publicNetworkAccess=Disabled, PE-only."
  type        = bool
  default     = false
}

variable "zscaler_api_key" {
  description = "Zscaler portal API key. Supply through TF_VAR_zscaler_api_key, never in tfvars."
  type        = string
  sensitive   = true
}

variable "zscaler_username" {
  description = "Zscaler portal admin username. Supply through TF_VAR_zscaler_username."
  type        = string
  sensitive   = true
}

variable "zscaler_password" {
  description = "Zscaler portal admin password. Supply through TF_VAR_zscaler_password."
  type        = string
  sensitive   = true
}

variable "private_endpoint_subnet_id" {
  description = "Subnet the vault private endpoint terminates in - the management subnet."
  type        = string
}

variable "private_dns_zone_id" {
  description = "privatelink.vaultcore.azure.net zone id for the endpoint's DNS zone group. Created by the private-dns module, or looked up when the hub already owns it."
  type        = string
}

variable "rbac_propagation_delay" {
  description = "How long to wait after granting the deployer Secrets Officer before writing secrets."
  type        = string
  default     = "120s"
}
