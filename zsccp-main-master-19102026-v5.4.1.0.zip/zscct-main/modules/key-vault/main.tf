# The vault holding the three Zscaler portal credentials, and its private endpoint.
#
# Who can read the vault is decided here rather than in the identity module, so the
# access list sits next to the thing it protects. That includes the grant to whoever is
# running Terraform, without which the apply could not write the secrets at all.
#
# This takes two applies. The first runs with locked = false so Terraform can reach the
# vault over its public endpoint and write the secrets. Set locked = true and apply
# again to close it: public access off, default-deny ACLs, private endpoint only.
#
# The privatelink DNS zone is not here. It is linked to a VNet, so it belongs with the
# network - this only needs the zone id to point the endpoint at.
resource "azurerm_key_vault" "zscc" {
  name                            = var.name
  location                        = var.location
  resource_group_name             = var.resource_group_name
  tenant_id                       = var.tenant_id
  sku_name                        = "standard"
  enabled_for_deployment          = true
  enabled_for_template_deployment = true
  soft_delete_retention_days      = 90
  rbac_authorization_enabled      = true
  # Purge protection is what gives soft delete any teeth. Without it, someone who can
  # delete the vault can purge it straight away and the retention window never applies.
  # It cannot be turned off once it is on, so decide before the first apply.
  purge_protection_enabled      = var.enable_purge_protection
  public_network_access_enabled = !var.locked
  tags                          = var.tags

  network_acls {
    default_action = var.locked ? "Deny" : "Allow"
    bypass         = "AzureServices"
  }
}

# Who can read the secrets
#
# Secrets User for the connectors and the function. Secrets Officer for whoever is
# running Terraform, so the apply can write them in the first place.
resource "azurerm_role_assignment" "cc_secrets_user" {
  scope                = azurerm_key_vault.zscc.id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = var.cc_principal_id
}

resource "azurerm_role_assignment" "funcapp_secrets_user" {
  scope                = azurerm_key_vault.zscc.id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = var.funcapp_principal_id
}

resource "azurerm_role_assignment" "deployer_secrets_officer" {
  scope                = azurerm_key_vault.zscc.id
  role_definition_name = "Key Vault Secrets Officer"
  principal_id         = var.deployer_object_id
}

# Azure RBAC takes a moment to propagate. Writing a secret immediately after granting
# the role gets rejected often enough that it is worth waiting it out.
resource "time_sleep" "kv_rbac" {
  create_duration = var.rbac_propagation_delay
  depends_on      = [azurerm_role_assignment.deployer_secrets_officer]
}

# After the role grant has settled. The private endpoint is listed so a destroy deletes
# the secrets before it: once the vault is locked, it is the only way in.
resource "azurerm_key_vault_secret" "api_key" {
  name         = "api-key"
  value        = var.zscaler_api_key
  key_vault_id = azurerm_key_vault.zscc.id
  depends_on   = [time_sleep.kv_rbac, azurerm_private_endpoint.vault]
}

resource "azurerm_key_vault_secret" "username" {
  name         = "username"
  value        = var.zscaler_username
  key_vault_id = azurerm_key_vault.zscc.id
  depends_on   = [time_sleep.kv_rbac, azurerm_private_endpoint.vault]
}

resource "azurerm_key_vault_secret" "password" {
  name         = "password"
  value        = var.zscaler_password
  key_vault_id = azurerm_key_vault.zscc.id
  depends_on   = [time_sleep.kv_rbac, azurerm_private_endpoint.vault]
}

# The private endpoint is what the connectors and the function reach the vault through
# once locked = true closes the public one.
resource "azurerm_private_endpoint" "vault" {
  name                = "pe-${var.name}"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = var.private_endpoint_subnet_id
  tags                = var.tags

  private_service_connection {
    name                           = "pe-${var.name}"
    private_connection_resource_id = azurerm_key_vault.zscc.id
    is_manual_connection           = false
    subresource_names              = ["vault"]
  }

  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = [var.private_dns_zone_id]
  }
}
