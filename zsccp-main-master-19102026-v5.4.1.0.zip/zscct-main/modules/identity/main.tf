# The two managed identities: one the connectors run as, one the lifecycle function
# runs as. Also the roles granted to them on the resource group.
#
# Roles granted on a specific resource are not here - they sit with that resource, so
# each thing's access list is next to the thing itself. Key Vault grants are in the
# key-vault module, storage grants in function-app, the scale set remediation role in
# compute. Putting them all here would mean this module depended on everything.
#
# Roles are assigned by name, so a built-in role and a custom role the platform team
# already defined are used the same way. This configuration never creates role
# definitions, which keeps roleDefinitions/write out of the deployer's permissions.

resource "azurerm_user_assigned_identity" "cc" {
  name                = local.cc_name
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_user_assigned_identity" "funcapp" {
  name                = local.funcapp_name
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_role_assignment" "connector" {
  for_each             = toset(var.connector_role_names)
  scope                = var.resource_group_id
  role_definition_name = each.value
  principal_id         = azurerm_user_assigned_identity.cc.principal_id
}

resource "azurerm_role_assignment" "function" {
  for_each             = toset(var.function_role_names)
  scope                = var.resource_group_id
  role_definition_name = each.value
  principal_id         = azurerm_user_assigned_identity.funcapp.principal_id
}

# Grants made under the earlier role modes keep their place in state instead of being
# deleted and recreated.
moved {
  from = azurerm_role_assignment.cc_network_contributor[0]
  to   = azurerm_role_assignment.connector["Network Contributor"]
}

moved {
  from = azurerm_role_assignment.cc_metrics_publisher[0]
  to   = azurerm_role_assignment.connector["Monitoring Metrics Publisher"]
}

moved {
  from = azurerm_role_assignment.funcapp_reader[0]
  to   = azurerm_role_assignment.function["Reader"]
}

moved {
  from = azurerm_role_assignment.funcapp_network_contributor[0]
  to   = azurerm_role_assignment.function["Network Contributor"]
}
