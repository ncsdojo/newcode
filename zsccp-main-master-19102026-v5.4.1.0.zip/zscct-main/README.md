# Zscaler Cloud Connector on Azure

Terraform for deploying Zscaler Cloud Connectors into Azure, as reusable modules with one
folder per environment.

## What it deploys

Cloud Connectors are Zscaler appliances that sit in your VNet and forward workload traffic
out to the Zscaler cloud. A deployment is:

- **Connectors** in scale sets, one set per availability zone. Each instance has a
  management NIC for administration and a service NIC that carries customer traffic.
  All zones share one management subnet and one service subnet - Azure subnets are
  regional, so a subnet is not tied to a zone.
- **An internal load balancer** in front of them. Workload subnets route their default
  traffic at its address, and it spreads that across whichever connectors are healthy.
- **A NAT gateway**, zone-redundant, giving the connectors a stable public IP to leave
  from. That address is what you allowlist in the Zscaler portal.
- **A Key Vault** holding the Zscaler portal credentials the connectors and the lifecycle
  function read.
- **A lifecycle function**, published by Zscaler, that runs on timers. Every 30 minutes
  it deletes connectors the portal still lists but the scale sets no longer hold, and
  every minute it checks connector health and replaces unhealthy instances. The apply
  syncs its triggers, which is what starts it. Each environment needs a Zscaler
  provisioning template of its own, so its function only ever sees its own connectors.
- **Private endpoints** for the vault and the function's storage account, so once the
  vault closes to public access and the storage firewall to all but the function, both
  are still reachable from inside the network.
- **Alerts**: fewer than half the connectors passing the load balancer's health probe, the
  lifecycle function has stopped running, it logged an error, or it judged a connector
  unhealthy.

## Layout

```
modules/         building blocks, each one creating a single kind of thing
environments/    one folder per region, then per environment
templates/       starting points for a new environment
```

| Module | What it creates |
| --- | --- |
| `network/vnet` | The virtual network |
| `network/subnets` | The subnets, and the checks on the subnet plan |
| `network/nsg` | The management and service NSGs, and their subnet associations |
| `network/nat-gateway` | The zone-redundant NAT gateway and its public IP |
| `network/load-balancer` | The internal load balancer the connectors sit behind |
| `network/route-table` | The route sending workload traffic to the connectors |
| `network/spoke-routes` | The Zscaler VDI routes, added to an existing route table on AVD session-host subnets |
| `network/private-dns` | The privatelink zones (vault, blob, sites) and their VNet links |
| `network/bastion` | Azure Bastion, for SSH without public IPs |
| `identity` | The two managed identities and their resource group roles |
| `key-vault` | The vault, the Zscaler credentials, and who can read them |
| `function-app` | The lifecycle function, its storage and endpoint, its telemetry, and the trigger sync |
| `compute` | The connector scale sets and autoscale |
| `monitoring` | The action group, the load balancer health alert and three log alerts |
| `locks` | CanNotDelete locks |

Environments are grouped by region first, then by environment name. A second region is a
new folder next to `westus2/`, not a new set of modules.

Every environment folder has the same files: `main.tf` wires modules together,
`variables.tf` declares inputs, `terraform.tfvars` sets them, `data.tf` looks up anything
that already exists, `locals.tf` holds shared values, and `providers.tf`, `backend.tf`,
`versions.tf` and `outputs.tf` do what their names suggest.

## dev and prod are built differently on purpose

`dev` creates its own VNet, subnets and DNS zones.

`prod` attaches to ones the platform team already created. Those are data lookups in
`prod/data.tf`, and the three modules that would have built them are simply not called.
Both look up a pre-created resource group.

This is one decision, not several flags. The VNet, subnets and DNS zones come as a set -
either you own them or you do not - so `locals.tf` in each environment resolves them once
at the top, and everything below that point is written the same way in both files.

Two things follow from attaching rather than creating:

- The VNet is left out of the locks. A network you did not create is not yours to lock.
- The NSGs and the NAT gateway attach to the platform's subnets, and only to subnets
  that have none: Terraform stops rather than take over one already attached. Where the
  platform attaches its own, set `attach_nsgs` or `attach_nat_gateway` to false.

## Integrating with an existing platform

prod and slz create nothing the platform team owns. They read it, and the one thing
they write to - routes on the AVD route tables named in `spoke_route_tables` - is
opt-in:

| Existing | How it is used |
| --- | --- |
| Resource group | Looked up; everything is deployed into it |
| VNet and its subnets | Looked up in the deployment subscription, which has to be the VNet's: Azure attaches NICs, private endpoints, NSGs, NAT gateways and route tables only to a VNet in their own subscription |
| `privatelink.vaultcore.azure.net`, `privatelink.blob.core.windows.net` (and `privatelink.azurewebsites.net` with a Function App endpoint) | Looked up through the `dns` provider alias, which can point at a subscription of its own; the private endpoints write their A records into them |
| NSGs and NAT gateway on the connector subnets | Ours attach where the subnets have none. Where the platform attaches its own, `attach_nsgs` and `attach_nat_gateway` turn ours off: their NSGs must then allow what `modules/network/nsg` allows, including outbound TCP 12002 to Zscaler's remote-support server, and their egress address is the one to allowlist in the Zscaler portal |
| Custom roles | Named in `connector_role_names`, `function_role_names` or `remediation_role_name`, exactly like built-in roles, and assignable at the deployment resource group. This configuration never creates role definitions |
| Bastion subnet | Looked up for its range, which becomes the SSH source |
| Workload routing | The platform team's route tables point at the `lb_frontend_ip` output. Only a subnet named in `workload_subnet_name`, such as a temporary validation subnet, gets a route table from this deployment |
| AVD route tables | Left alone unless named in `spoke_route_tables`, which adds the Zscaler VDI routes to them; see [Routing AVD session hosts](#routing-avd-session-hosts-zscaler-client-connector-for-vdi) |

Handing an applied environment's NSGs or NAT gateway over to the platform starts with
`terraform state rm`. Destroying an association empties the subnet of whatever is
attached at the time - the platform's own, if it has already swapped it in - and a policy
that requires an NSG on every subnet refuses an empty one. So remove the associations
from state (`module.nsg[0].azurerm_subnet_network_security_group_association.mgmt` and
`.svc`, or `module.nat_gateway[0].azurerm_subnet_nat_gateway_association.mgmt`,
`.service` and `.funcapp`), let the platform attach its own, then set the flag to false
and apply, which deletes ours. A new NAT gateway means a new egress address to allowlist
in the Zscaler portal.

Grants the platform team makes, because they sit on resources this deployment does not
own, are listed in step 6 below.

Bastion is a straightforward yes or no. `enable_bastion` puts `count` on the module call,
so turning it off means it is not evaluated at all.

## Routing AVD session hosts (Zscaler Client Connector for VDI)

Session hosts running Zscaler Client Connector for VDI tunnel their traffic to the
connectors through the load balancer. In point-to-point mode, the client's default, the
tunnel's outer destination is Zscaler's anycast global VIP, `185.46.212.80`, and Zscaler
requires the session hosts' route for the global VIP to point at the load balancer.
Without it, traffic for that address follows the subnet's default route out to Zscaler's
public cloud instead of reaching the connectors. The client's `SERVERIP` install option
can name the load balancer, a connector's service address, an FQDN or the global VIP;
Zscaler documents it as optional where the global VIP or the default route is routed to
the connectors.

Each AVD session-host subnet's route table needs:

| Route | Prefix | Next hop | When |
| --- | --- | --- | --- |
| `zscaler-vdi-gvip` | `185.46.212.80/32` | Virtual appliance, `lb_frontend_ip` | Always |
| `default-to-zscc` | `0.0.0.0/0` | Virtual appliance, `lb_frontend_ip` | Only where all of the hosts' traffic should go through the connectors, or the client runs in A2A tunnel mode, which needs it |

Two ways to add them:

- **From this deployment.** Name the tables in `spoke_route_tables` and the
  `network/spoke-routes` module adds the routes to them through the `spoke` provider
  alias. Set `spoke_subscription_id` where the tables live in another subscription.
  Whoever runs Terraform needs Network Contributor on each table, or a custom role with
  `Microsoft.Network/routeTables/routes/*`; the platform team grants it.
- **By the platform team**, by hand or by calling `modules/network/spoke-routes` from
  their own code with the `lb_frontend_ip` output.

Two things break the client even with the routes in place:

- **A firewall that sees one direction only.** The connectors answer the session hosts
  straight back over peering. If the spoke's route table sends the hub's range, and with
  it the load balancer frontend, through a firewall, that firewall sees the requests but
  never the replies: TCP connects and then TLS fails. Route only the prefixes that need
  inspecting through the firewall, or send the service subnet's return traffic through
  the same firewall.
- **Per-flow load balancing.** Zscaler recommends client IP (2-tuple) persistence on a
  load balancer in front of the connectors. In point-to-point mode the tunnel copies each
  inner flow's source port into its own header, so the default 5-tuple hash can spread
  one session host's tunnel across connectors as soon as there is more than one.
  `modules/network/load-balancer` sets SourceIP (`load_distribution = "SourceIP"`).

Endpoints the forwarding policy sends DIRECT rather than to ZIA leave the connectors on
their own ports. The service NSG allows the three non-443 ones Azure Virtual Desktop
needs - TCP 80 for certificate checks, TCP 1688 for Windows activation and UDP 3478 for
relayed RDP. Where the platform team attaches its own NSG to the service subnet, it needs
the same.

## Order of operations

The VNet comes first, then the subnets, and then everything that attaches to a subnet -
NSGs, the NAT gateway, Bastion, and the load balancer. The route table comes after the
load balancer because it points at its address.

Separately, the identities come before the Key Vault, which comes before the function app
and the connectors, because both read credentials from the vault.

Locks are created last so that on a destroy they are removed first. The function's
trigger sync runs after its storage account has closed.

## Running it

```bash
cd environments/westus2/prod
```

1. Put Zscaler's `zscaler_cc_function_app.zip` into
   `modules/function-app/function_package/`, or point `function_package_path` at a copy
   somewhere else. There is a README in that folder explaining why it is not committed.
2. Fill in the placeholders in `terraform.tfvars` and `backend.tf`. State goes to the
   platform team's storage account, never the local backend: it holds the Zscaler
   credentials in plain text. An environment first applied on the local backend moves
   across with `terraform init -migrate-state`; the comment in its `backend.tf` has the
   steps, including deleting the local state files afterwards.
3. Export the Zscaler credentials. They must never go in a tfvars file:

```bash
export TF_VAR_zscaler_api_key="<portal api key>"
export TF_VAR_zscaler_username="<portal admin>"
export TF_VAR_zscaler_password="<portal password>"
```

4. Apply once with `kv_locked = false`. Terraform needs to reach the Key Vault over its
   public endpoint to write the secrets.

```bash
terraform init && terraform apply
```

5. The apply has synced the Function App's triggers, which loads its package and starts
   it. Check Application Insights for a first execution; if there is none, open the
   Function App in the Azure portal, which syncs it again.
6. Grant the function identity - the `funcapp_principal_id` output -
   `Microsoft.Network/virtualNetworks/subnets/join/action` on the management and service
   subnets (Network Contributor, or a custom role with that action). Starting a
   replacement connector writes the scale set, which joins those subnets; without the
   grant the unhealthy connector is still removed but the scale set refills only to its
   autoscale minimum. Whoever can assign roles where the subnets live makes the grant:
   the platform team for prod and slz.

   The same write also references the load balancer's backend pool and the connector
   identity, and with only Reader on the resource group the function has no join right
   on the first or assign right on the second. Test a replacement in slz: stop one
   connector VM and watch for `LinkedAuthorizationFailed` in the function's traces. If
   it names the load balancer, grant Virtual Machine Contributor on the load balancer;
   if it names the identity, grant Managed Identity Operator on the connector identity.
7. Set `kv_locked = true` and apply again. The vault closes to the private endpoint only.
   From here on, run Terraform from a machine inside the network that resolves the hub's
   privatelink zones: every plan reads the vault's secrets and the package blob, and both
   now answer only on their private endpoints.
8. Commit the `.terraform.lock.hcl` that `init` wrote, so every apply resolves the same
   provider builds.

The identity running Terraform needs, on the resource group: Contributor, Role Based
Access Control Administrator, and `Microsoft.Authorization/locks/*` for the locks -
neither of the first two carries it, so that means a custom role or User Access
Administrator. Set `enable_resource_locks = false` where that cannot be granted.

Where purge protection is off, as in dev and slz, the destroy also purges the vault so a
rebuild can reuse its name. Azure treats a deleted vault as belonging to the
subscription, so that takes `Microsoft.KeyVault/locations/deletedVaults/purge/action`
and `Microsoft.KeyVault/locations/operationResults/read` at the subscription. Without
them the destroy fails at the vault after deleting it; running it again finishes the
job, and the name stays reserved for 90 days.

## Removing a deployment

```bash
terraform destroy
```

One destroy removes everything this configuration created. The locks go first, the
provider waits for each removal to replicate, and then the rest is deleted: connectors,
function, storage, vault, private endpoints and their DNS records, alerts, role
assignments, and the NSG, NAT gateway and route table associations on the platform's
subnets, which are left as they were handed over. If a delete still reports
`ScopeLocked`, run the destroy again.

To remove only the locks, set `enable_resource_locks = false` and apply. Do the same
before a change that replaces a locked resource or deletes something inside one, such
as a load balancer rule or a role assignment on the vault; the lock refuses both.

Run it from inside the network, for the same reason as later plans, with the same
permissions as the apply.

What a destroy cannot take back:

- **The Key Vault, where purge protection is on** (prod). It stays soft-deleted for 90
  days, and until Azure purges it only recovering it frees the name - which the next
  apply does if its identity can read deleted vaults at the subscription. Purge
  protection cannot be turned off once on; dev and slz leave it off so they can be
  rebuilt.
- **The `Application Insights Smart Detection` action group.** Azure creates it in the
  resource group with the Failure Anomalies rule and shares it with every Application
  Insights there, so it is not this configuration's to delete. The rule itself is
  removed with the rest. Delete the group by hand if nothing else in the resource group
  uses Application Insights.
- **Grants made outside Terraform**, such as the subnet join in step 6. The platform team
  removes them.
- **Connector entries in the Zscaler portal.** The function that would clean them up is
  deleted with everything else, so remove the Cloud Connector group's entries in the
  portal.
- **Marketplace terms**, if this configuration accepted them (`accept_marketplace_terms =
  true`). Destroy cancels them for the whole subscription, so leave that false wherever
  another deployment shares the subscription.

## Provider versions

azurerm is held to `>= 4.77, < 5.0`, azapi to 2.x and time to 0.x. 4.77 is the first
release with `storage_container_id` on `azurerm_storage_blob`, which replaces the account
and container name arguments deprecated there. 5.0 removes or renames arguments these
modules use, so moving to it is its own change:

- `network_interface.enable_accelerated_networking` and `enable_ip_forwarding` on the
  scale set become `accelerated_networking_enabled` and `ip_forwarding_enabled`.
- `service_endpoints` on `azurerm_subnet` becomes `service_endpoint` blocks.
- `private_dns_zone_name` and `resource_group_name` on
  `azurerm_private_dns_zone_virtual_network_link` become `private_dns_zone_id`.

## Why there are five subnets, not nine

Zscaler's reference modules create a management and a service subnet per zone, plus a NAT
gateway per zone. The split exists for one reason: a subnet can only be associated with a
single NAT gateway, so per-zone subnets were the only way to get per-zone egress that
survives losing a zone.

Two things make that unnecessary here:

- **Azure subnets are regional.** One subnet already serves instances in every zone.
- **A StandardV2 NAT gateway is zone-redundant on its own.** One gateway spans the
  region and survives a zone failure, so the subnets do not have to be split to achieve it.

So the layout is one management subnet, one service subnet, one load balancer subnet, one
Function App subnet, and `AzureBastionSubnet`: one NSG pair, and one egress address to
allowlist.

Zscaler's own `base_cc_vmss` example goes further and passes the *same* subnet to both
the management and service NICs. Keeping them separate here is a deliberate choice, so
the SSH rules and the data-path rules stay on different NSGs.

The two connector subnets are held to `/26` by the plan validator, since each has to hold
one NIC per instance across every zone.
