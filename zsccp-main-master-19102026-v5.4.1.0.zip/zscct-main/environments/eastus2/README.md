# East US 2

No environment has been built here yet.

To add one:

1. Create a folder for the environment here, for example `prod` or `dev`.
2. Copy every file from one template into it:
   - `templates/brownfield` if the resource group, VNet and subnets already exist
   - `templates/greenfield` if the deployment should build them
3. In `terraform.tfvars`, set `location = "eastus2"` and `region_code = "ue2"`, then fill in the remaining placeholders.

Full steps are in `templates/README.md`.
