# West Central US

No environment has been built here yet.

To add one:

1. Create a folder for the environment here, for example `prod` or `dev`.
2. Copy every file from one template into it:
   - `templates/brownfield` if the resource group, VNet and subnets already exist
   - `templates/greenfield` if the deployment should build them
3. In `terraform.tfvars`, set `location = "westcentralus"` and `region_code = "uwc"`, then fill in the remaining placeholders.
   This region has no availability zones, so also set `zones_enabled = false` and `zones = ["1"]`.
   It also does not offer Application Insights, so set `app_insights_location = "westus2"`.

Full steps are in `templates/README.md`.
