# ==============================================================================
# westus2 / slz    OT Secure Landing Zone
#
# A pre-production rehearsal of the production build. Same region, same tenant,
# same shape as prod: it attaches to a resource group, VNet and subnets that
# already exist and creates none of them.
#
# Three things differ from prod and are easy to get wrong:
#   1. Its own subscription, separate from Identity. The Zscaler marketplace
#      offer has to be accepted on THIS subscription, not inherited from prod.
#   2. Its own Terraform state storage account. See backend.tf. Do not point it
#      at the production state account.
#   3. No workload subnet. The SLZ validation workload lives on the workload
#      spoke VNet, not the hub, so it is not read here. Attach its route table
#      by hand, pointing at the lb_frontend_ip this deployment outputs. AVD
#      session hosts on that spoke can get the VDI route from spoke_route_tables.
#
# Secrets are NOT here. Export them before applying:
#   $env:TF_VAR_zscaler_api_key  = "<portal api key>"
#   $env:TF_VAR_zscaler_username = "<portal admin>"
#   $env:TF_VAR_zscaler_password = "<portal password>"
# ==============================================================================

# A. Azure basics
subscription_id = "<SLZ-SUBSCRIPTION-GUID>"
location        = "westus2"
environment     = "slz"

# LLD naming tokens. Names are built as
#   <app_code><env_code>arm  +  <type>  +  <region_code><instance>
# e.g. cc + slz + arm + nsg-mgmt- + uw2 + 001  ->  ccslzarmnsg-mgmt-uw2001
app_code    = "cc"
env_code    = "slz"
region_code = "uw2"
instance    = "001"

# B. Uniqueness - must differ from every other environment (storage account and
#    key vault names are globally unique).
# PowerShell:  -join ((48..57)+(97..102) | Get-Random -Count 8 | % {[char]$_})
# or bash:     openssl rand -hex 4     (run twice, one per line)
short_id  = "<8-hex>"
kv_suffix = "<8-hex>"

# C. The pre-created foundation
resource_group_name      = "<PRE-CREATED-RG-NAME>"
vnet_name                = "<SLZ-HUB-VNET-NAME>"
vnet_resource_group_name = "<GROUP-HOLDING-THE-SLZ-HUB-VNET>"

# privatelink.vaultcore.azure.net and privatelink.blob.core.windows.net (and
# privatelink.azurewebsites.net if the Function App gets a private endpoint) must
# already exist here AND already be linked to the VNet above. This environment creates
# neither the zones nor the links.
private_dns_resource_group_name = "<GROUP-HOLDING-THE-PRIVATELINK-ZONES>"

# The VNet has to be in the subscription above: Azure attaches NICs, private endpoints,
# NSGs, NAT gateways and route tables only to a VNet in their own subscription.
#
# The privatelink zones can be elsewhere, such as a central DNS subscription. Set this
# when they are, or remove the line. Wherever they live, the identity running the apply
# needs Reader plus Private DNS Zone Contributor on them.
private_dns_subscription_id = "<PRIVATE-DNS-SUBSCRIPTION-GUID>"

# Regions without availability zones (UK West and West Central US among ours): set
# zones_enabled = false and zones = ["1"]. That builds one regional scale set, a load
# balancer frontend with no zone, and LRS storage for the function. Two connectors are
# enough there, so set desired_instances and min_instances to 2 in section H.
zones_enabled = true

# The four connector subnets, already created in the SLZ hub. Names are on the
# Subnet Build tab of the tracking spreadsheet. Management and service want /26 or
# larger, and the management subnet needs endpoint network policies disabled because
# the private endpoints terminate there.
zones               = ["1", "2"]
mgmt_subnet_name    = "<mgmt-subnet>"
service_subnet_name = "<service-subnet>"
lb_subnet_name      = "<lb-frontend-subnet>"
funcapp_subnet_name = "<funcapp-subnet>" # delegated to Microsoft.Web/serverFarms,
# with the Microsoft.Storage service endpoint

# No workload subnet in the SLZ hub; see the note at the top of this file.
workload_subnet_name = ""

# AVD session-host route tables that should get the Zscaler VDI route (185.46.212.80/32
# to the load balancer). Opt-in, because the tables are the platform team's; leave it
# empty and the README lists the routes to add by hand. Whoever runs Terraform needs
# Network Contributor on each table. Set spoke_subscription_id only where the tables are
# not in subscription_id.
# spoke_subscription_id = "<AVD-SPOKE-SUBSCRIPTION-GUID>"
spoke_route_tables = {
  # avd = { name = "<avd-route-table>", resource_group_name = "<its-resource-group>" }
}

# Terraform will not take over an NSG or NAT gateway already attached to these subnets.
# Set false for whichever the platform team attaches itself.
attach_nsgs        = true
attach_nat_gateway = true

# A Bastion subnet exists in the SLZ hub. Set bastion_subnet_name to "" if it does
# not, otherwise the management NSG uses its range as the SSH source.
enable_bastion = false

# D. Zscaler side - from the Zscaler console (Cloud & Branch Connector >
#      provisioning template) and your Cyber team. SLZ's own template, not prod's
#      or dev's.
provisioning_url = "<connector provisioning URL>"
zscaler_cloud    = "<e.g. zscalertwo>"

# The connector image, pinned as in prod: SLZ refuses "latest". This is where a new
# version is proven before prod moves to it, so change it here first.
# To list what the marketplace offers:
#   az vm image list --location westus2 --publisher zscaler1579058425289 \
#     --offer zia_cloud_connector --sku zs_ser_gen1_cc_01 --all --query "[].version" -o tsv
# Changing it later only affects connectors created afterwards; cycle the fleet to move
# the rest.
image_version = "<x.y.z>"

# E. Connector access
# ssh-keygen -t rsa -b 4096 -f zscc_key -N ""   -> paste zscc_key.pub content
ssh_public_key = "<ssh-rsa AAAA...>"

# F. Behavior - as prod, so this rehearses the real build, except the connector roles:
#    slz proves the Reader pair before prod drops Network Contributor
# Roles by name - built-in, or custom roles the platform team already defined.
connector_role_names = ["Reader", "Monitoring Metrics Publisher"]
function_role_names  = ["Reader"]

disable_health_remediation = false
# The marketplace offer is per subscription and is NOT inherited from prod. Either an
# owner accepts it on the SLZ subscription out of band and this stays false, or set it
# true and run the apply with MarketplaceOrdering rights at the subscription.
accept_marketplace_terms = false
notification_email       = [] # e.g. ["ops@example.com"]
# Matches prod so the teardown path is rehearsed too: a destroy removes the locks first.
enable_resource_locks = true

# Off here, unlike prod. Purge protection cannot be turned off once on, and it holds a
# deleted vault name for 90 days. SLZ is expected to be rebuilt, and each rebuild would
# otherwise burn a new kv_suffix. Turn it on if SLZ stops being disposable.
enable_purge_protection = false

# G. Two-phase apply
kv_locked                 = false                # flip to true for the SECOND apply
storage_deployer_ip_rules = ["<your-public-ip>"] # curl ifconfig.me

# H. Capacity - matches prod. There are no users on SLZ, so this can be trimmed to
#    1/1/2 for cost while still exercising multi-zone behaviour.
desired_instances = 2
min_instances     = 2
max_instances     = 4

# I. Optional overrides (defaults shown; uncomment to change)
# app_insights_location = null  # e.g. "westus2" where Application Insights is not offered, such as West Central US
# vm_size                          = "Standard_D2s_v3"
# http_probe_port                  = 50000
# enable_support_tunnel            = true
# support_server_ip                = "199.168.148.101"  # remotesupport.<cloud>.net on Zscaler's commercial clouds
# encrypt_at_host                  = false
# app_service_plan_sku             = "P0v3"   # must stay Dedicated: storage keys are disabled
# enable_function_private_endpoint = false
# scheduled_scaling                = false
# workload_cidrs                   = []
# ssh_source_cidr                  = "VirtualNetwork"  # used only when bastion_subnet_name = ""
# additional_tags                  = { "cost-centre" = "", "owner" = "" }
