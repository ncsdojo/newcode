provider "azurerm" {
  subscription_id = var.subscription_id
  # Providers are pre-registered by the platform owner. A deployer with rights only at
  # the resource group must never try to register them at the subscription.
  resource_provider_registrations = "none"
  # Storage data plane over Entra ID - shared keys are disabled on the account.
  storage_use_azuread = true
  features {
    # Deleted outright on destroy, rather than soft-deleted for 14 days with its name
    # still reserved.
    log_analytics_workspace {
      permanently_delete_on_destroy = true
    }
    # A purge-protected vault cannot be purged, so the provider is not asked to. Asking
    # makes it read the deleted vault back, which needs rights at the subscription and
    # fails the destroy after the vault has already gone. Without purge protection the
    # vault is purged, so a rebuild can reuse its name; see the README for the rights.
    key_vault {
      purge_soft_delete_on_destroy = !var.enable_purge_protection
    }
    # Azure gives every new Application Insights a Failure Anomalies alert rule that
    # emails everyone with a monitoring role on the subscription, and leaves it behind
    # when the component is deleted. This disables it on create and deletes it on
    # destroy. The monitoring module's rules are the ones that watch the function.
    application_insights {
      disable_generated_rule = true
    }
    # azurerm_storage_account reads its queue and static website settings over the data
    # plane, and the queue endpoint has no private endpoint here, so once the function's
    # storage firewall closes, a plan from inside the network is refused there. Nothing
    # here sets either, so the provider leaves them alone.
    storage {
      data_plane_available = false
    }
  }
}

# Used for the one ARM action azurerm has no resource for: syncing the Function App's
# triggers after it is created.
provider "azapi" {
  subscription_id            = var.subscription_id
  skip_provider_registration = true
}
