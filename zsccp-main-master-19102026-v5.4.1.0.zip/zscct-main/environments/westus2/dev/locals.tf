# Values used across this environment.
#
# The first block is the only part that differs between dev and prod. dev builds its own
# VNet, subnets and DNS zones, so those read from modules; the resource group is
# pre-created, so it reads from a data source. prod reads all four from data sources.
# Everything after it is the same in both files.
locals {
  # dev builds most of its own foundation
  #
  # Everything the foundation provides is named here, whether it is used once or ten
  # times. Nothing below this block references a foundation module directly, so swapping
  # any of it for a pre-created resource means editing these lines and nothing else.
  resource_group_name = data.azurerm_resource_group.zscc.name
  resource_group_id   = data.azurerm_resource_group.zscc.id

  vnet_id            = module.vnet.id
  mgmt_subnet_id     = module.subnets.mgmt_id
  service_subnet_id  = module.subnets.service_id
  funcapp_subnet_id  = module.subnets.funcapp_id
  workload_subnet_id = module.subnets.workload_id
  lb_subnet_id       = module.subnets.lb_id
  bastion_subnet_id  = module.subnets.bastion_id
  # SSH comes from the Bastion range only when there is a Bastion; otherwise the NSG
  # falls back to ssh_source_cidr.
  bastion_subnet_cidr = var.enable_bastion ? var.bastion_subnet_cidr : ""

  # dev owns its VNet, so it creates the privatelink zones and links them itself.
  vault_dns_zone_id = module.private_dns.vault_zone_id
  sites_dns_zone_id = module.private_dns.sites_zone_id
  blob_dns_zone_id  = module.private_dns.blob_zone_id

  # The same in every environment

  # The two halves every name is built from. The module supplies the type token that
  # sits between them.
  name_prefix = "${var.app_code}${var.env_code}arm"
  name_suffix = "${var.region_code}${var.instance}"

  key_vault_name    = "${local.name_prefix}kv${local.name_suffix}${substr(var.kv_suffix, 0, 4)}"
  function_app_name = "${local.name_prefix}func${local.name_suffix}"

  tags = merge({
    "zscaler-deployment-id" = var.short_id
    "environment"           = var.environment
    "managed-by"            = "terraform-zscc"
  }, var.additional_tags)

  # Needed by compute (which creates the scale sets) and by function-app (which only
  # needs the names). Deterministic, so the Function App is not ordered behind
  # scale sets it does not depend on.
  vmss_names = { for z in var.zones : z => "${local.name_prefix}vms-z${z}-${local.name_suffix}" }
}
