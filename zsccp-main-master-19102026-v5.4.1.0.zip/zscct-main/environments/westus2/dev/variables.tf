# Inputs for this environment.
#
# dev builds its own network, so the network inputs here are CIDRs. prod attaches to an
# existing one and takes subnet names instead.
#
# The Zscaler credentials are declared here but must never be written into a tfvars file.
# Pass them as TF_VAR_zscaler_api_key, TF_VAR_zscaler_username and TF_VAR_zscaler_password.

# Azure basics

variable "subscription_id" {
  description = "Target subscription id."
  type        = string
  sensitive   = true
}

variable "location" {
  description = "Azure region. Must match the region folder this environment lives in."
  type        = string
  default     = "westus2"
}

# LLD naming
#
# Names are built as <app_code><env_code>arm + <type> + <region_code><instance>. The type
# token in the middle belongs to the module that creates the resource; these four are the
# environment's half.

variable "app_code" {
  description = "Application code opening every name. cc for Cloud Connector."
  type        = string
  default     = "cc"
}

variable "env_code" {
  description = "Environment code inside the name prefix - dev or prd."
  type        = string
}

variable "region_code" {
  description = "Short region code opening the name suffix, e.g. uw2 for West US 2."
  type        = string
}

variable "instance" {
  description = "Instance number closing every name. Increments if a second deployment lands in the same region."
  type        = string
  default     = "001"
}

variable "environment" {
  description = "Lifecycle stage, written to every resource's environment tag."
  type        = string
  default     = "dev"
}

variable "short_id" {
  description = "8-character deployment id (e.g. a1b2c3d4). Tags every resource and keeps the function storage account and package blob names unique."
  type        = string
  validation {
    condition     = can(regex("^[a-z0-9]{8}$", var.short_id))
    error_message = "short_id must be 8 lowercase alphanumerics."
  }
}

variable "kv_suffix" {
  description = "8 random lowercase characters. The first four end the Key Vault name and keep it globally unique."
  type        = string
  validation {
    condition     = can(regex("^[a-z0-9]{8}$", var.kv_suffix))
    error_message = "kv_suffix must be 8 lowercase alphanumerics."
  }
}

variable "zones" {
  description = "Availability zones to deploy connectors into. One scale set per zone, all sharing the same management and service subnets."
  type        = list(string)
  default     = ["1", "2"]
  validation {
    condition     = length(var.zones) > 0 && alltrue([for z in var.zones : contains(["1", "2", "3"], z)])
    error_message = "zones must be a non-empty subset of [\"1\", \"2\", \"3\"]."
  }
}

variable "additional_tags" {
  description = "Extra tags merged over the standard set (cost centre, owner, ticket, ...)."
  type        = map(string)
  default     = {}
}

# Existing foundation
# The resource group is pre-created and looked up in data.tf. Everything else below is
# built by this environment.

variable "resource_group_name" {
  description = "Pre-created resource group everything is deployed into."
  type        = string
}

# Network plan

variable "vnet_address_space" {
  description = "Address space for the virtual network. Every subnet must sit inside it."
  type        = string
}

variable "mgmt_subnet_cidr" {
  description = "Management subnet, shared by every connector in every zone plus the private endpoints. /26 or larger."
  type        = string
}

variable "service_subnet_cidr" {
  description = "Service subnet, shared by every connector in every zone. /26 or larger."
  type        = string
}

variable "bastion_subnet_cidr" {
  description = "AzureBastionSubnet range. /26 or larger. Only used when enable_bastion is true."
  type        = string
  default     = ""
}

variable "workload_subnet_cidr" {
  description = "Workload subnet, the one carrying the default route to the connector load balancer."
  type        = string
}

variable "lb_subnet_cidr" {
  description = "Internal load balancer frontend subnet."
  type        = string
}

variable "funcapp_subnet_cidr" {
  description = "Lifecycle Function App delegated subnet. /28 minimum for Microsoft.Web/serverFarms; /26 recommended for scale-out."
  type        = string
}

variable "ssh_source_cidr" {
  description = "Management NSG SSH source, used only when enable_bastion is false."
  type        = string
  default     = "VirtualNetwork"
}

variable "workload_cidrs" {
  description = "Specific workload CIDRs allowed inbound on the service NSG. Empty means the whole virtual network."
  type        = list(string)
  default     = []
}

variable "enable_bastion" {
  description = "Deploy Azure Bastion and its subnet."
  type        = bool
  default     = true
}

variable "enable_support_tunnel" {
  description = "Allow the connectors' outbound TCP/12002 connection to Zscaler's remote-support server on the management NSG. On by default, as in Zscaler's own module."
  type        = bool
  default     = true
}

variable "support_server_ip" {
  description = "Zscaler's remote-support server: the address remotesupport.<zscaler_cloud>.net resolves to. The default is the commercial-cloud address Zscaler's own module uses; set this on any other cloud."
  type        = string
  default     = "199.168.148.101"
}

variable "http_probe_port" {
  description = "Connector health probe port. Used by the load balancer probe, both NSGs and cloud-init."
  type        = number
  default     = 50000
}

# Cloud Connector

variable "provisioning_url" {
  description = "Connector provisioning URL from the Zscaler console, with or without https://. Use a template no other environment shares, so the lifecycle function, which deletes portal entries whose VMs are gone, only ever sees this environment's connectors. No default: a placeholder default is written verbatim into cloud-init and produces connectors that never register."
  type        = string
}

variable "zscaler_cloud" {
  description = "Zscaler cloud name, e.g. zscalertwo. provisioning_url has to be on connector.<cloud>.net."
  type        = string
  validation {
    condition     = can(regex("^[a-z0-9]+$", var.zscaler_cloud))
    error_message = "zscaler_cloud must be a bare cloud name such as zscalertwo, with no punctuation or placeholder text."
  }
}

variable "image_version" {
  description = "Connector marketplace image version. An exact x.y.z, or 'latest' resolved per instance at creation time. Pin an exact version in prod."
  type        = string
  default     = "latest"
}

variable "vm_size" {
  description = "Connector VM size."
  type        = string
  default     = "Standard_D2s_v3"
}

variable "admin_username" {
  description = "Connector admin login. Password auth is disabled."
  type        = string
  default     = "zsroot"
}

variable "ssh_public_key" {
  description = "OpenSSH public key for CC admin login (must be generated)."
  type        = string
}

variable "encrypt_at_host" {
  description = "Encryption at host. Requires the feature to be registered on the subscription."
  type        = bool
  default     = false
}

variable "accelerated_networking" {
  description = "Accelerated networking on the connector service NIC."
  type        = bool
  default     = true
}

# Capacity

variable "desired_instances" {
  description = "Capacity each scale set is created with, and the autoscale default used while no metrics arrive. Changing it later does not resize a scale set directly; autoscale applies the new default only while metrics are missing."
  type        = number
  default     = 2
}

variable "min_instances" {
  description = "Autoscale floor per scale set."
  type        = number
  default     = 2
}

variable "max_instances" {
  description = "Autoscale ceiling per scale set. Capped at 16 by the Zscaler EC group limit."
  type        = number
  default     = 4
}

variable "scale_out_threshold" {
  description = "smedge_cpu_utilization above which a scale set adds an instance."
  type        = number
  default     = 70
}

variable "scale_in_threshold" {
  description = "smedge_cpu_utilization below which a scale set removes an instance."
  type        = number
  default     = 30
}

variable "scale_out_cooldown_minutes" {
  description = "Cooldown after a scale-out action."
  type        = number
  default     = 5
}

variable "scale_in_cooldown_minutes" {
  description = "Cooldown after a scale-in action."
  type        = number
  default     = 10
}

variable "scheduled_scaling" {
  description = "Add a recurring autoscale profile with its own floor, active from scheduled_start to scheduled_end on scheduled_days."
  type        = bool
  default     = false
}

variable "scheduled_min_instances" {
  description = "Instance floor during the scheduled window."
  type        = number
  default     = 1
}

variable "scheduled_days" {
  description = "Days the scheduled profile applies."
  type        = list(string)
  default     = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
}

variable "scheduled_start_hour" {
  description = "Hour the scheduled profile takes over (0-23)."
  type        = number
  default     = 9
}

variable "scheduled_start_minute" {
  description = "Minute the scheduled profile takes over (0-59)."
  type        = number
  default     = 0
}

variable "scheduled_end_hour" {
  description = "Hour the default profile resumes (0-23)."
  type        = number
  default     = 17
}

variable "scheduled_end_minute" {
  description = "Minute the default profile resumes (0-59)."
  type        = number
  default     = 0
}

variable "scheduled_timezone" {
  description = "Windows time zone id for the scheduled profile, e.g. 'Pacific Standard Time'."
  type        = string
  default     = "Pacific Standard Time"
}

# Lifecycle function

variable "sync_interval_minutes" {
  description = "How often the vendor package runs its sync (Zscaler documents every 30 minutes). Only sizes the heartbeat alert window; the package's own timer sets the schedule."
  type        = number
  default     = 30
}

variable "app_service_plan_sku" {
  description = "App Service plan tier: Basic, Standard or Premium v2-v4."
  type        = string
  default     = "P0v3"
}

variable "enable_storage_private_endpoint" {
  description = "Give the function storage account a blob private endpoint, so a deployment host inside the network can still refresh the package blob after the firewall closes. Needs privatelink.blob.core.windows.net."
  type        = bool
  default     = true
}

variable "enable_function_private_endpoint" {
  description = "Place the Function App behind a Private Endpoint and disable public inbound access. The app is timer-triggered and has no legitimate inbound caller."
  type        = bool
  default     = false
}

variable "function_package_path" {
  description = "Override the path to the vendor zip. Null uses the copy bundled with the function-app module."
  type        = string
  default     = null
}

# Zscaler credentials
# Supply through TF_VAR_zscaler_api_key / _username / _password. Never in tfvars.

variable "zscaler_api_key" {
  description = "Zscaler portal API key."
  type        = string
  sensitive   = true
}

variable "zscaler_username" {
  description = "Zscaler portal admin username."
  type        = string
  sensitive   = true
}

variable "zscaler_password" {
  description = "Zscaler portal admin password."
  type        = string
  sensitive   = true
}

# Two-phase lockdown

variable "kv_locked" {
  description = "false for first apply (Terraform writes secrets over public endpoint), then true + re-apply to reach the end state: publicNetworkAccess=Disabled, PE-only."
  type        = bool
  default     = false
}

variable "storage_deployer_ip_rules" {
  description = "Public IPs kept on the locked storage firewall so later applies can refresh the package blob. Single addresses go in bare, without a /32. Storage ignores IP rules for requests from its own region, so run Terraform from outside the deployment region."
  type        = list(string)
  default     = []
}

# Roles

variable "connector_role_names" {
  description = "Roles granted to the connector identity on the resource group, by name: built-in roles or custom roles the platform team already defined. Reader and Monitoring Metrics Publisher cover what the connectors need. Empty grants nothing, for roles assigned out of band."
  type        = list(string)
  default     = ["Reader", "Monitoring Metrics Publisher"]
}

variable "function_role_names" {
  description = "Roles granted to the lifecycle function identity on the resource group, by name. Reader covers what the function needs. Empty grants nothing."
  type        = list(string)
  default     = ["Reader"]
}

variable "remediation_role_name" {
  description = "Role granted to the function on each scale set so it can terminate unhealthy connectors: a built-in role or an existing custom role, by name."
  type        = string
  default     = "Virtual Machine Contributor"
}

variable "disable_health_remediation" {
  description = "true: unhealthy connectors are evaluated and logged but never terminated; no remediation role is created."
  type        = bool
  default     = false
}

variable "accept_marketplace_terms" {
  description = "false (default) assumes the platform owner accepted the Zscaler CC image terms on this subscription. true creates the agreement, which needs subscription-scope MarketplaceOrdering rights."
  type        = bool
  default     = false
}

variable "enable_purge_protection" {
  description = "Key Vault purge protection. Irreversible once applied."
  type        = bool
  default     = true
}

variable "enable_resource_locks" {
  description = "CanNotDelete locks on the VNet, Key Vault, load balancer, connector identity, NAT public IP and route table. The scale sets stay unlocked so autoscale can remove instances. Whoever runs Terraform needs Microsoft.Authorization/locks/*; a destroy removes the locks itself."
  type        = bool
  default     = true
}

# Monitoring

variable "notification_email" {
  description = "Alert action group email receivers. Empty creates the group with no receivers: alerts still fire in the portal, but nobody is notified."
  type        = list(string)
  default     = []
}
