# Provider versions are pinned once per environment. The modules in this repo are only
# ever used from an environment, so they inherit these rather than repeating them.
terraform {
  required_version = ">= 1.3.0, < 2.0.0"

  required_providers {
    azurerm = {
      source = "hashicorp/azurerm"
      # 4.77 adds storage_container_id to azurerm_storage_blob (StandardV2 NAT gateways
      # arrived in 4.67). 5.0 removes or renames arguments used here - the scale set NIC
      # flags, subnet service_endpoints and the DNS zone link's zone name - so it needs
      # its own upgrade.
      version = ">= 4.77, < 5.0"
    }
    time = {
      source  = "hashicorp/time"
      version = ">= 0.9.0, < 1.0"
    }
    azapi = {
      source  = "Azure/azapi"
      version = ">= 2.0, < 3.0"
    }
  }
}
