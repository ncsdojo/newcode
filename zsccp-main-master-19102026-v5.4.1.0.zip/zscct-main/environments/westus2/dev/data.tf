# Whoever is running Terraform. tenant_id configures the Key Vault, and object_id gets
# granted enough access to write the secrets and upload the function package.
#
# Read once here and passed down, rather than read inside each module - a module that
# reads the ambient credential itself is harder to reuse, and two modules reading it
# separately can end up disagreeing.
data "azurerm_client_config" "current" {}

# The resource group is pre-created, so it is looked up rather than built. dev still
# creates its own VNet, subnets and DNS zones - see main.tf. prod looks all four up;
# compare environments/westus2/prod/data.tf.

data "azurerm_resource_group" "zscc" {
  name = var.resource_group_name
}