# One state file per environment, in a storage account the platform team owns. Never the
# storage account this configuration creates - that one gets destroyed along with
# everything else, and it would take the state with it.
#
# Remote state is not optional here. The Zscaler API key, username and password pass
# through Terraform on their way into Key Vault, so the state file holds all three in
# plain text. On the local backend that file sits wherever Terraform last ran - a laptop,
# or a folder that syncs somewhere else. In the state container it sits behind Entra ID.
#
# Fill in the placeholders below, or leave them out and pass them at init time, which is
# what CI should do:
#
#   terraform init \
#     -backend-config="subscription_id=<state-storage-subscription-guid>" \
#     -backend-config="resource_group_name=<state-resource-group>" \
#     -backend-config="storage_account_name=<state-storage-account>" \
#     -backend-config="container_name=tfstate" \
#     -backend-config="key=zscc/westus2/prod.tfstate"
#
# An environment already applied on the local backend moves across with
#
#   terraform init -migrate-state
#
# run from this folder, answering yes to copying the existing state. Check that
# terraform plan shows nothing unexpected, then delete terraform.tfstate and
# terraform.tfstate.backup from this folder, and from anywhere they were synced or copied
# to: both still hold the secrets.
#
# use_azuread_auth keeps state access on Entra ID rather than storage keys, same as the
# rest of this deployment. Whoever runs Terraform needs Storage Blob Data Contributor on
# the state container.
#
# The backend authenticates on its own. It does not read provider "azurerm" and does not
# inherit its subscription, so where the state account lives outside the subscription
# this deployment targets, subscription_id below is not optional - without it Terraform
# looks for the account in the wrong place and init fails.
terraform {
  backend "azurerm" {
    subscription_id      = "<state-storage-subscription-guid>"
    resource_group_name  = "<state-resource-group>"
    storage_account_name = "<state-storage-account>"
    container_name       = "tfstate"
    key                  = "zscc/westus2/prod.tfstate"
    use_azuread_auth     = true
  }
}
