# greenfield

For a target where **only the resource group exists**. This environment creates its own
virtual network, subnets and private DNS zones, then everything else on top.

Modelled on `environments/westus2/dev`.

Calls, in addition to what `brownfield` calls:

- `modules/network/vnet` — the virtual network
- `modules/network/subnets` — all subnets, including a workload subnet for validation
- `modules/network/private-dns` — the privatelink zones (vault, blob, queue, table,
  and sites when the Function App has an endpoint) and their VNet links
- `modules/network/route-table` — the workload subnet's default route to the
  connectors (brownfield calls it only for a subnet named in `workload_subnet_name`)

The resource group is still expected to exist and is read by `data.tf`. Creating
a resource group usually needs subscription-level rights that a deployment
identity does not have.

See `../README.md` for how to copy and fill this in.
