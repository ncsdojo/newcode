output "resource_group" {
  description = "Group everything was deployed into. Pre-created; attached to by this environment."
  value       = local.resource_group_name
}

output "virtual_network" {
  description = "VNet the subnets live in. Pre-created; attached to by this environment."
  value       = data.azurerm_virtual_network.zscc.name
}

output "nat_gateway_public_ip" {
  description = "NAT egress address - allowlist this in the Zscaler portal. Null when attach_nat_gateway is false, and the platform's egress address is allowlisted instead."
  value       = one(module.nat_gateway[*].egress)
}

output "lb_frontend_ip" {
  description = "Internal load balancer frontend. This is the handover point: point workload and spoke route tables at this address to steer their traffic through the connectors. Only the subnet named in workload_subnet_name gets a route table from this deployment. AVD session hosts running Zscaler Client Connector for VDI also need 185.46.212.80/32 sent here: spoke_route_tables adds it, or see the README."
  value       = module.load_balancer.frontend_private_ip
}

output "spoke_routes" {
  description = "Zscaler VDI routes added through spoke_route_tables, by table label. Empty when none are named."
  value       = { for k, m in module.spoke_routes : k => m.routes }
}

output "bastion_name" {
  description = "Bastion host name, or null when Bastion is not deployed."
  value       = one(module.bastion[*].name)
}

output "bastion_private_only" {
  description = "True when the Bastion has no public IP and is reached only from inside the network (ExpressRoute, VPN or peering), with az network bastion ssh. Null when Bastion is not deployed."
  value       = one(module.bastion[*].private_only)
}

output "function_package_url" {
  description = "Where the lifecycle function runs its package from."
  value       = module.function_app.package_url
}

output "vmss_names" {
  description = "Connector scale sets, in zone order."
  value       = [for z in var.zones : local.vmss_names[z]]
}

output "cc_identity_client_id" {
  description = "Connector identity client id, as written into cloud-init."
  value       = module.identity.cc_client_id
}

output "key_vault_uri" {
  description = "Vault URI the connectors and the function read credentials from."
  value       = module.key_vault.vault_uri
}

output "function_app" {
  description = "Lifecycle Function App name."
  value       = module.function_app.name
}

output "funcapp_principal_id" {
  description = "Function identity principal id. Unless grant_function_subnet_join is true, it needs the subnet join grant in README step 5 to start replacement connectors."
  value       = module.identity.funcapp_principal_id
}
