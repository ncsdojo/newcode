variable "name_prefix" {
  description = "Leading name component, <app><environment>arm - e.g. ccprdarm."
  type        = string
}

variable "name_suffix" {
  description = "Trailing name component, <region><instance> - e.g. uw2001."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Group the identities are created in."
  type        = string
}

variable "resource_group_id" {
  description = "Scope of the resource-group-level role assignments. Sensitive: embeds the subscription id."
  type        = string
  sensitive   = true
}

variable "tags" {
  description = "Tags applied to both identities."
  type        = map(string)
  default     = {}
}

variable "connector_role_names" {
  description = "Roles granted to the connector identity on the resource group, by name: built-in roles or custom roles the platform team already defined. The connectors read their network configuration and publish the autoscale metric, which Reader and Monitoring Metrics Publisher cover. Empty grants nothing, for roles assigned out of band."
  type        = list(string)
  default     = ["Reader", "Monitoring Metrics Publisher"]
}

variable "function_role_names" {
  description = "Roles granted to the lifecycle function identity on the resource group, by name. The function reads the scale sets and their VMs, which Reader covers. Empty grants nothing."
  type        = list(string)
  default     = ["Reader"]
}
