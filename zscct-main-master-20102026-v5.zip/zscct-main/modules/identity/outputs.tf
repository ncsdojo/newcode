output "cc_identity_id" {
  description = "Connector identity resource id. Attached to the scale sets and locked by the locks module."
  value       = azurerm_user_assigned_identity.cc.id
}

output "cc_principal_id" {
  description = "Connector identity object id, the principal of every grant made to it."
  value       = azurerm_user_assigned_identity.cc.principal_id
}

output "cc_client_id" {
  description = "Connector identity client id, passed to the connectors through cloud-init."
  value       = azurerm_user_assigned_identity.cc.client_id
}

output "funcapp_identity_id" {
  description = "Function identity resource id, attached to the Function App and used for run-from-package."
  value       = azurerm_user_assigned_identity.funcapp.id
}

output "funcapp_principal_id" {
  description = "Function identity object id, the principal of every grant made to it."
  value       = azurerm_user_assigned_identity.funcapp.principal_id
}

output "funcapp_client_id" {
  description = "Function identity client id, used by the host storage connection and the app settings."
  value       = azurerm_user_assigned_identity.funcapp.client_id
}
