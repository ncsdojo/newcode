locals {
  cc_name      = "${var.name_prefix}mi${var.name_suffix}"
  funcapp_name = "${var.name_prefix}mifunc${var.name_suffix}"
}
