# azapi lives outside the hashicorp namespace, so the module has to say where it comes
# from: the trigger sync action main.tf forgets is an azapi resource. Versions are pinned
# by the environment.
terraform {
  required_providers {
    azapi = {
      source = "Azure/azapi"
    }
  }
}
