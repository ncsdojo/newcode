output "id" {
  description = "Function App id."
  value       = azurerm_linux_function_app.sync.id
}

output "name" {
  description = "Function App name."
  value       = azurerm_linux_function_app.sync.name
}

output "app_insights_id" {
  description = "Application Insights component id. Scope of the monitoring module's log alert rules."
  value       = azurerm_application_insights.zscc.id
}

output "log_analytics_workspace_id" {
  description = "Workspace backing Application Insights."
  value       = azurerm_log_analytics_workspace.zscc.id
}

output "storage_account_name" {
  description = "Function host storage account name."
  value       = azurerm_storage_account.func.name
}

output "package_url" {
  description = "Where the app runs its package from."
  value       = var.function_package_url
}
