# CanNotDelete locks on the things that would hurt to lose by accident. The scale sets
# are never locked, because autoscale has to be able to remove instances.
#
# A lock covers everything under it, so locking the VNet also protects its subnets.
#
# That is why the caller has to pass depends_on. On a destroy Terraform works backwards
# through dependencies, and a lock that only knows its target's id has no ordering
# against that target's children - it would try to delete a subnet while the VNet lock is
# still there, and Azure refuses. Naming the modules puts the locks in last, so they come
# out first, and the provider waits for each removal to replicate before moving on. One
# terraform destroy removes everything; set enabled = false and apply to remove the
# locks alone.
#
# The caller passes a map so an environment can leave out anything it does not own. Do
# not lock somebody else's VNet.
resource "azurerm_management_lock" "protect" {
  for_each = var.enabled ? var.scopes : {}

  name       = "zscc-protect"
  scope      = each.value
  lock_level = "CanNotDelete"
  notes      = "Zscaler CC - ${each.key}"
}
