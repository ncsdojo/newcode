variable "enabled" {
  description = "Create the locks. Creating and removing them needs Microsoft.Authorization/locks/* - Owner, User Access Administrator or a custom role; Contributor and Role Based Access Control Administrator do not carry it. false removes the locks and keeps everything else."
  type        = bool
  default     = true
}

variable "scopes" {
  description = "Resource ids to lock, keyed by a short label that ends up in the lock notes. Keys must be known at plan time; the ids need not be. Omit anything this deployment does not own - a BYO virtual network, for instance."
  type        = map(string)
}
