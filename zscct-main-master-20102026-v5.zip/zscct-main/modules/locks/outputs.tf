output "lock_ids" {
  description = "Management lock id per locked scope. Empty when disabled."
  value       = { for k, l in azurerm_management_lock.protect : k => l.id }
}
