output "id" {
  description = "Key Vault id. Also the scope of the Key Vault CanNotDelete lock."
  value       = azurerm_key_vault.zscc.id
}

output "vault_uri" {
  description = "Vault URI. Passed to the connectors through cloud-init and to the function as VAULT_URL."
  value       = azurerm_key_vault.zscc.vault_uri
}
