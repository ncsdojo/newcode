# azapi lives outside the hashicorp namespace, so a module that uses it has to say where
# it comes from. Versions are pinned by the environment.
terraform {
  required_providers {
    azapi = {
      source = "Azure/azapi"
    }
  }
}
