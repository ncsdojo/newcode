# The vault holding the three Zscaler portal credentials, and its private endpoint.
#
# Who can read the vault is decided here rather than in the identity module, so the
# access list sits next to the thing it protects.
#
# The vault is private from the first apply: public network access off, default-deny
# ACLs, reachable only through its private endpoint. Org-Delta's "Azure Key Vault should
# disable public network access" policy refuses a vault created any other way.
#
# Terraform writes the secrets from wherever it runs, including a laptop outside the
# network. It writes them through Azure Resource Manager - a PUT on
# Microsoft.KeyVault/vaults/secrets, the same path ARM templates and Bicep use - rather
# than through the vault's own endpoint, which is the only thing the vault firewall
# guards. That takes Microsoft.KeyVault/vaults/secrets/write on the vault, which
# Contributor on the resource group carries, and no Key Vault data role. Resource
# Manager never hands a secret's value back, so nothing here reads one.
#
# The connectors and the lifecycle function read the secrets through the private
# endpoint, as Key Vault Secrets User. Because the vault has been private since before
# the first connector booted, the first connector proves the same path every later one
# - a scale-out, or a replacement for an unhealthy one - will use.
#
# The privatelink DNS zone is not here. It is linked to a VNet, so it belongs with the
# network - this only needs the zone id to point the endpoint at.
resource "azurerm_key_vault" "zscc" {
  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group_name
  tenant_id           = var.tenant_id
  sku_name            = "standard"
  # The connectors and the function read the secrets at run time, as their own identities.
  # Template deployment would let anyone with Contributor on the group, which carries
  # Microsoft.KeyVault/vaults/deploy/action, pass a secret into a deployment of their own
  # and read it back from what it creates.
  enabled_for_deployment          = false
  enabled_for_template_deployment = false
  soft_delete_retention_days      = 90
  rbac_authorization_enabled      = true
  # Purge protection is what gives soft delete any teeth. Without it, someone who can
  # delete the vault can purge it straight away and the retention window never applies.
  # It cannot be turned off once it is on, so decide before the first apply.
  purge_protection_enabled      = var.enable_purge_protection
  public_network_access_enabled = false
  tags                          = var.tags

  network_acls {
    default_action = "Deny"
    bypass         = "AzureServices"
  }
}

# Who can read the secrets
#
# Secrets User for the connectors and the function. Nobody needs a write role on the
# data plane: Terraform writes through Resource Manager, below.
resource "azurerm_role_assignment" "cc_secrets_user" {
  scope                = azurerm_key_vault.zscc.id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = var.cc_principal_id
}

resource "azurerm_role_assignment" "funcapp_secrets_user" {
  scope                = azurerm_key_vault.zscc.id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = var.funcapp_principal_id
}

# A new grant takes a few minutes to reach the vault's data plane, and a connector reads its
# credentials as it boots, so one that started straight after the grant would be refused them.
# The scale sets depend on this module and so wait for this too.
resource "time_sleep" "secrets_user_propagation" {
  create_duration = var.rbac_propagation_delay

  triggers = {
    assignment = azurerm_role_assignment.cc_secrets_user.id
  }
}

# The three secrets, written through Resource Manager.
#
# A resource action rather than azapi_resource, because Resource Manager can create and
# update a vault secret but has no delete for one. On a destroy these are simply
# forgotten, and the secrets go with the vault.
#
# The value goes in sensitive_body, which is write-only: it is sent to Resource Manager and
# kept in neither the plan nor the state, and the credential variables are ephemeral, so a
# saved plan file holds none of them either. Terraform therefore cannot see a credential
# change. credentials_version is what it sees: raising it sends all three PUTs again, each
# writing a new version of its secret.
#
# The names are fixed: the connectors and the vendor function both read api-key,
# username and password. for_each iterates the names rather than the map of values,
# because a for_each over sensitive values is an error.
locals {
  secret_values = {
    "api-key"  = var.zscaler_api_key
    "username" = var.zscaler_username
    "password" = var.zscaler_password
  }
}

resource "azapi_resource_action" "secret" {
  for_each    = toset(["api-key", "username", "password"])
  type        = "Microsoft.KeyVault/vaults/secrets@2023-07-01"
  resource_id = "${azurerm_key_vault.zscc.id}/secrets/${each.key}"
  method      = "PUT"

  sensitive_body = {
    properties = {
      value = local.secret_values[each.key]
    }
  }
  sensitive_body_version = {
    "properties.value" = tostring(var.credentials_version)
  }
}

# The private endpoint is what the connectors and the function reach the vault through.
resource "azurerm_private_endpoint" "vault" {
  name                = "pe-${var.name}"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = var.private_endpoint_subnet_id
  tags                = var.tags

  private_service_connection {
    name                           = "pe-${var.name}"
    private_connection_resource_id = azurerm_key_vault.zscc.id
    is_manual_connection           = false
    subresource_names              = ["vault"]
  }

  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = [var.private_dns_zone_id]
  }
}

# State may still hold secrets written over the vault's own endpoint, with the
# deployer's Secrets Officer grant and the wait that preceded them. A private vault
# refuses that endpoint from outside the network, so Terraform forgets them rather than
# reading or deleting them; the PUTs above write new versions, and the grant is removed
# by hand (README). All of it leaves with the vault.
removed {
  from = azurerm_key_vault_secret.api_key
  lifecycle {
    destroy = false
  }
}

removed {
  from = azurerm_key_vault_secret.username
  lifecycle {
    destroy = false
  }
}

removed {
  from = azurerm_key_vault_secret.password
  lifecycle {
    destroy = false
  }
}

removed {
  from = azurerm_role_assignment.deployer_secrets_officer
  lifecycle {
    destroy = false
  }
}

removed {
  from = time_sleep.kv_rbac
  lifecycle {
    destroy = false
  }
}
