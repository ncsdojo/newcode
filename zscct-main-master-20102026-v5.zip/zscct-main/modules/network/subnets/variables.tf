variable "name_prefix" {
  description = "Leading name component, <app><environment>arm - e.g. ccprdarm."
  type        = string
}

variable "name_suffix" {
  description = "Trailing name component, <region><instance> - e.g. uw2001."
  type        = string
}

variable "virtual_network_name" {
  description = "VNet the subnets are carved from, from the vnet module."
  type        = string
}

variable "virtual_network_resource_group_name" {
  description = "Group the VNet lives in. Subnets are created there."
  type        = string
}

variable "vnet_address_space" {
  description = "The VNet's address space. Every subnet is checked to sit inside it."
  type        = string
}

variable "mgmt_subnet_cidr" {
  description = "Management subnet. Holds every connector's management NIC plus the private endpoints, so size it for all zones. /26 or larger."
  type        = string
}

variable "service_subnet_cidr" {
  description = "Service subnet. Holds every connector's service NIC, so size it for all zones. /26 or larger."
  type        = string
}

variable "workload_subnet_cidr" {
  description = "Workload subnet, the one carrying the default route to the connector load balancer."
  type        = string
}

variable "lb_subnet_cidr" {
  description = "Internal load balancer frontend subnet."
  type        = string
}

variable "funcapp_subnet_cidr" {
  description = "Lifecycle Function App delegated subnet. /28 minimum for Microsoft.Web/serverFarms; /26 recommended for scale-out."
  type        = string
}

variable "bastion_subnet_cidr" {
  description = "AzureBastionSubnet range. /26 or larger. Only used when enable_bastion is true."
  type        = string
  default     = ""
}

variable "enable_bastion" {
  description = "Create AzureBastionSubnet. The Bastion host itself is the bastion module."
  type        = bool
  default     = true
}
