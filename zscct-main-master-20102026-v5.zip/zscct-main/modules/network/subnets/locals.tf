locals {
  # The deployed subnet names, built once. The checks further down are keyed by these
  # same strings, so an error message names the subnet the way Azure will.
  names = {
    mgmt     = "${var.name_prefix}sub-mgmt-${var.name_suffix}"
    service  = "${var.name_prefix}sub-svc-${var.name_suffix}"
    workload = "${var.name_prefix}sub-wl-${var.name_suffix}"
    lb       = "${var.name_prefix}sub-lb-${var.name_suffix}"
    funcapp  = "${var.name_prefix}sub-func-${var.name_suffix}"
    # Azure requires this exact name; it is not ours to change.
    bastion = "AzureBastionSubnet"
  }

  # Every subnet this module creates, keyed by name. The Bastion range only joins the
  # plan when Bastion is actually on - an empty CIDR would blow up the arithmetic below
  # before the precondition could give a useful error.
  subnet_plan = merge(
    {
      (local.names.mgmt)     = var.mgmt_subnet_cidr
      (local.names.service)  = var.service_subnet_cidr
      (local.names.workload) = var.workload_subnet_cidr
      (local.names.lb)       = var.lb_subnet_cidr
      (local.names.funcapp)  = var.funcapp_subnet_cidr
    },
    var.enable_bastion && var.bastion_subnet_cidr != "" ? { (local.names.bastion) = var.bastion_subnet_cidr } : {}
  )
  subnet_names = keys(local.subnet_plan)

  vnet_prefix   = tonumber(split("/", var.vnet_address_space)[1])
  subnet_prefix = { for name, c in local.subnet_plan : name => tonumber(split("/", c)[1]) }

  # Turn each address into a plain number so ranges can be compared with < and >.
  # Terraform has cidrhost and cidrsubnet and nothing else, and neither answers "do these
  # two ranges overlap".
  subnet_start = { for name, c in local.subnet_plan :
    name => sum([for i, o in split(".", cidrhost(c, 0)) : tonumber(o) * pow(256, 3 - i)])
  }
  subnet_end = { for name, s in local.subnet_start :
    name => s + pow(2, 32 - local.subnet_prefix[name]) - 1
  }

  subnets_outside_vnet = [
    for name, c in local.subnet_plan : "${name}=${c}"
    if local.subnet_prefix[name] < local.vnet_prefix ||
    cidrhost("${cidrhost(c, 0)}/${local.vnet_prefix}", 0) != cidrhost(var.vnet_address_space, 0)
  ]

  # Check every pair once, so "a overlaps b" does not also come back as "b overlaps a".
  # Pairs are ordered by position in the sorted key list, because Terraform's < and >
  # compare numbers only.
  subnet_overlaps = [
    for pair in setproduct(local.subnet_names, local.subnet_names) :
    "${pair[0]} overlaps ${pair[1]}"
    if index(local.subnet_names, pair[0]) < index(local.subnet_names, pair[1]) &&
    local.subnet_start[pair[0]] <= local.subnet_end[pair[1]] &&
    local.subnet_end[pair[0]] >= local.subnet_start[pair[1]]
  ]

  subnet_min_prefix = {
    # The connector subnets are shared across zones, so each has to hold one NIC per
    # instance per zone. /26 leaves room to raise max_instances without re-addressing.
    (local.names.mgmt)    = 26
    (local.names.service) = 26
    # A serverFarms delegation cannot be smaller than /28. Microsoft suggests /26.
    (local.names.funcapp) = 28
    # AzureBastionSubnet must be /26 or larger.
    (local.names.bastion)  = 26
    (local.names.workload) = 29
    (local.names.lb)       = 29
  }

  subnets_too_small = [
    for name, p in local.subnet_prefix :
    "${name}=${local.subnet_plan[name]} needs /${local.subnet_min_prefix[name]} or larger"
    if p > local.subnet_min_prefix[name]
  ]
}
