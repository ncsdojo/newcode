# The subnets the connectors and their supporting services sit in.
#
# One management subnet and one service subnet, shared by connectors in every zone.
# Azure subnets are regional, not zonal, so a single subnet serves instances in all
# availability zones - and the NAT gateway in front of them is zone-redundant, so
# egress does not depend on a zone either.
#
# Subnets belong to the VNet's resource group, which is not necessarily the group
# holding everything else. Only used when this deployment owns the VNet; if the VNet
# already exists, the environment looks its subnets up instead.

# This subnet carries the checks for the whole plan. Any one of them failing stops the
# plan before a single subnet is created, so it does not matter which resource holds
# them - this one does because it always exists and is never counted.
resource "azurerm_subnet" "workload" {
  name                 = local.names.workload
  resource_group_name  = var.virtual_network_resource_group_name
  virtual_network_name = var.virtual_network_name
  address_prefixes     = [var.workload_subnet_cidr]

  lifecycle {
    # A subnet sits inside the VNet if re-masking its network address to the VNet's
    # prefix length gives back the VNet's own network address.
    precondition {
      condition     = length(local.subnets_outside_vnet) == 0
      error_message = "Subnet(s) fall outside the VNet ${var.vnet_address_space}: ${join(", ", local.subnets_outside_vnet)}. Adjust them to sit within the VNet range."
    }

    precondition {
      condition     = length(local.subnet_overlaps) == 0
      error_message = "Overlapping subnet CIDR(s): ${join("; ", local.subnet_overlaps)}. Each subnet must occupy a distinct range."
    }

    # Azure's floor is /29. A Microsoft.Web/serverFarms delegation needs /28 or larger,
    # and AzureBastionSubnet needs /26. The connector subnets need room for every
    # instance in every zone, so they are held to /26 as well.
    precondition {
      condition     = length(local.subnets_too_small) == 0
      error_message = "Subnet(s) too small: ${join("; ", local.subnets_too_small)}."
    }
  }
}

resource "azurerm_subnet" "bastion" {
  count                = var.enable_bastion ? 1 : 0
  name                 = local.names.bastion
  resource_group_name  = var.virtual_network_resource_group_name
  virtual_network_name = var.virtual_network_name
  address_prefixes     = [var.bastion_subnet_cidr]

  lifecycle {
    precondition {
      condition     = var.bastion_subnet_cidr != ""
      error_message = "enable_bastion is true but bastion_subnet_cidr is empty. Supply an AzureBastionSubnet range of /26 or larger, or set enable_bastion = false."
    }
  }
}

# Holds every connector's management NIC, plus the Key Vault, storage (blob, queue and
# table) and Function App private endpoints - which is why endpoint network policies are
# off here.
resource "azurerm_subnet" "mgmt" {
  name                              = local.names.mgmt
  resource_group_name               = var.virtual_network_resource_group_name
  virtual_network_name              = var.virtual_network_name
  address_prefixes                  = [var.mgmt_subnet_cidr]
  private_endpoint_network_policies = "Disabled"
}

# Holds every connector's service NIC - the ones carrying customer traffic.
resource "azurerm_subnet" "service" {
  name                 = local.names.service
  resource_group_name  = var.virtual_network_resource_group_name
  virtual_network_name = var.virtual_network_name
  address_prefixes     = [var.service_subnet_cidr]
}

resource "azurerm_subnet" "lb" {
  name                 = local.names.lb
  resource_group_name  = var.virtual_network_resource_group_name
  virtual_network_name = var.virtual_network_name
  address_prefixes     = [var.lb_subnet_cidr]
}

# The delegation makes this subnet exclusive to the Function App's VNet integration.
# No storage service endpoint: the function's storage account has public access
# disabled, and the app reaches it through private endpoints instead.
resource "azurerm_subnet" "funcapp" {
  name                 = local.names.funcapp
  resource_group_name  = var.virtual_network_resource_group_name
  virtual_network_name = var.virtual_network_name
  address_prefixes     = [var.funcapp_subnet_cidr]

  delegation {
    name = "Microsoft.Web.serverFarms"
    service_delegation {
      name = "Microsoft.Web/serverFarms"
    }
  }
}
