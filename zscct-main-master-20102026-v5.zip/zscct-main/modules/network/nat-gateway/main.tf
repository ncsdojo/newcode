# One zone-redundant NAT gateway with a static egress address, plus the subnet
# associations.
#
# This is how the connectors, and the lifecycle function through its VNet integration,
# reach the internet. Outbound through a load balancer is a public load balancer
# feature, so the internal one gives the connectors no way out, and Microsoft recommends
# a NAT gateway for outbound connectivity from a subnet. Without one, a connector falls
# back to Azure's default outbound access where its subnet still has it, which Microsoft
# advises against: the address can change, and virtual networks created from 31 March
# 2026 default to private subnets that have none.
#
# The load balancer's subnet is deliberately not associated. It holds only the frontend
# address, which receives traffic and never starts a connection, and a NAT gateway only
# carries connections that start in its subnets, and their replies.
#
# StandardV2 spans every availability zone in the region on its own, so one gateway
# survives losing a zone. That is why there is one here rather than one per zone - and
# why none of these resources sets `zones`, which would pin them to a single one.
#
# The egress address. A NAT gateway cannot work without a public IP or a public IP
# prefix, and it only ever carries connections that start inside the VNet - nothing can
# connect in through it. Org-Delta's "Not allowed resource types" policy refuses
# Microsoft.Network/publicIPAddresses, so whichever of these is used has to be one the
# platform team allows:
#
#   public_ip_mode = "ip"      a StandardV2 public IP (the default). Needs the policy
#                              exemption for this one resource - the runbook's A5 item.
#   public_ip_mode = "prefix"  a StandardV2 public IP prefix instead, for where the
#                              platform team allows prefixes but not addresses. The
#                              gateway uses every address in it, so allowlist the range.
#   existing_public_ip_id      attach an IP (ip mode) or prefix (prefix mode) the platform
#                              team created, under whatever exemption they hold, rather
#                              than creating one here.
#
# One gateway also means one egress address, or one range, to allowlist in the Zscaler
# portal.

resource "azurerm_public_ip" "natgw" {
  count               = local.create_ip ? 1 : 0
  name                = local.pip_name
  location            = var.location
  resource_group_name = var.resource_group_name
  # Must match the gateway's SKU - a StandardV2 gateway will not accept a Standard IP.
  sku               = "StandardV2"
  allocation_method = "Static"
  tags              = var.tags
}

resource "azurerm_public_ip_prefix" "natgw" {
  count               = local.create_prefix ? 1 : 0
  name                = local.prefix_name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "StandardV2"
  prefix_length       = var.public_ip_prefix_length
  tags                = var.tags
}

resource "azurerm_nat_gateway" "zscc" {
  name                = local.natgw_name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku_name            = "StandardV2"
  # Ten minutes, as in Zscaler's own module, rather than Azure's four-minute default.
  # Azure silently drops a flow once it has been idle that long, and sends a reset only
  # if traffic later arrives on it. Microsoft's general advice is to keep the default and
  # use TCP keepalives; this follows Zscaler's choice for its own connectors.
  idle_timeout_in_minutes = 10
  tags                    = var.tags
}

resource "azurerm_nat_gateway_public_ip_association" "zscc" {
  count                = var.public_ip_mode == "ip" ? 1 : 0
  nat_gateway_id       = azurerm_nat_gateway.zscc.id
  public_ip_address_id = local.public_ip_id

  lifecycle {
    precondition {
      condition     = var.existing_public_ip_id == null || can(regex("(?i)/providers/Microsoft\\.Network/publicIPAddresses/", var.existing_public_ip_id))
      error_message = "public_ip_mode is \"ip\" but existing_public_ip_id is not a public IP address. Pass a publicIPAddresses id, or set public_ip_mode = \"prefix\" for a prefix."
    }
  }
}

resource "azurerm_nat_gateway_public_ip_prefix_association" "zscc" {
  count               = var.public_ip_mode == "prefix" ? 1 : 0
  nat_gateway_id      = azurerm_nat_gateway.zscc.id
  public_ip_prefix_id = local.public_ip_prefix_id

  lifecycle {
    precondition {
      condition     = var.existing_public_ip_id == null || can(regex("(?i)/providers/Microsoft\\.Network/publicIPPrefixes/", var.existing_public_ip_id))
      error_message = "public_ip_mode is \"prefix\" but existing_public_ip_id is not a public IP prefix. Pass a publicIPPrefixes id, or set public_ip_mode = \"ip\" for an address."
    }
  }
}

# Read back when the platform team supplied the address, so the egress output still
# says what to allowlist.
data "azurerm_public_ip" "existing" {
  count               = var.public_ip_mode == "ip" && var.existing_public_ip_id != null ? 1 : 0
  name                = local.existing_name
  resource_group_name = local.existing_resource_group
}

data "azurerm_public_ip_prefix" "existing" {
  count               = var.public_ip_mode == "prefix" && var.existing_public_ip_id != null ? 1 : 0
  name                = local.existing_name
  resource_group_name = local.existing_resource_group
}

# Both had no count before the address became configurable.
moved {
  from = azurerm_public_ip.natgw
  to   = azurerm_public_ip.natgw[0]
}

moved {
  from = azurerm_nat_gateway_public_ip_association.zscc
  to   = azurerm_nat_gateway_public_ip_association.zscc[0]
}

# A gateway can serve several subnets; a subnet can only have one gateway.
resource "azurerm_subnet_nat_gateway_association" "mgmt" {
  subnet_id      = var.mgmt_subnet_id
  nat_gateway_id = azurerm_nat_gateway.zscc.id
}

resource "azurerm_subnet_nat_gateway_association" "service" {
  subnet_id      = var.service_subnet_id
  nat_gateway_id = azurerm_nat_gateway.zscc.id
}

resource "azurerm_subnet_nat_gateway_association" "funcapp" {
  subnet_id      = var.funcapp_subnet_id
  nat_gateway_id = azurerm_nat_gateway.zscc.id
}
