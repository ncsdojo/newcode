variable "name_prefix" {
  description = "Leading name component, <app><environment>arm - e.g. ccprdarm."
  type        = string
}

variable "name_suffix" {
  description = "Trailing name component, <region><instance> - e.g. uw2001."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Deployment group the gateway and its egress address are created in."
  type        = string
}

variable "tags" {
  description = "Tags applied to the gateway and its egress address."
  type        = map(string)
  default     = {}
}

variable "mgmt_subnet_id" {
  description = "Management subnet, routed through the gateway."
  type        = string
}

variable "service_subnet_id" {
  description = "Service subnet, routed through the gateway."
  type        = string
}

variable "funcapp_subnet_id" {
  description = "Function App subnet, routed through the same gateway."
  type        = string
}

variable "public_ip_mode" {
  description = "Egress address type. \"ip\" is a StandardV2 public IP; \"prefix\" a StandardV2 public IP prefix of public_ip_prefix_length. Either needs to be allowed by Org-Delta - see main.tf."
  type        = string
  default     = "ip"

  validation {
    condition     = contains(["ip", "prefix"], var.public_ip_mode)
    error_message = "public_ip_mode must be \"ip\" or \"prefix\"."
  }
}

variable "existing_public_ip_id" {
  description = "Resource id of an existing StandardV2 public IP (ip mode) or public IP prefix (prefix mode) to attach instead of creating one, e.g. one the platform team created under an exemption. Same subscription and region as the gateway."
  type        = string
  default     = null

  validation {
    condition     = var.existing_public_ip_id == null || can(regex("(?i)^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.Network/(publicIPAddresses|publicIPPrefixes)/[^/]+$", var.existing_public_ip_id))
    error_message = "existing_public_ip_id must be the full resource id of a public IP or public IP prefix."
  }
}

variable "public_ip_prefix_length" {
  description = "Size of the prefix created in prefix mode. A NAT gateway takes /28 to /31; /31 gives two egress addresses."
  type        = number
  default     = 31

  validation {
    condition     = var.public_ip_prefix_length >= 28 && var.public_ip_prefix_length <= 31
    error_message = "public_ip_prefix_length must be between 28 and 31 for a NAT gateway."
  }
}
