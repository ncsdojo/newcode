output "public_ip" {
  description = "The NAT egress address in ip mode, or null in prefix mode."
  value       = local.public_ip_address
}

output "public_ip_prefix" {
  description = "The NAT egress range in prefix mode, or null in ip mode."
  value       = local.public_ip_prefix_cidr
}

output "egress" {
  description = "What to allowlist in the Zscaler portal: the egress address, or the egress range in prefix mode."
  value       = coalesce(local.public_ip_address, local.public_ip_prefix_cidr)
}

output "public_ip_id" {
  description = "Id of the egress IP or prefix this module created - locked, because losing it means a new address to allowlist. Null when the address was supplied through existing_public_ip_id, which is not ours to lock."
  value       = var.existing_public_ip_id != null ? null : (local.create_ip ? local.public_ip_id : local.public_ip_prefix_id)
}

output "gateway_id" {
  description = "NAT gateway id."
  value       = azurerm_nat_gateway.zscc.id
}
