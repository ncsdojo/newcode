locals {
  natgw_name  = "${var.name_prefix}nat${var.name_suffix}"
  pip_name    = "${var.name_prefix}pip${var.name_suffix}"
  prefix_name = "${var.name_prefix}ippre${var.name_suffix}"

  create_ip     = var.public_ip_mode == "ip" && var.existing_public_ip_id == null
  create_prefix = var.public_ip_mode == "prefix" && var.existing_public_ip_id == null

  # /subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Network/<type>/<name>
  existing_parts          = var.existing_public_ip_id == null ? [] : split("/", var.existing_public_ip_id)
  existing_resource_group = try(local.existing_parts[4], null)
  existing_name           = try(local.existing_parts[8], null)

  public_ip_id        = local.create_ip ? azurerm_public_ip.natgw[0].id : var.existing_public_ip_id
  public_ip_prefix_id = local.create_prefix ? azurerm_public_ip_prefix.natgw[0].id : var.existing_public_ip_id

  public_ip_address = var.public_ip_mode != "ip" ? null : (
    local.create_ip ? azurerm_public_ip.natgw[0].ip_address : data.azurerm_public_ip.existing[0].ip_address
  )
  public_ip_prefix_cidr = var.public_ip_mode != "prefix" ? null : (
    local.create_prefix ? azurerm_public_ip_prefix.natgw[0].ip_prefix : data.azurerm_public_ip_prefix.existing[0].ip_prefix
  )
}
