# Sends the workload subnet's outbound traffic to the connectors.
#
# Separate from the other network modules because of the ordering: this needs the load
# balancer's frontend address, and the load balancer needs a subnet. Subnets, then load
# balancer, then this.

resource "azurerm_route_table" "workload" {
  name                = local.name
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
  # Where the hub has an ExpressRoute or VPN gateway, its BGP routes land in every
  # subnet's effective route table. A learned prefix more specific than 0.0.0.0/0 would
  # win on longest match and send that traffic around the connectors instead of through
  # them. Off means the route below is the only default this subnet has. The provider
  # default is the opposite.
  bgp_route_propagation_enabled = false
}

resource "azurerm_route" "default_to_lb" {
  name                   = "default-to-zscc"
  resource_group_name    = var.resource_group_name
  route_table_name       = azurerm_route_table.workload.name
  address_prefix         = "0.0.0.0/0"
  next_hop_type          = "VirtualAppliance"
  next_hop_in_ip_address = var.next_hop_ip
}

resource "azurerm_subnet_route_table_association" "workload" {
  subnet_id      = var.workload_subnet_id
  route_table_id = azurerm_route_table.workload.id
}
