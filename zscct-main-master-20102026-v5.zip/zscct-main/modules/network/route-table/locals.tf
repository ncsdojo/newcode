locals {
  name = "${var.name_prefix}rtbl${var.name_suffix}"
}
