output "id" {
  description = "Route table id. Also the scope of the route table CanNotDelete lock."
  value       = azurerm_route_table.workload.id
}
