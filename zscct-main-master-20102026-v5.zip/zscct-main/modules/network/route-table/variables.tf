variable "name_prefix" {
  description = "Leading name component, <app><environment>arm - e.g. ccprdarm."
  type        = string
}

variable "name_suffix" {
  description = "Trailing name component, <region><instance> - e.g. uw2001."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Deployment group the route table is created in."
  type        = string
}

variable "tags" {
  description = "Tags applied to the route table."
  type        = map(string)
  default     = {}
}

variable "workload_subnet_id" {
  description = "Subnet the route table is associated with, from subnets.workload_id."
  type        = string
}

variable "next_hop_ip" {
  description = "Virtual appliance next hop for 0.0.0.0/0, from load_balancer.frontend_private_ip."
  type        = string
}
