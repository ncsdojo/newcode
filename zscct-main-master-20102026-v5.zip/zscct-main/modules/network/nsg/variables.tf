variable "name_prefix" {
  description = "Leading name component, <app><environment>arm - e.g. ccprdarm."
  type        = string
}

variable "name_suffix" {
  description = "Trailing name component, <region><instance> - e.g. uw2001."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Deployment group the NSGs are created in. Not necessarily the VNet's group."
  type        = string
}

variable "tags" {
  description = "Tags applied to both NSGs."
  type        = map(string)
  default     = {}
}

variable "mgmt_subnet_id" {
  description = "Management subnet id."
  type        = string
}

variable "service_subnet_id" {
  description = "Service subnet id."
  type        = string
}

variable "funcapp_nsg_enabled" {
  description = "Create the Function App subnet's NSG and attach it to funcapp_subnet_id. A flag rather than a null check on the id, because the id is not known until the subnet exists."
  type        = bool
  default     = false
}

variable "funcapp_subnet_id" {
  description = "Function App VNet integration subnet id. Required when funcapp_nsg_enabled is true."
  type        = string
  default     = null
}

variable "private_endpoint_client_cidrs" {
  description = "Ranges allowed to reach the private endpoints in the management subnet on TCP 443: the management subnet itself, where the connectors read the vault, and the Function App subnet."
  type        = list(string)
}

variable "bastion_subnet_cidr" {
  description = "Bastion range, used as the SSH source whenever it is set - the Bastion itself may belong to this deployment or to the platform team. Empty or null falls back to ssh_source_cidr."
  type        = string
  default     = ""
  nullable    = false
}

variable "ssh_source_cidr" {
  description = "Mgmt NSG SSH source where there is no Bastion range to use."
  type        = string
  default     = "VirtualNetwork"
}

variable "enable_support_tunnel" {
  description = "Allow the connectors' outbound TCP/12002 connection to Zscaler's remote-support server on the management NSG. On by default, as in Zscaler's own module."
  type        = bool
  default     = true
}

variable "support_server_ip" {
  description = "Zscaler's remote-support server: the address remotesupport.<zscaler_cloud>.net resolves to. The default is the commercial-cloud address Zscaler's own module uses; set this on any other cloud."
  type        = string
  default     = "199.168.148.101"

  validation {
    condition     = can(cidrhost("${var.support_server_ip}/32", 0))
    error_message = "support_server_ip must be a single IPv4 address, without a prefix length."
  }
}

variable "http_probe_port" {
  description = "Connector health probe port, allowed inbound from AzureLoadBalancer on both NSGs."
  type        = number
  default     = 50000
}

variable "workload_cidrs" {
  description = "Specific workload CIDRs allowed inbound on the service NSG. Empty means the whole virtual network."
  type        = list(string)
  default     = []
}

variable "service_allow_all_outbound" {
  description = "Allow every port outbound from the service subnet to the internet, as Zscaler's own module does. Left false, the service NSG allows only what tunnelled and Azure Virtual Desktop traffic need, and drops traffic the forwarding policy sends DIRECT on any other port."
  type        = bool
  default     = false
}
