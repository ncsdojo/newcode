# One management NSG and one service NSG, and their subnet associations - plus, where
# asked for, one on the Function App's VNet integration subnet.
#
# The NSGs are created in this deployment's resource group even when the subnets they
# attach to belong to somebody else's VNet. The associations live here rather than with
# the subnets so the subnets module only ever deals with address space.
#
# A subnet takes one NSG, and the association refuses a subnet that already has one
# rather than replacing it. Where the platform team attaches its own, the environment
# does not call this module at all.

resource "azurerm_network_security_group" "mgmt" {
  name                = local.mgmt_name
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  dynamic "security_rule" {
    for_each = local.mgmt_rules
    content {
      name                   = security_rule.value.name
      priority               = security_rule.value.priority
      direction              = security_rule.value.direction
      access                 = security_rule.value.access
      protocol               = security_rule.value.protocol
      source_port_range      = "*"
      destination_port_range = security_rule.value.dest_port
      # AllowPrivateEndpointsIn is the only management rule with several sources, as
      # AllowWorkload is on the service NSG below.
      source_address_prefix      = security_rule.value.name == "AllowPrivateEndpointsIn" ? null : security_rule.value.src
      source_address_prefixes    = security_rule.value.name == "AllowPrivateEndpointsIn" ? var.private_endpoint_client_cidrs : null
      destination_address_prefix = security_rule.value.dst
    }
  }
}

resource "azurerm_network_security_group" "svc" {
  name                = local.svc_name
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  dynamic "security_rule" {
    for_each = local.svc_rules
    content {
      name                   = security_rule.value.name
      priority               = security_rule.value.priority
      direction              = security_rule.value.direction
      access                 = security_rule.value.access
      protocol               = security_rule.value.protocol
      source_port_range      = "*"
      destination_port_range = security_rule.value.dest_port
      # AllowWorkload is the only rule that can carry several prefixes; every other rule sets
      # the singular form and leaves the plural null. Azure accepts exactly one of the two.
      source_address_prefix      = security_rule.value.name == "AllowWorkload" ? local.svc_workload_src : security_rule.value.src
      source_address_prefixes    = security_rule.value.name == "AllowWorkload" ? local.svc_workload_srcs : null
      destination_address_prefix = security_rule.value.dst
    }
  }
}

# The Function App's outbound firewall. With vnet_route_all_enabled every connection the
# app makes leaves through its integration subnet, so this NSG decides what the app can
# reach: HTTPS to its private endpoints and to the internet (Zscaler portal API, Azure
# Resource Manager, Entra ID, Application Insights), HTTP for certificate revocation
# checks, DNS to servers inside the network, and nothing else.
# Inbound rules never apply to an integration subnet; the deny is there to say so.
resource "azurerm_network_security_group" "func" {
  count               = var.funcapp_nsg_enabled ? 1 : 0
  name                = local.func_name
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  dynamic "security_rule" {
    for_each = local.func_rules
    content {
      name                       = security_rule.value.name
      priority                   = security_rule.value.priority
      direction                  = security_rule.value.direction
      access                     = security_rule.value.access
      protocol                   = security_rule.value.protocol
      source_port_range          = "*"
      destination_port_range     = security_rule.value.dest_port
      source_address_prefix      = security_rule.value.src
      destination_address_prefix = security_rule.value.dst
    }
  }

  lifecycle {
    precondition {
      condition     = var.funcapp_subnet_id != null
      error_message = "funcapp_nsg_enabled is true but no funcapp_subnet_id was given."
    }
  }
}

resource "azurerm_subnet_network_security_group_association" "mgmt" {
  subnet_id                 = var.mgmt_subnet_id
  network_security_group_id = azurerm_network_security_group.mgmt.id
}

resource "azurerm_subnet_network_security_group_association" "svc" {
  subnet_id                 = var.service_subnet_id
  network_security_group_id = azurerm_network_security_group.svc.id
}

resource "azurerm_subnet_network_security_group_association" "func" {
  count                     = var.funcapp_nsg_enabled ? 1 : 0
  subnet_id                 = var.funcapp_subnet_id
  network_security_group_id = azurerm_network_security_group.func[0].id
}
