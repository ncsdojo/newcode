output "mgmt_id" {
  description = "Management NSG id."
  value       = azurerm_network_security_group.mgmt.id
}

output "service_id" {
  description = "Service NSG id."
  value       = azurerm_network_security_group.svc.id
}

output "funcapp_id" {
  description = "Function App subnet NSG id, or null when funcapp_nsg_enabled is false."
  value       = one(azurerm_network_security_group.func[*].id)
}
