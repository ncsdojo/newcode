locals {
  # Zone name => the token its VNet link is named with. The link names are the ones the
  # zones had when each was its own resource, so existing links keep their names.
  zones = merge(
    {
      "privatelink.vaultcore.azure.net"    = "kv"
      "privatelink.blob.core.windows.net"  = "blob"
      "privatelink.queue.core.windows.net" = "queue"
      "privatelink.table.core.windows.net" = "table"
    },
    var.enable_function_private_endpoint ? { "privatelink.azurewebsites.net" = "func" } : {},
  )
}
