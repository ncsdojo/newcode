output "zone_ids" {
  description = "Every zone this module created, zone name => id."
  value       = { for name, zone in azurerm_private_dns_zone.zone : name => zone.id }
}

output "vault_zone_id" {
  description = "privatelink.vaultcore.azure.net zone id, for the Key Vault private endpoint's DNS zone group."
  value       = azurerm_private_dns_zone.zone["privatelink.vaultcore.azure.net"].id
}

output "blob_zone_id" {
  description = "privatelink.blob.core.windows.net zone id, for the function storage account's blob private endpoint."
  value       = azurerm_private_dns_zone.zone["privatelink.blob.core.windows.net"].id
}

output "queue_zone_id" {
  description = "privatelink.queue.core.windows.net zone id, for the function storage account's queue private endpoint."
  value       = azurerm_private_dns_zone.zone["privatelink.queue.core.windows.net"].id
}

output "table_zone_id" {
  description = "privatelink.table.core.windows.net zone id, for the function storage account's table private endpoint."
  value       = azurerm_private_dns_zone.zone["privatelink.table.core.windows.net"].id
}

output "sites_zone_id" {
  description = "privatelink.azurewebsites.net zone id, or null when the Function App has no private endpoint."
  value       = try(azurerm_private_dns_zone.zone["privatelink.azurewebsites.net"].id, null)
}
