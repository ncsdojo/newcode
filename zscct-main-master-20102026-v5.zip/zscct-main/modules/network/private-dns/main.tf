# The privatelink zones the Key Vault, function storage and Function App private
# endpoints resolve through, and their links to the VNet.
#
# Only used when this deployment owns the VNet. Where the VNet belongs to a hub these
# zones already exist and are already linked, and Azure will not accept a second zone
# of the same name on the same VNet - the apply fails. Those environments look up the
# existing zone ids instead.
#
# Keyed by zone name, so an environment can adopt a zone an earlier deployment left in
# the resource group with an import block naming it exactly as the "already exists"
# error does. See import_existing_private_dns_zones in the environment.
#
# Blob, queue and table are always here: the function's storage account has public
# access disabled, so its host reaches all three through private endpoints.

resource "azurerm_private_dns_zone" "zone" {
  for_each            = local.zones
  name                = each.key
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "zone" {
  for_each              = local.zones
  name                  = "${var.name_prefix}vnl-${each.value}-${var.name_suffix}"
  resource_group_name   = var.resource_group_name
  private_dns_zone_name = azurerm_private_dns_zone.zone[each.key].name
  virtual_network_id    = var.virtual_network_id
  registration_enabled  = false
  tags                  = var.tags
}

# Each zone was its own resource before they were keyed by name.
moved {
  from = azurerm_private_dns_zone.vault
  to   = azurerm_private_dns_zone.zone["privatelink.vaultcore.azure.net"]
}

moved {
  from = azurerm_private_dns_zone_virtual_network_link.vault
  to   = azurerm_private_dns_zone_virtual_network_link.zone["privatelink.vaultcore.azure.net"]
}

moved {
  from = azurerm_private_dns_zone.blob[0]
  to   = azurerm_private_dns_zone.zone["privatelink.blob.core.windows.net"]
}

moved {
  from = azurerm_private_dns_zone_virtual_network_link.blob[0]
  to   = azurerm_private_dns_zone_virtual_network_link.zone["privatelink.blob.core.windows.net"]
}

moved {
  from = azurerm_private_dns_zone.sites[0]
  to   = azurerm_private_dns_zone.zone["privatelink.azurewebsites.net"]
}

moved {
  from = azurerm_private_dns_zone_virtual_network_link.sites[0]
  to   = azurerm_private_dns_zone_virtual_network_link.zone["privatelink.azurewebsites.net"]
}
