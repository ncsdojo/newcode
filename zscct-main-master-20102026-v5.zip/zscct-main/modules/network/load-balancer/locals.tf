locals {
  name = "${var.name_prefix}lb${var.name_suffix}"

  frontend_name = "fe-zscc"

  # A single-zone deployment pins the frontend to that zone; anything wider is zone-redundant.
  # A region without availability zones takes no zone at all.
  frontend_zones = !var.zones_enabled ? null : (length(var.zones) == 1 ? [var.zones[0]] : ["1", "2", "3"])
}
