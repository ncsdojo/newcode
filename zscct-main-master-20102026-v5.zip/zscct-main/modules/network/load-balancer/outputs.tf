output "id" {
  description = "Load balancer id. Also the scope of the LB CanNotDelete lock."
  value       = azurerm_lb.zscc.id
}

output "backend_address_pool_id" {
  description = "Backend pool the connector service NICs join."
  value       = azurerm_lb_backend_address_pool.zscc.id
}

output "frontend_private_ip" {
  description = "Internal LB frontend - next hop for the workload route table and any spoke UDR."
  value       = azurerm_lb.zscc.frontend_ip_configuration[0].private_ip_address
}
