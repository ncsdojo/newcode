variable "name_prefix" {
  description = "Leading name component, <app><environment>arm - e.g. ccprdarm."
  type        = string
}

variable "name_suffix" {
  description = "Trailing name component, <region><instance> - e.g. uw2001."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Deployment group the load balancer is created in."
  type        = string
}

variable "tags" {
  description = "Tags applied to the load balancer."
  type        = map(string)
  default     = {}
}

variable "zones" {
  description = "Availability zones. One zone pins the frontend to it; more than one makes it zone-redundant."
  type        = list(string)
}

variable "zones_enabled" {
  description = "false in a region without availability zones, where the frontend takes no zone and zones is ignored."
  type        = bool
  default     = true
}

variable "subnet_id" {
  description = "Frontend subnet, from subnets.lb_id."
  type        = string
}

variable "http_probe_port" {
  description = "Connector health probe port. Also names the probe (hp-<port>)."
  type        = number
  default     = 50000
}
