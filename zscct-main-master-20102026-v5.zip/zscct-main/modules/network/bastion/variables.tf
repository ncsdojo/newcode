variable "name_prefix" {
  description = "Leading name component, <app><environment>arm - e.g. ccprdarm."
  type        = string
}

variable "name_suffix" {
  description = "Trailing name component, <region><instance> - e.g. uw2001."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Deployment group the Bastion, its NSG and any public IP are created in."
  type        = string
}

variable "tags" {
  description = "Tags applied to the Bastion host, its NSG and any public IP."
  type        = map(string)
  default     = {}
}

variable "subnet_id" {
  description = "AzureBastionSubnet id, from subnets.bastion_id or a lookup of the platform's subnet."
  type        = string
}

variable "sku" {
  description = "Bastion SKU. Premium (default) is deployed private-only, with no public IP: reachable only over ExpressRoute, VPN or peering. Basic and Standard need a public IP, which Org-Delta refuses unless exempted."
  type        = string
  default     = "Premium"

  validation {
    condition     = contains(["Premium", "Standard", "Basic"], var.sku)
    error_message = "sku must be Premium (private-only), Standard or Basic."
  }
}

variable "attach_nsg" {
  description = "Create an NSG with Microsoft's Bastion rules and attach it to AzureBastionSubnet. Set false where the platform team attaches its own."
  type        = bool
  default     = true
}

variable "client_source_address_prefix" {
  description = "Source allowed to open sessions on 443. Null uses VirtualNetwork for private-only (VNet, peered VNets and on-premises through a gateway) and Internet for a public SKU. Narrow it to your admin range if you have one."
  type        = string
  default     = null
}
