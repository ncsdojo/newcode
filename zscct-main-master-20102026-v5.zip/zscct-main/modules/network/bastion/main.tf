# Azure Bastion - how an operator gets an SSH session to a connector without any of them
# having a public address.
#
# Premium and private-only by default: the Bastion has no public IP at all. Org-Delta's
# "Not allowed resource types" policy refuses Microsoft.Network/publicIPAddresses, and a
# private-only Bastion is Microsoft's locked-down deployment - it answers only on its
# private address inside AzureBastionSubnet and cannot reach anything outside the VNet.
# Operators reach it from a network with private line of sight to the VNet: ExpressRoute
# or VPN from on-premises, or a peered VNet. From outside Azure that means the Azure CLI
# native client, for example
#
#   az network bastion ssh --name <bastion> --resource-group <rg> \
#     --target-ip-address <connector management IP> \
#     --auth-type ssh-key --username zsroot --ssh-key <private key file>
#
# which is why native-client tunnelling and IP-based connection stay on: Microsoft
# requires IP-based connection for clients coming in from on-premises. Shareable links,
# file copy and Kerberos stay off.
#
# Basic or Standard can still be chosen where public IPs are allowed; only those two
# SKUs get one.
#
# There is no on/off variable here. The environment puts count on the module call, so
# when Bastion is off this module is not evaluated at all.
#
# AzureBastionSubnet itself belongs to the subnets module, because its range is part of
# the subnet plan and doubles as the SSH source on the management NSG. Its NSG is here,
# because its rules are Bastion's and nothing else's.

resource "azurerm_public_ip" "bastion" {
  count               = local.public ? 1 : 0
  name                = local.pip_name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "Standard"
  allocation_method   = "Static"
  tags                = var.tags
}

moved {
  from = azurerm_public_ip.bastion
  to   = azurerm_public_ip.bastion[0]
}

resource "azurerm_bastion_host" "zscc" {
  name                = local.name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = var.sku
  scale_units         = 2
  # Native client and IP-based connection: how a private-only Bastion is used from
  # on-premises. Neither exists on Basic.
  tunneling_enabled  = var.sku != "Basic"
  ip_connect_enabled = var.sku != "Basic"
  # Nothing that hands out access by link or moves files.
  shareable_link_enabled = false
  file_copy_enabled      = false
  kerberos_enabled       = false
  tags                   = var.tags

  # A Premium Bastion with no public IP here is created private-only. Moving between
  # public and private-only replaces the Bastion; Azure cannot convert one in place.
  ip_configuration {
    name                 = "bastion-ipcfg"
    subnet_id            = var.subnet_id
    public_ip_address_id = one(azurerm_public_ip.bastion[*].id)
  }

  # The NSG goes on the subnet before Bastion is deployed into it, so the two never
  # update the subnet at the same time.
  depends_on = [azurerm_subnet_network_security_group_association.bastion]
}

# AzureBastionSubnet's NSG. Users arrive on 443 - from inside the network for
# private-only, from the internet only where a public SKU was chosen - and Bastion talks
# SSH to the VNet, to its own instances, to Azure for diagnostics, and over HTTP for
# session and certificate validation.
resource "azurerm_network_security_group" "bastion" {
  count               = var.attach_nsg ? 1 : 0
  name                = local.nsg_name
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  dynamic "security_rule" {
    for_each = local.nsg_rules
    content {
      name                       = security_rule.value.name
      priority                   = security_rule.value.priority
      direction                  = security_rule.value.direction
      access                     = security_rule.value.access
      protocol                   = security_rule.value.protocol
      source_port_range          = "*"
      destination_port_range     = security_rule.value.dest_port
      destination_port_ranges    = security_rule.value.dest_ports
      source_address_prefix      = security_rule.value.src
      destination_address_prefix = security_rule.value.dst
    }
  }
}

resource "azurerm_subnet_network_security_group_association" "bastion" {
  count                     = var.attach_nsg ? 1 : 0
  subnet_id                 = var.subnet_id
  network_security_group_id = azurerm_network_security_group.bastion[0].id
}
