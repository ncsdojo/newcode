locals {
  name     = "${var.name_prefix}bas${var.name_suffix}"
  pip_name = "${var.name_prefix}pipbas${var.name_suffix}"
  nsg_name = "${var.name_prefix}nsg-bas-${var.name_suffix}"

  # Basic and Standard need a public IP. Premium without one is private-only.
  public = contains(["Basic", "Standard"], var.sku)

  # Where users' sessions come from. VirtualNetwork covers the VNet, peered VNets and
  # on-premises ranges arriving through an ExpressRoute or VPN gateway.
  client_source = coalesce(var.client_source_address_prefix, local.public ? "Internet" : "VirtualNetwork")

  # Microsoft's rule set for AzureBastionSubnet:
  # https://learn.microsoft.com/azure/bastion/bastion-nsg
  #
  # Two rules carry two ports and take the plural form; every other rule sets the
  # singular and leaves the plural null. Azure accepts exactly one of the two, as in
  # modules/network/nsg.
  nsg_rules = [
    { name = "AllowHttpsInbound", priority = 100, direction = "Inbound", access = "Allow", protocol = "Tcp", dest_port = "443", dest_ports = null, src = local.client_source, dst = "*" },
    { name = "AllowGatewayManagerInbound", priority = 110, direction = "Inbound", access = "Allow", protocol = "Tcp", dest_port = "443", dest_ports = null, src = "GatewayManager", dst = "*" },
    { name = "AllowAzureLoadBalancerInbound", priority = 120, direction = "Inbound", access = "Allow", protocol = "Tcp", dest_port = "443", dest_ports = null, src = "AzureLoadBalancer", dst = "*" },
    { name = "AllowBastionHostCommunicationInbound", priority = 130, direction = "Inbound", access = "Allow", protocol = "*", dest_port = null, dest_ports = ["8080", "5701"], src = "VirtualNetwork", dst = "VirtualNetwork" },
    { name = "DenyAllInbound", priority = 4096, direction = "Inbound", access = "Deny", protocol = "*", dest_port = "*", dest_ports = null, src = "*", dst = "*" },
    { name = "AllowSshRdpOutbound", priority = 100, direction = "Outbound", access = "Allow", protocol = "*", dest_port = null, dest_ports = ["22", "3389"], src = "*", dst = "VirtualNetwork" },
    { name = "AllowAzureCloudOutbound", priority = 110, direction = "Outbound", access = "Allow", protocol = "Tcp", dest_port = "443", dest_ports = null, src = "*", dst = "AzureCloud" },
    { name = "AllowBastionHostCommunicationOutbound", priority = 120, direction = "Outbound", access = "Allow", protocol = "*", dest_port = null, dest_ports = ["8080", "5701"], src = "VirtualNetwork", dst = "VirtualNetwork" },
    { name = "AllowHttpOutbound", priority = 130, direction = "Outbound", access = "Allow", protocol = "*", dest_port = "80", dest_ports = null, src = "*", dst = "Internet" },
    { name = "DenyAllOutbound", priority = 4096, direction = "Outbound", access = "Deny", protocol = "*", dest_port = "*", dest_ports = null, src = "*", dst = "*" },
  ]
}
