output "name" {
  description = "Bastion host name."
  value       = azurerm_bastion_host.zscc.name
}

output "id" {
  description = "Bastion host id."
  value       = azurerm_bastion_host.zscc.id
}

output "private_only" {
  description = "True when the Bastion has no public IP and answers only inside the network."
  value       = !local.public
}

output "public_ip" {
  description = "Bastion public IP address, or null for a private-only Bastion."
  value       = one(azurerm_public_ip.bastion[*].ip_address)
}
