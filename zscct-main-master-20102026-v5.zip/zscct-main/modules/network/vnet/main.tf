# The virtual network.
#
# Only used when this deployment owns the VNet. If it already exists, the environment
# reads it with a data source and skips this module and the subnets module together -
# you own both or neither. See environments/westus2/prod.
resource "azurerm_virtual_network" "zscc" {
  name                = local.name
  location            = var.location
  resource_group_name = var.resource_group_name
  address_space       = [var.address_space]
  tags                = var.tags
}
