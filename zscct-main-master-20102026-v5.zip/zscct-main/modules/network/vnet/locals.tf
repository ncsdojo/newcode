locals {
  name = "${var.name_prefix}vnt${var.name_suffix}"
}
