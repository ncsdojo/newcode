output "id" {
  description = "Virtual network id."
  value       = azurerm_virtual_network.zscc.id
}

output "name" {
  description = "Virtual network name."
  value       = azurerm_virtual_network.zscc.name
}

output "resource_group_name" {
  description = "Group the VNet lives in. Subnets must be created in the same group."
  value       = azurerm_virtual_network.zscc.resource_group_name
}
