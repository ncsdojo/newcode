variable "route_table_name" {
  description = "Existing route table on the AVD session-host subnet(s). Routes are added to it; the table itself is not managed here."
  type        = string
}

variable "route_table_resource_group_name" {
  description = "Resource group holding that route table."
  type        = string
}

variable "next_hop_ip" {
  description = "The connectors' internal load balancer frontend, from load_balancer.frontend_private_ip."
  type        = string
}

variable "include_default_route" {
  description = "Also send 0.0.0.0/0 to the load balancer. Only for a table with no default route of its own, where all of the hosts' traffic should go through the connectors or the VDI client runs in A2A tunnel mode."
  type        = bool
  default     = false
}

variable "global_vip" {
  description = "Zscaler's anycast global VIP: the outer destination of the VDI client's tunnel in point-to-point mode."
  type        = string
  default     = "185.46.212.80"

  validation {
    condition     = can(cidrhost("${var.global_vip}/32", 0))
    error_message = "global_vip must be a single IPv4 address, without a prefix length."
  }
}
