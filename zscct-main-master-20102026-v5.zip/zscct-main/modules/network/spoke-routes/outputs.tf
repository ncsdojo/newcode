output "routes" {
  description = "Routes added to the table, name to prefix."
  value = merge(
    { (azurerm_route.vdi_global_vip.name) = azurerm_route.vdi_global_vip.address_prefix },
    { for r in azurerm_route.default_to_lb : r.name => r.address_prefix },
  )
}
