# The caller hands this module an aliased provider (azurerm.spoke), so it names the
# provider it expects rather than leaving Terraform to assume. Versions are pinned by the
# environment.
terraform {
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm"
    }
  }
}
