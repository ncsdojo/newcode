# The routes AVD session hosts need for Zscaler Client Connector for VDI, added to a
# route table that already sits on their subnet. In practice that table is the platform
# team's, which is why this adds routes to it instead of creating a table of its own -
# a subnet takes one route table, and taking theirs over is not this deployment's call.
#
# In point-to-point mode, the VDI client's default, the tunnel's outer destination is
# Zscaler's anycast global VIP, and Zscaler requires the session hosts' route for that
# address to point at the connectors' load balancer. Without it, traffic for that address
# follows the subnet's default route out to Zscaler's public cloud instead of reaching
# the connectors. Zscaler documents the client's SERVERIP install option as optional
# where the global VIP or the default route is routed to the connectors.
#
# A /32 user route beats anything BGP brings in - it is the longest prefix there is, and
# for the same prefix a user route wins - so this holds even where the table keeps route
# propagation on, as platform tables usually do.
#
# The default route is optional and off. A platform table normally carries its own
# 0.0.0.0/0 and a table holds one route per prefix, so adding ours would fail there.
# Turn it on only where all of the hosts' traffic should go through the connectors, or
# where the client runs in A2A tunnel mode, which needs a default route to them.
#
# Routes are child resources of the table: this needs write access to the routes and
# nothing else - Network Contributor on the table, or Microsoft.Network/routeTables/routes/*.

resource "azurerm_route" "vdi_global_vip" {
  name                   = "zscaler-vdi-gvip"
  resource_group_name    = var.route_table_resource_group_name
  route_table_name       = var.route_table_name
  address_prefix         = "${var.global_vip}/32"
  next_hop_type          = "VirtualAppliance"
  next_hop_in_ip_address = var.next_hop_ip
}

resource "azurerm_route" "default_to_lb" {
  count                  = var.include_default_route ? 1 : 0
  name                   = "default-to-zscc"
  resource_group_name    = var.route_table_resource_group_name
  route_table_name       = var.route_table_name
  address_prefix         = "0.0.0.0/0"
  next_hop_type          = "VirtualAppliance"
  next_hop_in_ip_address = var.next_hop_ip
}
