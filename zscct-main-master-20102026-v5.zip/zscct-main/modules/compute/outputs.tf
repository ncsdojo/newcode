output "vmss_ids" {
  description = "Scale set id per zone."
  value       = { for z, s in azurerm_orchestrated_virtual_machine_scale_set.cc : z => s.id }
}

output "vmss_names" {
  description = "Scale set name per zone, read back from the created resources."
  value       = { for z, s in azurerm_orchestrated_virtual_machine_scale_set.cc : z => s.name }
}

output "autoscale_ids" {
  description = "Autoscale setting id per zone."
  value       = { for z, a in azurerm_monitor_autoscale_setting.cc : z => a.id }
}
