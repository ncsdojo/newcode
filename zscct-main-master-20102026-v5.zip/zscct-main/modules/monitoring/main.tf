# Where alerts go: one metric alert on the load balancer, and three log alerts on the
# lifecycle function.
#
# The load balancer rule watches its health probe - a platform metric, so it reports
# continuously - and fires when most connectors stop answering, which is when workloads
# start losing their route out.
#
# The function catches its own exceptions and exits cleanly - as far as Azure is
# concerned every run succeeds, so only its traces show that anything went wrong - and
# its plan does not emit an execution count metric to alert on. Its three rules query
# Application Insights instead.
#
# There are no metric alerts on what the connectors publish. Azure records a custom
# metric that stops arriving as no data rather than zero, so a "samples stopped" rule
# never fires. The per-connector health metric is published on each VM, which a rule
# scoped to the scale set does not see, and rules spanning many VMs take platform metrics
# only. The function's health monitor reads that metric every minute, and the health
# verdict rule below reports what it decides.
#
# Nothing depends on this module. An empty notification_email still creates the action
# group, just with nobody on it.

resource "azurerm_monitor_action_group" "zscc" {
  name                = local.action_group_name
  resource_group_name = var.resource_group_name
  short_name          = "zscc"
  tags                = var.tags

  dynamic "email_receiver" {
    for_each = local.email_receivers
    content {
      name                    = email_receiver.key
      email_address           = email_receiver.value
      use_common_alert_schema = true
    }
  }
}

# Fewer than half the connectors are passing the load balancer's health probe. The
# workload default route points at this load balancer, so this is the alert that means
# traffic is at risk rather than that something is degraded.
resource "azurerm_monitor_metric_alert" "lb_health" {
  name                = "${var.name_prefix}alt-lb-health-${var.name_suffix}"
  resource_group_name = var.resource_group_name
  scopes              = [var.load_balancer_id]
  description         = "Fewer than half the connectors are passing the load balancer health probe."
  severity            = 1
  frequency           = "PT1M"
  window_size         = "PT5M"
  tags                = var.tags

  criteria {
    metric_namespace = "Microsoft.Network/loadBalancers"
    metric_name      = "DipAvailability"
    aggregation      = "Average"
    operator         = "LessThan"
    threshold        = 50
  }

  action {
    action_group_id = azurerm_monitor_action_group.zscc.id
  }
}

# The lifecycle function has not run in two of its own sync intervals, so nothing is
# reconciling the portal against what is actually deployed. The package's host.json
# excludes requests from sampling, so every execution is recorded as a request.
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "heartbeat" {
  name                    = "${var.name_prefix}alt-func-heartbeat-${var.name_suffix}"
  resource_group_name     = var.resource_group_name
  location                = var.location
  scopes                  = [var.app_insights_id]
  description             = "The lifecycle function produced no executions across two sync intervals."
  severity                = local.severity
  enabled                 = true
  evaluation_frequency    = local.query_frequency
  window_duration         = local.heartbeat_window
  auto_mitigation_enabled = true
  tags                    = var.tags

  criteria {
    query                   = local.heartbeat_query
    time_aggregation_method = "Count"
    operator                = "LessThan"
    threshold               = 1

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  action {
    action_groups = [azurerm_monitor_action_group.zscc.id]
  }
}

# A connector was judged unhealthy, or terminated. Replacement is automatic - this is
# telling you it happened, not asking you to do something.
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "health_verdict" {
  name                    = "${var.name_prefix}alt-health-verdict-${var.name_suffix}"
  resource_group_name     = var.resource_group_name
  location                = var.location
  scopes                  = [var.app_insights_id]
  description             = "The health monitor judged a connector unhealthy or terminated one. Replacement is automatic; this reports that it happened."
  severity                = local.severity
  enabled                 = true
  evaluation_frequency    = local.query_frequency
  window_duration         = local.query_window
  auto_mitigation_enabled = true
  tags                    = var.tags

  criteria {
    query                   = local.health_verdict_query
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  action {
    action_groups = [azurerm_monitor_action_group.zscc.id]
  }
}

# The function hit an error it handled internally. Nothing failed loudly, so this query
# is the only thing that surfaces it.
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "func_errors" {
  name                    = "${var.name_prefix}alt-func-errors-${var.name_suffix}"
  resource_group_name     = var.resource_group_name
  location                = var.location
  scopes                  = [var.app_insights_id]
  description             = "The lifecycle function logged an error-level trace."
  severity                = local.severity
  enabled                 = true
  evaluation_frequency    = local.query_frequency
  window_duration         = local.query_window
  auto_mitigation_enabled = true
  tags                    = var.tags

  criteria {
    query                   = local.func_errors_query
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  action {
    action_groups = [azurerm_monitor_action_group.zscc.id]
  }
}
