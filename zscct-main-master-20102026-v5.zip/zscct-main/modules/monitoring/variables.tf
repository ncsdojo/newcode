variable "name_prefix" {
  description = "Leading name component, <app><environment>arm - e.g. ccprdarm."
  type        = string
}

variable "name_suffix" {
  description = "Trailing name component, <region><instance> - e.g. uw2001."
  type        = string
}

variable "location" {
  description = "Region the log alert rules are created in. Keep it with the Application Insights they query. The metric rule is global."
  type        = string
}

variable "resource_group_name" {
  description = "Group the action group and alert rules are created in."
  type        = string
}

variable "tags" {
  description = "Tags applied to the action group and every rule."
  type        = map(string)
  default     = {}
}

variable "notification_email" {
  description = "Action group email receivers. Empty creates the group with no receivers: the rules still fire in the portal, but nobody is notified."
  type        = list(string)
  default     = []
}

variable "load_balancer_id" {
  description = "Internal load balancer id, from load-balancer. The scope of the health probe rule."
  type        = string
}

variable "app_insights_id" {
  description = "Application Insights component id, from function-app. The scope of the three log alerts."
  type        = string
}

variable "sync_interval_minutes" {
  description = "How often the vendor package runs its sync (Zscaler documents every 30 minutes). Sizes the heartbeat window, which is two intervals rounded up to a window Azure accepts; it does not change the package's own timer."
  type        = number
  default     = 30
  validation {
    # Two intervals have to fit the longest log alert window Azure accepts, two days.
    condition     = var.sync_interval_minutes >= 1 && var.sync_interval_minutes <= 1440
    error_message = "sync_interval_minutes must be between 1 and 1440."
  }
}
