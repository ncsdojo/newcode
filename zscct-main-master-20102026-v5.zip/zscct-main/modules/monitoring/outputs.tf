output "action_group_id" {
  description = "Action group id. Every rule here already targets it; exported for rules defined elsewhere."
  value       = azurerm_monitor_action_group.zscc.id
}
