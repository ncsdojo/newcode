locals {
  action_group_name = "${var.name_prefix}ag${var.name_suffix}"
  severity          = 2
  query_frequency   = "PT15M"
  query_window      = "PT15M"

  # Keyed email0, email1, ... - the receiver name has to be stable and unique per address.
  email_receivers = { for i, a in var.notification_email : "email${i}" => a }

  # Windows a log alert accepts at a 15-minute frequency, shortest first. The heartbeat
  # takes the shortest one covering two sync intervals.
  allowed_windows = [
    { minutes = 15, duration = "PT15M" },
    { minutes = 30, duration = "PT30M" },
    { minutes = 45, duration = "PT45M" },
    { minutes = 60, duration = "PT1H" },
    { minutes = 120, duration = "PT2H" },
    { minutes = 180, duration = "PT3H" },
    { minutes = 240, duration = "PT4H" },
    { minutes = 300, duration = "PT5H" },
    { minutes = 360, duration = "PT6H" },
    { minutes = 1440, duration = "P1D" },
    { minutes = 2880, duration = "P2D" },
  ]
  heartbeat_window = [for w in local.allowed_windows : w.duration if w.minutes >= var.sync_interval_minutes * 2][0]

  # Each rule counts the rows its query returns, so the queries filter and stop there. A
  # trailing summarize would always return exactly one row and pin the count at 1.

  # Only the sync function. The package's other function, healthMonitor, runs every
  # minute, so counting every request would hide a sync that had stopped.
  heartbeat_query = <<-KQL
    requests
    | where name == "synchronizeCloudResources"
  KQL

  # Message text is the vendor package's own (1.0.3), matched as written, typos included.
  health_verdict_query = <<-KQL
    traces
    | where message has_any ("Instance is unhealthy, adding it to the termination list", "Failed provisioning state", "Successfully initiated termination")
  KQL

  # No severity filter: the package logs these at error level, but matching on the text
  # alone does not depend on how the host maps that level.
  func_errors_query = <<-KQL
    traces
    | where message has_any ("Failed to synchronize resources", "Failed to clean up stale instance", "Failed to update VMSS Config", "Failed to monitor health", "Failed to terminate instance", "Failed to evaluate health", "Authentication failed", "API request failed", "Error occurred during API request", "Maximum number of retries reached", "does not exist", "Missing ENV Varibales", "Failed to load")
  KQL
}
