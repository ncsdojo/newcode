# Everything this environment attaches to rather than creates: the resource group, the
# VNet, its subnets and the privatelink DNS zones.
#
# These are plain data sources rather than a flag on the modules. The VNet, subnets and
# DNS zones are either all created or all attached, so the decision is made once here
# and the vnet, subnets and private-dns modules are simply not called in this
# environment. To build them here instead, copy those module blocks over from
# the greenfield template and delete the lookups below.

# Whoever is running Terraform. Its tenant_id configures the Key Vault.
data "azurerm_client_config" "current" {}

data "azurerm_resource_group" "zscc" {
  name = var.resource_group_name
}

data "azurerm_virtual_network" "zscc" {
  name                = var.vnet_name
  resource_group_name = var.vnet_resource_group_name
}

data "azurerm_subnet" "mgmt" {
  name                 = var.mgmt_subnet_name
  virtual_network_name = data.azurerm_virtual_network.zscc.name
  resource_group_name  = data.azurerm_virtual_network.zscc.resource_group_name
}

data "azurerm_subnet" "service" {
  name                 = var.service_subnet_name
  virtual_network_name = data.azurerm_virtual_network.zscc.name
  resource_group_name  = data.azurerm_virtual_network.zscc.resource_group_name
}

data "azurerm_subnet" "lb" {
  name                 = var.lb_subnet_name
  virtual_network_name = data.azurerm_virtual_network.zscc.name
  resource_group_name  = data.azurerm_virtual_network.zscc.resource_group_name
}

data "azurerm_subnet" "funcapp" {
  name                 = var.funcapp_subnet_name
  virtual_network_name = data.azurerm_virtual_network.zscc.name
  resource_group_name  = data.azurerm_virtual_network.zscc.resource_group_name
}

# The hub owns these and has already linked them to the VNet. Azure will not accept a
# second zone of the same name on the same VNet, so we look them up rather than create
# our own.
#
# Read through the dns alias, because the zones can sit in a different subscription.
# See providers.tf.
data "azurerm_private_dns_zone" "vault" {
  provider            = azurerm.dns
  name                = "privatelink.vaultcore.azure.net"
  resource_group_name = var.private_dns_resource_group_name
}

# The function's storage account has public access disabled, so its host reaches blob,
# queue and table storage through private endpoints. All three zones are required.
data "azurerm_private_dns_zone" "blob" {
  provider            = azurerm.dns
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = var.private_dns_resource_group_name
}

data "azurerm_private_dns_zone" "queue" {
  provider            = azurerm.dns
  name                = "privatelink.queue.core.windows.net"
  resource_group_name = var.private_dns_resource_group_name
}

data "azurerm_private_dns_zone" "table" {
  provider            = azurerm.dns
  name                = "privatelink.table.core.windows.net"
  resource_group_name = var.private_dns_resource_group_name
}

data "azurerm_private_dns_zone" "sites" {
  provider            = azurerm.dns
  count               = var.enable_function_private_endpoint ? 1 : 0
  name                = "privatelink.azurewebsites.net"
  resource_group_name = var.private_dns_resource_group_name
}

# The subnet the route table in main.tf attaches to, when workload_subnet_name names one.
data "azurerm_subnet" "workload" {
  count                = var.workload_subnet_name == "" ? 0 : 1
  name                 = var.workload_subnet_name
  virtual_network_name = data.azurerm_virtual_network.zscc.name
  resource_group_name  = data.azurerm_virtual_network.zscc.resource_group_name
}

# Looked up whether or not this deployment builds a Bastion, because the Bastion may be
# one the platform team already runs, and the NSG still needs its range as the SSH
# source. Set bastion_subnet_name to "" where no Bastion exists at all.
data "azurerm_subnet" "bastion" {
  count                = var.bastion_subnet_name == "" ? 0 : 1
  name                 = var.bastion_subnet_name
  virtual_network_name = data.azurerm_virtual_network.zscc.name
  resource_group_name  = data.azurerm_virtual_network.zscc.resource_group_name
}
