output "resource_group" {
  description = "Group everything was deployed into. Pre-created; looked up by this environment."
  value       = local.resource_group_name
}

output "virtual_network" {
  description = "VNet the subnets live in. Created by this environment."
  value       = module.vnet.name
}

output "nat_gateway_public_ip" {
  description = "NAT egress address - allowlist this in the Zscaler portal. A CIDR range when the gateway uses a public IP prefix."
  value       = module.nat_gateway.egress
}

output "lb_frontend_ip" {
  description = "Internal LB frontend - next hop for workload/spoke UDRs."
  value       = module.load_balancer.frontend_private_ip
}

output "bastion_name" {
  description = "Bastion host name, or null when Bastion is not deployed."
  value       = one(module.bastion[*].name)
}

output "bastion_private_only" {
  description = "True when the Bastion has no public IP and is reached only from inside the network (ExpressRoute, VPN or peering), with az network bastion ssh. Null when Bastion is not deployed."
  value       = one(module.bastion[*].private_only)
}

output "function_package_url" {
  description = "Where the lifecycle function runs its package from."
  value       = module.function_app.package_url
}

output "vmss_names" {
  description = "Connector scale sets, in zone order."
  value       = [for z in var.zones : local.vmss_names[z]]
}

output "cc_identity_client_id" {
  description = "Connector identity client id, as written into cloud-init."
  value       = module.identity.cc_client_id
}

output "key_vault_uri" {
  description = "Vault URI the connectors and the function read credentials from."
  value       = module.key_vault.vault_uri
}

output "function_app" {
  description = "Lifecycle Function App name."
  value       = module.function_app.name
}

output "funcapp_principal_id" {
  description = "Function identity principal id. This environment grants it everything it needs to start replacement connectors."
  value       = module.identity.funcapp_principal_id
}
