# One state file per environment, in a storage account the platform team owns. Never the
# storage account this configuration creates - that one gets destroyed along with
# everything else, and it would take the state with it.
#
# Fill in the placeholders below, or leave them out and pass them at init time, which is
# what CI should do:
#
#   terraform init \
#     -backend-config="resource_group_name=<state-resource-group>" \
#     -backend-config="storage_account_name=<state-storage-account>" \
#     -backend-config="container_name=tfstate" \
#     -backend-config="key=zscc/<region>/<environment>.tfstate"
#
# use_azuread_auth keeps state access on Entra ID rather than storage keys, same as the
# rest of this deployment. Whoever runs Terraform needs Storage Blob Data Contributor on
# the state container.
#
# The backend authenticates on its own. It does not read provider "azurerm" and does not
# inherit its subscription, so where the state account lives outside the subscription
# this deployment targets, subscription_id is not optional.
terraform {
  backend "azurerm" {
    subscription_id      = "<state-storage-subscription-guid>"
    resource_group_name  = "<state-resource-group>"
    storage_account_name = "<state-storage-account>"
    container_name       = "tfstate"
    key                  = "zscc/<region>/<environment>.tfstate"
    use_azuread_auth     = true
  }
}
