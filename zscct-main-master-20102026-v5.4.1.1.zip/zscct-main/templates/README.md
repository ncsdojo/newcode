# Environment templates

Two starting points for a new Cloud Connector environment. Pick the one that
matches what already exists in the target subscription.

| Template | Use when | Modelled on |
|---|---|---|
| `greenfield/` | Only the resource group exists. The deployment creates its own virtual network, subnets and private DNS zones. | `environments/westus2/dev` |
| `brownfield/` | The resource group, virtual network, subnets and private DNS zones already exist and belong to someone else. The deployment attaches to them and creates none of them. | `environments/westus2/prod` |

The difference between the two is not a flag. It is which modules the environment
calls. `greenfield` calls the `vnet`, `subnets` and `private-dns` modules;
`brownfield` does not call them at all and reads the same things from data
sources in `data.tf`. Everything from the NSGs onward is the same in both, apart from
what attaching to someone else's subnets needs: `brownfield` can leave the NSGs and
NAT gateway to the platform team, and attaches a route table only to a subnet named in
`workload_subnet_name`.

## Using one

Copy the whole folder into the environments tree, then fill in the placeholders:

```
cp -r templates/brownfield environments/<region>/<environment>
```

**Copy it, do not apply it in place.** The module paths are written as
`../../../modules/...`, which is correct from `environments/<region>/<environment>/`
and wrong from `templates/<kind>/`. A template will not `init` where it sits, by
design.

Then work through, in order:

1. `terraform.tfvars` — every `<placeholder>` needs a real value. The naming
   tokens (`app_code`, `env_code`, `region_code`, `instance`) build every
   resource name, so get them right before the first apply; changing one later
   renames everything.
2. `backend.tf` — point the `azurerm` block at the state storage account for
   this environment, or pass the same values to `terraform init -backend-config`.
   Do not swap in a `local` backend for anything shared: the state holds the
   Zscaler portal credentials in plain text.
3. `variables.tf` — only if a default is wrong for this environment. Most
   environments change nothing here.

## Regions without availability zones

UK West and West Central US have no availability zones. In either, set
`zones_enabled = false` and `zones = ["1"]` in `terraform.tfvars`. The deployment
then builds one regional scale set instead of one per zone, gives the load balancer
frontend no zone, and uses LRS rather than ZRS storage for the function, because ZRS
needs zones. Everywhere else, leave `zones_enabled` at its default of `true`.

West Central US also does not offer Application Insights. Set
`app_insights_location = "westus2"` there, and Application Insights and the function's
log alerts are created in West US 2 while everything else stays in West Central US.

## Before the first apply

Three things no `tfvars` value can supply:

- **Portal credentials.** Never in `tfvars`. Export them:
  ```
  $env:TF_VAR_zscaler_api_key  = "<portal api key>"
  $env:TF_VAR_zscaler_username = "<portal admin>"
  $env:TF_VAR_zscaler_password = "<portal password>"
  ```
- **The marketplace offer**, accepted on the target subscription. It is per
  subscription and is not inherited from another environment.
- **A provisioning template of its own** in the Zscaler console, whose URL goes in
  `provisioning_url`. A template shared with another environment would put these
  connectors in front of that environment's lifecycle function, which deletes portal
  entries whose VMs are gone.

Then apply once, from anywhere. The Key Vault and the function's storage are
private from the start - the Org-Delta policies refuse anything else - and the apply
never touches their data planes: the secrets are written through Resource Manager,
and the function runs Zscaler's package from a commit-pinned URL. The one public
resource is the NAT gateway's egress address, which needs a policy exemption or an
allowed alternative; see "Org-Delta policy" in the top-level README.

## What has been removed

These are sanitized copies. Real subscription ids, resource group names, virtual
network names and address ranges have been replaced with placeholders. The
address ranges in `greenfield/terraform.tfvars` are a worked example on
`10.0.0.0/23` that satisfies the subnet size checks in
`modules/network/subnets`; they are not anyone's real allocation and are there
to show the shape, not to be used.

## Keeping these current

These are snapshots, not living code. When a module gains or loses a variable,
update both templates in the same change; a copied template that is out of step
fails to plan.
