# ==============================================================================
# brownfield template
#
# Attaches to a resource group, VNet and subnets the platform team already created.
# This file names them; data.tf looks them up.
#
# Secrets are NOT here. Export them before applying:
#   $env:TF_VAR_zscaler_api_key  = "<portal api key>"
#   $env:TF_VAR_zscaler_username = "<portal admin>"
#   $env:TF_VAR_zscaler_password = "<portal password>"
# ==============================================================================

# A. Azure basics
subscription_id = "<subscription-guid>"
location        = "<azure-region>"
environment     = "<environment>"

# LLD naming tokens. Names are built as
#   <app_code><env_code>arm  +  <type>  +  <region_code><instance>
# e.g. cc + prd + arm + nsg-mgmt- + uw2 + 001  ->  ccprdarmnsg-mgmt-uw2001
app_code    = "cc"
env_code    = "<3-char-env-code>"
region_code = "<3-char-region-code>"
instance    = "001"

# B. Uniqueness - must differ from every other environment (storage account and
#    key vault names are globally unique).
# PowerShell:  -join ((48..57)+(97..102) | Get-Random -Count 8 | % {[char]$_})
# or bash:     openssl rand -hex 4     (run twice, one per line)
short_id  = "<8-hex>"
kv_suffix = "<8-hex>"

# C. The pre-created foundation
resource_group_name      = "<PRE-CREATED-RG-NAME>"
vnet_name                = "<PRE-CREATED-VNET-NAME>"
vnet_resource_group_name = "<GROUP-HOLDING-THE-VNET>" # often the platform team's

# privatelink.vaultcore.azure.net, privatelink.blob.core.windows.net,
# privatelink.queue.core.windows.net and privatelink.table.core.windows.net (and
# privatelink.azurewebsites.net if the Function App gets a private endpoint) must
# already exist here AND already be linked to the VNet above. This environment creates
# neither the zones nor the links. Queue and table are new: the function's storage
# account has public access disabled, so its host reaches all three services through
# private endpoints.
private_dns_resource_group_name = "<GROUP-HOLDING-THE-PRIVATELINK-ZONES>"

# The VNet has to be in the subscription above: Azure attaches NICs, private endpoints,
# NSGs, NAT gateways and route tables only to a VNet in their own subscription.
#
# The privatelink zones can be elsewhere, such as a central DNS subscription. Set this
# when they are, or remove the line. Wherever they live, the identity running the apply
# needs Reader plus Private DNS Zone Contributor on them.
private_dns_subscription_id = "<PRIVATE-DNS-SUBSCRIPTION-GUID>"

# Regions without availability zones (UK West and West Central US among ours): set
# zones_enabled = false and zones = ["1"]. That builds one regional scale set, a load
# balancer frontend with no zone, and LRS storage for the function. Two connectors are
# enough there, so set desired_instances and min_instances to 2 in section H.
zones_enabled = true

# One management and one service subnet, shared by connectors in every zone. Ask the
# platform team for /26 or larger on both, and for endpoint network policies to be
# disabled on the management subnet - the private endpoints terminate there.
zones               = ["1", "2"]
mgmt_subnet_name    = "<mgmt-subnet>"
service_subnet_name = "<service-subnet>"
lb_subnet_name      = "<lb-frontend-subnet>"
funcapp_subnet_name = "<funcapp-subnet>" # delegated to Microsoft.Web/serverFarms

# A subnet to steer through the connectors with a route table this deployment owns,
# such as a temporary validation subnet. "" attaches none.
workload_subnet_name = ""

# AVD session-host route tables that should get the Zscaler VDI route (185.46.212.80/32
# to the load balancer). Opt-in, because the tables are the platform team's; leave it
# empty and the README lists the routes to add by hand. Whoever runs Terraform needs
# Network Contributor on each table. Set spoke_subscription_id only where the tables are
# not in subscription_id.
# spoke_subscription_id = "<AVD-SPOKE-SUBSCRIPTION-GUID>"
spoke_route_tables = {
  # avd = { name = "<avd-route-table>", resource_group_name = "<its-resource-group>" }
}

# Terraform will not take over an NSG or NAT gateway already attached to these subnets.
# Set false for whichever the platform team attaches itself.
attach_nsgs        = true
attach_nat_gateway = true
# The Function App subnet's NSG - its outbound firewall, HTTPS, HTTP and DNS only. Set
# false where the platform attaches its own there; it must then allow the same.
attach_funcapp_nsg = true

# The NAT gateway's egress address. Org-Delta refuses Microsoft.Network/publicIPAddresses,
# so either the exemption for this one public IP is in place (runbook A5), or the
# platform team allows a prefix ("prefix"), or it hands over one it created.
nat_gateway_public_ip_mode = "ip"
# nat_gateway_existing_public_ip_id = "/subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Network/publicIPAddresses/<name>"

# Starting a replacement connector needs the function identity to hold join rights on
# the management and service subnets. true (the default) makes that grant in the apply,
# so nothing is left to do afterwards - which needs whoever runs Terraform to be able to
# assign roles on the platform's subnets: ask the platform team for Role Based Access
# Control Administrator on the VNet's resource group before the first apply. Only where
# they will not, set false and they make the grant themselves (README step 5). The
# function's grants on the resource group and the connector identity are always made
# here.
grant_function_subnet_join = true

# Bastion, if wanted, uses the subnet named AzureBastionSubnet in the same VNet.
enable_bastion = false
# If enabled: Premium, private-only, no public IP - reached over ExpressRoute or VPN.
bastion_sku = "Premium"

# D. Zscaler side - from the Zscaler console (Cloud & Branch Connector >
#      provisioning template) and your Cyber team. A template this environment
#      shares with no other.
provisioning_url = "<connector provisioning URL>"
zscaler_cloud    = "<e.g. zscalertwo>"

# E. Connector access
# ssh-keygen -t rsa -b 4096 -f zscc_key -N ""   -> paste zscc_key.pub content
ssh_public_key = "<ssh-rsa AAAA...>"

# F. Behavior - matches your proven PowerShell run; change only knowingly
# Roles by name - built-in, or custom roles the platform team already defined.
connector_role_names = ["Reader", "Monitoring Metrics Publisher"]
function_role_names  = ["Reader"]

disable_health_remediation = false
accept_marketplace_terms   = false # owner accepted terms at the subscription
notification_email         = []    # e.g. ["ops@example.com"]
enable_resource_locks      = true

# G. One apply. The Key Vault and the function's storage are private from the start and
#    the apply never touches their data planes, so there is no second, locking apply
#    and no deployer IP to allowlist.

# H. Capacity
desired_instances = 2
min_instances     = 2
max_instances     = 4

# I. Optional overrides (defaults shown; uncomment to change)
# app_insights_location = null  # e.g. "westus2" where Application Insights is not offered, such as West Central US
# vm_size                          = "Standard_D2s_v3"
# image_version                    = "latest"   # pin an exact x.y.z for prod
# http_probe_port                  = 50000
# enable_support_tunnel            = true
# support_server_ip                = "199.168.148.101"  # remotesupport.<cloud>.net on Zscaler's commercial clouds
# encrypt_at_host                  = false
# app_service_plan_sku             = "P0v3"   # must stay Dedicated: storage keys are disabled
# enable_function_private_endpoint = false    # public inbound access is off either way
# scheduled_scaling                = false
# workload_cidrs                   = []
# ssh_source_cidr                  = "VirtualNetwork"  # used only when bastion_subnet_name = ""
# additional_tags                  = { "cost-centre" = "", "owner" = "" }
