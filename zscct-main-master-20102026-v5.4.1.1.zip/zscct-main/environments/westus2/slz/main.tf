# westus2 / slz
#
# This file only wires modules together. Resources are declared in the modules and
# names are built there too.
#
# slz attaches to a resource group, VNet, subnets and DNS zones the platform team
# already created. Those are data lookups in data.tf, which is why there are no vnet,
# subnets or private-dns module calls here. Everything below them is the same as dev
# (environments/westus2/dev/main.tf) except the network services, where attaching to
# somebody else's subnets needs a few choices of its own.

# Network services
#
# The NSGs and the NAT gateway attach to subnets the platform team owns. A subnet takes
# one of each, and Terraform will not take over one that is already attached - the apply
# stops instead - so where the platform attaches its own, attach_nsgs or
# attach_nat_gateway leaves theirs in place and creates none here.
module "nsg" {
  source = "../../../modules/network/nsg"
  count  = var.attach_nsgs ? 1 : 0

  name_prefix = local.name_prefix

  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  tags                = local.tags

  mgmt_subnet_id    = local.mgmt_subnet_id
  service_subnet_id = local.service_subnet_id

  # The Function App's outbound firewall: HTTPS, HTTP and DNS only.
  funcapp_nsg_enabled = var.attach_funcapp_nsg
  funcapp_subnet_id   = local.funcapp_subnet_id

  private_endpoint_client_cidrs = local.private_endpoint_client_cidrs

  bastion_subnet_cidr   = local.bastion_subnet_cidr
  ssh_source_cidr       = var.ssh_source_cidr
  enable_support_tunnel = var.enable_support_tunnel
  support_server_ip     = var.support_server_ip
  http_probe_port       = var.http_probe_port
  workload_cidrs        = var.workload_cidrs
}

module "nat_gateway" {
  source = "../../../modules/network/nat-gateway"
  count  = var.attach_nat_gateway ? 1 : 0

  name_prefix = local.name_prefix

  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  tags                = local.tags

  mgmt_subnet_id    = local.mgmt_subnet_id
  service_subnet_id = local.service_subnet_id
  funcapp_subnet_id = local.funcapp_subnet_id

  public_ip_mode          = var.nat_gateway_public_ip_mode
  existing_public_ip_id   = var.nat_gateway_existing_public_ip_id
  public_ip_prefix_length = var.nat_gateway_public_ip_prefix_length
}

# These two calls had no count when this environment was first applied.
moved {
  from = module.nsg
  to   = module.nsg[0]
}

moved {
  from = module.nat_gateway
  to   = module.nat_gateway[0]
}

module "load_balancer" {
  source = "../../../modules/network/load-balancer"

  name_prefix = local.name_prefix

  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  tags                = local.tags

  zones           = var.zones
  zones_enabled   = var.zones_enabled
  subnet_id       = local.lb_subnet_id
  http_probe_port = var.http_probe_port
}

# Steers the subnet named in workload_subnet_name through the connectors - a temporary
# validation subnet, typically. The platform team routes real workloads at lb_frontend_ip
# from their own route tables.
module "route_table" {
  source = "../../../modules/network/route-table"
  count  = var.workload_subnet_name == "" ? 0 : 1

  name_prefix = local.name_prefix

  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  tags                = local.tags

  workload_subnet_id = local.workload_subnet_id
  next_hop_ip        = module.load_balancer.frontend_private_ip
}

# Adds the Zscaler VDI routes to route tables the platform team already runs on AVD
# session-host subnets, through the spoke provider alias. Opt-in: spoke_route_tables is
# empty unless someone names a table, because those tables are not this deployment's.
# The README section on routing AVD session hosts lists the routes for anyone adding them
# by hand instead.
module "spoke_routes" {
  source   = "../../../modules/network/spoke-routes"
  for_each = var.spoke_route_tables

  providers = {
    azurerm = azurerm.spoke
  }

  route_table_name                = each.value.name
  route_table_resource_group_name = each.value.resource_group_name
  next_hop_ip                     = module.load_balancer.frontend_private_ip
  include_default_route           = each.value.include_default_route
}

# count rather than a variable inside the module, so turning Bastion off means this is
# not evaluated at all.
module "bastion" {
  source = "../../../modules/network/bastion"
  count  = var.enable_bastion ? 1 : 0

  name_prefix = local.name_prefix

  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  tags                = local.tags
  subnet_id           = local.bastion_subnet_id
  sku                 = var.bastion_sku

  client_source_address_prefix = var.bastion_client_source_address_prefix
  # The platform's AzureBastionSubnet may already carry an NSG of its own.
  attach_nsg = var.attach_nsgs
}

# The connectors and everything that supports them

module "identity" {
  source = "../../../modules/identity"

  name_prefix = local.name_prefix

  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  resource_group_id   = local.resource_group_id
  tags                = local.tags

  connector_role_names = var.connector_role_names
  function_role_names  = var.function_role_names
}

module "key_vault" {
  source = "../../../modules/key-vault"

  name                = local.key_vault_name
  location            = var.location
  resource_group_name = local.resource_group_name
  tags                = local.tags

  tenant_id = data.azurerm_client_config.current.tenant_id

  cc_principal_id      = module.identity.cc_principal_id
  funcapp_principal_id = module.identity.funcapp_principal_id

  enable_purge_protection = var.enable_purge_protection

  zscaler_api_key  = var.zscaler_api_key
  zscaler_username = var.zscaler_username
  zscaler_password = var.zscaler_password

  private_endpoint_subnet_id = local.mgmt_subnet_id
  private_dns_zone_id        = local.vault_dns_zone_id
}

module "function_app" {
  source = "../../../modules/function-app"

  name                = local.function_app_name
  short_id            = var.short_id
  name_prefix         = local.name_prefix
  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  tags                = local.tags

  subscription_id      = var.subscription_id
  app_service_plan_sku = var.app_service_plan_sku
  # ZRS needs availability zones, so a region without them falls back to LRS.
  storage_replication_type = var.zones_enabled ? "ZRS" : "LRS"
  app_insights_location    = var.app_insights_location

  funcapp_identity_id  = module.identity.funcapp_identity_id
  funcapp_client_id    = module.identity.funcapp_client_id
  funcapp_principal_id = module.identity.funcapp_principal_id

  subnet_id                  = local.funcapp_subnet_id
  private_endpoint_subnet_id = local.mgmt_subnet_id
  private_dns_zone_id        = local.sites_dns_zone_id

  blob_private_dns_zone_id  = local.blob_dns_zone_id
  queue_private_dns_zone_id = local.queue_dns_zone_id
  table_private_dns_zone_id = local.table_dns_zone_id

  key_vault_uri              = module.key_vault.vault_uri
  provisioning_url           = var.provisioning_url
  vmss_names                 = [for z in var.zones : local.vmss_names[z]]
  disable_health_remediation = var.disable_health_remediation

  enable_private_endpoint = var.enable_function_private_endpoint
  function_package_url    = var.function_package_url

  # The app starts as soon as it exists. Its outbound calls leave through the NAT
  # gateway, and its subnet's NSG should be in place before its first connection rather
  # than after.
  depends_on = [
    module.nat_gateway,
    module.nsg,
  ]
}

module "compute" {
  source = "../../../modules/compute"

  zones               = var.zones
  zones_enabled       = var.zones_enabled
  vmss_names          = local.vmss_names
  name_prefix         = local.name_prefix
  name_suffix         = local.name_suffix
  location            = var.location
  resource_group_name = local.resource_group_name
  resource_group_id   = local.resource_group_id
  tags                = local.tags

  vm_size                = var.vm_size
  image_version          = var.image_version
  admin_username         = var.admin_username
  ssh_public_key         = var.ssh_public_key
  encrypt_at_host        = var.encrypt_at_host
  accelerated_networking = var.accelerated_networking

  mgmt_subnet_id             = local.mgmt_subnet_id
  service_subnet_id          = local.service_subnet_id
  lb_backend_address_pool_id = module.load_balancer.backend_address_pool_id

  cc_identity_id        = module.identity.cc_identity_id
  cc_identity_client_id = module.identity.cc_client_id
  key_vault_uri         = module.key_vault.vault_uri

  provisioning_url = var.provisioning_url
  zscaler_cloud    = var.zscaler_cloud
  http_probe_port  = var.http_probe_port

  desired_instances          = var.desired_instances
  min_instances              = var.min_instances
  max_instances              = var.max_instances
  scale_out_threshold        = var.scale_out_threshold
  scale_in_threshold         = var.scale_in_threshold
  scale_out_cooldown_minutes = var.scale_out_cooldown_minutes
  scale_in_cooldown_minutes  = var.scale_in_cooldown_minutes

  scheduled_scaling       = var.scheduled_scaling
  scheduled_min_instances = var.scheduled_min_instances
  scheduled_days          = var.scheduled_days
  scheduled_start_hour    = var.scheduled_start_hour
  scheduled_start_minute  = var.scheduled_start_minute
  scheduled_end_hour      = var.scheduled_end_hour
  scheduled_end_minute    = var.scheduled_end_minute
  scheduled_timezone      = var.scheduled_timezone

  disable_health_remediation = var.disable_health_remediation
  funcapp_principal_id       = module.identity.funcapp_principal_id
  remediation_role_name      = var.remediation_role_name
  # The subnets are the platform team's, outside the deployment resource group, so the
  # function's remediation role there does not reach them. Where whoever runs Terraform
  # can assign roles on them, grant_function_subnet_join makes this grant here too;
  # otherwise the platform team makes it (README step 5).
  grant_function_subnet_join = var.grant_function_subnet_join
  accept_marketplace_terms   = var.accept_marketplace_terms

  # A connector reads its credentials from the vault the moment it boots, through the
  # vault's private endpoint, and needs egress to reach the Zscaler cloud. So none of
  # them starts before the identity has access, the secrets are written, egress works
  # and the NSGs are on - and none before the load balancer's rule and probe exist, so
  # every connector is probed from its first boot. Passing the subnet and identity ids
  # only gets us part of that ordering; these cover the rest. Autoscale and the
  # lifecycle function create later connectors into exactly the same conditions.
  depends_on = [
    module.identity,
    module.key_vault,
    module.nat_gateway,
    module.nsg,
    module.load_balancer,
  ]
}

module "monitoring" {
  source = "../../../modules/monitoring"

  name_prefix = local.name_prefix
  name_suffix = local.name_suffix

  # The log alerts sit with the Application Insights they query.
  location            = coalesce(var.app_insights_location, var.location)
  resource_group_name = local.resource_group_name
  tags                = local.tags

  notification_email    = var.notification_email
  sync_interval_minutes = var.sync_interval_minutes
  app_insights_id       = module.function_app.app_insights_id
  load_balancer_id      = module.load_balancer.id
}

module "locks" {
  source = "../../../modules/locks"

  enabled = var.enable_resource_locks

  # No VNet entry: the VNet is the platform team's. No route table either, because the
  # one workload_subnet_name gets is for a temporary subnet and has to come out before
  # that subnet is deleted.
  scopes = merge(
    {
      kv    = module.key_vault.id
      lb    = module.load_balancer.id
      ident = module.identity.cc_identity_id
    },
    # The NAT egress address, only when this deployment created it.
    var.attach_nat_gateway && var.nat_gateway_existing_public_ip_id == null ? { nat_ip = module.nat_gateway[0].public_ip_id } : {},
  )

  # Listed here so the locks are created last and, on a destroy, removed first.
  depends_on = [
    module.nsg,
    module.nat_gateway,
    module.load_balancer,
    module.identity,
    module.key_vault,
    module.function_app,
    # The function's grant on the connector identity sits under that identity's lock,
    # so the locks come off before the grant is deleted.
    module.compute,
  ]
}
