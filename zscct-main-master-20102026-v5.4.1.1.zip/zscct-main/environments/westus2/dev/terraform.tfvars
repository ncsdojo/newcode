# ==============================================================================
# westus2 / dev
#
# dev is greenfield: it creates its own VNet, subnets and DNS zones, so the network
# inputs here are CIDRs. The resource group is pre-created and named below.
#
# Secrets are NOT here. Export them before applying:
#   $env:TF_VAR_zscaler_api_key  = "<portal api key>"
#   $env:TF_VAR_zscaler_username = "<portal admin>"
#   $env:TF_VAR_zscaler_password = "<portal password>"
#
# Other differences from prod are deliberate: a single zone, smaller capacity, no
# resource locks, and purge protection off so the vault can be torn down and rebuilt.
#
# One apply reaches the end state, from anywhere: the Key Vault and the function's
# storage are private from the start (Org-Delta denies anything else), and nothing in
# the apply needs their data planes.
# ==============================================================================

# A. Azure basics
subscription_id     = "<azure-subscription-guid>"
resource_group_name = "<name-of-the-pre-created-group>"
location            = "westus2"
environment         = "dev"

# LLD naming tokens. Names are built as
#   <app_code><env_code>arm  +  <type>  +  <region_code><instance>
# e.g. cc + dev + arm + nsg-mgmt- + uw2 + 001  ->  ccdevarmnsg-mgmt-uw2001
app_code    = "cc"
env_code    = "dev"
region_code = "uw2"
instance    = "001"

# B. Uniqueness - must differ from every other environment (storage account and
#    key vault names are globally unique).
# PowerShell:  -join ((48..57)+(97..102) | Get-Random -Count 8 | % {[char]$_})
# or bash:     openssl rand -hex 4     (run twice, one per line)
short_id  = "<8-hex>"
kv_suffix = "<8-hex>"

# C. Network plan - 10.157.110.0/23.
#
# One management and one service subnet, shared by connectors in every zone. Both /26
# so max_instances can rise without re-addressing. The NAT gateway in front of them is
# zone-redundant, so nothing here is pinned to a zone.
vnet_address_space   = "10.157.110.0/23"
zones                = ["1"]
mgmt_subnet_cidr     = "10.157.110.0/26"
service_subnet_cidr  = "10.157.110.64/26"
lb_subnet_cidr       = "10.157.110.128/27"
funcapp_subnet_cidr  = "10.157.110.160/27"
bastion_subnet_cidr  = "10.157.111.0/26" # only used if enable_bastion = true
workload_subnet_cidr = "10.157.111.128/25"
ssh_source_cidr      = "10.157.111.0/26" # ignored while enable_bastion = true
enable_bastion       = true

# Bastion is Premium and private-only: no public IP, which Org-Delta refuses. It answers
# only from inside the network - ExpressRoute or VPN from on-premises, or a peered VNet -
# through the Azure CLI native client:
#   az network bastion ssh --name <bastion_name output> --resource-group <rg> `
#     --target-ip-address <connector mgmt IP> --auth-type ssh-key --username zsroot `
#     --ssh-key <private key file>
# This VNet needs that line of sight (peering to the hub) before Bastion is usable.
bastion_sku = "Premium"

# The NAT gateway stays: it is the connectors' and the function's only way out, and its
# address is what the Zscaler portal allowlists. A NAT gateway cannot work without a
# public IP or prefix, and Org-Delta's "Not allowed resource types" refuses
# Microsoft.Network/publicIPAddresses. So, one of:
#   "ip"      - needs the policy exemption for this one public IP (runbook item A5).
#               Nothing else here has one: Bastion is private-only.
#   "prefix"  - a StandardV2 public IP prefix (/31, two addresses; allowlist both), where
#               the platform team allows prefixes but not addresses.
#   nat_gateway_existing_public_ip_id - an IP or prefix the platform team created.
nat_gateway_public_ip_mode = "ip"
# nat_gateway_existing_public_ip_id = "/subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Network/publicIPAddresses/<name>"

# D. Zscaler side - a dev/test provisioning template of dev's own, not prod's or SLZ's
provisioning_url = "<connector provisioning URL>"
zscaler_cloud    = "<e.g. zscalertwo>"

# E. Connector access
# ssh-keygen -t rsa -b 4096 -f zscc_key -N ""   -> paste zscc_key.pub content
ssh_public_key = "<ssh-rsa AAAA...>"

# F. Behavior
# Roles by name - built-in, or custom roles the platform team already defined.
connector_role_names = ["Reader", "Monitoring Metrics Publisher"]
function_role_names  = ["Reader"]

disable_health_remediation = false
accept_marketplace_terms   = false # owner accepted terms at the subscription
notification_email         = []    # e.g. ["ops@example.com"]

# Locks off: dev is rebuilt and experimented on, and a CanNotDelete lock refuses deleting
# anything it covers, by hand as well. Purge protection off so a rebuild can reuse the
# vault name - once on it cannot be turned off, and a soft-deleted vault holds its name
# for 90 days.
enable_resource_locks   = false
enable_purge_protection = false

# G. Leftovers from earlier deployments
# A privatelink zone an earlier run left in the resource group fails the apply with "a
# resource with the ID ... already exists". Listing it here adopts it instead. Set it
# back to [] once adopted: from then on Terraform manages the zone, a destroy deletes
# it, and importing a zone that does not exist fails the plan.
import_existing_private_dns_zones = [] # e.g. ["privatelink.vaultcore.azure.net"]
# If a VNet link in one of those zones is reported the same way, add it too:
# import_existing_private_dns_zone_links = { "privatelink.vaultcore.azure.net" = "<link name from the error>" }

# H. Capacity - one connector, room for two
desired_instances = 1
min_instances     = 1
max_instances     = 2

# I. Optional overrides (defaults shown; uncomment to change)
# vm_size                          = "Standard_D2s_v3"
# http_probe_port                  = 50000
# enable_support_tunnel            = true
# support_server_ip                = "199.168.148.101"  # remotesupport.<cloud>.net on Zscaler's commercial clouds
# encrypt_at_host                  = false
# app_service_plan_sku             = "P0v3"   # must stay Dedicated: storage keys are disabled
# enable_function_private_endpoint = false    # public inbound access is off either way
# scheduled_scaling                = false
# workload_cidrs                   = []
# additional_tags                  = { "cost-centre" = "", "owner" = "" }
