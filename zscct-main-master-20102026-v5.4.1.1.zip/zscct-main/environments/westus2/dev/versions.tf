# Provider versions are pinned once per environment. The modules in this repo are only
# ever used from an environment, so they inherit these rather than repeating them.
terraform {
  # 1.9.3 for import blocks with for_each, and for the removed blocks in the modules,
  # which drop resources from state without destroying them: before 1.9.3 Terraform still
  # refreshes a resource it is only forgetting, and the Key Vault secrets and package blob
  # they cover can only be read through private endpoints.
  required_version = ">= 1.9.3, < 2.0.0"

  required_providers {
    azurerm = {
      source = "hashicorp/azurerm"
      # 4.68 creates a Premium Bastion private-only when it has no public IP (StandardV2
      # NAT gateways, public IPs and prefixes arrived in 4.67). 5.0 removes or renames
      # arguments used here - the scale set NIC flags and the DNS zone link's zone name -
      # so it needs its own upgrade.
      version = ">= 4.68, < 5.0"
    }
    time = {
      source  = "hashicorp/time"
      version = ">= 0.9.0, < 1.0"
    }
    azapi = {
      source  = "Azure/azapi"
      version = ">= 2.0, < 3.0"
    }
  }
}
