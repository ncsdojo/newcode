# Zscaler Cloud Connector on Azure

Terraform for deploying Zscaler Cloud Connectors into Azure, as reusable modules with one
folder per environment.

## What it deploys

Cloud Connectors are Zscaler appliances that sit in your VNet and forward workload traffic
out to the Zscaler cloud. A deployment is:

- **Connectors** in scale sets, one set per availability zone. Each instance has a
  management NIC for administration and a service NIC that carries customer traffic.
  All zones share one management subnet and one service subnet - Azure subnets are
  regional, so a subnet is not tied to a zone.
- **An internal load balancer** in front of them. Workload subnets route their default
  traffic at its address, and it spreads that across whichever connectors are healthy.
- **A NAT gateway**, zone-redundant, giving the connectors a stable public IP to leave
  from. That address is what you allowlist in the Zscaler portal. It is the one public
  resource in the deployment; see [Org-Delta policy](#org-delta-policy).
- **A Key Vault** holding the Zscaler portal credentials the connectors and the lifecycle
  function read. Private from the first apply: public network access off, reachable only
  through its private endpoint.
- **A lifecycle function**, published by Zscaler, that runs on timers. Every 30 minutes
  it deletes connectors the portal still lists but the scale sets no longer hold, and
  every minute it checks connector health and replaces unhealthy instances. Each
  environment needs a Zscaler
  provisioning template of its own, so its function only ever sees its own connectors.
  It runs Zscaler's published package from a commit-pinned URL, takes no inbound
  traffic at all, and sends everything outbound through the VNet and the NAT gateway,
  under an NSG that allows HTTPS, HTTP and DNS only.
- **Private endpoints** for the vault and for the function's storage account (blob,
  queue and table). Both have public network access disabled from creation, so these
  are the only way to them.
- **Azure Bastion**, Premium and private-only: no public IP, reachable only from inside
  the network.
- **Alerts**: fewer than half the connectors passing the load balancer's health probe, the
  lifecycle function has stopped running, it logged an error, or it judged a connector
  unhealthy.

## Layout

```
modules/         building blocks, each one creating a single kind of thing
environments/    one folder per region, then per environment
templates/       starting points for a new environment
```

| Module | What it creates |
| --- | --- |
| `network/vnet` | The virtual network |
| `network/subnets` | The subnets, and the checks on the subnet plan |
| `network/nsg` | The management, service and Function App subnet NSGs, and their subnet associations |
| `network/nat-gateway` | The zone-redundant NAT gateway and its public IP or public IP prefix |
| `network/load-balancer` | The internal load balancer the connectors sit behind |
| `network/route-table` | The route sending workload traffic to the connectors |
| `network/spoke-routes` | The Zscaler VDI routes, added to an existing route table on AVD session-host subnets |
| `network/private-dns` | The privatelink zones (vault, blob, queue, table, sites) and their VNet links |
| `network/bastion` | Azure Bastion, private-only by default, and its subnet's NSG |
| `identity` | The two managed identities and their resource group roles |
| `key-vault` | The vault, the Zscaler credentials (written through Resource Manager), and who can read them |
| `function-app` | The lifecycle function, its private storage and endpoints, and its telemetry |
| `compute` | The connector scale sets, autoscale, and what the function needs to replace a connector |
| `monitoring` | The action group, the load balancer health alert and three log alerts |
| `locks` | CanNotDelete locks |

Environments are grouped by region first, then by environment name. A second region is a
new folder next to `westus2/`, not a new set of modules.

Every environment folder has the same files: `main.tf` wires modules together,
`variables.tf` declares inputs, `terraform.tfvars` sets them, `data.tf` looks up anything
that already exists, `locals.tf` holds shared values, and `providers.tf`, `backend.tf`,
`versions.tf` and `outputs.tf` do what their names suggest.

## dev and prod are built differently on purpose

`dev` creates its own VNet, subnets and DNS zones.

`prod` attaches to ones the platform team already created. Those are data lookups in
`prod/data.tf`, and the three modules that would have built them are simply not called.
Both look up a pre-created resource group.

This is one decision, not several flags. The VNet, subnets and DNS zones come as a set -
either you own them or you do not - so `locals.tf` in each environment resolves them once
at the top, and everything below that point is written the same way in both files.

Two things follow from attaching rather than creating:

- The VNet is left out of the locks. A network you did not create is not yours to lock.
- The NSGs and the NAT gateway attach to the platform's subnets, and only to subnets
  that have none: Terraform stops rather than take over one already attached. Where the
  platform attaches its own, set `attach_nsgs` or `attach_nat_gateway` to false.

## Integrating with an existing platform

prod and slz create nothing the platform team owns. They read it, and the one thing
they write to - routes on the AVD route tables named in `spoke_route_tables` - is
opt-in:

| Existing | How it is used |
| --- | --- |
| Resource group | Looked up; everything is deployed into it |
| VNet and its subnets | Looked up in the deployment subscription, which has to be the VNet's: Azure attaches NICs, private endpoints, NSGs, NAT gateways and route tables only to a VNet in their own subscription |
| `privatelink.vaultcore.azure.net`, `privatelink.blob.core.windows.net`, `privatelink.queue.core.windows.net`, `privatelink.table.core.windows.net` (and `privatelink.azurewebsites.net` with a Function App endpoint) | Looked up through the `dns` provider alias, which can point at a subscription of its own; the private endpoints write their A records into them |
| NSGs and NAT gateway on the connector subnets | Ours attach where the subnets have none. Where the platform attaches its own, `attach_nsgs`, `attach_funcapp_nsg` and `attach_nat_gateway` turn ours off: their NSGs must then allow what `modules/network/nsg` allows, including outbound TCP 80 on the service subnet for certificate revocation checks and outbound TCP 12002 to Zscaler's remote-support server, and their egress address is the one to allowlist in the Zscaler portal |
| Function App subnet | Delegated to `Microsoft.Web/serverFarms`. No storage service endpoint: the function reaches its storage through private endpoints |
| Custom roles | Named in `connector_role_names`, `function_role_names` or `remediation_role_name`, exactly like built-in roles, and assignable at the deployment resource group. `remediation_role_name` is also granted on the subnets while `grant_function_subnet_join` is on, so it has to be assignable at the VNet's resource group as well. This configuration never creates role definitions |
| Bastion subnet | Looked up for its range, which becomes the SSH source. With `enable_bastion`, the Bastion is deployed into it private-only, and its NSG is attached unless `attach_nsgs` is false |
| Workload routing | The platform team's route tables point at the `lb_frontend_ip` output. Only a subnet named in `workload_subnet_name`, such as a temporary validation subnet, gets a route table from this deployment |
| AVD route tables | Left alone unless named in `spoke_route_tables`, which adds the Zscaler VDI routes to them; see [Routing AVD session hosts](#routing-avd-session-hosts-zscaler-client-connector-for-vdi) |

Handing an applied environment's NSGs or NAT gateway over to the platform starts with
`terraform state rm`. Destroying an association empties the subnet of whatever is
attached at the time - the platform's own, if it has already swapped it in - and a policy
that requires an NSG on every subnet refuses an empty one. So remove the associations
from state (`module.nsg[0].azurerm_subnet_network_security_group_association.mgmt` and
`.svc`, or `module.nat_gateway[0].azurerm_subnet_nat_gateway_association.mgmt`,
`.service` and `.funcapp`), let the platform attach its own, then set the flag to false
and apply, which deletes ours. A new NAT gateway means a new egress address to allowlist
in the Zscaler portal.

Grants the platform team makes, because they sit on resources this deployment does not
own, are listed in step 5 below.

Bastion is a straightforward yes or no. `enable_bastion` puts `count` on the module call,
so turning it off means it is not evaluated at all. When on, it is Premium and
private-only (`bastion_sku`): it has no public IP and answers only on its private address,
so operators reach it over ExpressRoute or VPN, or from a peered VNet, with the Azure CLI
native client - `az network bastion ssh --name <bastion> --resource-group <rg>
--target-ip-address <connector management IP> --auth-type ssh-key --username zsroot
--ssh-key <key file>`. Shareable links and file copy are off. A VNet with no private line
of sight from where operators sit cannot use it until that exists.

## Org-Delta policy

The non-production management group assigns the "Organizational Delta Initiative"
(`nonProd Org-Delta`). Three of its policies shape this deployment. It complies with all
three without exemptions, except for the NAT gateway's address.

| Policy | Effect here |
| --- | --- |
| Azure Key Vault should disable public network access | The vault is created private. Terraform writes the secrets through Resource Manager (`Microsoft.KeyVault/vaults/secrets`), which the vault firewall does not cover, so no apply ever needs the vault's own endpoint and there is no `kv_locked` second apply |
| Storage accounts should disable public network access | The function's storage account is created private. Its host reaches blob, queue and table through private endpoints, and the function runs Zscaler's package from a commit-pinned URL rather than a blob Terraform would have to upload, so no apply needs the storage data plane either |
| Not allowed resource types (`Microsoft.Network/publicIPAddresses`) | Bastion is private-only and has no public IP. The NAT gateway cannot work without one - see below |

A NAT gateway needs a public IP or a public IP prefix: it is how the connectors reach the
Zscaler cloud, and its address is what the portal allowlists. It only ever carries
connections that start inside the VNet; nothing can connect in through it. Keeping it
means one of:

- **`nat_gateway_public_ip_mode = "ip"`** (default) with a policy exemption for that one
  public IP - the runbook's A5 item, and the only exemption these three policies call
  for.
- **`nat_gateway_public_ip_mode = "prefix"`**, a StandardV2 public IP prefix (/31 by
  default, so two addresses to allowlist), where the platform team allows prefixes but
  not addresses. Confirm that with them rather than assuming it.
- **`nat_gateway_existing_public_ip_id`**, an IP or prefix the platform team created
  under its own exemption and hands over.

One more Org-Delta check before the first apply: the connectors' service NICs forward
traffic, so IP forwarding is on. Microsoft's landing-zone baseline assigns "Network
interfaces should disable IP forwarding" (`88c0b9da-ce96-4b03-9635-f29a937e2900`) to
deny exactly that. If Org-Delta includes it, no connector can be created until the
deployment resource group is exempted from that one policy. The portal lists what the
initiative holds: Policy, Assignments, the Org-Delta assignment, View definition.

Separately from the policy, Azure wires every new Application Insights component's
Failure Anomalies rule to the subscription's shared smart-detection action group, which
can sit in a resource group the deployer cannot read. Disabling that rule, which the
provider does by default, then fails with `LinkedAuthorizationFailed`, so
`disable_generated_rule` is off in every `providers.tf` and the rule is left alone. The
monitoring module's own alerts are the ones that watch the function.

## Routing AVD session hosts (Zscaler Client Connector for VDI)

Session hosts running Zscaler Client Connector for VDI tunnel their traffic to the
connectors through the load balancer. In point-to-point mode, the client's default, the
tunnel's outer destination is Zscaler's anycast global VIP, `185.46.212.80`, and Zscaler
requires the session hosts' route for the global VIP to point at the load balancer.
Without it, traffic for that address follows the subnet's default route out to Zscaler's
public cloud instead of reaching the connectors. The client's `SERVERIP` install option
can name the load balancer, a connector's service address, an FQDN or the global VIP;
Zscaler documents it as optional where the global VIP or the default route is routed to
the connectors.

Each AVD session-host subnet's route table needs:

| Route | Prefix | Next hop | When |
| --- | --- | --- | --- |
| `zscaler-vdi-gvip` | `185.46.212.80/32` | Virtual appliance, `lb_frontend_ip` | Always |
| `default-to-zscc` | `0.0.0.0/0` | Virtual appliance, `lb_frontend_ip` | Only where all of the hosts' traffic should go through the connectors, or the client runs in A2A tunnel mode, which needs it |

Two ways to add them:

- **From this deployment.** Name the tables in `spoke_route_tables` and the
  `network/spoke-routes` module adds the routes to them through the `spoke` provider
  alias. Set `spoke_subscription_id` where the tables live in another subscription.
  Whoever runs Terraform needs Network Contributor on each table, or a custom role with
  `Microsoft.Network/routeTables/routes/*`; the platform team grants it.
- **By the platform team**, by hand or by calling `modules/network/spoke-routes` from
  their own code with the `lb_frontend_ip` output.

Two things break the client even with the routes in place:

- **A firewall that sees one direction only.** The connectors answer the session hosts
  straight back over peering. If the spoke's route table sends the hub's range, and with
  it the load balancer frontend, through a firewall, that firewall sees the requests but
  never the replies: TCP connects and then TLS fails. Route only the prefixes that need
  inspecting through the firewall, or send the service subnet's return traffic through
  the same firewall.
- **Per-flow load balancing.** Zscaler recommends client IP (2-tuple) persistence on a
  load balancer in front of the connectors. In point-to-point mode the tunnel copies each
  inner flow's source port into its own header, so the default 5-tuple hash can spread
  one session host's tunnel across connectors as soon as there is more than one.
  `modules/network/load-balancer` sets SourceIP (`load_distribution = "SourceIP"`).

Endpoints the forwarding policy sends DIRECT rather than to ZIA leave the connectors on
their own ports. The service NSG allows the three non-443 ones Azure Virtual Desktop
needs - TCP 80 for certificate checks, TCP 1688 for Windows activation and UDP 3478 for
relayed RDP. Where the platform team attaches its own NSG to the service subnet, it needs
the same.

## Order of operations

The VNet comes first, then the subnets, and then everything that attaches to a subnet -
NSGs, the NAT gateway, Bastion, and the load balancer. The route table comes after the
load balancer because it points at its address.

Separately, the identities come before the Key Vault, which comes before the function app
and the connectors, because both read credentials from the vault.

The connectors also wait for the vault's DNS zone link, the NAT gateway, the NSGs and the
load balancer's rule and probe. Each connector reads its credentials through the vault's
private endpoint the moment it boots, so the first connector proves exactly the path
every later one - a scale-out, or the function's replacement for an unhealthy one -
depends on. The function app waits for its storage's private endpoints and zone links,
the NAT gateway and its subnet's NSG.

Locks are created last so that on a destroy they are removed first.

## Running it

```bash
cd environments/westus2/prod
```

1. Fill in the placeholders in `terraform.tfvars` and `backend.tf`. State goes to the
   platform team's storage account, never the local backend: it holds the Zscaler
   credentials in plain text. An environment first applied on the local backend moves
   across with `terraform init -migrate-state`; the comment in its `backend.tf` has the
   steps, including deleting the local state files afterwards.
2. Export the Zscaler credentials. They must never go in a tfvars file:

```bash
export TF_VAR_zscaler_api_key="<portal api key>"
export TF_VAR_zscaler_username="<portal admin>"
export TF_VAR_zscaler_password="<portal password>"
```

3. Apply once. The vault and the function's storage are private from the start and the
   apply never touches their data planes, so it runs from anywhere - there is no
   deployer IP to allowlist and no second, locking apply. Terraform 1.9.3 or later.

```bash
terraform init && terraform apply
```

   If the apply stops on `a resource with the ID ... privateDnsZones/... already exists`,
   an earlier deployment left that zone in the resource group: add its name to
   `import_existing_private_dns_zones` (dev and greenfield) and apply again, and it is
   adopted rather than recreated. Empty the list again after that apply; once the zone
   is Terraform's, a destroy deletes it and a leftover import entry would fail the next
   plan.

4. Check Application Insights for the function's first executions: `healthMonitor` runs
   every minute and `synchronizeCloudResources` every 30. The app needs no separate
   trigger sync: Microsoft accepts a restart as one, because the host syncs its triggers
   after it starts, and on this Dedicated plan Always On starts the host without being
   asked. If nothing executes within a few minutes, restart the app, and check that it
   can reach its package. The platform fetches it from `raw.githubusercontent.com`
   every time the app starts, over its own route rather than the app's VNet
   integration. To run from a copy you hold instead, publish it at an https URL the
   platform can reach and set `function_package_url` to it; a storage account with public
   network access disabled cannot serve it, because that fetch arrives from outside the
   network.
5. The function replaces an unhealthy connector by deleting it and writing the scale set
   back at its old capacity. The scale sets use Flexible orchestration, so every
   connector is a VM of its own, with its own NICs and disk, in the deployment resource
   group, and Microsoft lists VM write and network rights, not just the scale set write,
   as what Flexible orchestration needs. So the function identity (the
   `funcapp_principal_id` output) holds the remediation role on the resource group,
   which also covers the load balancer's backend pool and, in dev and greenfield, the
   subnets; join rights on the management and service subnets where the VNet is in
   another resource group; and assign rights on the connector identity. The apply makes
   all of these itself, so nothing is left to do after it. Without them an unhealthy
   connector either stays in the backend pool failing the health probe, or is removed
   and not replaced, and the scale set falls to its autoscale floor.

   The remediation role is Virtual Machine Contributor by default. On a resource group
   that also lets the function run commands on any VM in it, delete the scale sets and
   list storage account keys. Where that is too wide, the platform team defines a custom
   role with exactly the actions listed in the `remediation_role_name` description,
   assignable at the deployment resource group and, in prod and slz, at the VNet's
   resource group too, and you name it there.

   The subnet grant is behind `grant_function_subnet_join`, true in prod and slz by
   default: the subnets are the platform team's, so whoever runs Terraform needs Role
   Based Access Control Administrator on the VNet's resource group (or the two subnets)
   before the first apply. Only where the platform team will not give that, set it false
   and they grant `Microsoft.Network/virtualNetworks/subnets/join/action` on both subnets
   themselves (Virtual Machine Contributor or Network Contributor).

   Test a replacement in dev, and in slz before prod: stop one connector VM and watch the
   function's traces. Five missed one-minute health samples make it unhealthy, so within
   about ten minutes the function deletes it and writes the scale set back; the new
   connector joins the backend pool on its own and passes the probe once it has booted
   and registered. `AuthorizationFailed` or `LinkedAuthorizationFailed` in the traces
   names whatever grant is still missing.
6. Commit the `.terraform.lock.hcl` that `init` wrote, so every apply resolves the same
   provider builds.

The identity running Terraform needs, on the resource group: Contributor (which carries
`Microsoft.KeyVault/vaults/secrets/write`, the Resource Manager path the secrets are
written through), Role Based Access Control Administrator, and
`Microsoft.Authorization/locks/*` for the locks - neither of the first two carries it, so
that means a custom role or User Access Administrator. Set `enable_resource_locks = false`
where that cannot be granted.

Where purge protection is off, as in dev and slz, the destroy also purges the vault so a
rebuild can reuse its name. Azure treats a deleted vault as belonging to the
subscription, so that takes `Microsoft.KeyVault/locations/deletedVaults/purge/action`
and `Microsoft.KeyVault/locations/operationResults/read` at the subscription. Without
them the destroy fails at the vault after deleting it; running it again finishes the
job, and the name stays reserved for 90 days.

### Upgrading an environment applied with the earlier code

- Delete `kv_locked` and `storage_deployer_ip_rules` from your filled-in tfvars, and add
  the new settings (`bastion_sku`, `nat_gateway_public_ip_mode`, and in prod and slz
  `attach_funcapp_nsg` and `grant_function_subnet_join`). Terraform 1.9.3 or later.
- The Key Vault secrets are written through Resource Manager. `removed` blocks let
  Terraform forget the old data-plane secret resources without deleting them, and the
  first apply writes a new version of each.
- prod and slz need `privatelink.queue.core.windows.net` and
  `privatelink.table.core.windows.net` in the hub, linked to the VNet, before the plan
  will run.
- A Standard Bastion with a public IP is replaced by the private-only one; Azure cannot
  convert in place.
- The function's remediation role moves from each scale set to the resource group: the
  plan deletes the per-scale-set grants and creates one on the group.
- The earlier README had you grant the function Managed Identity Operator on the
  connector identity by hand. The apply now makes that same grant, and Azure refuses a
  duplicate with `RoleAssignmentExists`, so if you made it, import it first:

  ```bash
  id=$(az role assignment list --assignee <funcapp principal id> \
    --role "Managed Identity Operator" --scope <connector identity id> --query "[0].id" -o tsv)
  terraform import 'module.compute.azurerm_role_assignment.replacement_identity[0]' "$id"
  ```

  Virtual Machine Contributor on the load balancer, the other grant that README asked
  for, is covered by the resource group grant now. Network Contributor on the subnets is
  covered too: by the resource group grant in dev and greenfield, and in prod and slz by
  the subnet grant while `grant_function_subnet_join` is true, where removing it is the
  platform team's job. Remove these once a replacement test passes; the ones under a
  lock need the locks off first.
- Where the earlier code uploaded the package blob, Terraform forgets the blob and its
  container without reading them back or deleting them; they go with the storage
  account. The deployer's blob role on the account is deleted.
- The deployer's Key Vault Secrets Officer grant on the vault is forgotten rather than
  deleted, so nothing is deleted under a vault lock. Nothing needs it; if no standing
  data-plane write role should be left, remove it by hand:
  `az role assignment delete --assignee <deployer object id> --role "Key Vault Secrets Officer" --scope <vault id>`.

## Removing a deployment

```bash
terraform destroy
```

One destroy removes everything this configuration created. The locks go first, the
provider waits for each removal to replicate, and then the rest is deleted: connectors,
function, storage, vault (and the secrets with it), private endpoints and their DNS
records, alerts, role assignments, and the NSG, NAT gateway and route table associations
on the platform's subnets, which are left as they were handed over. If a delete still
reports `ScopeLocked`, run the destroy again.

To remove only the locks, set `enable_resource_locks = false` and apply. Do the same
before a change that replaces a locked resource or deletes something inside one, such
as a load balancer rule or a role assignment on the vault; the lock refuses both.

Run it with the same permissions as the apply. It runs from anywhere.

What a destroy cannot take back:

- **The Key Vault, where purge protection is on** (prod). It stays soft-deleted for 90
  days, and until Azure purges it only recovering it frees the name - which the next
  apply does if its identity can read deleted vaults at the subscription. Purge
  protection cannot be turned off once on; dev and slz leave it off so they can be
  rebuilt.
- **The `Failure Anomalies` smart detector rule and the `Application Insights Smart
  Detection` action group.** Azure creates the rule with Application Insights and wires
  it to an action group shared across the subscription - in the sandbox, one in another
  team's resource group - so neither is this configuration's to delete. Delete the rule
  by hand if it is left behind.
- **Grants made outside Terraform**, such as the subnet join in step 5 where the
  platform team made it. The platform team removes them.
- **Connector entries in the Zscaler portal.** The function that would clean them up is
  deleted with everything else, so remove the Cloud Connector group's entries in the
  portal.
- **Marketplace terms**, if this configuration accepted them (`accept_marketplace_terms =
  true`). Destroy cancels them for the whole subscription, so leave that false wherever
  another deployment shares the subscription.

## Provider versions

Terraform is held to `>= 1.9.3`, for the `import` blocks with `for_each` that adopt
leftover DNS zones and the `removed` blocks that let go of resources the earlier code
managed. Before 1.9.3 Terraform still refreshes a resource it is only forgetting, and
the old Key Vault secrets and package blob can only be read through private endpoints.

azurerm is held to `>= 4.68, < 5.0`, azapi to 2.x and time to 0.x. 4.68 is the first
release that creates a Premium Bastion private-only when it has no public IP; StandardV2
NAT gateways, public IPs and public IP prefixes arrived in 4.67. Validation and the
mocked plan tests ran against 4.81. 5.0 removes or renames arguments these modules use,
so moving to it is its own change:

- `network_interface.enable_accelerated_networking` and `enable_ip_forwarding` on the
  scale set become `accelerated_networking_enabled` and `ip_forwarding_enabled`.
- `private_dns_zone_name` and `resource_group_name` on
  `azurerm_private_dns_zone_virtual_network_link` become `private_dns_zone_id`.

## Why there are five subnets, not nine

Zscaler's reference modules create a management and a service subnet per zone, plus a NAT
gateway per zone. The split exists for one reason: a subnet can only be associated with a
single NAT gateway, so per-zone subnets were the only way to get per-zone egress that
survives losing a zone.

Two things make that unnecessary here:

- **Azure subnets are regional.** One subnet already serves instances in every zone.
- **A StandardV2 NAT gateway is zone-redundant on its own.** One gateway spans the
  region and survives a zone failure, so the subnets do not have to be split to achieve it.

So the layout is one management subnet, one service subnet, one load balancer subnet, one
Function App subnet, and `AzureBastionSubnet`: one NSG pair for the connectors (plus one
each on the Function App and Bastion subnets), and one egress address to allowlist.

Zscaler's own `base_cc_vmss` example goes further and passes the *same* subnet to both
the management and service NICs. Keeping them separate here is a deliberate choice, so
the SSH rules and the data-path rules stay on different NSGs.

The two connector subnets are held to `/26` by the plan validator, since each has to hold
one NIC per instance across every zone.
